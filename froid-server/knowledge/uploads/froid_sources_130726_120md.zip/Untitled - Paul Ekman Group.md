# Untitled - Paul Ekman Group

https://www.paulekman.com/wp-content/uploads/2013/07/Classifying-Facial-Action.pdf

