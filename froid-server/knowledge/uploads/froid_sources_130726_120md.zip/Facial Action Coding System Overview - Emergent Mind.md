# Facial Action Coding System Overview - Emergent Mind

https://www.emergentmind.com/topics/facial-action-coding-system-facs

Facial Action Coding System Overview

https://www.emergentmind.com/

https://www.emergentmind.com/

https://www.emergentmind.com/videos

Whiteboards

https://www.emergentmind.com/whiteboards

Open Problems

https://www.emergentmind.com/open-problems

Email Digest

https://www.emergentmind.com/subscribe

https://www.emergentmind.com/labs

https://www.emergentmind.com/pricing?utm\_source=nav

https://updates.emergentmind.com/

https://www.emergentmind.com/users/sign\_in

https://www.emergentmind.com/users/sign\_up?redirect\_to=https%3A%2F%2Fwww.emergentmind.com%2Ftopics%2Ffacial-action-coding-system-facs

Research Explorer

https://www.emergentmind.com/

https://www.emergentmind.com/videos

Whiteboards

https://www.emergentmind.com/whiteboards

Open Problems

https://www.emergentmind.com/open-problems

Email Digest

https://www.emergentmind.com/subscribe

Pixel Art Generator

https://www.emergentmind.com/pixel-art

All Projects

https://www.emergentmind.com/labs

https://www.emergentmind.com/pricing?utm\_source=nav

https://www.emergentmind.com/users/sign\_in

https://www.emergentmind.com/users/sign\_up?redirect\_to=https%3A%2F%2Fwww.emergentmind.com%2Ftopics%2Ffacial-action-coding-system-facs

Discord Discord Logo Streamline Icon: https://streamlinehq.com

https://discord.gg/BhfTC4mTXq

Facial Action Coding System (FACS)

https://www.emergentmind.com/history

Search by paper, topic, or author

Succinct overviews based on relevant paper abstracts

Deep Research Max

In-depth responses based on relevant abstracts and paper content

2000 character limit reached

Chrome Extension

Install our Chrome Extension

https://chromewebstore.google.com/detail/emergent-mind-%E2%80%94-arxiv-int/hgmnadjffdiipehljmhagdgpaoiiklml

to automatically enhance arXiv.

Promote your business

https://www.emergentmind.com/sponsorship

to millions of monthly visitors.

Facial Action Coding System Overview

Updated 21 February 2026

Facial Action Coding System (FACS) is a muscle-based framework that quantifies human facial movements into discrete Action Units, facilitating objective expression analysis.

It supports applications across affective computing, clinical diagnostics, and 3D facial animation by mapping specific muscle activations to observable facial changes.

Recent advancements in machine learning and computer vision have enhanced FACS with data-driven models that improve scalability and capture nuanced, co-articulated expressions.

The Facial Action Coding System (FACS) is the primary anatomical and behavioral framework for decomposing and quantifying all visible human facial movements. Developed to provide an objective, muscle-based encoding of facial expressions, FACS systematically maps facial appearance changes to a set of discrete "Action Units" (

https://www.emergentmind.com/topics/facial-action-units-aus

), each corresponding to the contraction of underlying facial muscles or muscle groups. FACS—and its Action Unit taxonomy—provides a universal foundation for automatic expression recognition, clinical evaluation, affective computing, and multi-modal human behavior analysis. While FACS remains foundational, advances in machine learning and computer vision have revealed important structural limitations, motivating new data-driven approaches that inherit FACS's locality, interpretability, and compositionality while achieving superior coverage and analytical scalability.

1. Structure and Purpose of FACS

FACS defines 44 Action Units (AUs), of which approximately 30 are under voluntary muscular control. Each AU codes for the contraction of one or more anatomically-defined muscles, leading to specific, observable facial deformations. For example, AU1 ("Inner Brow Raiser") corresponds to the frontalis, pars medialis; AU12 ("Lip Corner Puller") to the zygomaticus major; AU4 ("Brow Lowerer") to corrugator supercilii and procerus. The AU set is intended to be compositional: any facial expression, including complex blends, can be represented as a combination (simultaneous or sequential) of AU activations, each possibly graded in intensity (traditionally on a five-point scale, A–E, or numerically as in recent datasets).

#### AUs can be coded at the levels of:

Occurrence (presence/absence)

Intensity (ordinal or continuous)

Temporal phase (onset, apex, offset, neutral) (

Chen et al., 2018

https://www.emergentmind.com/papers/1811.07988

Yan et al., 2019

https://www.emergentmind.com/papers/1904.01509

This structural foundation enables FACS to exhaustively represent visible facial behavior across contexts, individuals, and cultures.

2. Annotation Protocols and Dataset Standards

Manual FACS coding is highly demanding, requiring months of expert training and exhibiting substantial inter-rater variability, especially for rare or subtle AUs. Coders annotate video sequences frame-by-frame or at critical moments (apex), using either the original A–E ordinal scale or, in enriched corpora such as FEAFA, continuous \[

https://www.emergentmind.com/topics/l-p-regularization-for-p-in-0-1

\] values for each AU and Action Descriptor (AD) (

Yan et al., 2019

https://www.emergentmind.com/papers/1904.01509

). FEAFA, for example, subdivides symmetrical AUs into left/right instances, and augments the AU set with symmetrical and asymmetrical ADs, supporting fine-grained, float-valued annotation protocols ideally suited for quantitative analysis and for driving 3D facial animation via blendshapes.

AU Annotation

Number of Frames

44 AUs, A–E

12 AUs, 0–5

Float \[0,1\]

27 AUs, 0–5

Current public corpora vary in AU coverage, intensity resolution, and inter-coder protocol. The continuous-valued FEAFA standard—enabled via interactive 3D blendshape annotation—captures AU co-articulation and subtle gradations not possible in the traditional system (

Yan et al., 2019

https://www.emergentmind.com/papers/1904.01509

3. Computational and Automated FACS Pipelines

Traditional manual annotation is both costly and limited in scalability; as a result, computer vision and machine learning methods aim to automatically extract AUs (and often their intensities) from video data. Early methods rely on geometric landmark tracking, Gabor wavelet filtering, local appearance features (e.g., LBP, HOG), or

optical flow

https://www.emergentmind.com/topics/optical-flow-raft

. These features are then fused using classifiers such as SVMs, HMMs, or (more recently)

https://www.emergentmind.com/topics/deep-1d-convolutional-neural-networks-cnns

https://www.emergentmind.com/topics/long-short-term-memory-units-lstms

. Systems such as OpenFace provide robust, multi-AU continuous regression pipelines, leveraging a combination of landmark detection, facial alignment, and per-AU regressors (

Ahmed et al., 2021

https://www.emergentmind.com/papers/2105.13659

Geoffroy et al., 13 Dec 2025

https://www.emergentmind.com/papers/2512.12277

Zeng et al., 2021

https://www.emergentmind.com/papers/2111.06517

Recent deep learning approaches operate end-to-end, unifying appearance and motion information, and treat AU recognition as multi-label classification or regression. Architectures include:

https://www.emergentmind.com/topics/3d-convolutional-neural-network-cnn-backbone

feature extractors for static or framewise features (

Breuer et al., 2017

https://www.emergentmind.com/papers/1705.01842

Region-based learning and attention modules for muscle-specific focus (

Ge et al., 2024

https://www.emergentmind.com/papers/2408.00644

Multi-modal pipelines incorporating facial, audio, and contextual cues (

Wang et al., 2022

https://www.emergentmind.com/papers/2203.13301

Masur et al., 2023

https://www.emergentmind.com/papers/2311.11980

Sequence models (LSTM, CRF) for temporal dynamics and micro-expressions (

Ahmed et al., 2021

https://www.emergentmind.com/papers/2105.13659

Khademi et al., 2010

https://www.emergentmind.com/papers/1004.0515

Davison et al., 2016

https://www.emergentmind.com/papers/1612.05038

https://www.emergentmind.com/topics/hg-tnet-hybrid

fusion of AU and deep features for continual learning and adaptive recognition (

Geoffroy et al., 13 Dec 2025

https://www.emergentmind.com/papers/2512.12277

Optimization objectives typically include weighted multi-label cross-entropy for AU occurrence, ordinal or

https://www.emergentmind.com/topics/weighted-mean-square-error-mse-fusion-method

loss for intensity, and auxiliary reconstruction or language losses for interpretability and explanation (

Ge et al., 2024

https://www.emergentmind.com/papers/2408.00644

Recent work has further integrated

3D morphable models

https://www.emergentmind.com/topics/3d-morphable-models

https://www.emergentmind.com/topics/3d-morphable-model-3dmm

), residual vector quantization, and unsupervised dictionary learning to define new, additive bases that generalize the AU concept while retaining the interpretability and locality of the original FACS (

Sariyanidi et al., 30 May 2025

https://www.emergentmind.com/papers/2505.24679

Tran et al., 2 Oct 2025

https://www.emergentmind.com/papers/2510.01662

Tripathi et al., 2024

https://www.emergentmind.com/papers/2406.09017

4. Applications and Impact Domains

FACS-based representations, and their automated extracts, are used extensively in:

Affective computing: emotion recognition, stress and depression assessment, clinical diagnostics (

Tran et al., 2 Oct 2025

https://www.emergentmind.com/papers/2510.01662

Geoffroy et al., 13 Dec 2025

https://www.emergentmind.com/papers/2512.12277

Masur et al., 2023

https://www.emergentmind.com/papers/2311.11980

Human-computer interaction: adaptive user interfaces, social gaming, behavioral monitoring (

Breuer et al., 2017

https://www.emergentmind.com/papers/1705.01842

Geoffroy et al., 13 Dec 2025

https://www.emergentmind.com/papers/2512.12277

Deception and micro-expression analysis: detailed time-resolved quantification of fleeting facial cues (

Ahmed et al., 2021

https://www.emergentmind.com/papers/2105.13659

Davison et al., 2016

https://www.emergentmind.com/papers/1612.05038

Pain detection: automated, objective scoring of acute and chronic pain in noncommunicative patients via pain-prototypical AU combinations (e.g., Prkachin–Solomon PSPI) (

Chen et al., 2018

https://www.emergentmind.com/papers/1811.07988

Biomechanical and graphics modeling: mapping FACS AUs to muscle activations for anatomically plausible 3D face simulation and animation (

Zeng et al., 2021

https://www.emergentmind.com/papers/2111.06517

Yan et al., 2019

https://www.emergentmind.com/papers/1904.01509

Performance evaluation standards draw on per-AU recognition rate, F1/ROC-AUC, pain metrics (PSPI), or task-specific regression (e.g., RMSE, CCC), with domain-specific downstream measures (e.g., autism classification accuracy, micro-expression retrieval scores).

5. Structural Limitations and Data-Driven Alternatives

#### Despite its centrality, FACS exhibits foundational limitations:

Limited AU set: automated detectors (e.g., OpenFace) typically cover only a restricted subset (e.g., 17–19 of ≈30 main AUs).

Non-additivity: physical AU combinations may yield emergent features (wrinkle patterns, occlusion) not explainable by simple superposition; detection accuracy drops for co-articulated expressions (

Sariyanidi et al., 30 May 2025

https://www.emergentmind.com/papers/2505.24679

Annotation reliance: supervised training for AU detectors depends on frame-wise, expert-coded ground truth, constraining data scale and domain coverage.

Inter-rater and base-rate variance: rare or subtle AUs are coded inconsistently, undermining statistical power.

To overcome these challenges, multiple research groups have introduced unsupervised, data-driven representation frameworks:

Facial Basis: A localized, additive, and unsupervised dictionary of facial movement components learned via sparse coding on 3DMM coefficients, which generalizes FACS by reconstructing all observed movement and supporting hemiface and noncanonical blends (

Sariyanidi et al., 30 May 2025

https://www.emergentmind.com/papers/2505.24679

Discrete Facial Encoding

https://www.emergentmind.com/topics/discrete-facial-encoding-dfe

(DFE): Compositional, codebook-driven modeling of facial deformations learned from 3D meshes using RVQ-VAE; the resulting tokens are more diverse, additive, and cover a vastly larger expression space than FACS AUs, achieving superior downstream behavioral prediction (

Tran et al., 2 Oct 2025

https://www.emergentmind.com/papers/2510.01662

https://www.emergentmind.com/topics/robust-principal-component-analysis-pca

AUs: Principal components of landmark displacements, explaining >92% variance across datasets; these bases partially overlap but do not coincide exactly with FACS AUs, suggesting a degree of universality unattainable via manual coding (

Tripathi et al., 2024

https://www.emergentmind.com/papers/2406.09017

These approaches regularly outperform standard AU pipelines in predictive power for clinical, psychological, and affective tasks, and bypass the manual annotation bottleneck.

6. Interpretability, Explainability, and Next-Generation Systems

Interpretable, communicative systems are a growing priority. FACS—by construction—permits explicit mapping of facial changes to muscle actions. Recent neural approaches further embed semantic interpretability by integrating vision-language modules: architectures such as VL-FAU jointly optimize AU detection and natural language description, yielding both superior discrimination and human-readable explanations at global (expression) and local (AU, muscle) levels (

Ge et al., 2024

https://www.emergentmind.com/papers/2408.00644

). Language-regularized systems improve intra-AU consistency and inter-AU distinctiveness, facilitating trust and diagnostic transparency in real-world applications.

In physically-based graphics, FACS acts as an intermediate latent between image evidence and biomechanical simulation: neural networks are trained to map AU vectors to high-dimensional muscle-jaw activation signals, yielding anatomically consistent deformation of 3D face models without manual rigging or retargeting (

Zeng et al., 2021

https://www.emergentmind.com/papers/2111.06517

7. Future Directions and Open Challenges

#### Research trajectories include:

Construction of universal, open-source action-unit dictionaries learned on massive, diverse video corpora, capturing rare, asymmetric, and culturally-specific expressions (

Sariyanidi et al., 30 May 2025

https://www.emergentmind.com/papers/2505.24679

Tran et al., 2 Oct 2025

https://www.emergentmind.com/papers/2510.01662

Hybrid frameworks fusing data-driven bases with hand-crafted AUs, supporting both complete movement coverage and backward compatibility with legacy psychological frameworks.

Improvement of AU-to-muscle and AU-to-expression mapping via biomechanical priors, 3D-aware annotation, and transfer learning across cultures, clinical populations, and recording resolutions (

Zeng et al., 2021

https://www.emergentmind.com/papers/2111.06517

Tripathi et al., 2024

https://www.emergentmind.com/papers/2406.09017

Integration of AU-based systems with multimodal feature streams—incorporating voice, body, physiological signals—for a holistic representation of affect (

Geoffroy et al., 13 Dec 2025

https://www.emergentmind.com/papers/2512.12277

Masur et al., 2023

https://www.emergentmind.com/papers/2311.11980

Expansion of explainable, language-grounded recognizers and robust continual learning systems, enabling adaptive, privacy-preserving, and transparent facial behavior analysis at scale.

These directions aim to preserve the fundamental scientific virtues of FACS—locality, interpretability, modularity—while elevating scalability, coverage, and analytic rigor in computational and psychological studies of human facial expression.

https://www.emergentmind.com/users/sign\_up?redirect\_to=https%3A%2F%2Fwww.emergentmind.com%2Farticles%2Ffacial-action-coding-system-facs

Report Issue

https://www.emergentmind.com/users/sign\_up?redirect\_to=https%3A%2F%2Fwww.emergentmind.com%2Farticles%2Ffacial-action-coding-system-facs

Upgrade to Chat

https://www.emergentmind.com/pricing?utm\_source=chat-button

Definition Search Book Streamline Icon: https://streamlinehq.com

References (14)

Automated Pain Detection from Facial Expressions using FACS: A Review

https://www.emergentmind.com/papers/1811.07988

FEAFA: A Well-Annotated Dataset for Facial Expression Analysis and 3D Facial Animation

https://www.emergentmind.com/papers/1904.01509

Deception Detection in Videos using the Facial Action Coding System

https://www.emergentmind.com/papers/2105.13659

Feature Aggregation for Efficient Continual Learning of Complex Facial Expressions

https://www.emergentmind.com/papers/2512.12277

Neuromuscular Control of the Face-Head-Neck Biomechanical Complex With Learning-Based Expression Transfer From Images and Videos

https://www.emergentmind.com/papers/2111.06517

A Deep Learning Perspective on the Origin of Facial Expressions

https://www.emergentmind.com/papers/1705.01842

Towards End-to-End Explainable Facial Action Unit Recognition via Vision-Language Joint Learning

https://www.emergentmind.com/papers/2408.00644

Multi-modal Multi-label Facial Action Unit Detection with Transformer

https://www.emergentmind.com/papers/2203.13301

Leveraging Previous Facial Action Units Knowledge for Emotion Recognition on Faces

https://www.emergentmind.com/papers/2311.11980

Recognizing Combinations of Facial Action Units with Different Intensity Using a Mixture of Hidden Markov Models and Neural Network

https://www.emergentmind.com/papers/1004.0515

Objective Micro-Facial Movement Detection Using FACS-Based Regions and Baseline Evaluation

https://www.emergentmind.com/papers/1612.05038

Beyond FACS: Data-driven Facial Expression Dictionaries, with Application to Predicting Autism

https://www.emergentmind.com/papers/2505.24679

Discrete Facial Encoding: : A Framework for Data-driven Facial Display Discovery

https://www.emergentmind.com/papers/2510.01662

A PCA based Keypoint Tracking Approach to Automated Facial Expressions Encoding

https://www.emergentmind.com/papers/2406.09017

Manage your marketing, customers, and checkout flow with Squarespace.

https://srv.carbonads.net/ads/click/x/GTND427UCWBDP2JWC6B4YKQUCABIE5QNFTBI5Z3JCASIP27NF67DC53KFTSI523MCWSD4537CTBIP2QWCE7I6Z3JCASIP23NF6SDTK3K2JWNABY

ads via Carbon

http://carbonads.net/?utm\_source=wwwemergentmindcom&utm\_medium=ad\_via\_link&utm\_campaign=in\_unit&utm\_term=carbon

Topic to Video (Beta)

No one has generated a video about this topic yet.

Sign Up to Generate

https://www.emergentmind.com/users/sign\_up?redirect\_to=https%3A%2F%2Fwww.emergentmind.com%2Farticles%2Ffacial-action-coding-system-facs

https://www.emergentmind.com/videos

Subscribe on YouTube

https://www.youtube.com/@EmergentMindAI?sub\_confirmation=1

No one has generated a whiteboard explanation for this topic yet.

Sign Up to Generate

https://www.emergentmind.com/users/sign\_up?redirect\_to=https%3A%2F%2Fwww.emergentmind.com%2Farticles%2Ffacial-action-coding-system-facs

Follow Topic

Get notified by email when new papers are published related to

Facial Action Coding System (FACS)

Sign Up to Follow Topic by Email

https://www.emergentmind.com/users/sign\_up?redirect\_to=%2Ftopics%2Ffacial-action-coding-system-facs

Continue Learning

How does FACS decompose complex facial expressions into individual Action Units?

https://www.emergentmind.com/search?q=In+the+context+of+Facial+Action+Coding+System+%28FACS%29%2C+how+does+FACS+decompose+complex+facial+expressions+into+individual+Action+Units%3F&search\_mode=research

What are the challenges associated with manual FACS annotation and inter-rater variability?

https://www.emergentmind.com/search?q=In+the+context+of+Facial+Action+Coding+System+%28FACS%29%2C+what+are+the+challenges+associated+with+manual+FACS+annotation+and+inter-rater+variability%3F&search\_mode=research

How have deep learning techniques advanced automated FACS pipelines for facial expression recognition?

https://www.emergentmind.com/search?q=In+the+context+of+Facial+Action+Coding+System+%28FACS%29%2C+how+have+deep+learning+techniques+advanced+automated+FACS+pipelines+for+facial+expression+recognition%3F&search\_mode=research

What are the limitations of FACS and how are data-driven approaches addressing these issues?

https://www.emergentmind.com/search?q=In+the+context+of+Facial+Action+Coding+System+%28FACS%29%2C+what+are+the+limitations+of+FACS+and+how+are+data-driven+approaches+addressing+these+issues%3F&search\_mode=research

Find recent papers about automated facial expression recognition.

https://www.emergentmind.com/search?q=Find+recent+papers+about+automated+facial+expression+recognition.&search\_mode=search

Related Topics

Discrete Facial Encoding (DFE) Overview

https://www.emergentmind.com/topics/discrete-facial-encoding-dfe

Facial Expression Analysis Systems

https://www.emergentmind.com/topics/facial-expression-analysis-systems

Micro-Expression Recognition (MER)

https://www.emergentmind.com/topics/micro-expression-recognition-mer

Facial Scoring Mechanisms Overview

https://www.emergentmind.com/topics/facial-scoring-mechanism

Video-Based Facial Sequence Analysis

https://www.emergentmind.com/topics/video-based-facial-sequence-analysis

Continuous Micro-Expression Intensity Estimation

https://www.emergentmind.com/topics/continuous-micro-expression-intensity-estimation

Facial Action Units (AUs) Analysis

https://www.emergentmind.com/topics/facial-action-units-aus

Facial Expression Transition Model

https://www.emergentmind.com/topics/facial-expression-transition-model

AI Facial Emotion Recognition System

https://www.emergentmind.com/topics/ai-based-facial-emotion-recognition-system

Streamlined Facial Data Collection Method

https://www.emergentmind.com/topics/streamlined-facial-data-collection-method

https://www.emergentmind.com/topics/facial-action-coding-system-facs#topic-content

https://www.emergentmind.com/topics/facial-action-coding-system-facs#references

Topic to Video

https://www.emergentmind.com/topics/facial-action-coding-system-facs#video

https://www.emergentmind.com/topics/facial-action-coding-system-facs#whiteboard

Follow Topic

https://www.emergentmind.com/topics/facial-action-coding-system-facs#follow-topic

Continue Learning

https://www.emergentmind.com/topics/facial-action-coding-system-facs#continue-learning

Related Topics

https://www.emergentmind.com/topics/facial-action-coding-system-facs#related-topics-facial-action-coding-system-facs

#### Stay informed about trending AI papers:

https://www.emergentmind.com/about

https://updates.emergentmind.com/

Chrome Extension

https://chromewebstore.google.com/detail/emergent-mind-%E2%80%94-arxiv-int/hgmnadjffdiipehljmhagdgpaoiiklml

Sponsorship

https://www.emergentmind.com/sponsorship

https://www.emergentmind.com/feeds/rss

https://www.emergentmind.com/terms

https://www.emergentmind.com/privacy

https://www.emergentmind.com/contact

https://twitter.com/EmergentMind

https://discord.gg/BhfTC4mTXq

