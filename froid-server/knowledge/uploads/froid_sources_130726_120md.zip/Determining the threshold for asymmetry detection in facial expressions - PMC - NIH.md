# Determining the threshold for asymmetry detection in facial expressions - PMC - NIH

https://pmc.ncbi.nlm.nih.gov/articles/PMC4392713/

Checking your browser - reCAPTCHA

Checking your browser before accessing pmc.ncbi.nlm.nih.gov ...

https://www.google.com/recaptcha/challengepage/

if you are not automatically redirected after 5 seconds.

Try again later

Your computer or network may be sending automated queries. To protect our users, we can't process your request right now. For more details visit

our help page

https://support.google.com/websearch/answer/86640

