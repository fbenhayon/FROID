# codigo para analise.txt

--------codigo

python3 << 'PYEOF'

with open("/root/froid/packages/froid-dashboard/src/pages/LiveSession.tsx", "r") as f:

content = f.read()

1. Fix zone descriptions to match actual FROID zones from config.py

old\_zones = """  const zoneDescriptions: Record<string, string> = {

'C2': 'Zona basal profunda (65-130 Hz). Associada a estados de profundo relaxamento, dissociacao ou depressao grave.',

'C#2': 'Transicao basal (130-139 Hz). Indicador de fadiga vocal ou afeto embotado.',

'C3': 'Zona grave-media (139-262 Hz). Comum em fala monotona, possivel indicador de anedonia.',

'C#3': 'Transicao grave (262-277 Hz). Zona de transicao emocional, instabilidade afetiva.',

'C4': 'Zona media fundamental (277-523 Hz). Faixa de fala normal, equilibrio entre acao e contemplacao.',

'C#4': 'Transicao media (523-554 Hz). Elevacao emocional moderada, engajamento ativo.',

'C5': 'Zona aguda-media (554-1047 Hz). Ativacao emocional significativa, possivel ansiedade.',

'C#5': 'Transicao aguda (1047-1109 Hz). Excitacao intensa, possivel estado maniaco.',

'C6': 'Zona aguda (1109-2093 Hz). Alta ativacao, estresse agudo ou panico.',

'C#6': 'Transicao hiper-aguda (2093-2217 Hz). Estado de alerta maximo.',

'C7': 'Zona hiper-aguda (2217-4186 Hz). Harmonicos superiores, tensao extrema.',

'C#7': 'Limite superior (4186+ Hz). Microexpressoes vocais, indicadores sutis de estresse.',

new\_zones = """  const zoneDescriptions: Record<string, { freq: string; positive: string; negative: string; correlate: string }> = {

'C': { freq: '130.81 Hz', positive: 'Seguranca', negative: 'Medo', correlate: 'Zona 1 - Tronco cerebral, regulacao autonomica' },

'C#': { freq: '138.59 Hz', positive: 'Valor pessoal', negative: 'Vergonha', correlate: 'Zona 2 - Sistema limbico, emocoes primarias' },

'D': { freq: '146.83 Hz', positive: 'Poder', negative: 'Impotencia', correlate: 'Zona 3 - Cortex pre-frontal, regulacao emocional' },

'D#': { freq: '155.56 Hz', positive: 'Amor', negative: 'Odio', correlate: 'Zona 4 - Equilibrio, serenidade' },

'E': { freq: '164.81 Hz', positive: 'Expressao', negative: 'Repressao', correlate: 'Zona 5 - Expressao emocional, vulnerabilidade' },

'F': { freq: '174.61 Hz', positive: 'Intuicao', negative: 'Confusao', correlate: 'Zona 6 - Introspecao, tristeza' },

'F#': { freq: '185.00 Hz', positive: 'Conexao espiritual', negative: 'Desconexao', correlate: 'Zona 7 - Criatividade, insight' },

'G': { freq: '196.00 Hz', positive: 'Responsabilidade', negative: 'Culpa', correlate: 'Zona 8 - Integracao cognitiva' },

'G#': { freq: '207.65 Hz', positive: 'Verdade', negative: 'Negacao', correlate: 'Zona 9 - Processamento superior' },

'A': { freq: '220.00 Hz', positive: 'Aceitacao', negative: 'Resistencia', correlate: 'Zona 10 - Harmonizacao' },

'A#': { freq: '233.08 Hz', positive: 'Gratidao', negative: 'Ressentimento', correlate: 'Zona 11 - Expansao consciente' },

'B': { freq: '246.94 Hz', positive: 'Transcendencia', negative: 'Apego', correlate: 'Zona 12 - Integracao total' },

content = content.replace(old\_zones, new\_zones)

2. Fix zone chart labels to match config

content = content.replace(

"labels: \['C2', 'C#2', 'C3', 'C#3', 'C4', 'C#4', 'C5', 'C#5', 'C6', 'C#6', 'C7', 'C#7'\],",

"labels: \['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B'\],"

3. Fix zone chart colors to use colorimetry gradient (green to red spectrum)

content = content.replace(

"""backgroundColor: \[

'rgba(255, 99, 132, 0.8)', 'rgba(255, 159, 64, 0.8)', 'rgba(255, 205, 86, 0.8)',

'rgba(75, 192, 192, 0.8)', 'rgba(54, 162, 235, 0.8)', 'rgba(153, 102, 255, 0.8)',

'rgba(231, 233, 237, 0.8)', 'rgba(255, 99, 132, 0.6)', 'rgba(255, 159, 64, 0.6)',

'rgba(255, 205, 86, 0.6)', 'rgba(75, 192, 192, 0.6)', 'rgba(54, 162, 235, 0.6)',

"""backgroundColor: zoneData.map((val) => {

if (val >= 70) return 'rgba(0, 100, 0, 0.8)';

if (val >= 50) return 'rgba(50, 205, 50, 0.8)';

if (val >= 30) return 'rgba(154, 205, 50, 0.8)';

if (val >= 15) return 'rgba(255, 215, 0, 0.8)';

if (val >= 5) return 'rgba(255, 140, 0, 0.8)';

return 'rgba(139, 0, 0, 0.5)';

4. Add custom tooltip to zone chart showing dichotomies

content = content.replace(

"plugins: { legend: { display: false }, title: { display: true, text: '12 Zonas FROID', color: '#fff' } },",

"""plugins: {

legend: { display: false },

title: { display: true, text: '12 Zonas FROID', color: '#fff' },

callbacks: {

afterLabel: (ctx: any) => {

const zoneKeys = \['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B'\];

const key = zoneKeys\[ctx.dataIndex\];

const zd = zoneDescriptions\[key\];

if (!zd) return '';

${zd.freq}\\n+ ${zd.positive}  / - ${zd.negative}\\n${zd.correlate}

5. Fix zone info panel to use new structure

content = content.replace(

"""                {Object.entries(zoneDescriptions).map((\[zone, desc\]) => (

<p key={zone} className="mb-1">

<span className="font-bold text-blue-400">

<span className="text-gray-300">

"""                {Object.entries(zoneDescriptions).map((\[zone, desc\]) => (

<p key={zone} className="mb-1">

<span className="font-bold text-blue-400">

{zone} ({desc.freq}):

<span className="text-green-400">

+{desc.positive}

<span className="text-red-400">

-{desc.negative}

<span className="text-gray-500">

| {desc.correlate}

6. Fix zone dominant info button

content = content.replace(

"""                {currentZone && zoneDescriptions\[currentZone\] && (

<button onClick={() => setShowZoneInfo(!showZoneInfo)} className="w-4 h-4 rounded-full bg-gray-600 hover:bg-blue-600 text-xs flex items-center justify-center">?

"""                {currentZone && (

<button onClick={() => setShowZoneInfo(!showZoneInfo)} className="w-4 h-4 rounded-full bg-gray-600 hover:bg-blue-600 text-xs flex items-center justify-center">?

7. Fix risk scores - map backend keys correctly and show 0 when no data

content = content.replace(

"""      if (data.clinical\_scores) {

setRiskScores({

depression: Math.round((data.clinical\_scores.depression\_risk || 0) \* 100),

mania: Math.round((data.clinical\_scores.mania\_activation || 0) \* 100),

stress: Math.round((data.clinical\_scores.stress\_cognitive || 0) \* 100),

anxiety: Math.round((data.clinical\_scores.anxiety\_risk || 0) \* 100),

dissociation: Math.round((data.clinical\_scores.dissociation\_risk || 0) \* 100),

trauma: Math.round((data.clinical\_scores.trauma\_risk || 0) \* 100),

"""      if (data.clinical\_scores) {

const cs = data.clinical\_scores;

const toPercent = (v: number) => Math.max(0, Math.round((v - 0.5) \* 200));

setRiskScores({

depression: toPercent(cs.depression\_risk ?? 0.5),

mania: toPercent(cs.mania\_activation ?? 0.5),

stress: toPercent(cs.stress\_cognitive ?? 0.5),

anxiety: toPercent(cs.anxiety\_risk ?? 0.5),

dissociation: toPercent(cs.dissociation\_risk ?? 0.5),

trauma: toPercent(cs.trauma\_risk ?? 0.5),

8. Fix IPM - remove ring border from circle

content = content.replace(

relative w-24 h-24 rounded-full ring-4 ${getIPMRingColor(ipmScore)} flex items-center justify-center bg-gray-900

relative w-24 h-24 rounded-full flex items-center justify-center bg-gray-900

9. Remove getIPMRingColor function (no longer needed)

content = content.replace(

"""  const getIPMRingColor = (score: number) => {

if (score >= 70) return 'ring-green-500';

if (score >= 40) return 'ring-yellow-500';

return 'ring-red-500';

10. Make radar chart bigger and add hover tooltips for emotions

content = content.replace(

"""    plugins: { legend: { display: false } },

const colorimetryColors""",

"""    plugins: {

legend: { display: false },

callbacks: {

afterLabel: (ctx: any) => {

const keys = Object.keys(emotionDescriptions);

const key = keys\[ctx.dataIndex\];

const desc = emotionDescriptions\[key\];

if (!desc) return '';

AUs: ${desc.canonical\_aus}\\n${desc.description}

const colorimetryColors"""

11. Make radar chart bigger (h-48 -> h-64) and remove loose emotion list

content = content.replace(

<div className="h-48">

<Radar data={emotionRadarData} options={emotionRadarOptions} />

<div className="h-64">

<Radar data={emotionRadarData} options={emotionRadarOptions} />

Remove the grid of emotion items below radar (they show in radar hover now)

content = content.replace(

<div className="grid grid-cols-2 gap-1 mt-2">

{Object.entries(emotionDescriptions).map((\[key, desc\]) => (

<div key={key} className={

flex items-center justify-between px-1.5 py-0.5 rounded text-xs ${ currentEmotion === key ? 'bg-green-900 ring-1 ring-green-500' : 'bg-gray-700' }

<span className={currentEmotion === key ? 'text-green-400 font-semibold' : 'text-gray-400'}>{desc.label}

onClick={() => setTooltipEmotion(tooltipEmotion === key ? null : key)}

className="w-4 h-4 rounded-full bg-gray-600 hover:bg-blue-600 text-xs flex items-center justify-center ml-1"

title={desc.canonical\_aus}

12. Colorimetry - use actual FROID colors from config (green-to-red, not rainbow)

content = content.replace(

"const colorimetryColors = \['#FF0000', '#FF7F00', '#FFFF00', '#00FF00', '#0000FF', '#4B0082', '#9400D3'\];",

"const colorimetryColors = \['#006400', '#32CD32', '#9ACD32', '#FFD700', '#FF8C00', '#FF4500', '#8B0000'\];"

content = content.replace(

"\['Vermelho', 'Laranja', 'Amarelo', 'Verde', 'Azul', 'Indigo', 'Violeta'\]\[colorimetryLevel\]",

"\['Muito positivo', 'Positivo', 'Levemente positivo', 'Neutro', 'Levemente negativo', 'Negativo', 'Muito negativo'\]\[colorimetryLevel\]"

13. Add colorimetry integration to risk bars

content = content.replace(

"""  const getRiskColor = (score: number) => {

if (score < 30) return 'bg-green-500';

if (score < 60) return 'bg-yellow-500';

return 'bg-red-500';

"""  const getRiskColor = (score: number) => {

if (score <= 0) return 'bg-gray-600';

if (score < 15) return 'bg-green-700';

if (score < 30) return 'bg-green-500';

if (score < 50) return 'bg-yellow-500';

if (score < 70) return 'bg-orange-500';

return 'bg-red-600';

14. Add band chart tooltip with descriptions

content = content.replace(

"plugins: { legend: { display: false }, title: { display: true, text: '7 Bandas Espectrais', color: '#fff' } },",

"""plugins: {

legend: { display: false },

title: { display: true, text: '7 Bandas Espectrais', color: '#fff' },

callbacks: {

afterLabel: (ctx: any) => {

const keys = \['Subharmonics', 'Delta', 'Theta', 'Alpha', 'Beta', 'Gamma', 'High-Gamma'\];

const key = keys\[ctx.dataIndex\];

return bandDescriptions\[key\] || '';

with open("/root/froid/packages/froid-dashboard/src/pages/LiveSession.tsx", "w") as f:

f.write(content)

print("LiveSession.tsx updated - all changes applied")

