# Facial Action Coding System

https://web.cs.wpi.edu/~matt/courses/cs563/talks/face\_anim/ekman.html

A new method of describing facial movement based on an anatomical analysis of facial action.

Their primary goal in developing the Facial Action Coding System was to develop a

comprehensive

system which could distinguish all possible visually distinguishable facial movements.

They chose to derive FACS from an analysis of the anatomical basis of facial movement. Since every facial movement is the result of muscular action, a comprehensive system could be obtained by discovering how each muscle of the face acts to change visible appearance. With that knowledge it would be possible to analyze any facial movement into anatomically based minimal action units.

Constraints

A constraint in the development of FACS was that it deals with what is clearly visible in the face, ignoring invisible changes (e.g. certain changes in muscle tonus), and discarding visible changes too subtle for reliable distinction.

FACS excludes visible changes in muscle tonus which do not entail movement; changes in skin coloration are usually not visible on black and white records. Also excluded from FACS are: facial sweating, tears, rashes, pimples and permanent facial characteristics.

The user of FACS must learn the mechanics -- the muscular basis -- of facial movement, not just the consequence of movement or a description of a static landmark. FACS emphasizes patterns of movement, the changing nature of facial appearance. Distinctive actions are described: the movements of the skin, the temporary changes in shape and location of the features, and the gathering, pouching, bulging and wrinkling of the skin.

Development

The first step in developing FACS was to study various anatomical texts to discover the minimal units. The authors expected to find a listing of the muscles which can fire separately, and how each muscle changes facial appearance.

Next, they examine the photographs taken of each of their faces, scrambling the pictures so they would not know what muscle had been fired. Their purpose was to determine if all the separate muscular actions could be distinguished accurately from appearance alone. Note that they call the measurements

not muscle units; this is because they have combined more than one muscle in their unitization of appearance changes. Another reason for using the term

action unit

is because they also have separated more than one action from what most anatomists described as one muscle.

For example, the

muscle which raises the brow was separated into two action units, depending upon whether the inner or outer portion of this muscle lifts the inner or outer portions of the eyebrow.

Table: Single Action Units

AU No.	FACS Name		Muscular Basis

1	Inner Brow Raiser	Frontalis, Pars Medialis
2	Outer Brow Raiser	Frontalis, Pars Lateralis
4	Brow Lowerer    	Depressor Glabellae; Depressor
				Supercilli; Corrugator
5	Upper Lid Raiser	Levator Palebrae Superioris
6	Cheek Raiser		Orbicularis Oculi, Pars Orbitalis
7	Lid Tightener		Orbicularis Oculi, Pars Palebralis
8	Lips Toward		Orbicularis Oris
	Each Other
9	Nose Wrinkler		Levator Labii Superioris,
				Alaeque Nasi
10	Upper Lip Raiser	Levator Labii Superioris, Caput
				Infraorbitalis
11	Nasolabial Furrow	Zygomatic Minor
	Deepener
12	Lip Corner Puller	Zygomatic Major
13	Cheek puffer		Caninus
14	Dimpler			Buccinnator
15	Lip Corner Depressor	Triangularis
16	Lower Lip Depressor	Depressor Labii
17	Chin Raiser		Mentalis
18	Lip Puckerer		Incisivii Labii Superioris;
				Incisivii Labii Inferioris
20	Lip Stretcher		Risorius
22	Lip Funneler		Orbicularis Oris
23	Lip Tightner		Orbicularis Oris
24	Lip Pressor		Orbicularis Oris
25	Lips Part		Depressor Labii, or Relaxation of
				Mentalis or Orbicularis Oris
26	Jaw Drop		Masetter; Temporal and Internal
				Pterygoid
27	Mouth Stretch		Ptergoids; Digastric
28	Lip suck		Orbicularis Oris
38	Nostril Dilator		Nasalis, Pars Alaris
39	Nostril Compressor	Nasalis, Pars Transversa and
				Depressor Septi Nasi
41	Lid Droop		Relaxation of Levator
				Palpebrae Superioris
42	Slit			Orbicularis Oculi
43	Eyes Closed		Relaxation of Levator
				Palpebrae Superioris
44	Squint			Orbicularis Oculi, Pars
				Palpebralis
45	Blink			Relaxation of Levator Palpebrae and
				Contraction o Orbicularis oculi,
				Pars Palpebralis
46	Wink			Orbicularis Oculi

The table indicates where they have collapsed more than one muscle into a single Action Unit from a single muscle.

Back to home..

http://www.wpi.edu/~sudhir/presentation.html

