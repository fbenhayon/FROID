# FROID TECH.pdf

Frequency Recognition of Internal Dynamics

Stack Tecnológico Completo

Tecnologias de IA, Ferramentas e Arquitetura de Integração

para codificação pelo software ANTIGRAVITY

Versão 1.0 — Abril 2026 Documento Confidencial

FROID — Stack Tecnológico | ANTIGRAVITY

Confidencial  |  Pág. 2

1. Visão Geral da Arquitetura Tecnológica

Este documento especifica todas as tecnologias de inteligência artificial, bibliotecas, APIs e frameworks necessários para a construção do sistema FROID pelo software ANTIGRAVITY. A seleção prioriza as soluções mais avançadas disponíveis em 2026, com foco em precisão clínica, latência mínima e conformidade regulatória.

A arquitetura segue um modelo de microsserviços com três camadas principais: captura e processamento de sinais (voz e vídeo), motor de análise com IA (inferência emocional multimodal), e plataforma de gestão clínica e administrativa. Cada camada opera de forma independente, comunicando-se via APIs RESTful e WebSocket.

1.1 Mapa Geral do Stack

Camada Função Tecnologias Principais

Captura de Vídeo Aquisição de stream de vídeo em tempo real da câmera do consultório

WebRTC, MediaStream API, getUserMedia, FFmpeg

Captura de Áudio Aquisição de áudio contínuo para análise vocal e transcrição

Web Audio API, MediaRecorder, PortAudio, PyAudio

Análise Facial Detecção de landmarks, Action Units e classificação emocional

Hume AI Expression Measurement, MediaPipe Face Mesh, OpenCV

Análise Vocal Extração de features acústicas e classificação emocional da voz

Hume AI Prosody + Vocal Burst, openSMILE, librosa, Praat/Parselmouth

Transcrição (STT) Conversão speech-to-text em tempo real com diarização

OpenAI Whisper V4, Deepgram Nova-3, AssemblyAI Universal-2

NLP / Análise Semântica

Identificação de temas, sentimento e coerência emocional

Claude API (Anthropic), Hume AI Language Model, spaCy

Motor de Fusão Multimodal

Correlação temporal entre voz, face e texto para IPM

PyTorch, TensorFlow, modelo custom ConvLSTM

Dashboard Real-Time Visualização gráfica em tempo real para o profissional

React 19, D3.js, Recharts, Socket.IO, WebSocket

Backend / API Orquestração de serviços, autenticação e lógica de negócios

Node.js/NestJS, FastAPI (Python), GraphQL

Banco de Dados Persistência de dados clínicos, analíticos e administrativos

PostgreSQL 16, TimescaleDB, Redis, S3/MinIO

Administrativo Agenda, financeiro, pacientes, compartilhamento

Cal.com (agenda), Stripe/Asaas (pagamentos), Resend (e-mail)

Infraestrutura Deploy, escala, segurança e observabilidade

AWS/GCP, Docker, Kubernetes, Terraform, Datadog

FROID — Stack Tecnológico | ANTIGRAVITY

Confidencial  |  Pág. 3

2. Camada de Análise Facial — Tecnologias de IA
2.1 Hume AI — Expression Measurement API (RECOMENDADO PRIMÁRIO)

A Hume AI é a plataforma mais avançada de reconhecimento emocional multimodal disponível em 2026. Fundada pelo cientista cognitivo Dr. Alan Cowen (UC Berkeley/Google), a Hume oferece modelos construídos sobre mais de 10 anos de pesquisa em ciência computacional da emoção, utilizando a Semantic Space Theory.

#### Capacidades para o FROID:

Detecção de 48 dimensões de expressão emocional facial (vai muito além das 7 emoções básicas de Ekman)

Suporte nativo a FACS 2.0 — saída de Action Units com scores de intensidade

Análise de vídeo frame-a-frame com rastreamento temporal de expressões

API Batch (processamento de arquivos) e Streaming (tempo real via WebSocket)

SDKs oficiais para Python e TypeScript — integração direta com o ANTIGRAVITY

Custo aproximado: US$ 0,08/minuto para vídeo com áudio

#### Exemplo de integração:

from hume import HumeClient; client = HumeClient(api\_key); predictions = client.expression\_measurement.batch.start\_inference\_job(models=Models(face=Face()), urls=\[video\_url\])

2.2 Google MediaPipe Face Landmarker (CAMADA LOCAL COMPLEMENTAR)

O MediaPipe Face Landmarker é a solução de visão computacional do Google para detecção de landmarks faciais em tempo real. É essencial como camada local de processamento, pois opera no dispositivo sem necessidade de conexão com a nuvem, garantindo baixa latência.

#### Especificações técnicas:

468 landmarks 3D faciais com rastreamento em tempo real (> 30fps em CPUs modernas)

Predição de 52 blendshape scores — coeficientes que representam expressões faciais específicas

Baseado em BlazeFace (deteção) + rede residual de regressão 3D (landmarks)

Funciona em navegador (JavaScript/WASM), Python, Android, iOS e desktop

Open-source e gratuito (Apache 2.0) — sem custos de API

Latenência sub-milissegundo em GPUs móveis e ~ 5ms em CPU

2.3 OpenCV + Modelos Custom de Classificação

O OpenCV fornece a infraestrutura de processamento de vídeo e imagem. Combinado com modelos CNN customizados treinados em datasets como FER-2013, AffectNet e RAF-DB, permite:

Pré-processamento de frames: normalização, crop facial, alinhamento

Detecção de microexpressões via análise de diferenças entre frames consecutivos

Cálculo de assimetria facial a partir dos landmarks do MediaPipe

Rastreamento de direção do olhar (gaze estimation) e frequência de piscadas

2.4 Ferramentas Adicionais de Análise Facial

FROID — Stack Tecnológico | ANTIGRAVITY

Confidencial  |  Pág. 4

Ferramenta Uso no FROID Tipo Licença

Face++ (Megvii) Fallback para reconhecimento facial em condições de baixa luminosidade

API Cloud Comercial (freemium)

Visage SDK Análise facial offline em dispositivos móveis/tablets

SDK nativo Comercial

Imentiv AI Detecção de 29 emoções complexas (confusão, curiosidade, tédio)

API Cloud Comercial

CompreFace Reconhecimento facial open-source para identificação de pacientes

Self-hosted Apache 2.0

dlib + shape\_predictor Fallback de landmarks (68 pontos) para ambientes sem GPU

Biblioteca Boost License

FROID — Stack Tecnológico | ANTIGRAVITY

Confidencial  |  Pág. 5

3. Camada de Análise Vocal — Tecnologias de IA
3.1 Hume AI — Speech Prosody + Vocal Burst (RECOMENDADO PRIMÁRIO)

A mesma plataforma Hume AI oferece modelos específicos para análise emocional da voz, o que permite integração unificada com a análise facial em um único pipeline multimodal.

#### Modelos de voz disponíveis:

Speech Prosody: analisa ritmo, entração, ênfase e entonação — detecta mais de 25 padrões prossódicos. Identifica nuances como sarcasmo, urgência, calidez e hesitação

Vocal Burst: detecta riso, suspiros, arquejos e outras vocalizações não-verbais — marcadores cruciais em sessões terapêuticas

Saída unificada com 48+ dimensões emocionais por modalidade, incluindo admiração, constrangimento, dor empática, nostalgia, entre outras

API Streaming para análise em tempo real via WebSocket com latência mínima

3.2 openSMILE 3.0 (EXTRAÇÃO DE FEATURES ACÚSTICAS LOCAL)

O openSMILE (open-source Speech and Music Interpretation by Large-space Extraction) é o toolkit de referência acadêmica e industrial para extração de features acústicas. Desenvolvido pela audEERING, opera localmente com alta performance.

#### Features extraídas relevantes para o FROID:

eGeMAPS (Geneva Minimalistic Acoustic Parameter Set): conjunto padronizado de 88 parâmetros otimizados para reconhecimento emocional

Pitch contour (F0), jitter, shimmer, HNR (Harmonics-to-Noise Ratio)

Loudness, spectral flux, MFCC (Mel-Frequency Cepstral Coefficients)

Taxa de fala, pausas, e parâmetros de qualidade vocal

Processamento em tempo real com latência < 50ms em C++ nativo

Python wrapper (opensmile-python) para integração direta com o pipeline de ML

3.3 librosa (ANÁLISE ESPECTRAL COMPLEMENTAR)

Biblioteca Python de referência para análise de sinais de áudio, utilizada para:

Extração de MFCCs, chroma features, mel spectrograms e spectral contrast

Análise de contorno de pitch via funções yin/pyin

Detecção de onset/offset para segmentação de fala/silêncio

Visualização de espectrogramas para geração de relatórios

3.4 Praat / Parselmouth

O Praat é o software mais respeitado em fonética e análise acústica da fala. Através do wrapper Python Parselmouth, fornece:

Extração precisa de F0 com algoritmo autocorrelação (padrão-ouro em fonética)

Cálculo de formantes (F1, F2, F3) para análise de qualidade vocal

Intensidade, HNR e medidas de perturbação vocal (jitter/shimmer) com precisão clínica

FROID — Stack Tecnológico | ANTIGRAVITY

Confidencial  |  Pág. 6

3.5 Modelos de Deep Learning para SER

Modelo/Framework Aplicação no FROID Detalhes

Wav2Vec 2.0 (Meta) Embeddings de áudio pré-treinados para classificação emocional

Modelo auto-supervisionado treinado em 60.000h de fala. Fine-tuning com RAVDESS/IEMOCAP

HuBERT (Meta) Representações latentes de fala para SER avançado

Superior ao Wav2Vec em tarefas de emoção. Captura nuances prossódicas complexas

NVIDIA NeMo Framework end-to-end para ASR + classificação emocional

Modelos pré-treinados, fine-tuning via TAO Toolkit. Otimizado para GPUs NVIDIA

ConvLSTM1D custom Modelo de fusão temporal para seqências de features prossódicas

Combina CNN (padrões espectrais) + LSTM (dinâmica temporal). Treinamento custom

Whisper encoder (OpenAI)

Embeddings de áudio para correlação com transcrição

O encoder do Whisper pode ser reutilizado para gerar representações de áudio

FROID — Stack Tecnológico | ANTIGRAVITY

Confidencial  |  Pág. 7

4. Transcrição de Fala e Análise de Linguagem Natural
4.1 Transcrição em Tempo Real (Speech-to-Text)

Solução WER (pt-BR) Latência Diarização Uso no FROID

OpenAI Whisper V4

~ 4% (multilingual) < 500ms (streaming)

Sim (nativo V4) PRIMÁRIO — precisão superior

Deepgram Nova-3 ~ 5% < 200ms Sim FALLBACK — menor latência

AssemblyAI Universal-2

~ 4.5% < 300ms Sim (avançada) Alternativa com NLP integrado

Azure Speech (Whisper)

~ 5% < 400ms Sim Para clientes Azure existentes

4.2 Análise de Linguagem Natural (NLP)

O processamento de linguagem natural é essencial para identificar temas, extrair insights e correlacionar conteúdo verbal com dados emocionais:

Claude API (Anthropic): modelo de linguagem principal para geração de relatórios pós-sessão, identificação de temas, sumarização e análise de coerência emocional. Modelo recomendado: claude-sonnet-4-6

Hume AI Language Model: 53 dimensões de expressão emocional a partir do texto, incluindo análise de sentimento e toxicidade

spaCy (v3.7+): tokenização, NER (reconhecimento de entidades), classificação de temas e segmentação de tópicos para português

Hugging Face Transformers: modelos BERT/RoBERTa fine-tuned para análise de sentimento em português (BERTimbau)

5. Motor de Fusão Multimodal e Cálculo do IPM

O coração do FROID é o motor de fusão que integra dados de voz, face e texto em um índice unificado (IPM). Este módulo correlaciona temporalmente os sinais das três modalidades:

#### Arquitetura do motor:

Camada de alinhamento temporal: sincroniza streams de áudio, vídeo e texto usando timestamps unificados (UTC milissegundos)

Camada de normalização: converte outputs de diferentes modelos (Hume 48 dimensões, openSMILE 88 features, MediaPipe 52 blendshapes) em espaços vetoriais comparáveis

Camada de fusão: modelo ConvLSTM1D custom treinado em dados clínicos para gerar o IPM (0–100)

Detector de dissonância: comparação em tempo real entre emoção vocal (Hume Prosody) e emoção facial (Hume Face) para identificar incoerências

#### Tecnologias:

PyTorch 2.x: framework principal para o modelo de fusão

ONNX Runtime: inferência otimizada para produção com latência < 100ms

FROID — Stack Tecnológico | ANTIGRAVITY

Confidencial  |  Pág. 8

TensorRT (NVIDIA): aceleração de inferência em GPU para clientes enterprise

MLflow: versionamento de modelos, tracking de experimentos e registro de métricas

FROID — Stack Tecnológico | ANTIGRAVITY

Confidencial  |  Pág. 9

6. Camada de Captura de Vídeo e Áudio
6.1 Captura de Vídeo

Tecnologia Função Detalhes Técnicos

WebRTC Captura e transmissão de vídeo em tempo real navegador-a-servidor

Protocolo P2P com suporte a TURN/STUN. Latência < 100ms. Criptografia SRTP nativa

MediaStream API Acesso à câmera do dispositivo no navegador

navigator.mediaDevices.getUserMedia(). Controle de resolução e FPS

FFmpeg / GStreamer Processamento e transcodificação de vídeo no servidor

Conversão de formatos, extração de frames, compressão para armazenamento

OpenCV VideoCapture Captura e pré-processamento de frames para análise

Python: cv2.VideoCapture(). Suporte a câmeras USB, IP e streams RTSP

Canvas API + OffscreenCanvas

Processamento de frames no client-side (Web Workers)

Extração de frames do vídeo para processamento local com MediaPipe

6.2 Captura e Gravação de Áudio

Tecnologia Função Detalhes

Web Audio API Captura e processamento de áudio no navegador em tempo real

AudioContext, AnalyserNode para FFT em tempo real, ScriptProcessorNode

MediaRecorder API Gravação de áudio em chunks para envio ao servidor

Formatos: webm/opus, ogg/opus. Chunks de 250ms para streaming

PortAudio / PyAudio Captura de áudio nativo em aplicações desktop (Python)

Acesso direto ao hardware. Buffer configurável. Latência < 10ms

SOX (Sound eXchange) Pré-processamento de áudio: normalização, filtros, conversão

Redução de ruído, equalização, conversão de sample rate

FROID — Stack Tecnológico | ANTIGRAVITY

Confidencial  |  Pág. 10

7. Dashboard em Tempo Real e Frontend
7.1 Stack de Frontend

React 19 + TypeScript: framework principal. Componentes funcionais com hooks para estado reativo

Next.js 15: framework full-stack para SSR, routing e API routes

Socket.IO / native WebSocket: comunicação bidirecional em tempo real para atualização do dashboard

D3.js v7: visualizações customizadas — disco de zonas vocais (estilo EVOX), timelines emocionais, radar charts

Recharts / Visx: gráficos declarativos para indicadores e relatórios

Tailwind CSS 4: estilização rápida e responsiva

Framer Motion: animações suaves para transições de dados e alertas visuais

Radix UI / shadcn/ui: componentes acessíveis e estilizáveis

7.2 Componentes Específicos do Dashboard

VoiceSpectrumDisc: componente D3.js customizado que renderiza o disco de zonas vocais com atualização a cada 500ms (SVG animado)

EmotionTimeline: gráfico de área empilhada com dois canais (vocal + facial) sincronizados

IPMGauge: indicador circular do Índice de Percepção Móvel com código de cores dinâmico

FaceMapOverlay: renderização esquemática do rosto com destaque nas áreas ativas de AU

CoherenceIndicator: semáforo voz-face com animação de pulso em estados de dissonância

EventMarker: botão de marcação rápida com atalho de teclado e notação por voz

8. Backend, Banco de Dados e Infraestrutura
8.1 Arquitetura de Backend

FastAPI (Python 3.12+): serviços de análise de IA — endpoints assíncronos com suporte nativo a WebSocket e streaming

NestJS (Node.js/TypeScript): serviços administrativos, API GraphQL, autenticação e autorização

GraphQL (Apollo Server): API unificada para consultas complexas de dados clínicos e administrativos

Celery + Redis: fila de tarefas assíncronas para processamento pós-sessão (geração de relatórios, análise longitudinal)

gRPC: comunicação de alta performance entre microsserviços internos

8.2 Banco de Dados

Tecnologia Função Justificativa

PostgreSQL 16 Dados relacionais: pacientes, sessões, profissionais, agenda, financeiro

ACID compliance, JSONB para dados semi-estruturados, Row-Level Security

FROID — Stack Tecnológico | ANTIGRAVITY

Confidencial  |  Pág. 11

TimescaleDB Séries temporais: IPM, features vocais/faciais por timestamp

Extensão PostgreSQL otimizada para dados time-series. Compressão 10-20x

Redis 7 Cache de sessão, fila de mensagens, dados temp. em tempo real

Latência < 1ms. Pub/Sub para eventos do dashboard

S3 / MinIO Armazenamento de mídia: áudio, vídeo, relatórios PDF

Object storage escalável. Criptografia at-rest AES-256

Elasticsearch Busca full-text em transcrições e anotações

Indexação rápida para busca em histórico de sessões

FROID — Stack Tecnológico | ANTIGRAVITY

Confidencial  |  Pág. 12

9. Stack Administrativo e Financeiro
9.1 Agenda e Calendário

Tecnologia Função Integração

Cal.com (open-source) Engine de agendamento: tipos de consulta, disponibilidade, recorrência, timezone

API REST. Self-hosted ou cloud. Webhooks para eventos

Google Calendar API Sincronização bidirecional com agenda pessoal do profissional

OAuth 2.0. Events, reminders, busy/free status

Microsoft Graph API Sincronização com Outlook/M365 Calendar

OAuth 2.0. Para profissionais em ambiente corporativo

Twilio / Evolution API Lembretes automáticos via SMS e WhatsApp

API REST. Templates aprovados. Confirmação interativa

Resend / SendGrid Notificações por e-mail: lembretes, relatórios, faturas

API REST. Templates HTML. Tracking de entrega

9.2 Módulo Financeiro

Tecnologia Função Detalhes

Stripe Pagamentos internacionais: assinaturas, invoices, checkout

API completa. Billing portal. Webhooks. PCI DSS Level 1

Asaas Pagamentos Brasil: boleto, PIX, cartão. Cobrança recorrente

API REST. Split de pagamentos. Nota fiscal integrada

Nota Fiscal API (eNotas/NFe.io)

Emissão automática de NFS-e e recibos

Integração com prefeituras brasileiras. CNAE de saúde

Metabase / Apache Superset

Dashboards financeiros e relatórios gerenciais

Conecta direto ao PostgreSQL. Gráficos interativos. Self-hosted

9.3 Gestão de Pacientes e Compartilhamento

Supabase Auth: autenticação de profissionais (email/senha, Google, SSO enterprise) com Row-Level Security nativo

Supabase Storage: armazenamento de documentos de pacientes com políticas de acesso granulares

PDF-lib / Puppeteer: geração programática de relatórios em PDF para compartilhamento

Presigned URLs (S3): compartilhamento seguro de relatórios com expiração automática

Audit Trail: tabela imutável (append-only) no PostgreSQL para log de todos os acessos e compartilhamentos

FROID — Stack Tecnológico | ANTIGRAVITY

Confidencial  |  Pág. 13

10. Segurança, Criptografia e Compliance
10.1 Stack de Segurança

Componente Tecnologia Implementação

Criptografia em trânsito TLS 1.3 + SRTP (WebRTC) Certificados Let’s Encrypt / AWS ACM. HSTS habilitado

Criptografia em repouso AES-256-GCM AWS KMS / HashiCorp Vault para gestão de chaves

Autenticação OAuth 2.0 + OIDC / JWT Supabase Auth ou Auth0. MFA obrigatório. Refresh token rotation

Autorização RBAC + ABAC + Row-Level Security Papéis: admin, profissional, paciente, supervisor. Políticas por recurso

Consentimento DocuSign API / Clickwrap Termos digitais com assinatura. Revogação programática

Auditoria Append-only audit log Tabela imutável no PostgreSQL. Exportação para SIEM

Anonimização ARX / Microsoft Presidio K-anonimidade para dados de pesquisa. PII detection + redaction

10.2 Compliance Regulatório

LGPD (Brasil): consentimento explícito, direito ao esquecimento, DPO, relatório de impacto (RIPD)

HIPAA (EUA): BAA com provedores cloud, PHI encryption, access controls, audit trails

GDPR (Europa): data residency, portabilidade, minimização de dados, DPO

CFP/CRP (Brasil): conformidade com resoluções do Conselho Federal de Psicologia sobre uso de tecnologia em atendimento

11. Infraestrutura, Deploy e Observabilidade
11.1 Stack de Infraestrutura

AWS (preferencial) ou GCP: compute (ECS/EKS ou Cloud Run/GKE), storage (S3), database (RDS), CDN (CloudFront)

Docker: containerização de todos os serviços com multi-stage builds

Kubernetes (EKS/GKE): orquestração de containers com auto-scaling baseado em carga

Terraform / Pulumi: Infrastructure-as-Code para reprodutibilidade de ambientes

GitHub Actions / GitLab CI: pipelines de CI/CD com testes, linting e deploy automático

NVIDIA T4/A10G (GPU): instâncias GPU para inferência de modelos de ML em tempo real

11.2 Observabilidade

Datadog / Grafana + Prometheus: métricas de performance, latência de API e uso de recursos

FROID — Stack Tecnológico | ANTIGRAVITY

Confidencial  |  Pág. 14

Sentry: error tracking e performance monitoring no frontend e backend

OpenTelemetry: tracing distribuído entre microsserviços

CloudWatch / Cloud Logging: logs centralizados com retenção configurável

FROID — Stack Tecnológico | ANTIGRAVITY

Confidencial  |  Pág. 15

12. Mapa de Integração para Codificação no ANTIGRAVITY

O software ANTIGRAVITY deve codificar o FROID seguindo a arquitetura de microsserviços abaixo, onde cada serviço é independente, testável e escalável individualmente:

12.1 Serviços a Codificar

Serviço Linguagem Framework APIs Externas Prioridade

froid-voice Python FastAPI + openSMILE + librosa

Hume AI Prosody API

froid-face Python + JS FastAPI + MediaPipe + OpenCV

Hume AI Face API MVP - P0

froid-transcribe Python FastAPI + Whisper OpenAI Whisper V4 API

froid-fusion Python PyTorch + ONNX Runtime

— (modelo interno) v1.0 - P1

froid-nlp Python spaCy + Transformers

Claude API (Anthropic)

froid-dashboard

TypeScript Next.js 15 + React 19 + D3.js

froid-api TypeScript NestJS + GraphQL + Prisma

froid-admin TypeScript Next.js 15 + Cal.com SDK

Cal.com, Stripe, Asaas

froid-storage Python FastAPI + boto3 (S3) AWS S3 / MinIO MVP - P0

12.2 Fluxo de Dados em Tempo Real

O ANTIGRAVITY deve implementar o seguinte pipeline de dados durante uma sessão ativa:

1. Câmera/Microfone → WebRTC/MediaStream → split em streams de áudio e vídeo

2. Stream de vídeo → froid-face (MediaPipe local + Hume Face API) → 48 dimensões

emocionais + 52 blendshapes a cada 500ms

3. Stream de áudio → froid-voice (openSMILE local + Hume Prosody API) → features acústicas

+ 25 padrões prossódicos a cada 500ms

4. Stream de áudio → froid-transcribe (Whisper V4) → texto transcrito com timestamps e

5. Dados 2+3+4 → froid-fusion → IPM (0-100) + índice de coerência + alertas a cada 5 segundos

6. Resultados → WebSocket → froid-dashboard → visualização em tempo real

7. Fim da sessão → froid-nlp (Claude API) → relatório automático + identificação de temas
12.3 Custos Estimados por Sessão (50 minutos)

Serviço Consumo por Sessão Custo Estimado (USD)

Hume AI (vídeo + áudio) 50 min de vídeo com áudio ~ $4.00

FROID — Stack Tecnológico | ANTIGRAVITY

Confidencial  |  Pág. 16

OpenAI Whisper V4 50 min de áudio ~ $0.30

Claude API (relatório) ~ 5.000 tokens input + 2.000 output

GPU compute (inferência) 50 min de GPU T4 ~ $0.40

Storage (S3) ~ 500MB (áudio + dados) ~ $0.01

TOTAL por sessão  ~ $4.76

FROID — Stack Tecnológico para ANTIGRAVITY

Documento de Especificação v1.0 — Abril 2026

