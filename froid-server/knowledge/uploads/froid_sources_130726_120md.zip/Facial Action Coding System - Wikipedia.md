# Facial Action Coding System - Wikipedia

https://en.wikipedia.org/wiki/Facial\_Action\_Coding\_System

Jump to content

https://en.wikipedia.org/wiki/Facial\_Action\_Coding\_System#bodyContent

move to sidebar hide

https://en.wikipedia.org/wiki/Main\_Page

https://en.wikipedia.org/wiki/Wikipedia:Contents

Current events

https://en.wikipedia.org/wiki/Portal:Current\_events

Random article

https://en.wikipedia.org/wiki/Special:Random

About Wikipedia

https://en.wikipedia.org/wiki/Wikipedia:About

https://en.wikipedia.org/wiki/Wikipedia:Contact\_us

https://en.wikipedia.org/wiki/Help:Contents

Learn to edit

https://en.wikipedia.org/wiki/Help:Introduction

Community portal

https://en.wikipedia.org/wiki/Wikipedia:Community\_portal

Recent changes

https://en.wikipedia.org/wiki/Special:RecentChanges

Upload file

https://en.wikipedia.org/wiki/Wikipedia:File\_upload\_wizard

Special pages

https://en.wikipedia.org/wiki/Special:SpecialPages

https://en.wikipedia.org/wiki/Special:Search

https://donate.wikimedia.org/?wmf\_source=donate&wmf\_medium=sidebar&wmf\_campaign=en.wikipedia.org&uselang=en

Create account

https://en.wikipedia.org/w/index.php?title=Special:CreateAccount&returnto=Facial+Action+Coding+System

https://en.wikipedia.org/w/index.php?title=Special:UserLogin&returnto=Facial+Action+Coding+System

Personal tools

https://donate.wikimedia.org/?wmf\_source=donate&wmf\_medium=sidebar&wmf\_campaign=en.wikipedia.org&uselang=en

Create account

https://en.wikipedia.org/w/index.php?title=Special:CreateAccount&returnto=Facial+Action+Coding+System

https://en.wikipedia.org/w/index.php?title=Special:UserLogin&returnto=Facial+Action+Coding+System

move to sidebar hide

https://en.wikipedia.org/wiki/Facial\_Action\_Coding\_System

https://en.wikipedia.org/wiki/Facial\_Action\_Coding\_System#Method

https://en.wikipedia.org/wiki/Facial\_Action\_Coding\_System#Uses

#### Toggle Uses subsection

2.1 Baby F.A.C.S.

https://en.wikipedia.org/wiki/Facial\_Action\_Coding\_System#Baby\_F.A.C.S.

2.2 Use in medicine

https://en.wikipedia.org/wiki/Facial\_Action\_Coding\_System#Use\_in\_medicine

2.3 Interspecial applications

https://en.wikipedia.org/wiki/Facial\_Action\_Coding\_System#Interspecial\_applications

2.4 Computer-generated imagery

https://en.wikipedia.org/wiki/Facial\_Action\_Coding\_System#Computer-generated\_imagery

3 Codes for action units

https://en.wikipedia.org/wiki/Facial\_Action\_Coding\_System#Codes\_for\_action\_units

#### Toggle Codes for action units subsection

3.1 Intensity scoring

https://en.wikipedia.org/wiki/Facial\_Action\_Coding\_System#Intensity\_scoring

3.2 Other letter modifiers

https://en.wikipedia.org/wiki/Facial\_Action\_Coding\_System#Other\_letter\_modifiers

3.3 List of A.U.s and A.D.s (with underlying facial muscles)

https://en.wikipedia.org/wiki/Facial\_Action\_Coding\_System#List\_of\_A.U.s\_and\_A.D.s\_(with\_underlying\_facial\_muscles)

3.3.1 Main codes

https://en.wikipedia.org/wiki/Facial\_Action\_Coding\_System#Main\_codes

3.3.2 Head movement codes

https://en.wikipedia.org/wiki/Facial\_Action\_Coding\_System#Head\_movement\_codes

3.3.3 Eye movement codes

https://en.wikipedia.org/wiki/Facial\_Action\_Coding\_System#Eye\_movement\_codes

3.3.4 Visibility codes

https://en.wikipedia.org/wiki/Facial\_Action\_Coding\_System#Visibility\_codes

3.3.5 Gross behavior codes

https://en.wikipedia.org/wiki/Facial\_Action\_Coding\_System#Gross\_behavior\_codes

https://en.wikipedia.org/wiki/Facial\_Action\_Coding\_System#See\_also

5 References

https://en.wikipedia.org/wiki/Facial\_Action\_Coding\_System#References

6 External links

https://en.wikipedia.org/wiki/Facial\_Action\_Coding\_System#External\_links

Toggle the table of contents

Facial Action Coding System

8 languages

https://ca.wikipedia.org/wiki/Facial\_Action\_Coding\_System

https://de.wikipedia.org/wiki/Facial\_Action\_Coding\_System

https://es.wikipedia.org/wiki/Sistema\_de\_Codificaci%C3%B3n\_Facial

https://fa.wikipedia.org/wiki/%D8%B3%DB%8C%D8%B3%D8%AA%D9%85\_%DA%A9%D8%AF%DA%AF%D8%B0%D8%A7%D8%B1%DB%8C\_%D8%AD%D8%B1%DA%A9%D8%A7%D8%AA\_%DA%86%D9%87%D8%B1%D9%87

https://fr.wikipedia.org/wiki/Facial\_action\_coding\_system

https://it.wikipedia.org/wiki/Sistema\_di\_codifica\_delle\_espressioni\_facciali

https://pt.wikipedia.org/wiki/Facial\_Action\_Coding\_System

https://ru.wikipedia.org/wiki/%D0%A1%D0%B8%D1%81%D1%82%D0%B5%D0%BC%D0%B0\_%D0%BA%D0%BE%D0%B4%D0%B8%D1%80%D0%BE%D0%B2%D0%B0%D0%BD%D0%B8%D1%8F\_%D0%BB%D0%B8%D1%86%D0%B5%D0%B2%D1%8B%D1%85\_%D0%B4%D0%B2%D0%B8%D0%B6%D0%B5%D0%BD%D0%B8%D0%B9

https://www.wikidata.org/wiki/Special:EntityPage/Q1391629#sitelinks-wikipedia

https://en.wikipedia.org/wiki/Facial\_Action\_Coding\_System

https://en.wikipedia.org/wiki/Talk:Facial\_Action\_Coding\_System

https://en.wikipedia.org/wiki/Facial\_Action\_Coding\_System

https://en.wikipedia.org/w/index.php?title=Facial\_Action\_Coding\_System&action=edit

View history

https://en.wikipedia.org/w/index.php?title=Facial\_Action\_Coding\_System&action=history

move to sidebar hide

https://en.wikipedia.org/wiki/Facial\_Action\_Coding\_System

https://en.wikipedia.org/w/index.php?title=Facial\_Action\_Coding\_System&action=edit

View history

https://en.wikipedia.org/w/index.php?title=Facial\_Action\_Coding\_System&action=history

What links here

https://en.wikipedia.org/wiki/Special:WhatLinksHere/Facial\_Action\_Coding\_System

Related changes

https://en.wikipedia.org/wiki/Special:RecentChangesLinked/Facial\_Action\_Coding\_System

Upload file

https://en.wikipedia.org/wiki/Wikipedia:File\_Upload\_Wizard

Permanent link

https://en.wikipedia.org/w/index.php?title=Facial\_Action\_Coding\_System&oldid=1346752375

Page information

https://en.wikipedia.org/w/index.php?title=Facial\_Action\_Coding\_System&action=info

Cite this page

https://en.wikipedia.org/w/index.php?title=Special:CiteThisPage&page=Facial\_Action\_Coding\_System&id=1346752375&wpFormIdentifier=titleform

Get shortened URL

https://en.wikipedia.org/w/index.php?title=Special:UrlShortener&url=https%3A%2F%2Fen.wikipedia.org%2Fwiki%2FFacial\_Action\_Coding\_System

https://en.wikipedia.org/wiki/Facial\_Action\_Coding\_System

Edit interlanguage links

https://www.wikidata.org/wiki/Special:EntityPage/Q1391629#sitelinks-wikipedia

Print/export

Download as PDF

https://en.wikipedia.org/w/index.php?title=Special:DownloadAsPdf&page=Facial\_Action\_Coding\_System&action=show-download-screen

Printable version

https://en.wikipedia.org/w/index.php?title=Facial\_Action\_Coding\_System&printable=yes

In other projects

Wikidata item

https://www.wikidata.org/wiki/Special:EntityPage/Q1391629

move to sidebar hide

Birthday mode (Baby Globe)

\[x\] 1 Enabled

Learn more about Birthday mode

https://wikimediafoundation.org/wikipedia25/wikipedia-mascot/?utm\_campaign=wpam&utm\_source=wpam&utm\_medium=wpamen

\[x\] 1 Standard

\[-\] 2 Large

This page always uses small font size

The content is as wide as possible for your browser window.

Color (beta)

\[x\] day Light

\[-\] night Dark

This page is always in light mode.

From Wikipedia, the free encyclopedia

System of classifying human facial movements

Muscles of head and neck

Facial Action Coding System

) is a system to

https://en.wikipedia.org/wiki/Taxonomize

facial movements

https://en.wikipedia.org/wiki/Facial\_expression

by their appearance on the face, based on a system originally developed by a Swedish

https://en.wikipedia.org/wiki/Anatomist

Carl-Herman Hjortsjö

https://en.wikipedia.org/wiki/Carl-Herman\_Hjortsj%C3%B6

https://en.wikipedia.org/wiki/Facial\_Action\_Coding\_System#cite\_note-1

It was later adopted by

https://en.wikipedia.org/wiki/Paul\_Ekman

Wallace V. Friesen

https://en.wikipedia.org/w/index.php?title=Wallace\_V.\_Friesen&action=edit&redlink=1

, and published in 1978.

https://en.wikipedia.org/wiki/Facial\_Action\_Coding\_System#cite\_note-2

Ekman, Friesen, and Joseph C. Hager published a significant update to F.A.C.S. in 2002.

https://en.wikipedia.org/wiki/Facial\_Action\_Coding\_System#cite\_note-3

Movements of individual

facial muscles

https://en.wikipedia.org/wiki/Facial\_muscles

are encoded by the F.A.C.S. from slight different instant changes in facial appearance. It has proven useful to

psychologists

https://en.wikipedia.org/wiki/Psychologist

https://en.wikipedia.org/wiki/Animator

https://en.wikipedia.org/w/index.php?title=Facial\_Action\_Coding\_System&action=edit&section=1

Using the F.A.C.S.,

https://en.wikipedia.org/wiki/Facial\_Action\_Coding\_System#cite\_note-4

human coders can manually code nearly any anatomically possible facial expression, deconstructing it into the specific "action units" (A.U.) and their temporal segments that produced the expression. As A.U.s are independent of any interpretation, they can be used for any higher-order decision-making process including

recognition of basic emotions

https://en.wikipedia.org/wiki/Emotion\_recognition

, or pre-programmed commands for an ambient intelligent environment. The F.A.C.S. manual is over five hundred pages in length and provides the A.U.s, as well as Ekman's interpretation of their meanings.

The F.A.C.S. defines A.U.s as contractions or relaxations of one or more muscles. It also defines a number of "action descriptors", which differ from A.U.s in that the authors of the F.A.C.S. have not specified the muscular basis for the action and have not distinguished specific behaviors as precisely as they have for the A.U.s.

For example, the F.A.C.S. can be used to distinguish two types of

https://en.wikipedia.org/wiki/Smile

as follows:

https://en.wikipedia.org/wiki/Facial\_Action\_Coding\_System#cite\_note-pmid17484588-5

the insincere and voluntary

Pan-Am smile

https://en.wikipedia.org/wiki/Pan-Am\_smile

: contraction of

zygomatic major

the sincere and involuntary

Duchenne smile

https://en.wikipedia.org/wiki/Duchenne\_smile

: contraction of

zygomatic major

and inferior part of

orbicularis oculi

The F.A.C.S. is designed to be self-instructional. People can learn the technique from a number of sources including manuals and workshops,

https://en.wikipedia.org/wiki/Facial\_Action\_Coding\_System#cite\_note-6

and obtain certification through testing.

https://en.wikipedia.org/wiki/Facial\_Action\_Coding\_System#cite\_note-7

Although the labeling of expressions currently requires trained experts, researchers have had some success in using computers to automatically identify the F.A.C.S. codes.

https://en.wikipedia.org/wiki/Facial\_Action\_Coding\_System#cite\_note-8

One obstacle to automatic FACS code recognition is a shortage of manually coded ground truth data.

https://en.wikipedia.org/wiki/Facial\_Action\_Coding\_System#cite\_note-9

https://en.wikipedia.org/w/index.php?title=Facial\_Action\_Coding\_System&action=edit&section=2

Baby F.A.C.S.

https://en.wikipedia.org/w/index.php?title=Facial\_Action\_Coding\_System&action=edit&section=3

Baby F.A.C.S. (Facial Action Coding System for Infants and Young Children)

https://en.wikipedia.org/wiki/Facial\_Action\_Coding\_System#cite\_note-10

is a behavioral coding system that adapts the adult F.A.C.S. to code facial expressions in infants aged 0–2 years. It corresponds to specific underlying facial muscles, tailored to infant facial anatomy and expression patterns.

It was created by Dr. Harriet Oster and colleagues to address the limitations of applying adult F.A.C.S. directly to infants, whose facial musculature, proportions and developmental capabilities differ significantly.

Use in medicine

https://en.wikipedia.org/w/index.php?title=Facial\_Action\_Coding\_System&action=edit&section=4

The use of the F.A.C.S. has been proposed for use in the analysis of

https://en.wikipedia.org/wiki/Clinical\_depression

https://en.wikipedia.org/wiki/Facial\_Action\_Coding\_System#cite\_note-pmid18020726-11

and the measurement of pain in patients unable to express themselves verbally.

https://en.wikipedia.org/wiki/Facial\_Action\_Coding\_System#cite\_note-pmid18028046-12

Interspecial applications

https://en.wikipedia.org/w/index.php?title=Facial\_Action\_Coding\_System&action=edit&section=5

The original F.A.C.S. has been modified to analyze facial movements in several non-human primates, namely

chimpanzees

https://en.wikipedia.org/wiki/Common\_chimpanzee

https://en.wikipedia.org/wiki/Facial\_Action\_Coding\_System#cite\_note-pmid17352572-13

rhesus macaques

https://en.wikipedia.org/wiki/Rhesus\_macaque

https://en.wikipedia.org/wiki/Facial\_Action\_Coding\_System#cite\_note-14

https://en.wikipedia.org/wiki/Gibbon

https://en.wikipedia.org/wiki/Siamang

https://en.wikipedia.org/wiki/Facial\_Action\_Coding\_System#cite\_note-15

and orangutans.

https://en.wikipedia.org/wiki/Facial\_Action\_Coding\_System#cite\_note-16

More recently, it was developed also for domesticated species, including dogs,

https://en.wikipedia.org/wiki/Facial\_Action\_Coding\_System#cite\_note-17

https://en.wikipedia.org/wiki/Facial\_Action\_Coding\_System#cite\_note-18

https://en.wikipedia.org/wiki/Facial\_Action\_Coding\_System#cite\_note-19

Similarly to the human F.A.C.S., the non-human F.A.C.S. has manuals available online for each species with the respective certification tests.

https://en.wikipedia.org/wiki/Facial\_Action\_Coding\_System#cite\_note-20

Thus the F.A.C.S. can be used to compare facial repertoires across species due to its anatomical basis. A study conducted by Vick and others (2006) suggests that the F.A.C.S. can be modified by taking differences in underlying morphology into account. Such considerations enable a comparison of the homologous facial movements present in humans and chimpanzees, to show that the facial expressions of both species result from extremely notable appearance changes. The development of F.A.C.S. tools for different species allows the objective and anatomical study of facial expressions in communicative and emotional contexts. Furthermore, an interspecial analysis of facial expressions can help to answer interesting questions, such as which emotions are uniquely human.

https://en.wikipedia.org/wiki/Facial\_Action\_Coding\_System#cite\_note-21

The Emotional Facial Action Coding System (E.M.F.A.C.S.)

https://en.wikipedia.org/wiki/Facial\_Action\_Coding\_System#cite\_note-22

and the Facial Action Coding System Affect Interpretation Dictionary (F.A.C.S.A.I.D.)

https://en.wikipedia.org/wiki/Facial\_Action\_Coding\_System#cite\_note-23

consider only emotion-related facial actions. Examples of these are:

Action units

1+2+4+5+7+20+26

Computer-generated imagery

https://en.wikipedia.org/w/index.php?title=Facial\_Action\_Coding\_System&action=edit&section=6

F.A.C.S. coding is also used extensively in

computer animation

https://en.wikipedia.org/wiki/Computer\_animation

, in particular for

computer facial animation

https://en.wikipedia.org/wiki/Computer\_facial\_animation

, with facial expressions being expressed as

vector graphics

https://en.wikipedia.org/wiki/Vector\_graphics

https://en.wikipedia.org/wiki/Facial\_Action\_Coding\_System#cite\_note-24

F.A.C.S. vectors are used as weights for

blend shapes

https://en.wikipedia.org/wiki/Morph\_target\_animation

corresponding to each A.U., with the resulting face mesh then being used to render the finished face.

https://en.wikipedia.org/wiki/Facial\_Action\_Coding\_System#cite\_note-25

https://en.wikipedia.org/wiki/Facial\_Action\_Coding\_System#cite\_note-26

Deep-learning

https://en.wikipedia.org/wiki/Deep-learning

techniques can be used to determine the F.A.C.S. vectors from face images obtained during

motion capture acting

https://en.wikipedia.org/wiki/Motion\_capture

facial motion capture

https://en.wikipedia.org/wiki/Facial\_motion\_capture

or other performances.

https://en.wikipedia.org/wiki/Facial\_Action\_Coding\_System#cite\_note-27

Codes for action units

https://en.wikipedia.org/w/index.php?title=Facial\_Action\_Coding\_System&action=edit&section=7

List of muscles in the human body § The muscles of the head

https://en.wikipedia.org/wiki/List\_of\_muscles\_in\_the\_human\_body#The\_muscles\_of\_the\_head

For clarification, the F.A.C.S. is an index of facial expressions, but does not actually provide any biomechanical information about the degree of muscle activation. Though muscle activation is not part of the F.A.C.S., the main muscles involved in the facial expression have been added here.

Action units

(A.U.s) are the fundamental actions of individual muscles or groups of muscles.

Action descriptors

(A.D.s) are unitary movements that may involve the actions of several muscle groups (e.g., a forward‐thrusting movement of the jaw). The muscular basis for these actions has not been specified and specific behaviors have not been distinguished as precisely as for the A.U.s.

For the most accurate annotation, the F.A.C.S. suggests agreement from at least two independent certified F.A.C.S. encoders.

Intensity scoring

https://en.wikipedia.org/w/index.php?title=Facial\_Action\_Coding\_System&action=edit&section=8

Intensities of the F.A.C.S. are annotated by appending letters A–E (for minimal-maximal intensity) to the action unit number (e.g. A.U. 1A is the weakest trace of A.U. 1 and A.U. 1E is the maximum intensity possible for the individual person).

C Marked or pronounced

D Severe or extreme

Other letter modifiers

https://en.wikipedia.org/w/index.php?title=Facial\_Action\_Coding\_System&action=edit&section=9

There are other modifiers present in F.A.C.S. codes for emotional expressions, such as "R" which represents an action that occurs on the right side of the face and "L" for actions which occur on the left. An action which is unilateral (occurs on only one side of the face) but has no specific side is indicated with a "U" and an action which is bilateral but has a stronger side is indicated with an "A" for "asymmetric".

List of A.U.s and A.D.s (with underlying facial muscles)

https://en.wikipedia.org/w/index.php?title=Facial\_Action\_Coding\_System&action=edit&section=10

https://en.wikipedia.org/w/index.php?title=Facial\_Action\_Coding\_System&action=edit&section=11

A.U. number

F.A.C.S. name

Muscular basis

Neutral face

Inner brow raiser

pars medialis

Outer brow raiser

pars lateralis

Brow lowerer

depressor glabellae

depressor supercilii

corrugator supercilii

Upper lid raiser

levator palpebrae superioris

superior tarsal muscle

https://en.wikipedia.org/wiki/Superior\_tarsal\_muscle

Cheek raiser

orbicularis oculi

pars orbitalis

Lid tightener

orbicularis oculi

pars palpebralis

Lips toward each other

orbicularis oris

Nose wrinkler

levator labii superioris alaeque nasi

Upper lip raiser

levator labii superioris

caput infraorbitalis

Nasolabial deepener

zygomaticus minor

Lip corner puller

zygomaticus major

Sharp lip puller

levator anguli oris

(also known as

Lip corner depressor

depressor anguli oris

(also known as

triangularis

Lower lip depressor

depressor labii inferioris

Chin raiser

incisivii labii superioris

incisivii labii inferioris

Tongue show

Lip stretcher

Neck tightener

Lip funneler

orbicularis oris

Lip tightener

orbicularis oris

Lip pressor

orbicularis oris

depressor labii inferioris

, or relaxation of

orbicularis oris

internal pterygoid

https://en.wikipedia.org/wiki/Medial\_pterygoid\_muscle

Mouth stretch

orbicularis oris

Head movement codes

https://en.wikipedia.org/w/index.php?title=Facial\_Action\_Coding\_System&action=edit&section=12

A.U. number

F.A.C.S. name

Head turn left

Head turn right

Head tilt left

Head tilt left

The onset of the symmetrical 14 is immediately preceded or accompanied by a head tilt to the left.

Head tilt right

Head tilt right

The onset of the symmetrical 14 is immediately preceded or accompanied by a head tilt to the right.

Head forward

Head thrust forward

The onset of 17+24 is immediately preceded, accompanied, or followed by a head thrust forward.

Head shake up and down

The onset of 17+24 is immediately preceded, accompanied, or followed by an up-down head shake (nod).

Head shake side to side

The onset of 17+24 is immediately preceded, accompanied, or followed by a side to side head shake.

Head upward and to the side

The onset of the symmetrical 14 is immediately preceded or accompanied by a movement of the head, upward and turned or tilted to either the left or right.

Eye movement codes

https://en.wikipedia.org/w/index.php?title=Facial\_Action\_Coding\_System&action=edit&section=13

A.U. number

F.A.C.S. name

Eyes turn left

The onset of the symmetrical 14 is immediately preceded or accompanied by eye movement to the left.

Eyes turn right

The onset of the symmetrical 14 is immediately preceded or accompanied by eye movement to the right.

https://en.wikipedia.org/wiki/Strabismus

Upward rolling of eyes

The onset of the symmetrical 14 is immediately preceded or accompanied by an upward rolling of the eyes.

Eyes positioned to look at other person

The 4, 5, or 7, alone or in combination, occurs while the eye position is fixed on the other person in the conversation.

Head or eyes look at other person

The onset of the symmetrical 14 or A.U.s 4, 5, and 7, alone or in combination, is immediately preceded or accompanied by a movement of the eyes or of the head and eyes to look at the other person in the conversation.

Visibility codes

https://en.wikipedia.org/w/index.php?title=Facial\_Action\_Coding\_System&action=edit&section=14

A.U. number

F.A.C.S. name

Brows and forehead not visible

Eyes not visible

Lower face not visible

Entire face not visible

Gross behavior codes

https://en.wikipedia.org/w/index.php?title=Facial\_Action\_Coding\_System&action=edit&section=15

These codes are reserved for recording information about gross behaviors that may be relevant to the facial actions that are scored.

A.U. number

F.A.C.S. name

Muscular basis

Jaw sideways

Jaw clencher

\[Cheek\] blow

\[Cheek\] puff

\[Cheek\] suck

\[Tongue\] bulge

Nostril dilator

nasalis (pars alaris)

Nostril compressor

pars transversa

depressor septi nasi

levator palpebrae superioris

(relaxation)

orbicularis oculi muscle

Eyes closed

relaxation of

levator palpebrae superioris

corrugator supercilii

orbicularis oculi

relaxation of

levator palpebrae superioris

; contraction of

orbicularis oculi

pars palpebralis

orbicularis oculi

Shoulder shrug

Head shake back and forth

Head nod up and down

Partial flash

Shiver/tremble

Fast up-down look

https://en.wikipedia.org/w/index.php?title=Facial\_Action\_Coding\_System&action=edit&section=16

Computer facial animation

https://en.wikipedia.org/wiki/Computer\_facial\_animation

Emotion classification

https://en.wikipedia.org/wiki/Emotion\_classification

Facial electromyography

https://en.wikipedia.org/wiki/Facial\_electromyography

Facial feedback hypothesis

https://en.wikipedia.org/wiki/Facial\_feedback\_hypothesis

Facial muscles

https://en.wikipedia.org/wiki/Facial\_muscles

Microexpression

https://en.wikipedia.org/wiki/Microexpression

https://en.wikipedia.org/w/index.php?title=Facial\_Action\_Coding\_System&action=edit&section=17

Hjortsjö CH (1969).

Man's face and mimic language

https://books.google.com/books?id=BakQAQAAIAAJ

. free download:

Carl-Herman Hjortsjö, Man's face and mimic language"

http://diglib.uibk.ac.at/ulbtirol/content/titleinfo/782346

https://web.archive.org/web/20220806115847/https://diglib.uibk.ac.at/ulbtirol/content/titleinfo/782346

2022-08-06 at the

Wayback Machine

https://en.wikipedia.org/wiki/Wayback\_Machine

Ekman P, Friesen W (1978).

Facial Action Coding System: A Technique for the Measurement of Facial Movement

. Palo Alto: Consulting Psychologists Press.

Ekman P, Friesen WV, Hager JC (2002).

Facial Action Coding System: The Manual on CD ROM

. Salt Lake City: A Human Face.

Freitas-Magalhães (2012). "Microexpression and macroexpression". In Ramachandran VS (ed.).

Encyclopedia of Human Behavior

. Vol. 2. Oxford: Elsevier/Academic Press. pp. 173– 183.

https://en.wikipedia.org/wiki/ISBN\_(identifier)

978-0-12-375000-6

https://en.wikipedia.org/wiki/Special:BookSources/978-0-12-375000-6

Del Giudice M, Colle L (May 2007). "Differences between children and adults in the recognition of enjoyment smiles".

Developmental Psychology

(3): 796– 803.

https://en.wikipedia.org/wiki/Doi\_(identifier)

10.1037/0012-1649.43.3.796

https://doi.org/10.1037%2F0012-1649.43.3.796

https://en.wikipedia.org/wiki/PMID\_(identifier)

https://pubmed.ncbi.nlm.nih.gov/17484588

Rosenberg EL.

"Example and web site of one teaching professional"

https://web.archive.org/web/20090206232546/http://www.erikarosenberg.com/FACS.html

. Archived from

the original

http://www.erikarosenberg.com/FACS.html

on 2009-02-06. Retrieved 2009-02-04.

"Facial Action Coding System"

https://www.paulekman.com/facial-action-coding-system/

Paul Ekman Group

. Retrieved 2019-10-23.

Facial Action Coding System.

http://www.cs.wpi.edu/~matt/courses/cs563/talks/face\_anim/ekman.html

Retrieved July 21, 2007.

Song, Juan; Liu, Zhilei (10 Mar 2023). "Self-supervised Facial Action Unit Detection with Region and Relation Learning".

https://en.wikipedia.org/wiki/ArXiv\_(identifier)

https://arxiv.org/abs/2303.05708

https://arxiv.org/archive/cs.CV

Oster, Harriet (2006).

Baby FACS: Facial Action Coding System for Infants and Young Children

. New York: Unpublished monograph and coding manual. New York University.

Reed LI, Sayette MA, Cohn JF (November 2007). "Impact of depression on response to comedy: a dynamic facial coding analysis".

Journal of Abnormal Psychology

(4): 804– 9.

https://en.wikipedia.org/wiki/CiteSeerX\_(identifier)

10.1.1.307.6950

https://citeseerx.ist.psu.edu/viewdoc/summary?doi=10.1.1.307.6950

https://en.wikipedia.org/wiki/Doi\_(identifier)

10.1037/0021-843X.116.4.804

https://doi.org/10.1037%2F0021-843X.116.4.804

https://en.wikipedia.org/wiki/PMID\_(identifier)

https://pubmed.ncbi.nlm.nih.gov/18020726

Lints-Martindale AC, Hadjistavropoulos T, Barber B, Gibson SJ (2007).

"A psychophysical investigation of the facial action coding system as an index of pain variability among older adults with and without Alzheimer's disease"

https://doi.org/10.1111%2Fj.1526-4637.2007.00358.x

Pain Medicine

(8): 678– 89.

https://en.wikipedia.org/wiki/Doi\_(identifier)

10.1111/j.1526-4637.2007.00358.x

https://doi.org/10.1111%2Fj.1526-4637.2007.00358.x

https://en.wikipedia.org/wiki/PMID\_(identifier)

https://pubmed.ncbi.nlm.nih.gov/18028046

Parr LA, Waller BM, Vick SJ, Bard KA (February 2007).

"Classifying chimpanzee facial expressions using muscle action"

https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2826116

(1): 172– 81.

https://en.wikipedia.org/wiki/Doi\_(identifier)

10.1037/1528-3542.7.1.172

https://doi.org/10.1037%2F1528-3542.7.1.172

https://en.wikipedia.org/wiki/PMC\_(identifier)

https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2826116

https://en.wikipedia.org/wiki/PMID\_(identifier)

https://pubmed.ncbi.nlm.nih.gov/17352572

Parr LA, Waller BM, Burrows AM, Gothard KM, Vick SJ (December 2010).

"Brief communication: MaqFACS: A muscle-based facial movement coding system for the rhesus macaque"

https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2988871

American Journal of Physical Anthropology

(4): 625– 30.

https://en.wikipedia.org/wiki/Bibcode\_(identifier)

2010AJPA..143..625P

https://ui.adsabs.harvard.edu/abs/2010AJPA..143..625P

https://en.wikipedia.org/wiki/Doi\_(identifier)

10.1002/ajpa.21401

https://doi.org/10.1002%2Fajpa.21401

https://en.wikipedia.org/wiki/PMC\_(identifier)

https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2988871

https://en.wikipedia.org/wiki/PMID\_(identifier)

https://pubmed.ncbi.nlm.nih.gov/20872742

Waller BM, Lembeck M, Kuchenbuch P, Burrows AM, Liebal K (2012). "GibbonFACS: A Muscle-Based Facial Movement Coding System for Hylobatids".

International Journal of Primatology

(4): 809– 821.

https://en.wikipedia.org/wiki/Doi\_(identifier)

10.1007/s10764-012-9611-6

https://doi.org/10.1007%2Fs10764-012-9611-6

https://en.wikipedia.org/wiki/S2CID\_(identifier)

https://api.semanticscholar.org/CorpusID:18321096

Caeiro CC, Waller BM, Zimmermann E, Burrows AM, Davila-Ross M (2012).

"OrangFACS: A Muscle-Based Facial Movement Coding System for Orangutans ( Pongo spp.)"

http://irep.ntu.ac.uk/id/eprint/41473/1/1383920\_Waller.pdf

International Journal of Primatology

: 115– 129.

https://en.wikipedia.org/wiki/Doi\_(identifier)

10.1007/s10764-012-9652-x

https://doi.org/10.1007%2Fs10764-012-9652-x

https://en.wikipedia.org/wiki/S2CID\_(identifier)

https://api.semanticscholar.org/CorpusID:17612028

Waller BM, Peirce K, Caeiro CC, Scheider L, Burrows AM, McCune S, Kaminski J (2013).

"Paedomorphic facial expressions give dogs a selective advantage"

https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3873274

(12) e82686.

https://en.wikipedia.org/wiki/Bibcode\_(identifier)

2013PLoSO...882686W

https://ui.adsabs.harvard.edu/abs/2013PLoSO...882686W

https://en.wikipedia.org/wiki/Doi\_(identifier)

10.1371/journal.pone.0082686

https://doi.org/10.1371%2Fjournal.pone.0082686

https://en.wikipedia.org/wiki/PMC\_(identifier)

https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3873274

https://en.wikipedia.org/wiki/PMID\_(identifier)

https://pubmed.ncbi.nlm.nih.gov/24386109

Wathan J, Burrows AM, Waller BM, McComb K (2015-08-05).

"EquiFACS: The Equine Facial Action Coding System"

https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4526551

(8) e0131738.

https://en.wikipedia.org/wiki/Bibcode\_(identifier)

2015PLoSO..1031738W

https://ui.adsabs.harvard.edu/abs/2015PLoSO..1031738W

https://en.wikipedia.org/wiki/Doi\_(identifier)

10.1371/journal.pone.0131738

https://doi.org/10.1371%2Fjournal.pone.0131738

https://en.wikipedia.org/wiki/PMC\_(identifier)

https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4526551

https://en.wikipedia.org/wiki/PMID\_(identifier)

https://pubmed.ncbi.nlm.nih.gov/26244573

Caeiro CC, Burrows AM, Waller BM (2017-04-01).

"Development and application of CatFACS: Are human cat adopters influenced by cat facial expressions?"

https://web.archive.org/web/20180721154529/http://eprints.lincoln.ac.uk/25940/1/25940%20Proof\_APPLAN\_4392.pdf

Applied Animal Behaviour Science

https://en.wikipedia.org/wiki/Doi\_(identifier)

10.1016/j.applanim.2017.01.005

https://doi.org/10.1016%2Fj.applanim.2017.01.005

https://en.wikipedia.org/wiki/ISSN\_(identifier)

https://search.worldcat.org/issn/0168-1591

. Archived from

the original

http://eprints.lincoln.ac.uk/25940/1/25940%20Proof\_APPLAN\_4392.pdf

(PDF) on 2018-07-21. Retrieved 2019-11-07.

http://animalfacs.com/

animalfacs.com

. Retrieved 2019-10-23.

Vick SJ, Waller BM, Parr LA, Smith Pasqualini MC, Bard KA (March 2007).

"A Cross-species Comparison of Facial Morphology and Movement in Humans and Chimpanzees Using the Facial Action Coding System (FACS)"

https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3008553

Journal of Nonverbal Behavior

(1): 1– 20.

https://en.wikipedia.org/wiki/Doi\_(identifier)

10.1007/s10919-006-0017-z

https://doi.org/10.1007%2Fs10919-006-0017-z

https://en.wikipedia.org/wiki/PMC\_(identifier)

https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3008553

https://en.wikipedia.org/wiki/PMID\_(identifier)

https://pubmed.ncbi.nlm.nih.gov/21188285

Friesen W, Ekman P (1983),

EMFACS-7: Emotional Facial Action Coding System. Unpublished manuscript

, vol. 2, University of California at San Francisco, p. 1

"Facial Action Coding System Affect Interpretation Dictionary (FACSAID)"

https://web.archive.org/web/20110520164308/http://face-and-emotion.com/dataface/facsaid/description.jsp

. Archived from

the original

http://www.face-and-emotion.com/dataface/facsaid/description.jsp

on 2011-05-20. Retrieved 2011-02-23.

Walsh, Joseph (2016-12-16).

"Rogue One: the CGI resurrection of Peter Cushing is thrilling – but is it right?"

https://www.theguardian.com/film/filmblog/2016/dec/16/rogue-one-star-wars-cgi-resurrection-peter-cushing

The Guardian

https://en.wikipedia.org/wiki/ISSN\_(identifier)

https://search.worldcat.org/issn/0261-3077

. Retrieved 2023-10-23.

Gilbert, Michaël; Demarchi, Samuel; Urdapilleta, Isabel (October 2021).

"FACSHuman, a software program for creating experimental material by modeling 3D facial expressions"

https://link.springer.com/10.3758/s13428-021-01559-9

Behavior Research Methods

(5): 2252– 2272.

https://en.wikipedia.org/wiki/Doi\_(identifier)

10.3758/s13428-021-01559-9

https://doi.org/10.3758%2Fs13428-021-01559-9

https://en.wikipedia.org/wiki/ISSN\_(identifier)

https://search.worldcat.org/issn/1554-3528

https://en.wikipedia.org/wiki/PMID\_(identifier)

https://pubmed.ncbi.nlm.nih.gov/33825127

"Discover how to create FACS facial blendshapes in Maya | CG Channel"

https://www.cgchannel.com/2021/04/discover-how-to-create-facs-facial-blendshapes-in-maya/

. Retrieved 2023-10-23.

Gudi, Amogh; Tasli, H. Emrah; Den Uyl, Tim M.; Maroulis, Andreas (2015). "Deep learning based FACS Action Unit occurrence and intensity estimation".

2015 11th IEEE International Conference and Workshops on Automatic Face and Gesture Recognition (FG)

. pp. 1– 5.

https://en.wikipedia.org/wiki/Doi\_(identifier)

10.1109/FG.2015.7284873

https://doi.org/10.1109%2FFG.2015.7284873

https://en.wikipedia.org/wiki/ISBN\_(identifier)

978-1-4799-6026-2

https://en.wikipedia.org/wiki/Special:BookSources/978-1-4799-6026-2

https://en.wikipedia.org/wiki/S2CID\_(identifier)

https://api.semanticscholar.org/CorpusID:6283665

External links

https://en.wikipedia.org/w/index.php?title=Facial\_Action\_Coding\_System&action=edit&section=18

Paul Ekman's articles relating to F.A.C.S.

https://web.archive.org/web/20150324015937/https://www.paulekman.com/research/

Paul Ekman's Facial Action Coding System (F.A.C.S.)

https://web.archive.org/web/20080606005626/http://www.face-and-emotion.com/dataface/facs/description.jsp

More information on the different animal F.A.C.S. projects

http://www.animalfacs.com/

New Yorker article discussing F.A.C.S.

https://www.newyorker.com/magazine/2002/08/05/the-naked-face

Details from 1978 edition of F.A.C.S.

http://www-2.cs.cmu.edu/afs/cs/project/face/www/facs.htm

download of

Carl-Herman Hjortsjö, Man's face and mimic language"

http://diglib.uibk.ac.at/ulbtirol/content/titleinfo/782346

https://web.archive.org/web/20220806115847/https://diglib.uibk.ac.at/ulbtirol/content/titleinfo/782346

2022-08-06 at the

Wayback Machine

https://en.wikipedia.org/wiki/Wayback\_Machine

(the original Swedish title of the book is: "Människans ansikte och mimiska språket". The correct translation would be: "Man's face and facial language")

https://en.wikipedia.org/wiki/Template:Nonverbal\_communication

https://en.wikipedia.org/wiki/Template\_talk:Nonverbal\_communication

https://en.wikipedia.org/wiki/Special:EditPage/Template:Nonverbal\_communication

Nonverbal communication

https://en.wikipedia.org/wiki/Nonverbal\_communication

https://en.wikipedia.org/wiki/Modality\_(semiotics)

https://en.wikipedia.org/wiki/Blushing

Body language

https://en.wikipedia.org/wiki/Body\_language

https://en.wikipedia.org/wiki/Kinesics

Body-to-body communication

https://en.wikipedia.org/wiki/Body-to-body\_communication

Facial expression

https://en.wikipedia.org/wiki/Facial\_expression

Facial Action Coding System

https://en.wikipedia.org/wiki/Facial\_Action\_Coding\_System

Microexpression

https://en.wikipedia.org/wiki/Microexpression

https://en.wikipedia.org/wiki/Gesture

https://en.wikipedia.org/wiki/List\_of\_gestures

Speech-independent gestures

https://en.wikipedia.org/wiki/Speech-independent\_gestures

Haptic communication

https://en.wikipedia.org/wiki/Haptic\_communication

https://en.wikipedia.org/wiki/Imitation

Interpersonal synchrony

https://en.wikipedia.org/wiki/Synchronization#Human\_movement

https://en.wikipedia.org/wiki/Laughter

https://en.wikipedia.org/wiki/Oculesics

Eye contact

https://en.wikipedia.org/wiki/Eye\_contact

Pupil dilation

https://en.wikipedia.org/wiki/Pupillary\_response

https://en.wikipedia.org/wiki/Olfactic\_communication

https://en.wikipedia.org/wiki/Posture\_(psychology)

https://en.wikipedia.org/wiki/Proxemics

https://en.wikipedia.org/wiki/Speech

https://en.wikipedia.org/wiki/Affect\_(linguistics)

Emotional prosody

https://en.wikipedia.org/wiki/Emotional\_prosody

Paralanguage

https://en.wikipedia.org/wiki/Paralanguage

https://en.wikipedia.org/wiki/Intonation\_(linguistics)

https://en.wikipedia.org/wiki/Loudness

https://en.wikipedia.org/wiki/Prosody\_(linguistics)

https://en.wikipedia.org/wiki/Rhythm

https://en.wikipedia.org/wiki/Stress\_(linguistics)

https://en.wikipedia.org/wiki/Tone\_(linguistics)

Voice quality

https://en.wikipedia.org/wiki/Phonation

Social context

https://en.wikipedia.org/wiki/Social\_environment

https://en.wikipedia.org/wiki/Chronemics

Conventions

https://en.wikipedia.org/wiki/Convention\_(norm)

Display rules

https://en.wikipedia.org/wiki/Display\_rules

https://en.wikipedia.org/wiki/Habitus\_(sociology)

High-context and low-context cultures

https://en.wikipedia.org/wiki/High-context\_and\_low-context\_cultures

Interpersonal relationship

https://en.wikipedia.org/wiki/Interpersonal\_relationship

Social norm

https://en.wikipedia.org/wiki/Social\_norm

https://en.wikipedia.org/wiki/Emoticon

https://en.wikipedia.org/wiki/Smiley

One-bit message

https://en.wikipedia.org/wiki/One-bit\_message

Missed call

https://en.wikipedia.org/wiki/Missed\_call

Silent service code

https://en.wikipedia.org/wiki/Silent\_service\_code

Unconscious

https://en.wikipedia.org/wiki/Unconscious\_communication

Microexpression

https://en.wikipedia.org/wiki/Microexpression

Non-verbal leakage

https://en.wikipedia.org/wiki/Non-verbal\_leakage

Multi-faceted

Affect display

https://en.wikipedia.org/wiki/Affect\_display

https://en.wikipedia.org/wiki/Deception

Emotion recognition

https://en.wikipedia.org/wiki/Emotion\_recognition

First impression

https://en.wikipedia.org/wiki/First\_impression\_(psychology)

https://en.wikipedia.org/wiki/Intimate\_relationship

show Broader concepts

Cognitive academic language proficiency

https://en.wikipedia.org/wiki/Cognitive\_academic\_language\_proficiency

Communication

https://en.wikipedia.org/wiki/Communication

Emotional intelligence

https://en.wikipedia.org/wiki/Emotional\_intelligence

https://en.wikipedia.org/wiki/Nunchi

People skills

https://en.wikipedia.org/wiki/People\_skills

https://en.wikipedia.org/wiki/Semiotics

Social behavior

https://en.wikipedia.org/wiki/Social\_behavior

Social competence

https://en.wikipedia.org/wiki/Social\_competence

https://en.wikipedia.org/wiki/Social\_cue

Social skills

https://en.wikipedia.org/wiki/Social\_skills

https://en.wikipedia.org/wiki/Unsaid

Further information

https://en.wikipedia.org/wiki/Aprosodia

Asperger syndrome

https://en.wikipedia.org/wiki/Asperger\_syndrome

https://en.wikipedia.org/wiki/Autism

https://en.wikipedia.org/wiki/Fragile\_X\_syndrome

Pervasive developmental disorder not otherwise specified

https://en.wikipedia.org/wiki/Pervasive\_developmental\_disorder\_not\_otherwise\_specified

Childhood disintegrative disorder

https://en.wikipedia.org/wiki/Childhood\_disintegrative\_disorder

Rett syndrome

https://en.wikipedia.org/wiki/Rett\_syndrome

https://en.wikipedia.org/wiki/Dyssemia

Nonverbal learning disorder

https://en.wikipedia.org/wiki/Nonverbal\_learning\_disorder

Social (pragmatic) communication disorder

https://en.wikipedia.org/wiki/Social\_(pragmatic)\_communication\_disorder

Neuroanatomy

https://en.wikipedia.org/wiki/Neuroanatomy

Limbic system

https://en.wikipedia.org/wiki/Limbic\_system

Limbic lobe

https://en.wikipedia.org/wiki/Limbic\_lobe

Mirror neuron

https://en.wikipedia.org/wiki/Mirror\_neuron

Applications

Cold reading

https://en.wikipedia.org/wiki/Cold\_reading

Lie detection

https://en.wikipedia.org/wiki/Lie\_detection

Freudian slip

https://en.wikipedia.org/wiki/Freudian\_slip

https://en.wikipedia.org/wiki/Tell\_(poker)

Targeted advertising

https://en.wikipedia.org/wiki/Advertising\_research

Computer processing of body language

https://en.wikipedia.org/wiki/Computer\_processing\_of\_body\_language

Emotion recognition in conversation

https://en.wikipedia.org/wiki/Emotion\_recognition\_in\_conversation

Gesture recognition

https://en.wikipedia.org/wiki/Gesture\_recognition

List of facial expression databases

https://en.wikipedia.org/wiki/List\_of\_facial\_expression\_databases

Sentiment analysis

https://en.wikipedia.org/wiki/Sentiment\_analysis

Ray Birdwhistell

https://en.wikipedia.org/wiki/Ray\_Birdwhistell

Charles Darwin

https://en.wikipedia.org/wiki/Charles\_Darwin

https://en.wikipedia.org/wiki/Paul\_Ekman

Animal communication

https://en.wikipedia.org/wiki/Animal\_communication

Behavioral communication

https://en.wikipedia.org/wiki/Behavioral\_communication

https://en.wikipedia.org/wiki/Aggression

https://en.wikipedia.org/wiki/Assertiveness

https://en.wikipedia.org/wiki/Deference

Passive-aggressive

https://en.wikipedia.org/wiki/Passive-aggressive\_behavior

Impression management

https://en.wikipedia.org/wiki/Impression\_management

Meta-communication

https://en.wikipedia.org/wiki/Meta-communication

Monastic sign lexicons

https://en.wikipedia.org/wiki/Monastic\_sign\_languages

Verbal communication

https://en.wikipedia.org/wiki/Linguistics

Manual-tactile verbal

Sign language

https://en.wikipedia.org/wiki/Sign\_language

Tactile signing

https://en.wikipedia.org/wiki/Tactile\_signing

https://en.wikipedia.org/wiki/Tadoma

Art and literature

https://en.wikipedia.org/wiki/Mime\_artist

Mimoplastic art

https://en.wikipedia.org/wiki/Mimoplastic\_art

https://en.wikipedia.org/wiki/Subtext

Retrieved from "

https://en.wikipedia.org/w/index.php?title=Facial\_Action\_Coding\_System&oldid=1346752375

https://en.wikipedia.org/w/index.php?title=Facial\_Action\_Coding\_System&oldid=1346752375

https://en.wikipedia.org/wiki/Help:Category

Facial expressions

https://en.wikipedia.org/wiki/Category:Facial\_expressions

https://en.wikipedia.org/wiki/Category:Encodings

Anatomical simulation

https://en.wikipedia.org/wiki/Category:Anatomical\_simulation

Animal communication

https://en.wikipedia.org/wiki/Category:Animal\_communication

1978 introductions

https://en.wikipedia.org/wiki/Category:1978\_introductions

#### Hidden categories:

Webarchive template wayback links

https://en.wikipedia.org/wiki/Category:Webarchive\_template\_wayback\_links

Articles with short description

https://en.wikipedia.org/wiki/Category:Articles\_with\_short\_description

Short description is different from Wikidata

https://en.wikipedia.org/wiki/Category:Short\_description\_is\_different\_from\_Wikidata

This page was last edited on 2 April 2026, at 17:43 (UTC).

Text is available under the

Creative Commons Attribution-ShareAlike 4.0 License

https://en.wikipedia.org/wiki/Wikipedia:Text\_of\_the\_Creative\_Commons\_Attribution-ShareAlike\_4.0\_International\_License

; additional terms may apply. By using this site, you agree to the

Terms of Use

https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Terms\_of\_Use

Privacy Policy

https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Privacy\_policy

. Wikipedia® is a registered trademark of the

Wikimedia Foundation, Inc.

https://wikimediafoundation.org/

, a non-profit organization.

Privacy policy

https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Privacy\_policy

About Wikipedia

https://en.wikipedia.org/wiki/Wikipedia:About

Disclaimers

https://en.wikipedia.org/wiki/Wikipedia:General\_disclaimer

Contact Wikipedia

https://en.wikipedia.org/wiki/Wikipedia:Contact\_us

Legal & safety contacts

https://foundation.wikimedia.org/wiki/Special:MyLanguage/Legal:Wikimedia\_Foundation\_Legal\_and\_Safety\_Contact\_Information

Code of Conduct

https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Universal\_Code\_of\_Conduct

https://developer.wikimedia.org/

https://stats.wikimedia.org/#/en.wikipedia.org

Cookie statement

https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Cookie\_statement

Mobile view

https://en.wikipedia.org/w/index.php?title=Facial\_Action\_Coding\_System&mobileaction=toggle\_view\_mobile

Toggle the table of contents

Facial Action Coding System

8 languages

https://en.wikipedia.org/wiki/Facial\_Action\_Coding\_System

https://en.wikipedia.org/wiki/Facial\_Action\_Coding\_System?action=edit

