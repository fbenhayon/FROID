# https://site.cfp.org.br/wp-content/uploads/2025/12/3699.1___ANEXO_REF_AO_OFICIO_N__009_20225___FENAPSI.pdf

Psicomotricidade individual Psicomotricidade em grupo Problemas de aprendizagem individual Problemas de aprendizagem em grupo Psicoterapia individual Psicoterapia em casal Psicoterapia familiar Psicoterapia em grupo Ludoterapia individual Ludoterapia em grupo Terapia psicomotora individual Terapia psicomotora em grupo

Assessoria em Psicologia

Orientação e Psicopedagógica

Orientação e Seleção Profissional Limite Inferior

Limite Inferior

Limite Inferior

Limite Inferior

Limite Inferior

Tabela de Referência Nacional de Honorários dos Psicólogos em Reais (R$) Valores Atualizados pelo INPC-IBGE até Junho de 2025\* para Vigência em 1º Julho/2025

Diagnóstico Psicológico Limite Inferior Limite Média

Limite Média

Limite Média

Limite Média

Limite Média

Limite Média

Realização de pesquisas Planejamento psicopedagógico Orientação psicopedagógico Preparação para aposentadoria

Orientação Vocacional Recrutamento e seleção de pessoal Elaboração de instrumentos psicológicos Desenvolvimento de projetos relativos ao trabalho Identificação de necessidades humanas Partic. em prog. Educacionais, culturais, recretativos Orientação e acompanhamento Orientação e encaminhamento de empregados Avaliação de programa de treinamento Orientação e Treinamento/ Desenvolvimento Desligamento de empregados Preparação para aposentadoria

Acompanhamento psicológico da gravidez, parto e puerperio Acompanhamento psicológico da gravidez em grupo Acompanhamento psicoterapêutico Acompanhamento psicológico de deficientes Acompanhamento psicológico de idosos Acompanhamento e reabilitação profissional

Consultoria empresarial Realização de pesquisa Movimentação de pessoal Supervisão de atividades psicológicas Assessorias a instituições escolares

Consulta Psicológica Anamnese Elaboração de perfil profissiográfico Avaliação de desempenho escolar e aprendizagem Avaliação Psicológica Avaliação das características psicológicas esportivas Avaliação de prontidão para alfabetização Avaliação de nível intelectual Avaliação Psicomotora Avaliação Psicomotora Relacionada ao Grafismo Avaliação das características da personalidade Avaliação da estrutura e dinâmica da personalidade Entrevista devolutiva Observação de campo com visita escolar e domiciliar Atuação junto à comunidade Realização de exames psicológicos (psicotécnicos) Realização de avaliação psicológica p\ Carteira Nacional de Habilitação Realização de avaliação psicológica p\ concessão de registro e/ou porte de arma de fogo

225,58 225,58 193,37 193,37 257,81 225,58 225,58 193,37 193,37 193,37 193,37 225,58 225,58 238,45 112,81 141,82 209,26 418,33

225,58 174,03 161,15 135,34 128,89 128,89 177,29 128,89 193,37 161,15 161,15 257,81

193,37 128,89 193,37 257,81

193,37 161,15 193,37 190,11 225,58 257,81 257,81 186,93 193,37 177,29 193,37 161,15

257,81 193,37 290,07 193,37 225,58 128,89

Fonte: CFP /Fenapsi

306,10 193,37 273,93 270,73 193,37

337,17 326,64 333,04 332,41 322,28 339,49 337,00 342,64 336,22 332,85 363,61 377,35 324,95 322,28 269,04 264,50 261,58 697,22

322,28 322,28 380,48 456,39 392,86 371,65 319,43 309,03 447,93 461,44 305,14 386,72

290,07 351,48 294,10 386,72

278,80 241,32 275,25 256,06 326,61 351,78 411,86 299,71 292,69 277,88 275,10 242,13

350,96 335,70 463,33 278,38 319,03 322,28

631,56 322,28 506,38 422,98 370,69

386,72 386,72 451,25 386,72 422,15 418,94 418,94 386,72 386,72 386,72 399,59 425,38 386,72 386,72 386,72 386,72 313,88 976,09

451,25 451,25 515,65 564,03 457,63 515,65 422,15 393,19 534,97 515,65 418,94 580,09

386,72 386,72 354,44 580,09

322,28 322,28 322,28 322,28 386,72 515,65 515,65 386,72 386,72 354,44 325,45 322,28

418,94 370,61 547,92 322,28 386,72 451,25

709,06 515,65 644,60 515,65 473,78

Acompanhamento e Orientação Psicológica

Solução de Problemas Psicológicos

