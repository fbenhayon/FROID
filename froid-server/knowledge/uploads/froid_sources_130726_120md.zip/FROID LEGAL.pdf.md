# FROID LEGAL.pdf

Frequency Recognition of Internal Dynamics

Implicações Legais, Disclaimers Obrigatórios

e Requisitos de Segurança Jurídica

Análise regulatória completa: LGPD, HIPAA, GDPR, CFP, CFM

Termos de consentimento, disclaimers e políticas obrigatórias

Versão 1.0 — Abril 2026 — Documento Confidencial

ATENÇÃO: Este documento não constitui assessoria jurídica. Recomenda-se revisão por advogado especializado antes da implementação.

FROID — Implicações Legais e Disclaimers

Confidencial  |  Pág. 2

1. Panorama Regulatório Aplicável ao FROID

O sistema FROID opera na interseção de três domínios jurídicos de alta sensibilidade: saúde mental, inteligência artificial e dados biométricos. Esta combinação exige conformidade simultânea com múltiplos marcos regulatórios, sendo o não cumprimento sujeito a sanções administrativas, civis e potencialmente criminais.

1.1 Legislações Aplicáveis

Legislação Jurisdição Aplicação ao FROID Sanções

LGPD (Lei 13.709/2018)

Brasil Dados de saúde mental são dados sensíveis (art. 5º, II). Gravações de voz/vídeo e dados biométricos faciais exigem consentimento específico e destacado (art. 11, I)

Multa de até 2% do faturamento, limitada a R$ 50 milhões por infração. Suspensão do banco de dados

HIPAA (1996) EUA PHI (Protected Health Information) inclui todos os dados gerados pelo FROID. Exige BAA com todos os fornecedores de IA

Multas de US$ 100 a US$ 50.000 por violação, até US$ 1,5 milhão/ano. Penalidades criminais possíveis

GDPR (2016/679)

União Europeia Dados de saúde são categoria especial (art. 9). Requer DPIA obrigatório. Direito à explicação de decisões automatizadas (art. 22)

Até €20 milhões ou 4% do faturamento global

Código de Ética CFP (Res. 10/2005)

Brasil Sigilo profissional absoluto (art. 9º). Responsabilidade do psicólogo sobre ferramentas tecnológicas utilizadas

Advertência, multa, censura pública, suspensão (até 30 dias) ou cassação do registro

Res. CFP 9/2024 (TDICs)

Brasil Regulamenta uso de tecnologias digitais na psicologia. Obriga especificar recursos tecnológicos e garantir sigilo (art. 7º, par. único)

Sanções disciplinares do CRP

Res. CFP 13/2022 (Psicoterapia)

Brasil Gravação de sessões exige consentimento livre, prévio, informado e por escrito (art. 11). Vedado uso para finalidades alheias

Sanções disciplinares do CRP

Lei 14.510/2022 (Telessaúde)

Brasil Autoriza telessaúde com autonomia profissional e consentimento. Aplicável a consultas psiquiátricas remotas

Conforme regulamentação CFM/CFP

FROID — Implicações Legais e Disclaimers

Confidencial  |  Pág. 3

CRM/CFM (Resoluções)

Brasil Para psiquiatras: regulamentação de telemedicina, prontuário eletrônico e sigilo médico

Sanções do CRM estadual

Marco Civil da Internet (Lei 12.965/2014)

Brasil Registros de acesso armazenados por 6 meses. Veda análise de conteúdo sem consentimento

Sanções do art. 12

Código de Defesa do Consumidor

Brasil Relação de consumo com paciente-cliente. Informação clara sobre riscos e limitações

Sanções do PROCON + responsa- bilidade civil objetiva

FROID — Implicações Legais e Disclaimers

Confidencial  |  Pág. 4

2. Implicações Legais Específicas do FROID
2.1 Dados de Saúde Mental como Dados Sensíveis

A LGPD classifica expressamente dados relativos à saúde como dados pessoais sensíveis (art. 5º, II), submetendo-os a regime jurídico especial. O FROID processa simultaneamente múltiplas categorias de dados sensíveis:

Dados de saúde mental: avaliações emocionais, índices psicológicos, relatórios clínicos

Dados biométricos: mapeamento facial (468 landmarks), impressão vocal (frequências, timbre), padrões de expressão facial

Gravações de áudio e vídeo: conteúdo verbal de sessões terapêuticas

Transcrições: texto completo das sessões com identificação de interlocutores

IMPACTO: Todos esses dados exigem consentimento específico e destacado (art. 11, I, LGPD), separado do consentimento geral de tratamento, para cada finalidade distinta de processamento.

2.2 Gravação de Sessões Terapêuticas

A Resolução CFP 13/2022 (art. 11) estabelece que a gravação de sessões de psicoterapia, por áudio ou vídeo, deve ser consentida em caráter livre, prévio, informado e por escrito. A gravação deve ser justificada pela finalidade ou método de trabalho e deve garantir o sigilo. O uso para finalidades alheias às previamente estabelecidas é vedado.

OBRIGAÇÃO CRÍTICA: O FROID não pode iniciar nenhuma captura de áudio, vídeo ou análise facial sem que o consentimento específico, por escrito, tenha sido obtido e registrado no sistema ANTES do início da sessão.

2.3 Uso de Inteligência Artificial na Prática Psicológica

O CFP publicou em 2025 a Cartilha “Inteligência Artificial na Psicologia: guia para uma prática ética e responsável” e uma Nota de Posicionamento que estabelecem princípios fundamentais:

A IA não substitui o juízo técnico ou ético do psicólogo — apenas apoia

A responsabilidade clínica permanece integralmente com o profissional

A confidencialidade deve ser plenamente preservada, incluindo armazenamento e compartilhamento

O paciente tem direito de saber que IA está sendo utilizada e como

Os dados não podem ser usados para treinamento de IA sem consentimento explícito e anônimo

2.4 Envio de Dados a APIs Externas

O FROID envia dados de pacientes a provedores externos de IA (Hume AI, OpenAI Whisper, Anthropic Claude). Cada envio constitui compartilhamento de dados sensíveis e exige:

BAA (Business Associate Agreement) assinado com cada provedor que processa PHI (obrigatório sob HIPAA)

Cláusula contratual de proteção de dados com cada operador (obrigatório sob LGPD, art. 39)

Garantia contratual de que dados não serão usados para treinamento de modelos de IA

Configuração de zero-data-retention nos provedores que oferecem esta opção

DPA (Data Processing Agreement) com cláusulas específicas de saúde mental

Informação explícita ao paciente sobre quais provedores externos receberão seus dados

FROID — Implicações Legais e Disclaimers

Confidencial  |  Pág. 5

2.5 Responsabilidade Civil e Profissional

O profissional que utiliza o FROID permanece como controlador dos dados e responsável único pela prática clínica. As implicações incluem:

Responsabilidade objetiva do controlador por danos causados por vazamento (art. 42, LGPD)

Responsabilidade ética do psicólogo/psiquiatra pelo uso de ferramentas tecnológicas

Risco de ação de regresso contra o FROID (operador) em caso de falha de segurança

Obrigação de notificação à ANPD em caso de incidente de segurança (art. 48, LGPD, prazo de 72h)

Seguro de responsabilidade civil profissional recomendado

FROID — Implicações Legais e Disclaimers

Confidencial  |  Pág. 6

3. Disclaimers Obrigatórios Definidos por Lei

Os seguintes disclaimers devem ser implementados no sistema FROID e exibidos obrigatoriamente nos momentos indicados. A ausência de qualquer um deles pode configurar infração regulatória.

3.1 Disclaimer de Natureza do Sistema (Exibir em: primeiro acesso, login, e em todos os relatórios)

"O FROID é uma ferramenta de apoio à percepção clínica. Não é um dispositivo médico, não realiza diagnósticos e não substitui o julgamento clínico do profissional de saúde mental. Os indicadores apresentados (IPM, zonas vocais, classificações emocionais) são estimativas geradas por algoritmos de inteligência artificial e estão sujeitos a imprecisões, vieses e limitações tecnológicas. Nenhuma decisão clínica deve ser baseada exclusivamente nos dados fornecidos pelo sistema. A responsabilidade pelo atendimento, diagnóstico e conduta terapêutica é exclusivamente do profissional habilitado."

#### Base legal:

Código de Ética CFP, art. 1º, alínea "b" — dever de prestação de serviços fundamentados na ciência psicológica

Nota de Posicionamento CFP 2025 sobre IA — IA não substitui o juízo do profissional

Código de Defesa do Consumidor, art. 6º, III — direito à informação adequada sobre riscos

HIPAA — AI systems are clinical support tools, not autonomous decision-makers

3.2 Disclaimer de Limitações da IA (Exibir em: dashboard durante sessão e relatórios)

"Os algoritmos de reconhecimento emocional utilizados pelo FROID possuem limitações conhecidas, incluindo: (a) menor precisão para expressões faciais de determinados grupos demográficos; (b) influência de condições de iluminação, posicionamento e qualidade de áudio; (c) impossibilidade de capturar o espectro completo da experiência emocional humana; (d) correlações estatísticas que não implicam causalidade. Os resultados não devem ser interpretados como medidas absolutas de estados emocionais."

#### Base legal:

Princípio da transparência (art. 6º, VI, LGPD) — informação clara sobre o tratamento

GDPR art. 22 — direito à explicação sobre decisões automatizadas

Cartilha CFP 2025 sobre IA — dever de informar sobre vieses e limitações

3.3 Disclaimer de Privacidade e Dados (Exibir em: cadastro do paciente e antes de cada sessão)

"Seus dados pessoais, incluindo gravações de áudio/vídeo, análises de voz e expressões faciais, transcrições e relatórios clínicos, são classificados como dados pessoais sensíveis conforme a Lei Geral de Proteção de Dados (Lei 13.709/2018). Estes dados são: (a) processados exclusivamente para fins terapêuticos sob responsabilidade do seu profissional de saúde; (b) criptografados em trânsito e em repouso; (c) armazenados em servidores seguros localizados em \[país\]; (d) compartilhados com provedores de tecnologia específicos exclusivamente para processamento técnico, conforme detalhado na Política de Privacidade. Você tem o direito de: acessar seus dados, corrigir informações, revogar consentimento a qualquer momento e solicitar a exclusão completa de seus dados."

#### Base legal:

LGPD art. 11, I — consentimento específico e destacado para dados sensíveis

FROID — Implicações Legais e Disclaimers

Confidencial  |  Pág. 7

LGPD art. 18 — direitos do titular (acesso, correção, exclusão, portabilidade)

LGPD art. 9º — direito à informação sobre compartilhamento com terceiros

HIPAA Privacy Rule — Notice of Privacy Practices obrigatório

FROID — Implicações Legais e Disclaimers

Confidencial  |  Pág. 8

3.4 Disclaimer de Gravação (Exibir em: tela de início de sessão, ANTES de ativar qualquer captura)

"Esta sessão poderá ser gravada em áudio e/ou vídeo, e suas expressões faciais e características vocais serão analisadas por sistemas de inteligência artificial para auxiliar seu profissional de saúde. Sua autorização é livre, voluntária e pode ser revogada a qualquer momento, sem prejuízo ao seu atendimento. Caso não autorize, a sessão prosseguirá normalmente sem o uso destas funcionalidades. \[AUTORIZO / NÃO AUTORIZO\]"

#### Base legal:

Res. CFP 13/2022, art. 11 — gravação exige consentimento livre, prévio, informado e por escrito

LGPD art. 8º — consentimento deve ser fornecido por escrito ou outro meio que demonstre a manifestação de vontade

Código de Ética CFP, art. 9º — sigilo profissional

Código Civil art. 20 — direito à imagem e proteção da intimidade

3.5 Disclaimer de Compartilhamento (Exibir em: antes de cada compartilhamento de relatório)

"O compartilhamento deste relatório foi autorizado pelo profissional responsável e é destinado exclusivamente a \[nome do destinatário/finalidade\]. O conteúdo é confidencial e protegido pelo sigilo profissional. A reprodução, distribuição ou divulgação não autorizada constitui violação legal sujeita às penalidades da LGPD e do Código Penal. Este link expirará em \[X\] dias."

3.6 Disclaimer de Não Emergência (Exibir em: dashboard e footer permanente)

"O FROID não é um sistema de monitoramento de crise ou emergência psiquiátrica. Em caso de risco iminente de vida, autolesão ou ideação suicida, o profissional deve seguir os protocolos clínicos estabelecidos e acionar os serviços de emergência competentes (SAMU 192 / CVV 188). Nenhum alerta do sistema substitui a avaliação clínica presencial."

3.7 Disclaimer para Relatórios Gerados por IA (Exibir em: cabeçalho de todos os relatórios)

"Este relatório foi gerado com auxílio de inteligência artificial e deve ser revisado, validado e, se necessário, editado pelo profissional responsável antes de qualquer uso clínico, compartilhamento ou arquivamento. O relatório não constitui documento psicológico nos termos da Resolução CFP 6/2019 até que seja formalmente revisado e assinado pelo profissional."

FROID — Implicações Legais e Disclaimers

Confidencial  |  Pág. 9

4. Termos de Consentimento Obrigatórios

O FROID deve implementar os seguintes termos de consentimento, que devem ser obtidos em momentos específicos e armazenados com integridade criptográfica (hash SHA-256):

4.1 Termo de Consentimento Livre e Esclarecido (TCLE) para Uso do FROID

Este é o termo principal, obtido no cadastro do paciente. Deve conter obrigatoriamente:

1. Identificação completa do profissional responsável e número de registro CRP/CRM

2. Descrição clara e em linguagem acessível de TODAS as funcionalidades do sistema (análise vocal, facial, gravação, transcrição, IA)

3. Lista de dados coletados: áudio, vídeo, dados biométricos faciais, características vocais, transcrições, índices emocionais

4. Finalidade específica de cada tipo de processamento

5. Lista nominal de provedores externos que receberão dados (Hume AI, OpenAI, Anthropic, etc.) e país de processamento

6. Período de retenção dos dados e critérios de exclusão

7. Direitos do titular: acesso, correção, exclusão, portabilidade, revogação

8. Declaração explícita de que a recusa não impede o atendimento convencional

9. Campo de consentimento granular: o paciente pode autorizar separadamente gravação de áudio, vídeo, análise facial e análise vocal

10. Assinatura eletrônica (válida sob Lei 14.063/2020) ou manuscrita
4.2 Consentimento de Sessão (Obtido ANTES de cada sessão)

Confirmação rápida, porém obrigatória, com registro datado e com hash de integridade:

Confirmação de que o paciente autoriza a captura e análise nesta sessão específica

Opção de desativar funcionalidades específicas (ex: não gravar vídeo, manter apenas análise vocal)

Registro automático de timestamp, IP e método de consentimento no audit trail

4.3 Consentimento para Menores de 18 Anos

#### Conforme LGPD (art. 14) e Código de Ética CFP (art. 8º):

Consentimento de pelo menos um responsável legal, obrigatoriamente por escrito

Para adolescentes (12-17 anos): consentimento do responsável + assentimento do adolescente

Coleta limitada ao estritamente necessário para a finalidade terapêutica

Vedado compartilhamento com terceiros sem autorização específica do responsável

4.4 Consentimento para Uso em Pesquisa (Opcional)

Caso dados anonimizados sejam utilizados para pesquisa ou melhoria de algoritmos:

Consentimento separado, nunca vinculado ao consentimento clínico

Submissão a Comitê de Ética em Pesquisa (CEP) obrigatória (Res. CNS 510/2016)

Anonimização irreversível antes de qualquer uso

Direito de retirada a qualquer momento, sem prejuízo ao tratamento

FROID — Implicações Legais e Disclaimers

Confidencial  |  Pág. 10

FROID — Implicações Legais e Disclaimers

Confidencial  |  Pág. 11

5. Políticas e Documentos Obrigatórios
5.1 Documentos que o FROID Deve Disponibilizar

Documento Base Legal Disponibilização

Política de Privacidade LGPD art. 9º; GDPR art. 13-14; HIPAA Notice of Privacy Practices

Pública no site e no app. Aceite obrigatório no cadastro

Termos de Uso do Profissional Código Civil; CDC; Res. CFP 9/2024 art. 7º

Aceite obrigatório no cadastro do profissional

TCLE do Paciente (modelo) LGPD art. 8º e 11; Res. CFP 13/2022 art. 11

Modelo fornecido, assinatura antes da 1ª sessão

Política de Retenção e Exclusão de Dados

LGPD art. 15-16; GDPR art. 17 Disponível no painel do profissional

Política de Segurança da Informação

LGPD art. 46; HIPAA Security Rule

Interna + resumo público

Plano de Resposta a Incidentes LGPD art. 48; HIPAA Breach Notification Rule

Interno com procedimentos documentados

RIPD (Relatório de Impacto) LGPD art. 38; GDPR art. 35 (DPIA)

Interno, disponível sob solicitação da ANPD

DPA/BAA com Fornecedores LGPD art. 39; HIPAA Business Associate Agreement

Arquivado. Disponível para auditoria

Registro de Atividades de Tratamento

LGPD art. 37; GDPR art. 30 Interno, atualizado continuamente

Nomeação de DPO/Encarregado

LGPD art. 41; GDPR art. 37 Pública no site com contato

6. Obrigações Técnicas Definidas por Lei
6.1 Segurança Técnica Mínima (art. 46, LGPD / HIPAA Security Rule)

Criptografia AES-256 para dados em repouso e TLS 1.3 para dados em trânsito — obrigatório

Autenticação multifatorial (MFA) para todos os profissionais — obrigatório

Controle de acesso baseado em papéis (RBAC) com princípio do menor privilégio

Audit trail imutável (append-only) com registro de todos os acessos e operações

Backup criptografado com teste periódico de restauração

Teste de penetração anual e varredura de vulnerabilidades contínua

Timeout automático de sessão após período de inatividade

Logs de acesso armazenados por mínimo de 6 meses (Marco Civil da Internet)

6.2 Direito ao Esquecimento e Exclusão (art. 15-16, LGPD)

Mecanismo de exclusão completa e irreversível de todos os dados do paciente sob solicitação

FROID — Implicações Legais e Disclaimers

Confidencial  |  Pág. 12

Exclusão deve alcançar: dados primários, backups, índices de busca e dados em provedores externos

Prazo máximo para execução: 15 dias úteis após solicitação (recomendado pela ANPD)

Exceção: retenção obrigatória por prazo legal (prontuário médico: 20 anos, CFM)

Certificado de exclusão deve ser emitido ao titular

6.3 Portabilidade de Dados (art. 18, V, LGPD)

Exportação em formato aberto e legível por máquina (JSON, CSV ou PDF)

Inclui: relatórios, transcrições, índices, anotações e metadados

Gravações de áudio/vídeo em formato padrão (MP4, WAV)

FROID — Implicações Legais e Disclaimers

Confidencial  |  Pág. 13

7. Checklist de Conformidade Legal para o ANTIGRAVITY

O ANTIGRAVITY deve implementar todos os itens abaixo na codificação do FROID. Cada item é obrigatório para operação legal do sistema:

7.1 Antes do Lançamento (Pré-Requisitos Legais)

11. Contratação de DPO (Encarregado de Proteção de Dados) nomeado publicamente

12. Elaboração do RIPD/DPIA com avaliação de riscos completa

13. Assinatura de BAA/DPA com Hume AI, OpenAI, Anthropic e todos os provedores

14. Revisão jurídica de todos os termos, políticas e disclaimers por advogado especializado

15. Parecer de comitê de ética (recomendado) sobre uso de IA em saúde mental

16. Registro de Atividades de Tratamento documentado

17. Teste de penetração e audit de segurança independente

18. Definição de data residency (onde os dados serão armazenados fisicamente)
7.2 Na Plataforma (Implementação Técnica Obrigatória)

19. Fluxo de consentimento granular ANTES de qualquer captura de dados

20. Botão de revogação de consentimento acessível em 1 clique

21. Todos os 7 disclaimers implementados nos pontos especificados

22. Política de Privacidade acessível em no máximo 2 cliques de qualquer tela

23. Mecanismo de exclusão de dados funcional e testável

24. Exportação de dados em formato aberto

25. Audit trail imutável com hash de integridade

26. MFA obrigatório para profissionais

27. Criptografia end-to-end em todas as transmissões de dados sensíveis

28. Marca d’água/hash de integridade em relatórios gerados por IA

29. Mecanismo de revisão e assinatura do profissional antes da finalização de relatórios

30. Log de compartilhamentos com rastreabilidade completa
7.3 Operação Contínua

31. Treinamento obrigatório de profissionais sobre uso ético da ferramenta

32. Revisão semestral de políticas e termos

33. Teste de penetração anual

34. Auditoria de conformidade LGPD anual

35. Monitoramento contínuo de incidentes de segurança

36. Atualização de DPAs/BAAs conforme mudanças em provedores

37. Acompanhamento de novas resoluções do CFP, CFM e ANPD

FROID — Implicações Legais e Disclaimers v1.0

AVISO FINAL: Este documento é uma análise técnica-regulatória e NÃO constitui assessoria jurídica. Todos os termos, políticas e disclaimers aqui propostos devem ser revisados por

FROID — Implicações Legais e Disclaimers

Confidencial  |  Pág. 14

advogado especializado em Direito Digital, LGPD e Direito de Saúde antes da implementação. A legislação está em constante evolução, especialmente no que tange a IA e saúde.

