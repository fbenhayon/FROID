# Cadastro Nacional de Profissionais de Psicologia

https://cadastro.cfp.org.br/

Ir para o conteúdo 1

https://cadastro.cfp.org.br/#content

Ir para o menu 2

https://cadastro.cfp.org.br/#site-navigation

Ir para o rodapé 3

https://cadastro.cfp.org.br/#colophon

Acessibilidade

https://cadastro.cfp.org.br/

Alto contraste

https://cadastro.cfp.org.br/

http://www.vlibras.gov.br/

https://cadastro.cfp.org.br/

Base de dados de Psicólogos Brasileiros

https://cadastro.cfp.org.br/login.html

https://cadastro.cfp.org.br/#primary-menu

Consultar Psicólogas(os)

https://cadastro.cfp.org.br/

Área da Profissional

https://cadastro.cfp.org.br/login.html

Consultar Profissional

Pessoa Física

https://cadastro.cfp.org.br/

Pessoa Jurídica

https://cadastro.cfp.org.br/

Encontrar Pessoa Física

Nome do profissional

Acre - CRP 24ª Região

Alagoas - CRP 15ª Região

Amapá - CRP 10ª Região

Amazonas - CRP 20ª Região

Bahia - CRP 3ª Região

Ceará - CRP 11ª Região

Distrito Federal - CRP 1ª Região

Espirito Santo - CRP 16ª Região

Goiás - CRP 9ª Região

Maranhão - CRP 22ª Região

Mato Grosso do Sul - CRP 14ª Região

Mato Grosso - CRP 18ª Região

Minas Gerais - CRP 4ª Região

Pará - CRP 10ª Região

Paraíba - CRP 13ª Região

Paraná - CRP 8ª Região

Pernambuco - CRP 2ª Região

Piauí - CRP 21ª Região

Rio de Janeiro - CRP 5ª Região

Rio Grande do Norte - CRP 17ª Região

Rio Grande do Sul - CRP 7ª Região

Rondônia - CRP 24ª Região

Roraima - CRP 20ª Região

Santa Catarina - CRP 12ª Região

São Paulo - CRP 6ª Região

Sergipe - CRP 19ª Região

Tocantins - CRP 23ª Região

Número de registro

Buscar Busca avançada

Sistema desenvolvido pela Gerência de Tecnologia da Informação do CFP

0cAFcWeA4SvRrmN02JRZlryPa0D1\_JVCoDM3glMumB3rMFg\_vIHKNqsUx2kKposVTcFcoHh5XuOxHtq3LT2BjGbsPZn4U8aa23SvHajUtxqgGOlz72Txu\_V3Rtpr0GGaSiBLNmPDMausOxXzXF6fZj5y1ZGR3cczUPk076pntznVBtj6peznpqSladuHl6pUYZUh8iqJ-CeG6j1Tx5fHYRE2sSQAr6ZWR0zuYgGl3fqwehG2zlchRcdRGqA4T2AGVWogrDE5TyNvj9Lml7Q1BNmRlx3NosHoKCZaMrf5EzSluIGN5AMRQGsgt\_OWHlmq6wQ54zGrtBTpbgGh3bZwVp77SAg2RNMFlrWiREgCKbvUgXoWW4aREBDlUFl-BKpk3uHP08quU6S30JzjsfcGOemjSlducMpHiIASm-u8umn0PLJCrE\_bFIYl1hzGXdydKAqEfy4PXBAKP2y3WSLUxGicWBCT4Nn5NNcvGdgiKlDMetq8ZQfJ\_EwAtwHCzd\_9YuWgGPxXszL-h56whrdYS7O-PFfTfQgy\_T6dS75P2wmitCjJdoEDgmR4E8-e\_cJ0bTwCltPl-7A62p0lV9PNnMZ0LcbCbRBgdoMeMqL609Qmk9l0MevoHCL5WJSaUQzIbc6s2n1WR-sKK36AUzjUqJ30KYwvnf115EzUseRVKaNhuJDOs1df5jCwaLG7vKUGFTUHZELNm1RRKAObpAmLEjUTCV-C3eVQWaRRnlX8R6M8aJQYOSkCu15o9egT0dvrKWTDdoKDHS0Mt0QwX\_JKaBfL\_bf43TWQicl476NaKzZHhZzMtx9doDt-xaNjFTbFYm70IjhqUE2\_BndsrDank-ZGJfEYHC1WMmUokgH9JyRXoDQYyMIzBkXue1Et9p8Au6K\_h2wIwBFwo4Z5rOqFVJxrihdCCEi8Mz2k\_kYhoilYvDYsJ6cXhIDeUlZAfztnlOtViS5NFuivqysPAGCJriOpIB6KxfH5YvvT8hm3548Vue6PqoQEHtIDc3tRKn2eoRzlkeavIj6UGWC9RQcsujgSYimUAafX6NdA

