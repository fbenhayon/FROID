# Familia e relacionamentos verdadeiramente humanos

Celebrar 15 anos juntos, cercados de amigos e família, é uma verdadeira conquista que a filosofia explica e celebra de maneira muito bonita.

Na tradição de Confúcio, a família e os relacionamentos próximos são o laboratório fundamental onde aprendemos a ser verdadeiramente humanos. O grande segredo para um relacionamento resistir ao tempo é o cultivo da confiabilidade e da confiança mútua (um conceito chamado

), que significa alinhar suas palavras com suas ações dia após dia para que vocês sempre possam contar um com o outro. A convivência não exige que vocês sejam iguais; a harmonia a dois é comparada a preparar um caldo delicioso, onde ingredientes e temperos completamente diferentes se misturam para criar um sabor perfeito e equilibrado.

Se olharmos para a Grécia Antiga, o filósofo Platão dedicou uma obra inteira chamada

a uma festa entre amigos onde o amor é o grande tema. Nessa história, o personagem Aristófanes relata o belo mito de que, no passado, éramos seres inteiros que foram divididos ao meio, sendo o amor a busca apaixonada por nossa outra metade para nos sentirmos completos novamente. No mesmo livro, a sábia Diotima ensina que o amor é mais do que romance; é uma força divina que nos impulsiona a criar coisas belas juntos e a realizar uma espécie de imortalidade mesmo sendo mortais.

Já nos tempos modernos, o casal de filósofos existencialistas Simone de Beauvoir e Jean-Paul Sartre nos mostra que o amor verdadeiro é o encontro de duas liberdades. Beauvoir não via o amor como uma troca de favores, dívida ou gratidão, mas sim como uma escolha livre e viva. Juntos, eles criaram um "pacto" lendário de cumplicidade que provou que é perfeitamente possível reconciliar o parceiro de longo prazo com a liberdade, a honestidade e a igualdade. O amor profundo acontece quando reconhecemos a visão de mundo do parceiro e decidimos construir um projeto generoso em comum.

Por fim, o filósofo contemporâneo Slavoj Žižek lembra que o amor é sempre uma força excessiva que "bagunça" a nossa rotina normal. No entanto, é exatamente esse apego exagerado pelo outro que dá a verdadeira razão para vivermos e nos permite tocar e conhecer o outro de forma autêntica e profunda.

Que os próximos anos da jornada de vocês continuem repletos da harmonia de Confúcio, da beleza de Platão, da liberdade de Beauvoir e da paixão genuína que faz a vida valer a pena! Feliz 15 anos!

