# Leveraging Symmetry and Addressing Asymmetry Challenges for Improved Convolutional Neural Network-Based Facial Emotion Recognition - MDPI

https://www.mdpi.com/2073-8994/17/3/397

Leveraging Symmetry and Addressing Asymmetry Challenges for Improved Convolutional Neural Network-Based Facial Emotion Recognition

Loading web-font Gyre-Pagella/Normal/Regular

Next Article in Journal

Nearly Complete Generalized Clifford Monoids and Applications

https://www.mdpi.com/2073-8994/17/3/398

Next Article in Special Issue

A Study on Dual-Mode Hybrid Dynamics Finite Element Algorithm for Human Soft Tissue Deformation Simulation

https://www.mdpi.com/2073-8994/17/5/765

Previous Article in Journal

Optical Bacteria Recognition: Cross-Polarized Scattering

https://www.mdpi.com/2073-8994/17/3/396

Previous Article in Special Issue

Comparison of the Meta-Heuristic Algorithms for Maximum Likelihood Estimation of the Exponentially Modified Logistic Distribution

https://www.mdpi.com/2073-8994/16/3/259

Active Journals

https://www.mdpi.com/about/journals

Find a Journal

https://www.mdpi.com/about/journalfinder

Journal Proposal

https://www.mdpi.com/about/journals/proposal

Proceedings Series

https://www.mdpi.com/about/proceedings

\](https://www.mdpi.com/topics)

Information

For Authors

https://www.mdpi.com/authors

For Reviewers

https://www.mdpi.com/reviewers

For Editors

https://www.mdpi.com/editors

For Librarians

https://www.mdpi.com/librarians

For Publishers

https://www.mdpi.com/publishing\_services

For Societies

https://www.mdpi.com/societies

For Conference Organizers

https://www.mdpi.com/conference\_organizers

Open Access Policy

https://www.mdpi.com/openaccess

Institutional Open Access Program

https://www.mdpi.com/ioap

Special Issues Guidelines

https://www.mdpi.com/special\_issues\_guidelines

Editorial Process

https://www.mdpi.com/editorial\_process

Research and Publication Ethics

https://www.mdpi.com/ethics

Article Processing Charges

https://www.mdpi.com/apc

https://www.mdpi.com/awards

Testimonials

https://www.mdpi.com/testimonials

Author Services

\](https://www.mdpi.com/authors/english)

Initiatives

https://sciforum.net/

https://www.mdpi.com/books

Preprints.org

https://www.preprints.org/

https://www.scilit.com/

SciProfiles

https://sciprofiles.com/

Encyclopedia

https://encyclopedia.pub/

https://jams.pub/

Proceedings Series

https://www.mdpi.com/about/proceedings

https://www.mdpi.com/about

https://www.mdpi.com/about/contact

https://careers.mdpi.com/

https://www.mdpi.com/about/announcements

https://www.mdpi.com/about/press

http://blog.mdpi.com/

Sign In / Sign Up

https://www.mdpi.com/user/login

You can make submissions to other journals

https://susy.mdpi.com/user/manuscripts/upload

https://www.mdpi.com/2073-8994/17/3/397

You are accessing a machine-readable page. In order to be human-readable, please install an RSS reader.

https://www.mdpi.com/2073-8994/17/3/397

https://www.mdpi.com/2073-8994/17/3/397

https://www.mdpi.com/2073-8994/17/3/397

All articles published by MDPI are made immediately available worldwide under an open access license. No special permission is required to reuse all or part of the article published by MDPI, including figures and tables. For articles published under an open access Creative Common CC BY license, any part of the article may be reused without permission provided that the original article is clearly cited. For more information, please refer to

https://www.mdpi.com/openaccess

https://www.mdpi.com/openaccess

Feature papers represent the most advanced research with significant potential for high impact in the field. A Feature Paper should be a substantial original Article that involves several techniques or approaches, provides an outlook for future research directions and describes possible research applications.

Feature papers are submitted upon individual invitation or recommendation by the scientific editors and must receive positive feedback from the reviewers.

Editor's Choice articles are based on recommendations by the scientific editors of MDPI journals from around the world. Editors select a small number of articles recently published in the journal that they believe will be particularly interesting to readers, or important in the respective research area. The aim is to provide a snapshot of some of the most exciting work published in the various research areas of the journal.

Original Submission Date Received: .

You seem to have javascript disabled. Please note that many of the page functionalities won't work as expected without javascript enabled.

https://www.mdpi.com/2073-8994/17/3/397

zoom\_out\_map

https://www.mdpi.com/toggle\_desktop\_layout\_cookie

https://www.mdpi.com/2073-8994/17/3/397

https://www.mdpi.com/2073-8994/17/3/397

https://www.mdpi.com/about/journals

Active Journals

https://www.mdpi.com/about/journals

Find a Journal

https://www.mdpi.com/about/journalfinder

Journal Proposal

https://www.mdpi.com/about/journals/proposal

Proceedings Series

https://www.mdpi.com/about/proceedings

https://www.mdpi.com/topics

Information

https://www.mdpi.com/authors

For Authors

https://www.mdpi.com/authors

For Reviewers

https://www.mdpi.com/reviewers

For Editors

https://www.mdpi.com/editors

For Librarians

https://www.mdpi.com/librarians

For Publishers

https://www.mdpi.com/publishing\_services

For Societies

https://www.mdpi.com/societies

For Conference Organizers

https://www.mdpi.com/conference\_organizers

Open Access Policy

https://www.mdpi.com/openaccess

Institutional Open Access Program

https://www.mdpi.com/ioap

Special Issues Guidelines

https://www.mdpi.com/special\_issues\_guidelines

Editorial Process

https://www.mdpi.com/editorial\_process

Research and Publication Ethics

https://www.mdpi.com/ethics

Article Processing Charges

https://www.mdpi.com/apc

https://www.mdpi.com/awards

Testimonials

https://www.mdpi.com/testimonials

Author Services

https://www.mdpi.com/authors/english

Initiatives

https://www.mdpi.com/about/initiatives

https://sciforum.net/

https://www.mdpi.com/books

Preprints.org

https://www.preprints.org/

https://www.scilit.com/

SciProfiles

https://sciprofiles.com/

Encyclopedia

https://encyclopedia.pub/

https://jams.pub/

Proceedings Series

https://www.mdpi.com/about/proceedings

https://www.mdpi.com/about

https://www.mdpi.com/about

https://www.mdpi.com/about/contact

https://careers.mdpi.com/

https://www.mdpi.com/about/announcements

https://www.mdpi.com/about/press

http://blog.mdpi.com/

Sign In / Sign Up

https://www.mdpi.com/user/login

https://susy.mdpi.com/user/manuscripts/upload?journal=symmetry

#### Search for Articles:

Title / Keyword

Author / Affiliation / Email

All Journals

Accounting and Auditing

Acta Microbiologica Hellenica (AMH)

Administrative Sciences

Adolescents

Advances in Respiratory Medicine (ARM)

Aerobiology

Agriculture

AgriEngineering

Agrochemicals

AI Chemistry

AI for Engineering

AI in Education

AI in Medicine

AI Materials

Anesthesia Research

Antibiotics

Antioxidants

Applied Biosciences

Applied Mechanics

Applied Microbiology

Applied Nano

Applied Sciences

Applied System Innovation (ASI)

AppliedChem

AppliedMath

AppliedPhys

Aquaculture Journal

Architecture

Astronautics

Audiology Research

Behavioral Sciences

Big Data and Cognitive Computing (BDCC)

Bioengineering

Biology and Life Sciences Forum

Biomechanics

Biomedicines

BioMedInformatics

Biomimetics

Biomolecules

Bioresources and Bioproducts

Blockchains

Brain Sciences

C (Journal of Carbon Research)

Cardiogenetics

Cardiovascular Medicine

ChemEngineering

Chemistry Proceedings

Chemosensors

Clean Technologies (Clean Technol.)

Clinical and Translational Neuroscience (CTN)

Clinical Bioenergetics

Clinics and Practice

Clocks & Sleep

Colloids and Interfaces

Commodities

Complexities

Complications

Computation

Computer Sciences & Mathematics Forum

Condensed Matter

Conservation

Construction Materials

Corrosion and Materials Degradation (CMD)

Craniomaxillofacial Trauma & Reconstruction (CMTR)

Cryptography

Current Issues in Molecular Biology (CIMB)

Current Oncology

Dentistry Journal

Dermatopathology

Diabetology

Diagnostics

Disabilities

Drugs and Drug Candidates (DDC)

Econometrics

Education Sciences

Electricity

Electrochem

Electronic Materials

Electronics

Emergency Care and Medicine

Encyclopedia

Energy Storage and Applications (ESA)

Engineering Proceedings

Entropic and Disordered Matter (EDM)

Environmental and Earth Sciences Proceedings

Environmental Remediation

Environments

Epidemiologia

European Burn Journal (EBJ)

European Journal of Investigation in Health, Psychology and Education (EJIHPE)

Family Sciences

Fermentation

Forecasting

Forensic Sciences

Fossil Studies

Foundations

Fractal and Fractional (Fractal Fract)

Future Internet

Future Pharmacology

Future Transportation

Gastroenterology Insights

Gastrointestinal Disorders

Geographies

Geosciences

Geotechnics

Gout, Urate, and Crystal Deposition Disease (GUCDD)

Green Health

Hematology Reports

Horticulturae

Hydrobiology

Infectious Disease Reports

Informatics

Information

Infrastructures

Instruments

Intelligent Infrastructure and Construction

International Journal of Cognitive Sciences (IJCS)

International Journal of Environmental Medicine (IJEM)

International Journal of Environmental Research and Public Health (IJERPH)

International Journal of Financial Studies (IJFS)

International Journal of Molecular Sciences (IJMS)

International Journal of Neonatal Screening (IJNS)

International Journal of Orofacial Myology and Myofunctional Therapy (IJOM)

International Journal of Plant Biology (IJPB)

International Journal of Topology

International Journal of Translational Medicine (IJTM)

International Journal of Turbomachinery, Propulsion and Power (IJTPP)

International Medical Education (IME)

ISPRS International Journal of Geo-Information (IJGI)

Journal of Aesthetic Medicine (J. Aesthetic Med.)

Journal of Ageing and Longevity (JAL)

Journal of CardioRenal Medicine (JCRM)

Journal of Cardiovascular Development and Disease (JCDD)

Journal of Clinical & Translational Ophthalmology (JCTO)

Journal of Clinical Medicine (JCM)

Journal of Composites Science (J. Compos. Sci.)

Journal of Cybersecurity and Privacy (JCP)

Journal of Dementia and Alzheimer's Disease (JDAD)

Journal of Developmental Biology (JDB)

Journal of Experimental and Theoretical Analyses (JETA)

Journal of Eye Movement Research (JEMR)

Journal of Functional Biomaterials (JFB)

Journal of Functional Morphology and Kinesiology (JFMK)

Journal of Fungi (JoF)

Journal of Genome Biotechnology and Genetics (JGBG)

Journal of Gerontology and Geriatrics (JGG)

Journal of Imaging (J. Imaging)

Journal of Innovation

Journal of Intelligence (J. Intell.)

Journal of Interdisciplinary Research Applied to Medicine (JDReAM)

Journal of Low Power Electronics and Applications (JLPEA)

Journal of Manufacturing and Materials Processing (JMMP)

Journal of Marine Science and Engineering (JMSE)

Journal of Market Access & Health Policy (JMAHP)

Journal of Mind and Medical Sciences (JMMS)

Journal of Molecular Pathology (JMP)

Journal of Nanotheranostics (JNT)

Journal of Nuclear Engineering (JNE)

Journal of Otorhinolaryngology, Hearing and Balance Medicine (JOHBM)

Journal of Parks

Journal of Personalized Medicine (JPM)

Journal of Pharmaceutical and BioTech Industry (JPBI)

Journal of Phytomedicine

Journal of Respiration (JoR)

Journal of Risk and Financial Management (JRFM)

Journal of Sensor and Actuator Networks (JSAN)

Journal of Superintelligence

Journal of the American Podiatric Medical Association (JAPMA)

Journal of the Oman Medical Association (JOMA)

Journal of Theoretical and Applied Electronic Commerce Research (JTAER)

Journal of Vascular Diseases (JVD)

Journal of Xenobiotics (JoX)

Journal of Zoological and Botanical Gardens (JZBG)

Journalism and Media

Kidney and Dialysis

Kinases and Phosphatases

Laboratories

Limnological Review

Low-Altitude Economy

Machine Learning and Knowledge Extraction (MAKE)

Magnetochemistry

Marine Drugs

Materials Proceedings

Mathematical and Computational Applications (MCA)

Mathematics

Medical Sciences

Medical Sciences Forum

Metabolites

Meteorology

Methods and Protocols (MPs)

Microbiology Research

Microelectronics

Micromachines

Microorganisms

Microplastics

Modern Mathematical Physics

Multimodal Technologies and Interaction (MTI)

Nanoenergy Advances

Nanomanufacturing

Nanomaterials

Neuroimaging

Neurology International

Non-Coding RNA (ncRNA)

Nursing Reports

Nutraceuticals

Occupational Health

Parasitologia

Pathophysiology

Peace Studies

Pediatric Reports

Pharmaceuticals

Pharmaceutics

Pharmacoepidemiology

Philosophies

Physical Sciences Forum

Physiologia

Polysaccharides

Populations

Precision Oncology

Primary and Hospital Care (PHC)

Proceedings

Psychiatry International

Psychoactives

Psychology International

Publications

Purification

Quantum Beam Science (QuBS)

Quantum Reports

Real Estate

Regional Science and Environmental Economics (RSEE)

Remote Sensing

Reproductive Medicine (Reprod. Med.)

Romanian Journal of Preventive Medicine (RJPM)

Scientia Pharmaceutica (Sci. Pharm.)

Semiconductors and Heterogeneous Integration

Separations

Smart Cities

Social Sciences

Société Internationale d'Urologie Journal (SIUJ)

Soil Systems

Spectroscopy Journal

Stratigraphy and Sedimentology

Surgical Techniques Development

Sustainability

Sustainable Chemistry

Swiss Archives of Neurology, Psychiatry and Psychotherapy (SANPP)

Technologies

Thalassemia Reports

Theoretical and Applied Ergonomics

Therapeutics

Time and Space

Tourism and Hospitality

Transplantology

Trauma Care

Trends in Higher Education

Trends in Public Health

Tropical Medicine and Infectious Disease (TropicalMed)

Urban Science

Venereology

Veterinary Sciences

Virtual Worlds

World Electric Vehicle Journal (WEVJ)

Zoonotic Diseases

https://www.mdpi.com/2073-8994/17/3/397

Article Type

All Article Types

Communication

Book Review

Brief Communication

Brief Report

Case Report

Clinicopathological Challenge

Concept Paper

Conference Report

Data Descriptor

Expression of Concern

Extended Abstract

Field Guide

Giants in Urology

Interesting Images

New Book Received

Patent Summary

Perspective

Proceeding Paper

Project Report

Registered Report

Study Protocol

Systematic Review

Technical Note

Urology around the World

All Article Types

https://www.mdpi.com/2073-8994/17/3/397

Advanced Search

https://www.mdpi.com/2073-8994/17/3/397

All Sections

Chemistry: Symmetry/Asymmetry

Engineering and Materials

Life Sciences

Mathematics

All Sections

https://www.mdpi.com/2073-8994/17/3/397

Special Issue

All Special Issues

Symmetry: Feature Papers 2025

Symmetry: Feature Papers 2026

Symmetry or Asymmetry in Artificial Intelligence

Advanced Symmetry Modelling and Services in Future IT Environments

Advances in 2D Materials and Symmetry Breaking in Graphene

Algorithms for Multi-Criteria Decision-Making under Uncertainty

Applications Based on Symmetry in Adversarial Machine Learning

Applications of Internet of Things

Applied Cryptography and Security Concerns based on Symmetry for the Future Cyber World

Aromaticity and Molecular Symmetry

Asymmetric Catalysis

Asymmetric Catalysis and Transition-Metal Chemistry

Asymmetric Organocatalysis

Asymmetrical Problems and Countermeasures in Deep Excavations and Tunnelling Engineering

Biometric Recognition In-The-Wild

Bipartite Graphs, Gauge Theories and Mirror Symmetry

Brain Asymmetry of Structure and/or Function

Broken Symmetry

Chemical Applications of Symmetry

Chiral Auxiliaries and Chirogenesis

Chiral Organic Crystal

Chiral Separations

Chirality in Theoretical and Experimental Chemistry

Complexity and Symmetry

Computational Hemodynamics

CPT Symmetry

Crystal Symmetry and Structure

Deep Learning and Deep Learning Synergy of Transformers and Symmetry in Small Object Detection and Tracking

Diagrams, Topology, Categories and Logic

Discrete Symmetries

Dynamic Systems and Mechanics—2nd Edition

Electroweak Symmetry Breaking 2019

Entropy, Order and Symmetry

Feature Papers: Symmetry Concepts and Applications

Flavor Symmetry

Fluctuating Asymmetry

Fluctuating Asymmetry 2016

Frontiers in Asymmetric Multicomponent Reactions

Fuzzy Sets Theory and Its Applications

Harmonic Oscillators In Modern Physics

Highly Symmetrical Graphs

Implications of Symmetry for Polar Molecular Crystals

Knot Theory and Its Applications

Lie and Conditional Symmetries and Their Applications for Solving Nonlinear Models

Lie Theory and Its Applications

Mathematical Modeling and Computational Methods in Science and Engineering IV

Molecular Adhesion Codes in Geometric Regulation of Bilaterian Morphogenesis

Multibody Systems with Flexible Elements, 2nd Edition

Multiscale Structuring for Biomimetics and Functional Properties

New Trends in Dynamics

Non-linear Topological Photonics

Nuclear Symmetry Energy

Ordinary and Partial Differential Equations: Theory and Application

Parity-Time Symmetry in Optics and Photonics

Perceptual, Cognitive and Emotional Processing of Mathematical Symmetries

Physics based on Two-by-two Matrices

Polyhedral Structures

Quantum Symmetry

Revealing the Symmetries of the Universe: Dark Energy, Inflation and Modified Gravity

Rigidity and Symmetry

Scientific Programming in Practical Symmetric Big Data

Selected Papers from IIKII 2019 conferences in Symmetry

Selected Papers from IIKII 2021 Conferences

Selected Papers from IIKII 2022 Conferences

Selected Papers Symmetry 2023—The Fourth Edition of the International Conference on Symmetry

Selected Papers: Symmetry 2017—The First International Conference on Symmetry

Selected Papers: Symmetry 2025—The Fifth Edition of the International Conference on Symmetry

Structural Symmetry and Protein Function

Supersymmetry 2014

Supersymmetry and Dark Matter

Supramolecular Chirality

Sustainability of Future Satellite Communications: Opportunities and Challenges for 6G and Beyond

Symmetrical Mathematical Computation in Fluid Dynamics, 2nd Edition

Symmetries of Electronic Order

Symmetry and Asymmetry in Biology

Symmetry and Asymmetry in Data Science: Blockchain, IoT and Security

Symmetry and Beauty

Symmetry and Beauty of Knots

Symmetry and Complexity, 4th Edition

Symmetry and Duality

Symmetry and Equivalence Transformations:Theory and Their Applications to Real Phenomena Modeling

Symmetry and Fractals

Symmetry and Games

Symmetry and Integrability

Symmetry and Symmetry Breaking in Quantum Mechanics

Symmetry and Symmetry Breaking in Statistical Systems

Symmetry and Symmetry-Breaking in Organic Chemistry

Symmetry Breaking

Symmetry Breaking Phenomena

Symmetry Group Methods for Molecular Systems

Symmetry in Combinatorics and Geometry

Symmetry in Complex Networks II

Symmetry in Cooperative Applications

Symmetry in Cooperative Applications II

Symmetry in Fuzzy Sets and Systems

Symmetry in Hadrons and Nuclei

Symmetry in Human Evolutionary Biology

Symmetry in Modern Energy Systems and Electrical Power

Symmetry in Nano-optics and Nanophotonics

Symmetry in Next-Generation Intelligent Information Technologies

Symmetry in Orthogonal Polynomials

Symmetry in Probability and Inference

Symmetry in Secure Cyber World

Symmetry in Structural Biology

Symmetry in Systems Design and Analysis

Symmetry in the Numerical Resolution of the Elliptic Monge-Ampere Equation

Symmetry in Theoretical Computer Science

Symmetry in Theoretical Particle Physics and Hadron Physics

Symmetry in Variational Inequality Problems and Fixed Point Theory and Their Applications

Symmetry in Vision

Symmetry Measures on Complex Networks

Symmetry of Lie Algebras

Symmetry of Life and Homochirality

Symmetry of the Order Parameter in Iron-Based Superconductors

Symmetry Problems in Metal Forming

Symmetry Processing in Perception and Art

Symmetry-Related Activity in Mid-Level Vision

Symmetry: Anniversary Feature Papers 2018

Symmetry: Feature Papers 2016

Symmetry: Feature Papers 2017

Symmetry: Feature Papers 2022

Symmetry: Feature Papers 2023

Symmetry: Feature Papers 2024

Symmetry: Theory and Applications in Vision

Symmetry/Asymmetry in Fuzzy Multi-Criteria Decision-Making: Application in Management and Engineering

Symmetry/Asymmetry in Robust Chaos and Chaotification–Theory and Applications

Symmetry/Asymmetry: Feature Review Papers

Symmetry/Asymmetry: Feature Review Papers 2024

The 17th International Conference on Information Security Practice and Experience (ISPEC 2022)

Unraveling the Black Box: Unleashing the Power of Explainable Deep Learning in Advanced Engineering Sciences

Visual Symmetry

All Special Issues

https://www.mdpi.com/2073-8994/17/3/397

Logical Operator Operator

Search Text

Search Type

Affiliations

add\_circle\_outline

remove\_circle\_outline

https://www.mdpi.com/about/journals

https://www.mdpi.com/journal/symmetry

https://www.mdpi.com/2073-8994/17

https://www.mdpi.com/2073-8994/17/3

10.3390/sym17030397

https://www.mdpi.com/2073-8994/17/3/397

Submit to this Journal

https://susy.mdpi.com/user/manuscripts/upload?form%5Bjournal\_id%5D%3D44

Review for this Journal

https://susy.mdpi.com/volunteer/journals/review

Propose a Special Issue

https://www.mdpi.com/journalproposal/sendproposalspecialissue/symmetry

► ▼ Article Menu

https://www.mdpi.com/2073-8994/17/3/397

Article Menu

Academic Editor

https://www.mdpi.com/2073-8994/17/3/397#academic\_editors

Nikos Mastorakis

https://sciprofiles.com/profile/1078662?utm\_source=mdpi.com&utm\_medium=website&utm\_campaign=avatar\_name

Recommended Articles

https://www.mdpi.com/2073-8994/17/3/397

Related Info Link

https://www.mdpi.com/2073-8994/17/3/397#related

Google Scholar

http://scholar.google.com/scholar?q=Leveraging%20Symmetry%20and%20Addressing%20Asymmetry%20Challenges%20for%20Improved%20Convolutional%20Neural%20Network-Based%20Facial%20Emotion%20Recognition

More by Authors Links

https://www.mdpi.com/2073-8994/17/3/397#authors

https://www.mdpi.com/2073-8994/17/3/397

Sălăgean, G. Laura

http://doaj.org/search/articles?source=%7B%22query%22%3A%7B%22query\_string%22%3A%7B%22query%22%3A%22%5C%22Gabriela%20Laura%20S%C4%83l%C4%83gean%5C%22%22%2C%22default\_operator%22%3A%22AND%22%2C%22default\_field%22%3A%22bibjson.author.name%22%7D%7D%7D

http://doaj.org/search/articles?source=%7B%22query%22%3A%7B%22query\_string%22%3A%7B%22query%22%3A%22%5C%22Monica%20Leba%5C%22%22%2C%22default\_operator%22%3A%22AND%22%2C%22default\_field%22%3A%22bibjson.author.name%22%7D%7D%7D

Ionica, A. Cristina

http://doaj.org/search/articles?source=%7B%22query%22%3A%7B%22query\_string%22%3A%7B%22query%22%3A%22%5C%22Andreea%20Cristina%20Ionica%5C%22%22%2C%22default\_operator%22%3A%22AND%22%2C%22default\_field%22%3A%22bibjson.author.name%22%7D%7D%7D

on Google Scholar

https://www.mdpi.com/2073-8994/17/3/397

Sălăgean, G. Laura

http://scholar.google.com/scholar?q=Gabriela%20Laura%20S%C4%83l%C4%83gean

http://scholar.google.com/scholar?q=Monica%20Leba

Ionica, A. Cristina

http://scholar.google.com/scholar?q=Andreea%20Cristina%20Ionica

https://www.mdpi.com/2073-8994/17/3/397

Sălăgean, G. Laura

http://www.pubmed.gov/?cmd=Search&term=Gabriela%20Laura%20S%C4%83l%C4%83gean

http://www.pubmed.gov/?cmd=Search&term=Monica%20Leba

Ionica, A. Cristina

http://www.pubmed.gov/?cmd=Search&term=Andreea%20Cristina%20Ionica

Article Views 2566

https://www.mdpi.com/2073-8994/17/3/397#metrics

Citations 6

https://www.mdpi.com/2073-8994/17/3/397#metrics

Table of Contents

https://www.mdpi.com/2073-8994/17/3/397#table\_of\_contents

https://www.mdpi.com/2073-8994/17/3/397#html-abstract

Introduction

https://www.mdpi.com/2073-8994/17/3/397#sec1-symmetry-17-00397

Literature Review

https://www.mdpi.com/2073-8994/17/3/397#sec2-symmetry-17-00397

Materials and Methods

https://www.mdpi.com/2073-8994/17/3/397#sec3-symmetry-17-00397

Results and Analysis

https://www.mdpi.com/2073-8994/17/3/397#sec4-symmetry-17-00397

Conclusions, Limitations, and Research Directions

https://www.mdpi.com/2073-8994/17/3/397#sec5-symmetry-17-00397

Author Contributions

https://www.mdpi.com/2073-8994/17/3/397

https://www.mdpi.com/2073-8994/17/3/397

Data Availability Statement

https://www.mdpi.com/2073-8994/17/3/397

Acknowledgments

https://www.mdpi.com/2073-8994/17/3/397#html-ack

Conflicts of Interest

https://www.mdpi.com/2073-8994/17/3/397

Abbreviations

https://www.mdpi.com/2073-8994/17/3/397#html-glossary

https://www.mdpi.com/2073-8994/17/3/397#html-references\_list

share Share

https://www.mdpi.com/2073-8994/17/3/397

announcement Help

https://www.mdpi.com/2073-8994/17/3/397

format\_quote Cite

javascript:void(0);

question\_answer Discuss in SciProfiles

https://sciprofiles.com/discussion-groups/public/10.3390/sym17030397?utm\_source=mpdi.com&utm\_medium=publication&utm\_campaign=discuss\_in\_sciprofiles

Find support for a specific problem in the support section of our website.

Get Support

https://www.mdpi.com/about/contactform

Please let us know what you think of our products and services.

Give Feedback

https://www.mdpi.com/feedback/send

Information

Visit our dedicated information section to learn more about MDPI.

Get Information

https://www.mdpi.com/authors

https://www.mdpi.com/2073-8994/17/3/397

JSmol Viewer

https://www.mdpi.com/2073-8994/17/3/397

Download PDF

https://www.mdpi.com/2073-8994/17/3/397/pdf?version=1741251964

Order Article Reprints

https://www.mdpi.com/2073-8994/17/3/397/reprints

#### Line Spacing:

#### Column Width:

#### Background:

Open Access Article

Leveraging Symmetry and Addressing Asymmetry Challenges for Improved Convolutional Neural Network-Based Facial Emotion Recognition

Gabriela Laura Sălăgean

Gabriela Laura Sălăgean

SciProfiles

https://sciprofiles.com/profile/3666350?utm\_source=mdpi.com&utm\_medium=website&utm\_campaign=avatar\_name

https://scilit.com/scholars?q=Gabriela%20Laura%20S%C4%83l%C4%83gean

Preprints.org

https://www.preprints.org/search?condition\_blocks=\[{%22value%22:%22Gabriela+Laura+S%C4%83l%C4%83gean%22,%22type%22:%22author%22,%22operator%22:null}\]&sort\_field=relevance&sort\_dir=desc&page=1&exact\_match=true

Google Scholar

https://scholar.google.com/scholar?q=Gabriela+Laura+S%C4%83l%C4%83gean

mailto:gabisalagean@yahoo.com

Monica Leba

Monica Leba

SciProfiles

https://sciprofiles.com/profile/1262710?utm\_source=mdpi.com&utm\_medium=website&utm\_campaign=avatar\_name

https://scilit.com/scholars?q=Monica%20Leba

Preprints.org

https://www.preprints.org/search?condition\_blocks=\[{%22value%22:%22Monica+Leba%22,%22type%22:%22author%22,%22operator%22:null}\]&sort\_field=relevance&sort\_dir=desc&page=1&exact\_match=true

Google Scholar

https://scholar.google.com/scholar?q=Monica+Leba

mailto:monicaleba@upet.ro

Andreea Cristina Ionica

Andreea Cristina Ionica

SciProfiles

https://sciprofiles.com/profile/2121625?utm\_source=mdpi.com&utm\_medium=website&utm\_campaign=avatar\_name

https://scilit.com/scholars?q=Andreea%20Cristina%20Ionica

Preprints.org

https://www.preprints.org/search?condition\_blocks=\[{%22value%22:%22Andreea+Cristina+Ionica%22,%22type%22:%22author%22,%22operator%22:null}\]&sort\_field=relevance&sort\_dir=desc&page=1&exact\_match=true

Google Scholar

https://scholar.google.com/scholar?q=Andreea+Cristina+Ionica

mailto:andreeaionica@upet.ro

Doctoral School, University of Petroșani, 332006 Petrosani, Romania

System Control and Computer Engineering Department, University of Petroșani, 332006 Petrosani, Romania

Management and Industrial Engineering Department, University of Petroșani, 332006 Petrosani, Romania

Author to whom correspondence should be addressed.

https://doi.org/10.3390/sym17030397

https://doi.org/10.3390/sym17030397

Submission received: 20 January 2025 / Revised: 19 February 2025 / Accepted: 4 March 2025 / Published: 6 March 2025

(This article belongs to the Special Issue

Simulation and Modelling in Natural Sciences, Biomedicine and Engineering III

https://www.mdpi.com/journal/symmetry/special\_issues/Simulation\_Modelling\_Natural\_Sciences\_Biomedicine\_Engineering\_2022

Download keyboard\_arrow\_down

https://www.mdpi.com/2073-8994/17/3/397

Download PDF

https://www.mdpi.com/2073-8994/17/3/397/pdf?version=1741251964

Download PDF with Cover

https://www.mdpi.com/2073-8994/17/3/397

Download XML

https://www.mdpi.com/2073-8994/17/3/397

Download Epub

https://www.mdpi.com/2073-8994/17/3/397/epub

Browse Figures

https://www.mdpi.com/2073-8994/17/3/397

https://pub.mdpi-res.com/symmetry/symmetry-17-00397/article\_deploy/html/images/symmetry-17-00397-g001.png?1741252106

https://pub.mdpi-res.com/symmetry/symmetry-17-00397/article\_deploy/html/images/symmetry-17-00397-g002.png?1741252108

https://pub.mdpi-res.com/symmetry/symmetry-17-00397/article\_deploy/html/images/symmetry-17-00397-g003.png?1741252109

https://pub.mdpi-res.com/symmetry/symmetry-17-00397/article\_deploy/html/images/symmetry-17-00397-g004.png?1741252111

https://pub.mdpi-res.com/symmetry/symmetry-17-00397/article\_deploy/html/images/symmetry-17-00397-g005.png?1741252112

https://pub.mdpi-res.com/symmetry/symmetry-17-00397/article\_deploy/html/images/symmetry-17-00397-g006.png?1741252113

https://pub.mdpi-res.com/symmetry/symmetry-17-00397/article\_deploy/html/images/symmetry-17-00397-g007.png?1741252115

https://pub.mdpi-res.com/symmetry/symmetry-17-00397/article\_deploy/html/images/symmetry-17-00397-g008.png?1741252117

https://pub.mdpi-res.com/symmetry/symmetry-17-00397/article\_deploy/html/images/symmetry-17-00397-g009.png?1741252118

https://pub.mdpi-res.com/symmetry/symmetry-17-00397/article\_deploy/html/images/symmetry-17-00397-g010.png?1741252119

https://pub.mdpi-res.com/symmetry/symmetry-17-00397/article\_deploy/html/images/symmetry-17-00397-g011.png?1741252121

https://pub.mdpi-res.com/symmetry/symmetry-17-00397/article\_deploy/html/images/symmetry-17-00397-g012.png?1741252123

Versions Notes

https://www.mdpi.com/2073-8994/17/3/397/notes

Article Views

https://www.mdpi.com/2073-8994/17/3/397#metrics

Citations -

https://www.mdpi.com/2073-8994/17/3/397#metrics

This study introduces a custom-designed CNN architecture that extracts robust, multi-level facial features and incorporates preprocessing techniques to correct or reduce asymmetry before classification. The innovative characteristics of this research lie in its integrated approach to overcoming facial asymmetry challenges and enhancing CNN-based emotion recognition. This is completed by well-known data augmentation strategies—using methods such as vertical flipping and shuffling—that generate symmetric variations in facial images, effectively balancing the dataset and improving recognition accuracy. Additionally, a Loss Weight parameter is used to fine-tune training, thereby optimizing performance across diverse and unbalanced emotion classes. Collectively, all these contribute to an efficient, real-time facial emotion recognition system that outperforms traditional CNN models and offers practical benefits for various applications while also addressing the inherent challenges of facial asymmetry in emotion detection. Our experimental results demonstrate superior performance compared to other CNN methods, marking a step forward in applications ranging from human–computer interaction to immersive technologies while also acknowledging privacy and ethical considerations.

convolutional neural networks

https://www.mdpi.com/search?q=convolutional+neural+networks

deep learning

https://www.mdpi.com/search?q=deep+learning

image preprocessing

https://www.mdpi.com/search?q=image+preprocessing

real-time emotion analysis

https://www.mdpi.com/search?q=real-time+emotion+analysis

1. Introduction

In recent years, immersive technologies, such as virtual reality (VR), augmented reality (AR), and mixed reality (MR), have become major subjects of interest in research and industry due to their potential to transform various fields, from education and entertainment to professional training and healthcare. Recent studies have mainly focused on the development and optimization of haptic feedback, which provides users with a tactile sensation or physical interaction in virtual environments, thereby enhancing the level of realism and engagement.

However, emotional feedback, which can be observed and interpreted through facial expressions, represents another essential component of immersive experiences. The ability to understand and respond to users' emotions in real time plays an important role in creating a natural and authentic interaction between humans and immersive systems. Recognizing facial emotions through convolutional neural networks (CNNs) is an advanced and effective tool for analyzing emotional experiences and providing appropriate feedback.

Facial emotions are not only essential indicators of a person's internal state but also mechanisms that provide fundamental information about intentions and attitudes. They can be defined as a universal language through which we communicate our affective experiences. Throughout history, researchers and psychologists have explored the complexity of human emotions, focusing, in particular, on the facial expressions that accompany them. In this context, the study of facial emotion recognition is grounded in Charles Darwin's \[

https://www.mdpi.com/2073-8994/17/3/397#B1-symmetry-17-00397

\] evolutionary theory, which suggests that certain facial expressions emerged as a way to communicate emotional states that could influence survival and social interactions.

Studies show that recognizing “what is seen on the face” can influence not only our perception of others but also our emotional reactions. For example, a facial expression of joy can generate a sense of comfort and openness, while an expression of Fear or anger can induce a state of alertness or even anxiety \[

https://www.mdpi.com/2073-8994/17/3/397#B2-symmetry-17-00397

\]. This emphasizes the interconnection between expressed and perceived emotions, having a direct impact on social dynamics.

Research conducted by Paul Ekman, a pioneer in this field, emphasizes that there are seven fundamental emotions that are recognized through facial expressions: joy, Sadness, Fear, anger, Disgust, surprise, and contempt \[

https://www.mdpi.com/2073-8994/17/3/397#B3-symmetry-17-00397

\]. Each of these emotions has a distinct function and is associated with physiological and behavioral responses that reflect the way an individual perceives and reacts to the surrounding environment.

This classification has not only revolutionized the understanding of emotions but has also opened new directions for research regarding non-verbal communication and social perception.

However, not all researchers agree with Ekman's assertions. Gendron and his collaborators conducted a similar study, but unlike Ekman, they did not provide definitions of facial expressions, which led to difficulties in replicating results \[

https://www.mdpi.com/2073-8994/17/3/397#B4-symmetry-17-00397

\]. Other research, such as that conducted by Reisenzein et al., has highlighted the existence of reduced coherence between the identified universal emotions and the associated facial expressions \[

https://www.mdpi.com/2073-8994/17/3/397#B5-symmetry-17-00397

\]. This suggests that, despite some partial consensus, the debate regarding the universality of these emotions and expressions is far from settled.

The recognition of facial emotions through CNNs is significantly influenced by the concepts of symmetry and asymmetry in facial expressions. Research indicates that facial asymmetries are not merely cosmetic but play a major role in how emotions are expressed and perceived, which is vital for training effective CNN models. For instance, the authors of \[

https://www.mdpi.com/2073-8994/17/3/397#B6-symmetry-17-00397

\] emphasize that the left side of the face often displays more intense emotional expressions due to the right hemisphere's dominance in emotional processing. This inherent asymmetry can create challenges for CNNs, as traditional datasets may not adequately represent the emotional cues present in the less expressive side of the face. Additionally, the work by \[

https://www.mdpi.com/2073-8994/17/3/397#B7-symmetry-17-00397

\] highlights that the intensity of expressions can vary based on hemispheric dominance, suggesting that CNNs must be trained on diverse datasets that capture these details to improve accuracy in emotion recognition. Furthermore, ref. \[

https://www.mdpi.com/2073-8994/17/3/397#B8-symmetry-17-00397

\] provides evidence that the orientation of facial poses affects emotional expression, indicating that CNN architectures should be designed to account for variations in pose and expression to enhance their robustness. By integrating all these into the design and training of CNNs, models can be created that are capable of accurately recognizing emotions that reflect the complexities of human emotional expression.

In this context, in order to address the challenges associated with facial emotion recognition and to contribute to the development of efficient and innovative solutions in this field, this paper aims to achieve the following objectives:

OB1: Leveraging symmetry and addressing asymmetry.

OB2: Development and validation of a custom CNN model.

Beyond investigating symmetry techniques aimed at improving facial emotion recognition through CNNs, this study also proposes the development of a network focused on creating an efficient model for facial emotion recognition and its implementation in a real-time facial expression recognition application. Building a CNN from scratch for facial emotion recognition provides a detailed understanding of the internal mechanisms of the network, thereby facilitating the customization and optimization of the network architecture. Unlike pre-trained models, such as EfficientNet or ResNet, which are computationally expensive and may include redundant features not specifically tailored for facial emotion recognition, our approach ensures a lightweight, interpretable, and resource-efficient model optimized for real-time applications.

It is important to note that the images used for facial emotion recognition were not included in the datasets covered by standard pre-trained models. This reality emphasizes the need to develop a comprehensive learning model that can be appropriately adapted to the unique characteristics and specific requirements of the addressed problem. Thus, a customized model responds more adequately to current challenges in the field and contributes to the overall advancement of facial emotion recognition technologies, opening new research and application possibilities across various domains, from psychology and sociology to human–computer interaction and marketing.

Therefore, this endeavor is not limited to technical improvements but has profound implications for how we can advance our understanding of human emotions through modern technologies.

2. Literature Review

Among the most popular techniques developed in the initial period of this field are Fisherfaces \[

https://www.mdpi.com/2073-8994/17/3/397#B9-symmetry-17-00397

\] and Eigenfaces \[

https://www.mdpi.com/2073-8994/17/3/397#B10-symmetry-17-00397

\], which used advanced mathematical methods such as Principal Component Analysis (PCA) \[

https://www.mdpi.com/2073-8994/17/3/397#B11-symmetry-17-00397

\] and Linear Discriminant Analysis (LDA) \[

https://www.mdpi.com/2073-8994/17/3/397#B12-symmetry-17-00397

\]. In the contemporary technological era, facial emotion recognition methods have evolved significantly, benefiting from advances in the field of artificial intelligence. CNNs have become an exceptionally effective tool for the automatic recognition of these facial emotions, demonstrating promising applications in computer vision \[

https://www.mdpi.com/2073-8994/17/3/397#B13-symmetry-17-00397

\]. Several relevant studies have used widely recognized datasets, such as Cohn–Kanade (CK) \[

https://www.mdpi.com/2073-8994/17/3/397#B14-symmetry-17-00397

\], Cohn–Kanade Extended (CK+) \[

https://www.mdpi.com/2073-8994/17/3/397#B15-symmetry-17-00397

\], facial expression recognition (FER2013) \[

https://www.mdpi.com/2073-8994/17/3/397#B16-symmetry-17-00397

\], and Japanese Female Facial Expression (JAFFE) \[

https://www.mdpi.com/2073-8994/17/3/397#B17-symmetry-17-00397

\]. These resources include the seven fundamental emotions recognized in the research conducted in this field \[

https://www.mdpi.com/2073-8994/17/3/397#B18-symmetry-17-00397

Supta et al. \[

https://www.mdpi.com/2073-8994/17/3/397#B19-symmetry-17-00397

\] developed an FER system utilizing Histogram of Oriented Gradients (HOG) and Support Vector Machine (SVM) technology, achieving remarkable accuracy levels of 97.62% for the JAFFE dataset and 98.61% for the CK dataset. Traditional methods for feature extraction in emotion recognition systems typically involve complex image preprocessing and manual feature extraction, which are time-consuming \[

https://www.mdpi.com/2073-8994/17/3/397#B20-symmetry-17-00397

\]. This manual process heavily relies on the prior knowledge and experience of researchers, and the techniques used can significantly influence the efficiency of the extracted features, potentially leading to variations in system performance. In contrast, an automated approach based on deep learning has proven highly effective for image classification, though it requires large datasets for training to achieve efficient recognition. Recent studies have shown the effectiveness of automated approaches in the feature extraction process, particularly using CNN algorithms. These approaches enable more robust feature extraction that is less susceptible to subjective variations, thereby enhancing the accuracy and efficiency of emotion recognition systems.

Ramalingam and Garzia \[

https://www.mdpi.com/2073-8994/17/3/397#B21-symmetry-17-00397

\] developed a CNN algorithm that integrates a convolutional layer, rectified linear unit (ReLU), max pooling layer for feature extraction, and a fully connected layer, achieving an accuracy of approximately 60% on the FER2013 dataset, which contains 35,887 images. In another study, they employed transfer learning with the pre-trained VGG16 model on FER2013, achieving an accuracy of 78%. Both these accuracies are rather low.

Raja Sekaran et al. \[

https://www.mdpi.com/2073-8994/17/3/397#B22-symmetry-17-00397

\] implemented a transfer learning method using AlexNet as a pre-trained model and introduced an early stopping mechanism to address overfitting. This model achieved an accuracy of 70.52% on the FER2013 dataset. Abdulsattar and Hussain \[

https://www.mdpi.com/2073-8994/17/3/397#B23-symmetry-17-00397

\] developed six dedicated deep learning models for facial expression identification, including MobileNet, VGG16, VGG19, DenseNet121, Inception-v3, and Xception. They evaluated these models through transfer learning strategies and fine-tuning on the FER2013 dataset. Their results demonstrated that fine-tuning outperformed transfer learning, with efficiency variations ranging from 1% to 10%. Notably, pre-trained models like ResNet101V2 achieved remarkable performance, with a training accuracy of 93.08% and a validation accuracy of 92.87%. These findings highlight the effectiveness of deep learning approaches in facial expression recognition and the importance of advanced preprocessing and model optimization, but they require considerable computational resources.

Sajjanhar et al. \[

https://www.mdpi.com/2073-8994/17/3/397#B24-symmetry-17-00397

\] showed that the type of preprocessing applied to input data can significantly influence the quality of the resulting model. Meena et al. \[

https://www.mdpi.com/2073-8994/17/3/397#B25-symmetry-17-00397

\] investigated the use of a CNN for emotion identification based on facial expressions, utilizing both the CK+ and FER2013 datasets. They developed various architectures to assess the effectiveness of the models on these datasets. The CNN-3 model, which classifies expressions into three categories—positive, negative, and neutral—achieved 79% accuracy on FER2013 and 95% on CK+. In comparison, the CNN-7 model, which recognizes seven basic expressions, demonstrated slightly lower accuracy: 69% on FER2013 and 92% on CK+. These results indicate that the complexity of facial expression classification affects model efficiency, keeping low accuracies on the FER2013 dataset.

Recent research has also explored advanced models to improve emotion recognition from video data \[

https://www.mdpi.com/2073-8994/17/3/397#B26-symmetry-17-00397

https://www.mdpi.com/2073-8994/17/3/397#B27-symmetry-17-00397

\]. Bilotti et al. \[

https://www.mdpi.com/2073-8994/17/3/397#B27-symmetry-17-00397

\] proposed a multimodal approach using CNNs, integrating frames with human faces, optical flow, and Mel spectrograms. This method achieved an accuracy of approximately 95% on the BAUM-1 dataset and 95.5% on the RAVDESS dataset. The accuracies are very high, but the BAUM-1 and RAVDESS datasets provide multimodal datasets that include audio–visual recordings with posed expressions and speech components, while FER2013 consists of a large number of unconstrained, in-the-wild grayscale facial images covering seven fundamental emotions.

The limitations in the current literature on FER are multifaceted and significantly impact the effectiveness of existing systems. One major issue is the tendency of deep learning models to overfit, particularly when trained on limited datasets, which can result in poor generalization to real-world scenarios \[

https://www.mdpi.com/2073-8994/17/3/397#B18-symmetry-17-00397

https://www.mdpi.com/2073-8994/17/3/397#B23-symmetry-17-00397

\]. Additionally, the reliance on specific datasets, such as the Cohn–Kanade (CK) dataset, raises concerns about the representativeness of the training data, as these datasets often contain posed expressions rather than spontaneous emotional responses, leading to discrepancies in model performance \[

https://www.mdpi.com/2073-8994/17/3/397#B15-symmetry-17-00397

\]. The computational complexity of deep learning approaches further complicates their practical application, as they require substantial resources for training and inference, which may not be feasible in real-time settings \[

https://www.mdpi.com/2073-8994/17/3/397#B24-symmetry-17-00397

\]. Moreover, the simplistic categorization of human emotions in many models fails to capture the nuanced and dynamic nature of emotional expressions, which can vary significantly across individuals and contexts \[

https://www.mdpi.com/2073-8994/17/3/397#B25-symmetry-17-00397

https://www.mdpi.com/2073-8994/17/3/397#B26-symmetry-17-00397

\]. Finally, ethical considerations surrounding the deployment of FER technologies, particularly in sensitive areas such as surveillance and healthcare, necessitate careful scrutiny to prevent potential misuse and ensure respect for individual privacy \[

https://www.mdpi.com/2073-8994/17/3/397#B20-symmetry-17-00397

\]. Collectively, these limitations highlight the need for ongoing research to develop more robust, generalizable, and ethically sound FER systems.

In light of the previously presented research, significant progress can be observed in the field of facial emotion recognition, particularly through the use of CNNs and modern deep learning methods. Studies highlight both the efficiency of customized CNN architectures and the advantages of using pre-trained models through transfer learning and fine-tuning to enhance performance.

However, certain challenges remain regarding the optimization of CNN architectures to address the complexity of facial expressions, especially under conditions of asymmetric variability and the need for advanced preprocessing of input data. Also, data augmentation methods and asymmetry correction strategies represent promising directions for robustly improving system performance.

These aspects pave the way for more detailed investigations into the following research questions:

What are the most effective methods for correcting the asymmetry of facial expressions to achieve improved performance of the CNN model?

To what extent does data augmentation, through the generation of symmetrical variations, contribute to increasing accuracy in facial emotion recognition?

How can the architecture of a CNN be optimized to improve real-time facial emotion recognition?

How can the performance of the CNN be evaluated, and what are the limitations of the model in facial emotion recognition?

3. Materials and Methods

The objectives guide the methods and approaches adopted in this study, as shown in

https://www.mdpi.com/2073-8994/17/3/397#fig\_body\_display\_symmetry-17-00397-f001

Research flowchart illustrating the objectives and methods employed.

OB1: Leveraging symmetry and addressing asymmetry. To improve the performance of CNNs in recognizing facial emotions, image preprocessing techniques aimed at correcting or reducing asymmetry in facial expressions are used. Asymmetry often poses a challenge for models by introducing variability that can affect accurate classification. Additionally, image augmentation methods are employed to generate symmetrical variations, thereby enhancing the diversity and representativeness of the training dataset. These methods aim to provide the model with more balanced and varied data, improving its ability to generalize across different cases.

OB2: Development and validation of a custom CNN model. To address the unique challenges posed by real-time facial emotion recognition, the focus is on the development of a custom CNN model. The model is designed and trained to efficiently classify facial expressions, with particular attention to the complexities introduced by asymmetrical features. Following its development, the CNN is tested for its performance in recognizing emotions. Validation is conducted on unseen datasets to assess the model's generalizability and robustness, ensuring its applicability in real-world cases.

The following subsections provide a detailed overview of all the materials and methods involved.

## Dataset Analysis

In selecting the dataset for this study, we considered several widely used benchmarks in FER, including Cohn–Kanade Extended (CK+), FER2013, AffectNet, and RAF-DB, each with distinct characteristics and advantages. CK+ is a well-structured dataset containing high-quality, sequentially captured facial expressions, primarily in controlled environments. While it is effective for analyzing posed emotions, its relatively small size and limited diversity in real-world variations make it less suitable for deep learning models that require large-scale data. AffectNet and RAF-DB provide more extensive emotion annotations, including compound expressions, offering a richer dataset for fine-grained emotion recognition. However, these datasets come with increased computational costs due to their complexity and larger image resolutions.

Given the objectives of our study, we chose FER2013, a widely recognized benchmark dataset, for its large-scale, diverse, and challenging nature. FER2013 contains 35,887 grayscale images of facial expressions across seven fundamental emotions, collected from various sources under unconstrained, real-world conditions. Unlike CK+, FER2013 provides significant variability in facial angles, lighting, and occlusions, which better simulates the challenges encountered in real-world FER applications. However, we acknowledge certain limitations of FER2013, including its class imbalance—where emotions such as Disgust are underrepresented—as well as inconsistencies in annotation quality due to its automatic collection process. Despite these limitations, FER2013 remains one of the most widely used datasets for benchmarking CNN-based emotion recognition models, ensuring comparability with existing research while providing a robust training and evaluation platform.

FER2013 is a dataset provided by Kaggle, introduced at the International Conference on Computer Vision (ICCV) in 2013 \[

https://www.mdpi.com/2073-8994/17/3/397#B28-symmetry-17-00397

https://www.mdpi.com/2073-8994/17/3/397#B29-symmetry-17-00397

https://www.mdpi.com/2073-8994/17/3/397#B30-symmetry-17-00397

\]. This dataset was developed to support the advancement of research in the field of emotion recognition through the analysis of facial expressions. The dataset contains images sized 48 × 48 pixels that capture various facial expressions. The images are grouped into the 7 types of emotions. Each image is associated with a label indicating the predominant emotion, thus facilitating the training of machine learning models. The dataset is divided into two parts: one for training and one for testing, which is essential for evaluating the performance of the developed models.

A notable aspect of the dataset is that the images contain facial expressions of individuals of different ages, genders, and races, leading to diversity and balanced representation. As research in artificial intelligence continues to evolve, FER2013 will remain a cornerstone for future innovations in recognizing and interpreting human emotions.

## Data Augmentation

To address the challenges of asymmetry in improving facial emotion recognition based on a CNN, we considered various data augmentation techniques and class weight adjustments:

Case 1: Training the CNN using data augmentation with the Shuffle function.

Case 2: Training the CNN using data augmentation with the Shuffle and Flip-Vertical functions.

Case 3: Training the CNN using data augmentation with the Loss Weight parameter.

Case 4: Training the CNN using data augmentation with the Shuffle function and the Loss Weight parameter.

Case 5: Training the CNN using data augmentation with the Flip-Vertical and Shuffle functions and the Loss Weight parameter.

Case 6: Training the CNN using data augmentation with the Shuffle function and a larger number of images in the test set.

All programs and tests were run on a general-purpose laptop with an Intel Core i7 processor, 1.80 GHz, 16 GB RAM, and a 512 GB hard drive, and no GPU. The software used to run the program was Python 3.9 with the Keras and TensorFlow 2.16 libraries, which are optimized for emotion-classification tasks based on images.

In this paper, for all cases, images from the FER2013 dataset were used for training the network, and the distribution of images is presented in

https://www.mdpi.com/2073-8994/17/3/397#fig\_body\_display\_symmetry-17-00397-f002

. There is an imbalance between classes in both the training and testing sets. The training set contains 28,412 images of size 48 × 48 pixels in grayscale.

Emotion image distribution in the training and validation sets.

For the proposed Cases 1–5, images from the FER2013 dataset \[

https://www.mdpi.com/2073-8994/17/3/397#B31-symmetry-17-00397

\] were used, which were divided as follows: 80% for the training set and 20% for validation. For the validation images, publicly labeled images from the FER2013 dataset were used, while privately labeled images were replaced with images from another source on kaggle.com \[

https://www.mdpi.com/2073-8994/17/3/397#B32-symmetry-17-00397

\]. The validation set contained 7066 images that were not included in the training set. Their distribution is presented in

https://www.mdpi.com/2073-8994/17/3/397#table\_body\_display\_symmetry-17-00397-t001

Distribution of data in the validation set.

For Case 6, the images in the dataset were divided as follows: 68% of the images were for the training set, and 32% were for the validation set. The test set contained 13,846 images and was enhanced with images that were not known, meaning they were not found in the training set. Their distribution is presented in

https://www.mdpi.com/2073-8994/17/3/397#fig\_body\_display\_symmetry-17-00397-f002

Regardless of the images we had in the datasets for facial expressions, the testing and training images were processed by normalizing the pixel values. Two image generators were created: one for training and one for testing/validation.

The flow from the folder function was used to scan the subfolders and collect and process all the data. Each image was resized to 48 × 48 pixels, and batches of size 64 were created with the color mode set to grayscale, while the class mode created categories based on the structure of the subfolders.

The proposed network architecture is designed to process grayscale images of 48 × 48 pixels and aims to classify them into one of the seven emotion categories. This specification directly influences the architecture of the neural network, setting the number of neurons in the output layer to 7, allowing the model to associate features extracted from the data with the seven emotions. The model evaluates each input against these emotions, using the ReLU activation function to determine the probability that an input belongs to a specific class.

## Convolutional Neural Network

A CNN represents a specialized category of a neural network that has been specifically developed to address the challenges associated with image classification and recognition \[

https://www.mdpi.com/2073-8994/17/3/397#B33-symmetry-17-00397

\]. It is an advanced technology frequently used in fields where data are of considerable complexity or size, exceeding the capabilities of traditional machine learning methods. These systems are structured in a series of layers, each with distinct responsibilities that contribute to the learning process and optimization of the model's performance \[

https://www.mdpi.com/2073-8994/17/3/397#B34-symmetry-17-00397

\]. CNNs use a specific type of layer called a convolutional layer, which performs a convolution operation on an input image, thereby generating a feature map at the output \[

https://www.mdpi.com/2073-8994/17/3/397#B35-symmetry-17-00397

\]. In the context of image classification, the convolution operation serves to detect patterns within images, indicating the presence of a specific object or feature unique to a particular class.

#### The main components of a CNN are as follows:

The first layer is the input layer, whose main function is to process the raw image data. It is responsible for transforming visual information into a compatible format usable for the subsequent stages of the model.

The next layer, the convolutional layer, applies a series of filters to the image. These filters are essential as they extract relevant features from the image, such as edges, corners, and textures. This feature extraction is important for understanding facial structures and the emotions they send. After applying the filters, the pooling layer serves to reduce the image size, thus decreasing the amount of data that needs to be processed. This reduction not only makes processing more efficient but also helps achieve a better level of model generalization.

Furthermore, the use of a dropout layer is a common method in training neural networks. This layer randomly sets a percentage of the neurons in that layer to zero during each training iteration, typically between 20% and 50%. The goal of this method is to prevent excessive dependence of the network on a single feature or neuron, which could lead to overfitting and, consequently, poor generalization on new data.

Finally, the output layer synthesizes the processed information and produces the final classification. To effectively train a CNN for facial emotion detection, it is essential to have a large dataset of appropriately labeled images that reflect the desired emotions.

Regardless of the chosen method, facial expression recognition consists of 4 main stages, as represented in

https://www.mdpi.com/2073-8994/17/3/397#fig\_body\_display\_symmetry-17-00397-f003

Stages of facial expression recognition.

Face detection is the stage responsible for selecting the region of interest (ROI) from an input image that will be used in the next stages of facial expression recognition systems.

In the literature, a notable example of this type of approach is the Viola–Jones face detector, recognized for its efficiency in this field \[

https://www.mdpi.com/2073-8994/17/3/397#B36-symmetry-17-00397

\]. Within this algorithm, a significant number of positive images (those containing faces) and negative images (those not containing faces) are used to train the model. An essential aspect of this process is the use of Haar features, which are systematically applied to all images in the training set. The goal is to determine the most suitable threshold for classifying faces as positive or negative detections, thus optimizing the model's accuracy.

However, it is important to mention that although faces can be identified in the input image, this does not guarantee that they are in a suitable condition for analysis. It is essential to verify the geometric correlation of the face whose emotions are to be classified with the geometric models of the faces used in the training of the classifier. Thus, geometric variations that can affect the quality of face detection and analysis include, in particular, scaling, rotation, and the presence of noise \[

https://www.mdpi.com/2073-8994/17/3/397#B37-symmetry-17-00397

\]. These transformations can negatively influence the emotional identification process and, therefore, must be carefully managed to ensure an accurate and correct assessment of affective states.

Image processing represents a fundamental step in facial emotion recognition systems. This phase involves transforming and organizing raw data to enhance its quality and relevance. In the absence of proper processing, data analysis can generate inadequate or even incorrect results.

The use of processing techniques, such as normalization, noise filtering (bilateral filter \[

https://www.mdpi.com/2073-8994/17/3/397#B38-symmetry-17-00397

\], Gaussian filter \[

https://www.mdpi.com/2073-8994/17/3/397#B39-symmetry-17-00397

\]), and anomaly detection and correction (histogram equalization \[

https://www.mdpi.com/2073-8994/17/3/397#B40-symmetry-17-00397

\]), allows for the extraction of significant and relevant features from these datasets.

Ensuring a high standard of data quality is an essential factor for the performance of the machine learning model. A dataset that has been properly processed is not only capable of improving prediction accuracy but also contributes to the efficiency of the algorithms used. Datasets dedicated to emotion recognition are generally small in size. This limitation constitutes a major obstacle because training on low-volume datasets can lead to overfitting, a phenomenon frequently encountered in machine learning models \[

https://www.mdpi.com/2073-8994/17/3/397#B41-symmetry-17-00397

\]. Overfitting occurs when a model successfully classifies the data used during the training process but faces significant challenges in classifying new data that were not previously used in the training process. This situation results in poor generalization performance, which is a major limitation for the practical use of that model.

To counteract this problem, which is often the result of using small datasets, data augmentation techniques are employed to increase the volume of the available data by modifying the data while preserving the integrity of the original meanings. The implementation of data augmentation can be achieved through a series of geometric and chromatic transformations, such as cropping, flipping, rotating, adjusting brightness, or resizing \[

https://www.mdpi.com/2073-8994/17/3/397#B42-symmetry-17-00397

Regarding feature extraction, in the context of facial emotion recognition techniques, researchers apply a variety of conventional methods to extract relevant features from input images. These methods include cropping faces followed by converting them into monochrome \[

https://www.mdpi.com/2073-8994/17/3/397#B43-symmetry-17-00397

\] images, approaches based on Local Binary Patterns (LBPs) \[

https://www.mdpi.com/2073-8994/17/3/397#B44-symmetry-17-00397

\], optical flow analysis \[

https://www.mdpi.com/2073-8994/17/3/397#B45-symmetry-17-00397

\], and Principal Component Analysis (PCA) \[

https://www.mdpi.com/2073-8994/17/3/397#B46-symmetry-17-00397

\], as well as the use of Histogram of Oriented Gradients (HOG) \[

https://www.mdpi.com/2073-8994/17/3/397#B19-symmetry-17-00397

\]. Also, a significant number of studies resort to using automated methods for feature extraction by implementing algorithms based on CNNs.

Classification involves applying specialized algorithms to the features extracted from the initial data. After these features have been extracted and appropriately processed, the next step is to implement classification algorithms to determine the emotion expressed on the human face. Among the most common classification techniques are CNNs, which are recognized for their ability to learn complex representations from input data \[

https://www.mdpi.com/2073-8994/17/3/397#B47-symmetry-17-00397

\]. By using convolutional layers, these networks can identify and extract relevant features from visual or textual data, significantly impacting the accuracy of emotion classification.

## Metrics Used in Evaluation

To evaluate the proposed neural network, we used the following metrics: confusion matrix, F1 score, precision, and recall \[

https://www.mdpi.com/2073-8994/17/3/397#B48-symmetry-17-00397

The confusion matrix is an essential tool in evaluating the performance of a classification model, providing information regarding the correct and incorrect classifications of instances. In the literature, it is also referred to by the name the error matrix. True Positive (TP) indicates instances in the dataset correctly classified as belonging to the positive class; True Negative (TN) indicates instances in the dataset correctly classified as belonging to the negative class; false positive (FP) indicates instances in the dataset that were incorrectly classified as positive; and False Negative (FN) indicates instances in the dataset that were incorrectly classified as negative.

The values on the diagonal represent the number of instances correctly classified for each class. The values outside the diagonal indicate the number of instances that were misclassified.

Accuracy is the ratio of correctly predicted values to the total predicted values. The higher the accuracy, the better the performance of the model.

Precision measures the accuracy of the model's positive predictions \[

https://www.mdpi.com/2073-8994/17/3/397#B49-symmetry-17-00397

\]. It is calculated according to the formula:

P r e c i s i o n = T P T P + F P

Recall or sensitivity measures the ability of the model to correctly identify positive instances \[

https://www.mdpi.com/2073-8994/17/3/397#B50-symmetry-17-00397

\]. It is calculated according to the formula:

R e c a l l = T P T P + F N

The F1 score is the harmonic mean of precision and recall. It is an essential metric used to evaluate the performance of a classification model, especially in the case of datasets with unbalanced classes, as it provides a more balanced assessment than using precision or recall alone \[

https://www.mdpi.com/2073-8994/17/3/397#B51-symmetry-17-00397

\]. It is calculated according to the formula:

· P r e c i s i o n

· R e c a l l P r e c i s i o n + R e c a l l

The F1 score ranges from 0 (poor performance) to 1 (perfect performance). A higher F1 score indicates better model performance.

## CNN Architecture

The model was defined sequentially. This approach facilitates adding layers in a specific order, thus creating a network architecture that is intuitive and easy to manage. The model structure is designed to reflect a gradual progression in complexity, which allows for efficient and accurate processing of input data. The network structure is represented in

https://www.mdpi.com/2073-8994/17/3/397#fig\_body\_display\_symmetry-17-00397-f004

Network structure.

The proposed model includes three convolutional layers (Conv2D), each with a different number of filters: 32, 64, and 128. These layers play an essential role in extracting relevant features from the input images. The first convolutional layer, with 32 filters, is responsible for detecting basic features such as edges and textures. Then, the second layer, with 64 filters, captures more complex features like shapes and patterns. Finally, the 128-filter layer deepens the analysis, identifying more complex combinations of features and allowing the model to learn meaningful representations of the visual data.

To introduce non-linearities into the network, the ReLU activation function was chosen. This is a frequently used choice in modern neural network architectures, having the advantage of allowing the network to learn complex functions and handle various classification tasks. In addition to the ReLU activation function, a subsampling technique called MaxPooling was applied. MaxPooling helps reduce the volume of information, keeping the most relevant features extracted from the previous layers and resulting in a more efficient and manageable network.

Another important aspect of the model is the use of Dropout as a regularization method. This technique plays an important role in preventing overfitting, a common problem in deep learning. By deactivating neurons randomly during training, Dropout helps the model not to depend too much on a limited set of neurons, which improves its generalization to new data.

To be able to efficiently interact with fully connected layers, we included a Flatten layer, which transforms the result of the last convolutional layer into a one-dimensional matrix. This step is essential because it allows the model to process the extracted features into a format suitable for classification. Data flattening ensures that complex information extracted by previous layers is presented in a form that can be used by fully connected layers.

The Dense layer, which follows the Flatten layer, is responsible for classifying the data. It receives the features extracted from the convolutional layers as input and processes them to determine the belonging to the different classes. In this layer, we included a ReLU activation function, which helps introduce non-linearity into the model, making it easier to learn complex relationships between the data. We also implemented Dropout with a rate of 20% to add an additional layer of regularization, which helps to prevent overfitting and improve the generalization of the model on new data.

In the end, the output layer is created using a Dense function, with the number of units equivalent to the number of classes we want to classify, in this case, 7 classes of emotions. The softmax activation function is applied to this layer, generating belonging probabilities for each of the defined classes. This allows the model to provide a probability distribution, indicating how likely it is that each input is associated with a particular emotion.

Our custom CNN architecture is optimized for facial emotion recognition, integrating convolutional layers for feature extraction, pooling layers for dimensionality reduction, and fully connected layers for classification. The network processes grayscale images of size 48 × 48, extracting hierarchical spatial features through successive convolutional layers with ReLU activation functions, ensuring non-linearity and efficient gradient propagation. Mathematically, the convolutional operation can be expressed as:

Z i j l = f ∑ m , n W m n l

· X i + m j + n l − 1 + b l

where Z i j l is the output of the convolution at layer l, W m n l represents the filter weights, X i + m j + n l − 1 is the input feature map, b l is the bias term, and f(⋅) denotes the ReLU activation function.

To improve generalization and prevent overfitting, Dropout layers are incorporated at different stages, randomly deactivating neurons during training. Additionally, categorical cross-entropy loss is minimized during optimization, given by:

L = − ∑ i = 1 N y i

· l o g y ^ i

where y i represents the true label and y ^ i is the predicted probability for class i. The model is optimized using the Adam optimizer, which updates weights iteratively as:

· m t − 1 + 1 − β 1

· v t − 1 + 1 − β 2

θ t = θ t − 1 − α v t + ϵ

are moving averages of the gradient g

are decay rates, and α is the learning rate.

This model is designed to efficiently extract emotion-related features while maintaining computational feasibility for real-time applications. Further refinements, such as loss weighting and data augmentation, enhance its robustness to challenges like class imbalance and facial asymmetry, ensuring reliable emotion classification.

In our model implementation, weight initialization is handled by default in Keras when using ReLU activation functions in both convolutional and dense layers. This initialization technique prevents issues such as vanishing or exploding gradients, ensuring stable training and facilitating efficient learning. To further enhance generalization and mitigate overfitting, we incorporated Dropout layers at multiple stages, with dropout rates of 0.25 and 0.5, randomly deactivating neurons during training. This technique reduces model dependency on specific neurons, encouraging more robust feature learning.

For optimization, we utilized the Adam optimizer with a learning rate of 0.0001 and a decay factor of 10

. Adam is a widely used adaptive optimization algorithm that combines the advantages of momentum-based and RMSprop optimization, leading to efficient weight update while maintaining stability across varying learning rates. The inclusion of weight decay ensures that learning rate adjustments continue throughout training, preventing the model from overfitting and maintaining generalization.

While explicit early stopping is not implemented in the training pipeline, the number of epochs (50) was carefully determined based on prior experiments to optimize model convergence. The combination of weight decay, dropout, and structured CNN architecture helps mitigate overfitting while maintaining strong generalization capabilities. Additionally, by monitoring validation accuracy trends during training, manual early stopping can be applied if performance degradation is observed.

The training process is designed to balance efficiency and stability using mini-batch stochastic gradient descent (SGD) with a batch size of 64. This approach optimally distributes computational resources while ensuring gradient stability. Furthermore, the steps per epoch and validation steps were configured to ensure that all available training and validation samples contribute effectively to the learning process, leading to a well-trained and generalizable model.

In our study, class imbalance was addressed through weighted loss adjustments, which ensured that underrepresented classes contribute proportionally to the overall loss function, thereby reducing bias toward majority classes. While focal loss and SMOTE (Synthetic Minority Over-sampling Technique) are widely used for handling imbalance, our approach was chosen for its computational efficiency and compatibility with our CNN model. Focal loss is particularly effective in object detection tasks where hard-to-classify examples require more emphasis, but in our case, weighted categorical cross-entropy provided a simpler and effective way to balance class contributions. Additionally, SMOTE, while useful for generating synthetic samples in tabular data, is less commonly applied to image-based datasets due to the complexity of generating realistic facial expression variations. Instead, our study leveraged data augmentation techniques (such as flipping and rescaling) to enhance representation across all classes.

4. Results and Analysis

## CNN Testing

Confusion matrices are presented in this section.

The best classification for Case 1 (

https://www.mdpi.com/2073-8994/17/3/397#fig\_body\_display\_symmetry-17-00397-f005

) is for the emotion Happy, at 95%, with 1738 correctly predicted images. This is also due to the large number of images in the training set for this emotion. The worst performance is seen for the emotion Disgust, with a predictability percentage of 86%, which represents 96 correctly predicted images. It is also the class with the fewest images in the training set.

Confusion matrix—Case 1: data augmentation with the Shuffle function.

The model's performance for Case 2 (

https://www.mdpi.com/2073-8994/17/3/397#fig\_body\_display\_symmetry-17-00397-f006

) improves, where the Happy emotion increases to 96%, and the Sad, Fear, Angry, and Disgust emotions have a percentage of 88%. The prediction percentages are more homogeneous.

Confusion matrix—Case 2: data augmentation with the Shuffle and Flip-Vertical functions.

In Case 3 (

https://www.mdpi.com/2073-8994/17/3/397#fig\_body\_display\_symmetry-17-00397-f007

), the prediction for the Fear class improves to 90%. The Disgust class remains with the lowest percentage of predictability, at 86%, and the Happy class remains with the highest percentage, at 94%.

Confusion matrix—Case 3: data augmentation with the Loss Weight parameter.

In Case 4 (

https://www.mdpi.com/2073-8994/17/3/397#fig\_body\_display\_symmetry-17-00397-f008

), 850 instances of Angry were correctly classified as “Angry”, representing 0.89, or 89%, correct classifications.

Confusion matrix—Case 4: data augmentation with the Shuffle function and the Loss Weight parameter.

We notice that the best classification is for the emotion Happy, at 94%, with 1720 correctly predicted images. This is also due to the large number of images in the training set for this emotion. We see the weakest performance for the feelings of Fear and Sadness, at 88%, with 897 and 1000 correctly predicted images, respectively. One explanation is that the facial expressions for the feelings of Angry, Fear, and Sad can be similar in some circumstances, as seen in

https://www.mdpi.com/2073-8994/17/3/397#fig\_body\_display\_symmetry-17-00397-f009

Similarities between feelings in the FER2013 dataset.

For example, we observe the following incorrect classifications for the feelings of Angry, Fear, and Sad:

A total of 36 cases where the real emotion was “Angry” were incorrectly classified as “Sad”.

A total of 37 cases where the real emotion was “Fear” were incorrectly classified as “Sad”.

Although in the training set, the fewest images were for the emotion Disgust, and we expected it to be in the last position in the hierarchy of prediction values, due to the similarity between the emotions Fear, Angry, and Sad, it is it is ranked in the second-to-last position with a percentage of 89% predictability, meaning that 99 images were correctly predicted.

In Case 5 (

https://www.mdpi.com/2073-8994/17/3/397#fig\_body\_display\_symmetry-17-00397-f010

), the emotion Happy has the best predictability percentage, at 94%, but the emotion Sad has the lowest predictability percentage, at 86%. The explanation, in this case, is also the similarity between the Fear, Angry, and Sad emotions.

Confusion matrix—Case 5: data augmentation with the Flip-Vertical and Shuffle functions and the Loss Weight parameter.

https://www.mdpi.com/2073-8994/17/3/397#fig\_body\_display\_symmetry-17-00397-f011

) shows improvements for most classes and a general tendency to classify the emotions Angry and Disgust better.

Confusion matrix—Case 6: data augmentation with the Shuffle function and a larger number of images in the test set.

https://www.mdpi.com/2073-8994/17/3/397#table\_body\_display\_symmetry-17-00397-t002

presents, for all six cases proposed, the values for precision and accuracy at training and at testing, as well as the number of epochs for training.

Results of training for the six cases.

In the first five cases, the model achieved an accuracy between 91% and 92%, indicating good performance in terms of correctly identifying positive classes. These results suggest that the model is able to effectively recognize facial expressions. It was observed that the training accuracy was also quite high in these cases, demonstrating the model's ability to learn from the available data.

In Case 6, the number of images in the validation set was higher but also more unbalanced compared to the rest of the cases. This is reflected in the accuracy value, indicating a decrease in performance in terms of generalizing the model on the test set. This difference shows the importance of balancing and preparing the dataset for the expected results.

In a specific way, Case 2 stands out for its use of data augmentation functions, i.e., shuffle and vertical flip, achieving the best overall performance. The augmentation by vertical flip addresses the asymmetry in the human face.

The performances on the test set for Cases 1–5 ranged between 90.51% and 91.16%, while Case 6 achieved the lowest accuracy on the test set of 89.25%.

The number of epochs varied between 25 and 50 in the analyses performed. Case 1, trained for 25 epochs, managed to achieve good performance, thus demonstrating that the developed model achieved an efficient adaptation to its data. This suggests that a smaller number of epochs is not necessarily a disadvantage but may indicate efficient learning in the particular context of the data used. On the other hand, Case 2, with 46 epochs, achieved the best precision of 92% and a training accuracy of 93.94%. This suggests that an average number of epochs can contribute to optimizing the performance, but there is no universal rule, as there are also situations in which models trained on a large number of epochs can suffer from the phenomenon of overtraining.

The metrics obtained on the emotion classes are found in

https://www.mdpi.com/2073-8994/17/3/397#table\_body\_display\_symmetry-17-00397-t003

Results for the six cases.

Accuracy analysis: Case 2 demonstrates a remarkable accuracy of 0.99 for the Disgust emotion class, suggesting that this model is exceptionally efficient in correctly identifying this emotion. Such performance is significant, as accuracy scores close to 1.0 indicate exceptional accuracy, reflecting the model's ability to make clear distinctions between adjacent emotions and minimize classification errors. On the other hand, Case 4, with an accuracy of 0.84, shows a significantly poorer performance in identifying the Disgust emotion. This discrepancy may suggest that the model used in this case fails to capture the specific details of the expressions or the context in which Disgust is expressed.

When focusing on the emotion Angry, we observe a variable accuracy, ranging from 0.88 and 0.90. Case 6 stands out as having the best performance, with a score of 0.90. This suggests a robust ability in identifying an emotion that, although it may seem, in many cases, easy to recognize, can still vary considerably depending on the specific context and the associated facial expressions. The stability of the accuracy between cases suggests that the models used were trained on diverse and well-labeled datasets, but there remains potential for enhancement to achieve optimal performance.

Regarding the emotion Surprised, Cases 2 and 4 demonstrate their efficiency with a precision of 0.95, which highlights an accurate identification of this emotion. However, Case 6, with an accuracy of 0.87, indicates an inferior performance. This situation highlights the complexity of emotions and the challenges they present in automatic classification.

Recall analysis: Analyzing the case of the emotion Angry, it is observed that the model achieves a recall of 0.92, which suggests remarkable performance in identifying cases of Anger. This high value indicates that the model is able to detect the majority of instances in which Anger is present, thus demonstrating significant accuracy.

In contrast, the emotion Fear presents a lower recall of 0.82. This value suggests difficulties in correctly identifying the Fear emotion, indicating an area where the model needs improvement. The emotion Fear can often be subtle and can vary significantly depending on the context. For example, Fear can be expressed through a wide range of behaviors and facial expressions, which are not always obvious. This diversity makes the model face challenges in distinguishing Fear from other similar emotions, such as Sadness or Anger. In this regard, a deeper analysis of the training data and the social context is required to improve the identification of this emotion.

Regarding the emotion Happy, the results show constant and good performance, with a recall ranging from 0.94 and 0.96 for all analyzed cases. These high values suggest that the model is effective in recognizing the emotion Happy, which is logical considering that this is an emotion that is often easier to identify.

F1 score analysis: In the case of the emotion Disgust, the observations suggest an F1 score of 0.93 for Case 2, which is distinguished by a remarkable balance between precision and recall. This result indicates that the model was able to identify this emotion efficiently, both in terms of avoiding false positive classifications and correctly capturing positive examples. Case 4, on the other hand, records an F1 score of 0.92, which, although lower, still suggests high performance. This result could suggest refined distinctions among the various datasets used and the complexity of the context in which the emotions are manifested.

In conclusion, the models in Cases 1–5 perform well on most emotions, with high precision and recall. Case 6, although having some good values, shows signs of weakness in identifying the emotions Fear, Sad, and Surprised.

Case 2 is the best optimized, having the best precision and good accuracy on the training set, which suggests that it could be a good reference model.

To assess whether the observed performance improvements are statistically meaningful, a Wilcoxon signed-rank test was conducted to compare accuracy and precision values across multiple runs. This non-parametric test was chosen due to its robustness in handling small sample sizes and non-normally distributed data. The results indicated no statistically significant difference between the accuracy and precision values, confirming the stability and consistency of the model's performance. This shows that the improvements observed across different experimental conditions are not due to random variations but rather reflect the effectiveness of the proposed approach in facial emotion recognition.

Comparing the results obtained in the literature on the FER2013 dataset (

https://www.mdpi.com/2073-8994/17/3/397#table\_body\_display\_symmetry-17-00397-t004

https://www.mdpi.com/2073-8994/17/3/397#B52-symmetry-17-00397

\]) with the results obtained in this study, we can conclude that data augmentation with the Shuffle and vertical flip functions offers the best optimization, achieving the best accuracy, namely, 92%.

Results from the literature.

Comparing the validation accuracy results obtained for the FER2013 dataset in the literature using complex models (

https://www.mdpi.com/2073-8994/17/3/397#table\_body\_display\_symmetry-17-00397-t005

) with the results obtained in this study, we can conclude that the proposed CNN model with data augmentation offers the best accuracy of 91.16%.

Accuracy results from the literature \[

https://www.mdpi.com/2073-8994/17/3/397#B58-symmetry-17-00397

https://www.mdpi.com/2073-8994/17/3/397#B59-symmetry-17-00397

When analyzing the experimental results, beyond the overall success rates of the model, it is important to examine the cases where misclassifications occurred and their potential causes. As observed in the confusion matrices, the highest classification accuracy is consistently achieved for the Happy emotion, with predictability percentages reaching up to 96%, largely due to the high number of training samples for this category. Conversely, the Disgust emotion exhibits the lowest predictability, ranging between 86% and 89%, which can be attributed to its underrepresentation in the training set.

Another recurring challenge is the misclassification of emotions with similar facial expressions, particularly among Angry, Fear, and Sad, as evidenced by instances where Fear was confused with Sad (37 cases) and Angry was misclassified as Sad (36 cases). This suggests that the model struggles with subtle variations in facial features that differentiate these emotions, a known limitation in FER systems, especially when trained on datasets like FER2013, where intra-class variations can be significant. Additionally, while applying data augmentation and class weighting strategies improved overall predictability, certain cases—such as Sad being the least accurately classified in Case 5 (86%)—demonstrate that these techniques alone may not fully resolve the inherent similarity-induced confusion among some emotions.

A further observation is that increasing the number of images in the test set (Case 6) led to improvements in classifying Angry and Disgust, suggesting that a more balanced dataset distribution during training and testing can enhance generalization. These findings indicate that while the model effectively captures distinct emotional patterns, future improvements could explore more sophisticated augmentation techniques, feature refinement strategies, or multimodal approaches incorporating additional cues like temporal dynamics or physiological signals to further enhance recognition accuracy in challenging cases.

## Testing on Completely New Data

To validate the results obtained, testing was carried out on completely new data by developing an application.

After training and testing the network, one file was created to save the model, and another file was created to save the structure with all the parameters. These will be loaded when running the application.

For face detection, the Haarcascade classifier was used. The images captured from the camera were resized to 1280 × 720 pixels so that they fit well on the laptop screen.

The detection of each face was accessed through the width and height coordinates, framing the face detected from the images taken by the webcam in real time in a rectangle. Regardless of the input image, it was converted to grayscale because the model was trained on grayscale images, thus improving the accuracy of emotion detection. From the image converted to grayscale, the region of interest was accessed, and all the face images were cropped. After cropping the frame, each face image was resized to 48 × 48 in grayscale to be sent to the trained model for facial expression recognition. The list of all emotions was directly mapped with labels: at index 0, we have the emotion Anger; at 1, Disgust; at 2, Fear; at 3, Happiness; at 4, Neutral; at 5, Sadness; and at 6, Surprise.

Five subjects were trained to reproduce the seven emotions, where each emotion was trained four times with a 5 s hold, captured using a webcam at a speed of 20 fps. A total of 2000 raw images were thus collected for each emotion. The obtained accuracies are presented in

https://www.mdpi.com/2073-8994/17/3/397#table\_body\_display\_symmetry-17-00397-t006

Testing on completely new data.

An example of detection is shown in

https://www.mdpi.com/2073-8994/17/3/397#fig\_body\_display\_symmetry-17-00397-f012

, where the emotion with the highest confidence percentage can be seen, which is displayed as the detected emotion.

Application results displaying emotions (images captured and used with the subject's consent).

For the 30 fps camera used in our study, the interval between consecutive frames is 0.033 s. The maximum processing time per frame is 0.0238 s, which remains within this interval, ensuring that no frames are skipped during real-time processing. However, the first frame experiences a processing delay of approximately 0.11 s due to the initial camera startup overhead. This delay is only present at the beginning and is eliminated in subsequent frames, allowing smooth and uninterrupted real-time execution.

5. Conclusions, Limitations, and Research Directions

Given the increasing applicability of facial expression recognition in various fields, it is necessary to develop accurate and reliable systems. This paper presented the successful development of a three-layer convolutional neural network and its implementation in a real-time application. The architecture of the neural network model is based on a gradual progression in complexity, including activation functions, subsampling, and regularization techniques. The application is capable of recognizing the seven types of emotions (Happy, Sad, Angry, Fear, Surprise, Disgust, and Neutral). The analysis of the cases presented in this paper demonstrates the complexity and variability in the performances of a CNN model depending on the training settings. The high accuracy of 92% in Case 2 was achieved by training the CNN using the Shuffle and Flip-Vertical functions in data augmentation, which, compared to the other cases, provides valuable insight into the impact of data augmentation and test set size on model generalization. However, the subtle similarities between complex emotions such as Fear, Angry, and Sad generated confusion in the classification, suggesting the need for additional techniques to improve the differentiation between them.

Therefore, the implementation of this CNN model in facial emotion recognition achieved promising results and could also contribute to the development of other applications. In the future, it is possible that integrating the CNN with other artificial intelligence-based methods can improve the performance of the application.

Although this research demonstrated the successful development of a CNN model for facial emotion recognition and its implementation in a real-time application, there are several significant limitations that need to be addressed. First, the use of the FER2013 dataset, although relevant and diverse, presents an imbalance between classes, affecting the model's performance in recognizing minimally represented emotions, such as Disgust and Surprise. Second, the reliance on grayscale images limits the applicability of the model to real-world situations, where data are colored and may include natural variations in light and contrast. Furthermore, the testing was conducted on a limited number of subjects, which may limit the generalizability of the model to a broader culturally and demographically diverse population. Last but not least, the ethical and privacy issues associated with real-time emotion recognition remain important challenges, requiring a responsible approach in the development and implementation of AI-based systems.

To address the limitations of FER2013, particularly the biases in age, ethnicity, and pose variation, our research incorporates data augmentation techniques to enhance model generalization across diverse facial expressions. By applying flipping, rotation, and rescaling, we introduce variability that helps mitigate pose-dependent biases. Additionally, we use class weighting to compensate for imbalances in underrepresented emotions, ensuring that the model does not disproportionately favor majority classes. While FER2013 lacks demographic annotations, our approach prioritizes robust feature learning rather than overfitting to specific facial characteristics, improving adaptability across different populations. These strategies allow our model to achieve strong recognition performance despite dataset limitations, making it suitable for real-world applications.

In our research, we took careful measures to address ethical and privacy concerns while ensuring responsible use of facial emotion recognition technology. Our study is based on the publicly available FER2013 dataset, which is widely used in emotion recognition research and is assumed to have been collected with appropriate consent from the individuals involved. Additionally, all experiments conducted on unseen data were performed with the expressed consent of the subjects, who were fully informed about the nature and purpose of this study. No personally identifiable information was stored or shared, and all image data used in testing were handled in compliance with ethical research guidelines.

Despite these precautions, we recognize the broader ethical implications of facial emotion recognition, particularly regarding bias, misinterpretation, and potential misuse in real-world applications. While our model demonstrates strong performance, it is essential to ensure that such systems are used transparently and responsibly, preventing applications that could infringe on personal privacy or lead to biased decision-making. Moving forward, integrating privacy-preserving techniques, such as data anonymization and ethical AI frameworks, can help mitigate risks while maintaining the benefits of facial emotion analysis in a fair and accountable manner.

These limitations highlight future research directions to optimize performance, extend generalizability, and responsibly address ethical issues.

Future work may extend this study by incorporating AffectNet and RAF-DB to further validate the model's generalization ability across different emotion datasets. Additionally, future enhancements could explore the integration of multimodal data, such as combining facial expressions with physiological signals (e.g., heart rate, EEG) or speech-based emotion cues, to improve recognition accuracy and robustness. Furthermore, sophisticated augmentation techniques, including GAN-based data synthesis or domain adaptation methods, could be employed to enhance model performance and address dataset limitations, aligning with current advancements in emotion recognition research.

Finally, we note several research directions based on the method presented in this paper.

#### Such a system can have significant applications in multiple areas:

Public speaking training: Providing accurate, real-time emotional feedback can help speakers improve their ability to transmit messages to their audience. By recognizing the emotions expressed on the faces of a virtual audience generated in virtual reality, an immersive system can identify the audience's level of engagement, interest, or boredom. Thus, the speaker can learn to adjust their tone, pace, or gestures to better capture attention and transmit the message in a more empathetic and effective way.

Actor training: Actors can use such systems to intensify their ability to transmit authentic and convincing emotions. By analyzing facial expressions in real time, the system can provide detailed feedback on the authenticity of the emotions transmitted, helping actors adjust their expressions and movements to create more believable performances.

Emotional rehabilitation: In the context of mental health, facial emotion recognition systems can be integrated into virtual reality therapies to help patients recognize and control their emotions. For example, in the case of disorders such as social anxiety or autism, such a system can become a useful therapeutic tool in developing interaction and communication skills.

More natural human–machine interfaces: In the context of interactions with robots or virtual assistants, facial emotion recognition allows systems to interpret the user's emotional state and respond appropriately. This contributes to a more fluid and personalized experience.

In conclusion, a CNN-based facial emotion recognition system holds immense potential across diverse domains, offering transformative solutions for real-world challenges. From improving mental health monitoring and enhancing customer experience to advancing human–robot interactions and optimizing educational outcomes, the system can provide valuable insights and facilitate adaptive responses. Its applications in security, healthcare, entertainment, automotive safety, and workforce management demonstrate its versatility and societal impact. Furthermore, the integration of emotion recognition in areas such as telemedicine, assistive technologies, and behavioral research underscores its ability to contribute to both innovation and well-being. By leveraging this technology, we can enable more empathetic, efficient, and personalized systems, addressing complex needs in an increasingly dynamic world.

Author Contributions

Conceptualization, M.L. and A.C.I.; methodology, A.C.I.; software, G.L.S.; validation, M.L., G.L.S. and A.C.I.; formal analysis, M.L.; investigation, G.L.S.; resources, G.L.S.; data curation, G.L.S.; writing—original draft preparation, G.L.S.; writing—review and editing, M.L. and A.C.I.; visualization, M.L. and A.C.I.; supervision, M.L.; project administration, A.C.I.; funding acquisition, G.L.S. All authors have read and agreed to the published version of the manuscript.

This research received no external funding.

Data Availability Statement

FER2013 dataset, available at

https://kaggle.com/competitions/challenges-in-representation-learning-facial-expression-recognition-challenge

https://kaggle.com/competitions/challenges-in-representation-learning-facial-expression-recognition-challenge

(accessed on 20 December 2024).

Acknowledgments

During the preparation of this manuscript, the authors used Copilot for the purposes of language editing, drafting assistance and references formatting. The authors have reviewed and edited the output and take full responsibility for the content of this publication.

Conflicts of Interest

The authors declare no conflicts of interest.

Abbreviations

#### The following abbreviations are used in this manuscript:

convolutional neural network

Principal Component Analysis

Linear Discriminant Analysis

Cohn–Kanade database

Cohn–Kanade Extended database

facial expression recognition

Japanese Female Facial Expression database

Histogram of Oriented Gradients

Support Vector Machine

rectified linear unit

Darwin, C. The Expression of the Emotions in Man and Animals; John Murray: London, UK, 1872. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=The+Expression+of+the+Emotions+in+Man+and+Animals&author=Darwin,+C.&publication\_year=1872

Sagliano, L.; Ponari, M.; Conson, M.; Trojano, L. The interpersonal effects of emotions: The influence of facial ex-pressions on social interactions. Front. Psychol.

, 13, 1074216. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=The+interpersonal+effects+of+emotions:+The+influence+of+facial+ex-pressions+on+social+interactions&author=Sagliano,+L.&author=Ponari,+M.&author=Conson,+M.&author=Trojano,+L.&publication\_year=2022&journal=Front.+Psychol.&volume=13&pages=1074216&doi=10.3389/fpsyg.2022.1074216&pmid=36425824

https://doi.org/10.3389/fpsyg.2022.1074216

https://www.ncbi.nlm.nih.gov/pubmed/36425824

Ekman, P.; Oster, H. Facial expressions of emotion. Annu. Rev. Psychol.

, 30, 527–554. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Facial+expressions+of+emotion&author=Ekman,+P.&author=Oster,+H.&publication\_year=1979&journal=Annu.+Rev.+Psychol.&volume=30&pages=527%E2%80%93554&doi=10.1146/annurev.ps.30.020179.002523

https://doi.org/10.1146/annurev.ps.30.020179.002523

Gendron, M.; Roberson, D.; Van der Vyver, J.M.; Barrett, L.F. Perceptions of emotion from facial expressions are not culturally universal: Evidence from a remote culture. Emotion

, 14, 251–262. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Perceptions+of+emotion+from+facial+expressions+are+not+culturally+universal:+Evidence+from+a+remote+culture&author=Gendron,+M.&author=Roberson,+D.&author=Van+der+Vyver,+J.M.&author=Barrett,+L.F.&publication\_year=2014&journal=Emotion&volume=14&pages=251%E2%80%93262&doi=10.1037/a0036052

https://doi.org/10.1037/a0036052

Reisenzein, R.; Studtmann, M.; Horstmann, G. Coherence between emotion and facial expression: Evidence from laboratory experiments. Emot. Rev.

, 5, 16–23. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Coherence+between+emotion+and+facial+expression:+Evidence+from+laboratory+experiments&author=Reisenzein,+R.&author=Studtmann,+M.&author=Horstmann,+G.&publication\_year=2013&journal=Emot.+Rev.&volume=5&pages=16%E2%80%9323&doi=10.1177/1754073912457228

https://doi.org/10.1177/1754073912457228

Indersmitten, T.; Gur, R. Emotion processing in chimeric faces: Hemispheric asymmetries in expression and recognition of emotions. J. Neurosci.

, 23, 3820–3825. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Emotion+processing+in+chimeric+faces:+Hemispheric+asymmetries+in+expression+and+recognition+of+emotions&author=Indersmitten,+T.&author=Gur,+R.&publication\_year=2003&journal=J.+Neurosci.&volume=23&pages=3820%E2%80%933825&doi=10.1523/JNEUROSCI.23-09-03820.2003

https://doi.org/10.1523/JNEUROSCI.23-09-03820.2003

Murray, E.; Krause, W.; Stafford, R.; Bono, A.; Meltzer, E.; Borod, J. Asymmetry of facial expressions of emotion. In Understanding Facial Expressions in Communication; Mandal, M., Awasthi, A., Eds.; Springer: New Delhi, India, 2014; pp. 73–99. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Asymmetry+of+facial+expressions+of+emotion&author=Murray,+E.&author=Krause,+W.&author=Stafford,+R.&author=Bono,+A.&author=Meltzer,+E.&author=Borod,+J.&publication\_year=2014&pages=73%E2%80%9399

https://doi.org/10.1007/978-81-322-1934-7\_5

Nicholls, M.; Wolfgang, B.; Clode, D.; Lindell, A. The effect of left and right poses on the expression of facial emotion. Neuropsychologia

, 40, 1662–1665. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=The+effect+of+left+and+right+poses+on+the+expression+of+facial+emotion&author=Nicholls,+M.&author=Wolfgang,+B.&author=Clode,+D.&author=Lindell,+A.&publication\_year=2002&journal=Neuropsychologia&volume=40&pages=1662%E2%80%931665&doi=10.1016/S0028-3932(02)00024-6

https://doi.org/10.1016/S0028-3932(02)00024-6

Belhumeur, P.N.; Hespanha, J.P.; Kriegman, D. Eigenfaces vs. Fisherfaces: Recognition using class-specific linear projection. In Proceedings of the IEEE Computer Society Conference on Computer Vision and Pattern Recognition (CVPR 1997), San Juan, PR, USA, 17–19 June 1997; pp. 711–720. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Eigenfaces+vs.+Fisherfaces:+Recognition+using+class-specific+linear+projection&conference=Proceedings+of+the+IEEE+Computer+Society+Conference+on+Computer+Vision+and+Pattern+Recognition+(CVPR+1997)&author=Belhumeur,+P.N.&author=Hespanha,+J.P.&author=Kriegman,+D.&publication\_year=1997&pages=711%E2%80%93720&doi=10.1109/34.598228

https://doi.org/10.1109/34.598228

Turk, M.; Pentland, A. Eigenfaces for recognition. J. Cogn. Neurosci.

, 3, 71–86. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Eigenfaces+for+recognition&author=Turk,+M.&author=Pentland,+A.&publication\_year=1991&journal=J.+Cogn.+Neurosci.&volume=3&pages=71%E2%80%9386&doi=10.1162/jocn.1991.3.1.71

https://doi.org/10.1162/jocn.1991.3.1.71

Ramadhani, A.L.; Musa, P.; Wibowo, E.P. Human face recognition application using PCA and eigenface approach. In Proceeding of the 7 Second International Conference on Informatics and Computing (ICIC), Jayapura, Indonesia, 1–3 November 2017; pp. 1–5. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Human+face+recognition+application+using+PCA+and+eigenface+approach&conference=In+Proceeding+of+the+7+Second+International+Conference+on+Informatics+and+Computing+(ICIC)&author=Ramadhani,+A.L.&author=Musa,+P.&author=Wibowo,+E.P.&publication\_year=2017&pages=1%E2%80%935&doi=10.1109/IAC.2017.8280652

https://doi.org/10.1109/IAC.2017.8280652

Lu, J.; Plataniotis, K.N.; Venetsanopoulos, A.N. Face recognition using LDA-based algorithms. IEEE Trans. Neural Netw.

, 14, 195–200. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Face+recognition+using+LDA-based+algorithms&author=Lu,+J.&author=Plataniotis,+K.N.&author=Venetsanopoulos,+A.N.&publication\_year=2003&journal=IEEE+Trans.+Neural+Netw.&volume=14&pages=195%E2%80%93200&doi=10.1109/TNN.2002.806647

https://doi.org/10.1109/TNN.2002.806647

Lecun, Y.; Bottou, L.; Bengio, Y.; Haffner, P. Gradient-based learning applied to document recognition. Proc. IEEE

, 86, 2278–2324. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Gradient-based+learning+applied+to+document+recognition&author=Lecun,+Y.&author=Bottou,+L.&author=Bengio,+Y.&author=Haffner,+P.&publication\_year=1998&journal=Proc.+IEEE&volume=86&pages=2278%E2%80%932324&doi=10.1109/5.726791

https://doi.org/10.1109/5.726791

Kanade, T.; Cohn, J.F.; Tian, Y. Comprehensive database for facial expression analysis. In Proceedings of the 4th IEEE International Conference on Automatic Face and Gesture Recognition (FG 2000), Grenoble, France, 28–30 March 2000. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Comprehensive+database+for+facial+expression+analysis&conference=Proceedings+of+the+4th+IEEE+International+Conference+on+Automatic+Face+and+Gesture+Recognition+(FG+2000)&author=Kanade,+T.&author=Cohn,+J.F.&author=Tian,+Y.&publication\_year=2000&doi=10.1109/AFGR.2000.840611

https://doi.org/10.1109/AFGR.2000.840611

Lucey, P.; Cohn, J.F.; Kanade, T.; Saragih, J.; Ambadar, Z.; Matthews, I. The extended Cohn-Kanade dataset (CK+): A complete dataset for action unit and emotion-specific expression. In Proceedings of the IEEE Computer Society Conference on Computer Vision and Pattern Recognition Workshops (CVPRW 2010), San Francisco, CA, USA, 13–18 June 2010. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=The+extended+Cohn-Kanade+dataset+(CK+):+A+complete+dataset+for+action+unit+and+emotion-specific+expression&conference=Proceedings+of+the+IEEE+Computer+Society+Conference+on+Computer+Vision+and+Pattern+Recognition+Workshops+(CVPRW+2010)&author=Lucey,+P.&author=Cohn,+J.F.&author=Kanade,+T.&author=Saragih,+J.&author=Ambadar,+Z.&author=Matthews,+I.&publication\_year=2010&doi=10.1109/CVPRW.2010.5543262

https://doi.org/10.1109/CVPRW.2010.5543262

Agostinelli, F.; Anderson, M.R.; Lee, H. Adaptive multi-column deep neural networks with application to robust image denoising. Adv. Neural Inf. Process. Syst.

, 26, 327. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Adaptive+multi-column+deep+neural+networks+with+application+to+robust+image+denoising&author=Agostinelli,+F.&author=Anderson,+M.R.&author=Lee,+H.&publication\_year=2013&journal=Adv.+Neural+Inf.+Process.+Syst.&volume=26&pages=327

Lyons, M.; Akamatsu, S.; Kamachi, M.; Gyoba, J. Coding facial expressions with Gabor wavelets. In Proceedings of the 3rd IEEE International Conference on Automatic Face and Gesture Recognition (FG 1998), Nara, Japan, 14–16 April 1998. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Coding+facial+expressions+with+Gabor+wavelets&conference=Proceedings+of+the+3rd+IEEE+International+Conference+on+Automatic+Face+and+Gesture+Recognition+(FG+1998)&author=Lyons,+M.&author=Akamatsu,+S.&author=Kamachi,+M.&author=Gyoba,+J.&publication\_year=1998&doi=10.1109/AFGR.1998.670949

https://doi.org/10.1109/AFGR.1998.670949

Li, S.; Deng, W. Deep facial expression recognition: A survey. IEEE Trans. Affect. Comput.

, 13, 1195–1215. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Deep+facial+expression+recognition:+A+survey&author=Li,+S.&author=Deng,+W.&publication\_year=2022&journal=IEEE+Trans.+Affect.+Comput.&volume=13&pages=1195%E2%80%931215&doi=10.1109/TAFFC.2020.2981446

https://doi.org/10.1109/TAFFC.2020.2981446

Supta, S.R.; Sahriar, M.R.; Rashed, M.G.; Das, D.; Yasmin, R. An effective facial expression recognition system. In Proceedings of the 2020 IEEE International Women in Engineering (WIE) Conference on Electrical and Computer Engineering (WIECON-ECE 2020), Dhaka, Bangladesh, 26–27 December 2020; pp. 66–69. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=An+effective+facial+expression+recognition+system&conference=Proceedings+of+the+2020+IEEE+International+Women+in+Engineering+(WIE)+Conference+on+Electrical+and+Computer+Engineering+(WIECON-ECE+2020)&author=Supta,+S.R.&author=Sahriar,+M.R.&author=Rashed,+M.G.&author=Das,+D.&author=Yasmin,+R.&publication\_year=2020&pages=66%E2%80%9369&doi=10.1109/WIECON-ECE52138.2020.9397965

https://doi.org/10.1109/WIECON-ECE52138.2020.9397965

Shi, W.; Jiang, M. Fuzzy wavelet network with feature fusion and LM algorithm for facial emotion recognition. In Proceedings of the 2018 IEEE International Conference of Safety Produce Informatization (IICSPI 2018), Chongqing, China, 10–12 December 2018; pp. 582–586. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Fuzzy+wavelet+network+with+feature+fusion+and+LM+algorithm+for+facial+emotion+recognition&conference=Proceedings+of+the+2018+IEEE+International+Conference+of+Safety+Produce+Informatization+(IICSPI+2018)&author=Shi,+W.&author=Jiang,+M.&publication\_year=2018&pages=582%E2%80%93586&doi=10.1109/IICSPI.2018.8690353

https://doi.org/10.1109/IICSPI.2018.8690353

Ramalingam, S.; Garzia, F. Facial expression recognition using transfer learning. In Proceedings of the International Carnahan Conference on Security Technology (CCST 2018), Montreal, QC, Canada, 22–25 October 2018; pp. 1–5. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Facial+expression+recognition+using+transfer+learning&conference=Proceedings+of+the+International+Carnahan+Conference+on+Security+Technology+(CCST+2018)&author=Ramalingam,+S.&author=Garzia,+F.&publication\_year=2018&pages=1%E2%80%935&doi=10.1109/CCST.2018.8585504

https://doi.org/10.1109/CCST.2018.8585504

Raja Sekaran, S.A.P.C.; Lee, P.; Lim, K.M. Facial emotion recognition using transfer learning of AlexNet. In Proceedings of the 2021 9th International Conference on Information and Communication Technology (ICoICT 2021), Yogyakarta, Indonesia, 3–5 August 2021; pp. 170–174. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Facial+emotion+recognition+using+transfer+learning+of+AlexNet&conference=Proceedings+of+the+2021+9th+International+Conference+on+Information+and+Communication+Technology+(ICoICT+2021)&author=Raja+Sekaran,+S.A.P.C.&author=Lee,+P.&author=Lim,+K.M.&publication\_year=2021&pages=170%E2%80%93174&doi=10.1109/ICoICT52021.2021.9527512

https://doi.org/10.1109/ICoICT52021.2021.9527512

Abdulsattar, N.S.; Hussain, M.N. Facial expression recognition using transfer learning and fine-tuning strategies: A comparative study. In Proceedings of the 2nd 2022 International Conference on Computer Science and Software Engineering (CSASE 2022), Baghdad, Iraq, 26–27 March 2022; pp. 101–106. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Facial+expression+recognition+using+transfer+learning+and+fine-tuning+strategies:+A+comparative+study&conference=Proceedings+of+the+2nd+2022+International+Conference+on+Computer+Science+and+Software+Engineering+(CSASE+2022)&author=Abdulsattar,+N.S.&author=Hussain,+M.N.&publication\_year=2022&pages=101%E2%80%93106&doi=10.1109/CSASE51777.2022.9759754

https://doi.org/10.1109/CSASE51777.2022.9759754

Sajjanhar, A.; Wu, Z.; Wen, Q. Deep learning models for facial expression recognition. In Proceedings of the 2018 International Conference on Digital Image Computing: Techniques and Applications (DICTA 2018), Canberra, Australia, 10–13 December 2018; pp. 1–6. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Deep+learning+models+for+facial+expression+recognition&conference=Proceedings+of+the+2018+International+Conference+on+Digital+Image+Computing:+Techniques+and+Applications+(DICTA+2018)&author=Sajjanhar,+A.&author=Wu,+Z.&author=Wen,+Q.&publication\_year=2018&pages=1%E2%80%936&doi=10.1109/DICTA.2018.8615843

https://doi.org/10.1109/DICTA.2018.8615843

Meena, G.; Mohbey, K.K.; Khan, M.Z.; Kumar, S. Identifying emotions from facial expressions using a deep convolutional neural network-based approach. Multimed. Tools Appl.

, 83, 15711–15732. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Identifying+emotions+from+facial+expressions+using+a+deep+convolutional+neural+network-based+approach&author=Meena,+G.&author=Mohbey,+K.K.&author=Khan,+M.Z.&author=Kumar,+S.&publication\_year=2024&journal=Multimed.+Tools+Appl.&volume=83&pages=15711%E2%80%9315732&doi=10.1007/s11042-023-16174-3

https://doi.org/10.1007/s11042-023-16174-3

Manalu, H.V.; Rifai, A.P. Detection of human emotions through facial expressions using hybrid convolutional neural network-recurrent neural network algorithm. Intell. Syst. Appl.

, 21, 200339. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Detection+of+human+emotions+through+facial+expressions+using+hybrid+convolutional+neural+network-recurrent+neural+network+algorithm&author=Manalu,+H.V.&author=Rifai,+A.P.&publication\_year=2024&journal=Intell.+Syst.+Appl.&volume=21&pages=200339&doi=10.1016/j.iswa.2024.200339

https://doi.org/10.1016/j.iswa.2024.200339

Bilotti, U.; Bisogni, C.; De Marsico, M.; Tramonte, S. Multimodal Emotion Recognition via Convolutional Neural Networks: Comparison of different strategies on two multimodal datasets. Eng. Appl. Artif. Intell.

, 130, 107708. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Multimodal+Emotion+Recognition+via+Convolutional+Neural+Networks:+Comparison+of+different+strategies+on+two+multimodal+datasets&author=Bilotti,+U.&author=Bisogni,+C.&author=De+Marsico,+M.&author=Tramonte,+S.&publication\_year=2024&journal=Eng.+Appl.+Artif.+Intell.&volume=130&pages=107708&doi=10.1016/j.engappai.2023.107708

https://doi.org/10.1016/j.engappai.2023.107708

Goodfellow, I.J.; Erhan, D.; Luc Carrier, P.; Courville, A.; Mirza, M.; Hamner, B.; Cukierski, W.; Tang, Y.; Thaler, D.; Lee, D.H.; et al. Challenges in representation learning: A report on three machine learning contests. Neural Netw.

, 64, 59–63. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Challenges+in+representation+learning:+A+report+on+three+machine+learning+contests&author=Goodfellow,+I.J.&author=Erhan,+D.&author=Luc+Carrier,+P.&author=Courville,+A.&author=Mirza,+M.&author=Hamner,+B.&author=Cukierski,+W.&author=Tang,+Y.&author=Thaler,+D.&author=Lee,+D.H.&author=et+al.&publication\_year=2015&journal=Neural+Netw.&volume=64&pages=59%E2%80%9363&doi=10.1016/j.neunet.2014.09.005

https://doi.org/10.1016/j.neunet.2014.09.005

Bapat, M.M.; Patil, C.H.; Mali, S.M. Database Development and Recognition of Facial Expression using Deep Learning. Int. J. Comput.

, 23, 606–617. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Database+Development+and+Recognition+of+Facial+Expression+using+Deep+Learning&author=Bapat,+M.M.&author=Patil,+C.H.&author=Mali,+S.M.&publication\_year=2024&journal=Int.+J.+Comput.&volume=23&pages=606%E2%80%93617&doi=10.47839/ijc.23.4.3760

https://doi.org/10.47839/ijc.23.4.3760

Giannopoulos, P.; Perikos, I.; Hatzilygeroudis, I. Deep Learning Approaches for Facial Emotion Recognition: A Case Study on FER-2013. In Advances in Hybridization of Intelligent Methods. Smart Innovation, Systems and Technologies; Hatzilygeroudis, I., Palade, V., Eds.; Springer: Cham, Switzerland, 2018; Volume 85. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Deep+Learning+Approaches+for+Facial+Emotion+Recognition:+A+Case+Study+on+FER-2013&author=Giannopoulos,+P.&author=Perikos,+I.&author=Hatzilygeroudis,+I.&publication\_year=2018

https://doi.org/10.1007/978-3-319-66790-4\_1

#### Kaggle. FER2013 Dataset. Available online:

https://kaggle.com/competitions/challenges-in-representation-learning-facial-expression-recognition-challenge

https://kaggle.com/competitions/challenges-in-representation-learning-facial-expression-recognition-challenge

(accessed on 20 December 2024).

#### Kaggle. Face Expression Recognition Dataset. Available online:

https://www.kaggle.com/datasets/jonathanoheix/face-expression-recognition-dataset/data

https://www.kaggle.com/datasets/jonathanoheix/face-expression-recognition-dataset/data

(accessed on 20 December 2024).

Verma, G.; Verma, H. Hybrid-deep learning model for emotion recognition using facial expressions. Rev. Socionetwork Strateg.

, 14, 171–180. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Hybrid-deep+learning+model+for+emotion+recognition+using+facial+expressions&author=Verma,+G.&author=Verma,+H.&publication\_year=2020&journal=Rev.+Socionetwork+Strateg.&volume=14&pages=171%E2%80%93180&doi=10.1007/s12626-020-00061-6

https://doi.org/10.1007/s12626-020-00061-6

Saha, S.A. Comprehensive Guide to Convolutional Neural Networks—The ELI5 Way. Towards Data Science, 15 December 2018. Available online:

https://ise.ncsu.edu/wp-content/uploads/sites/9/2022/08/A-Comprehensive-Guide-to-Convolutional-Neural-Networks-%E2%80%94-the-ELI5-way--by-Sumit-Saha--Towards-Data-Science.pdf

https://ise.ncsu.edu/wp-content/uploads/sites/9/2022/08/A-Comprehensive-Guide-to-Convolutional-Neural-Networks-%E2%80%94-the-ELI5-way-\_-by-Sumit-Saha-\_-Towards-Data-Science.pdf

(accessed on 20 December 2024).

Rackauckas, C.; Ma, Y.; Martensen, J.; Warner, C.; Edelman, A. Universal differential equations for scientific machine learning. arXiv

, arXiv:2001.04385. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Universal+differential+equations+for+scientific+machine+learning&author=Rackauckas,+C.&author=Ma,+Y.&author=Martensen,+J.&author=Warner,+C.&author=Edelman,+A.&publication\_year=2020&journal=arXiv&doi=10.48550/arXiv.2001.04385

https://doi.org/10.48550/arXiv.2001.04385

Viola, P.; Jones, M.J. Robust real-time face detection. Int. J. Comput. Vis.

, 57, 137–154. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Robust+real-time+face+detection&author=Viola,+P.&author=Jones,+M.J.&publication\_year=2004&journal=Int.+J.+Comput.+Vis.&volume=57&pages=137%E2%80%93154&doi=10.1023/B:VISI.0000013087.49260.fb

https://doi.org/10.1023/B:VISI.0000013087.49260.fb

Farfade, S.S.; Saberian, M.J.; Li, L.J. Multi-view face detection using deep convolutional neural networks. In Proceedings of the 5th ACM International Conference on Multimedia Retrieval (ICMR 2015), Shanghai, China, 23–26 June 2015; ACM: New York, NY, USA, 2015; pp. 643–650. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Multi-view+face+detection+using+deep+convolutional+neural+networks&conference=Proceedings+of+the+5th+ACM+International+Conference+on+Multimedia+Retrieval+(ICMR+2015)&author=Farfade,+S.S.&author=Saberian,+M.J.&author=Li,+L.J.&publication\_year=2015&pages=643%E2%80%93650&doi=10.1145/2671188.2749408

https://doi.org/10.1145/2671188.2749408

Tomasi, C.; Manduchi, R. Bilateral filtering for gray and color images. In Proceedings of the 6th IEEE International Conference on Computer Vision (ICCV 1998), Bombay, India, 4–7 January 1998; pp. 839–846. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Bilateral+filtering+for+gray+and+color+images&conference=Proceedings+of+the+6th+IEEE+International+Conference+on+Computer+Vision+(ICCV+1998)&author=Tomasi,+C.&author=Manduchi,+R.&publication\_year=1998&pages=839%E2%80%93846&doi=10.1109/ICCV.1998.710815

https://doi.org/10.1109/ICCV.1998.710815

Lindenbaum, M.; Fischer, M.; Bruckstein, A. On Gabor's contribution to image enhancement. Pattern Recognit.

, 27, 1–8. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=On+Gabor%E2%80%99s+contribution+to+image+enhancement&author=Lindenbaum,+M.&author=Fischer,+M.&author=Bruckstein,+A.&publication\_year=1994&journal=Pattern+Recognit.&volume=27&pages=1%E2%80%938&doi=10.1016/0031-3203(94)90013-2

https://doi.org/10.1016/0031-3203(94)90013-2

Pizer, S.M.; Amburn, E.P.; Austin, J.D.; Cromartie, R.; Geselowitz, A.; Greer, T.; Ter Haar Romeny, B.; Zimmerman, J.B.; Zuiderveld, K. Adaptive histogram equalization and its variations. Comput. Vis. Graph. Image Process.

, 39, 355–368. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Adaptive+histogram+equalization+and+its+variations&author=Pizer,+S.M.&author=Amburn,+E.P.&author=Austin,+J.D.&author=Cromartie,+R.&author=Geselowitz,+A.&author=Greer,+T.&author=Ter+Haar+Romeny,+B.&author=Zimmerman,+J.B.&author=Zuiderveld,+K.&publication\_year=1987&journal=Comput.+Vis.+Graph.+Image+Process.&volume=39&pages=355%E2%80%93368&doi=10.1016/S0734-189X(87)80186-X

https://doi.org/10.1016/S0734-189X(87)80186-X

Hawkins, D.M. The problem of overfitting. J. Chem. Inf. Comput. Sci.

, 44, 1–12. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=The+problem+of+overfitting&author=Hawkins,+D.M.&publication\_year=2004&journal=J.+Chem.+Inf.+Comput.+Sci.&volume=44&pages=1%E2%80%9312&doi=10.1021/ci0342472&pmid=14741005

https://doi.org/10.1021/ci0342472

https://www.ncbi.nlm.nih.gov/pubmed/14741005

Wu, Z. Image data augmentation techniques based on deep learning: A survey. Math. Biosci. Eng.

, 21, 6190–6224. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Image+data+augmentation+techniques+based+on+deep+learning:+A+survey&author=Wu,+Z.&publication\_year=2024&journal=Math.+Biosci.+Eng.&volume=21&pages=6190%E2%80%936224&doi=10.3934/mbe.2024272

https://doi.org/10.3934/mbe.2024272

Gupta, S. Facial emotion recognition in real-time and static images. In Proceedings of the 2nd International Conference on Inventive Systems and Control (ICISC 2018), Coimbatore, India, 19–20 January 2018. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Facial+emotion+recognition+in+real-time+and+static+images&conference=Proceedings+of+the+2nd+International+Conference+on+Inventive+Systems+and+Control+(ICISC+2018)&author=Gupta,+S.&publication\_year=2018&doi=10.1109/ICISC.2018.8398861

https://doi.org/10.1109/ICISC.2018.8398861

Ojala, T.; Pietikainen, M.; Maenpaa, T. Multiresolution gray-scale and rotation invariant texture classification with local binary patterns. IEEE Trans. Pattern Anal. Mach. Intell.

, 24, 971–987. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Multiresolution+gray-scale+and+rotation+invariant+texture+classification+with+local+binary+patterns&author=Ojala,+T.&author=Pietikainen,+M.&author=Maenpaa,+T.&publication\_year=2002&journal=IEEE+Trans.+Pattern+Anal.+Mach.+Intell.&volume=24&pages=971%E2%80%93987&doi=10.1109/TPAMI.2002.1017623

https://doi.org/10.1109/TPAMI.2002.1017623

Anthwal, S.; Ganotra, D. An optical flow-based approach for facial expression recognition. In Proceedings of the 2019 International Conference on Power Electronics, Control and Automation (ICPECA 2019), Noida, India, 16–18 November 2019; pp. 1–5. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=An+optical+flow-based+approach+for+facial+expression+recognition&conference=Proceedings+of+the+2019+International+Conference+on+Power+Electronics,+Control+and+Automation+(ICPECA+2019)&author=Anthwal,+S.&author=Ganotra,+D.&publication\_year=2019&pages=1%E2%80%935&doi=10.1109/ICPECA47973.2019.8975442

https://doi.org/10.1109/ICPECA47973.2019.8975442

Jolliffe, I. Principal Component Analysis; Springer: Berlin, Germany, 2011. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Principal+Component+Analysis&author=Jolliffe,+I.&publication\_year=2011

Goodfellow, I.; Bengio, Y.; Courville, A. Deep Learning; MIT Press: Cambridge, MA, USA, 2016. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Deep+Learning&author=Goodfellow,+I.&author=Bengio,+Y.&author=Courville,+A.&publication\_year=2016

Vujovic, Z.D. Classification Model Evaluation Metrics. Int. J. Adv. Comput. Sci. Appl.

, 12, 599–606. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Classification+Model+Evaluation+Metrics&author=Vujovic,+Z.D.&publication\_year=2021&journal=Int.+J.+Adv.+Comput.+Sci.+Appl.&volume=12&pages=599%E2%80%93606&doi=10.14569/IJACSA.2021.0120670

https://doi.org/10.14569/IJACSA.2021.0120670

Lever, J.; Krzywinski, M.; Altman, N. Classification evaluation. Nat. Methods

, 13, 603–604. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Classification+evaluation&author=Lever,+J.&author=Krzywinski,+M.&author=Altman,+N.&publication\_year=2016&journal=Nat.+Methods&volume=13&pages=603%E2%80%93604&doi=10.1038/nmeth.3945

https://doi.org/10.1038/nmeth.3945

Sulaiman, M.N. A Review on Evaluation Metrics for Data Classification Evaluations. Int. J. Data Min. Knowl. Manag. Process

, 5, 1–11. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=A+Review+on+Evaluation+Metrics+for+Data+Classification+Evaluations&author=Sulaiman,+M.N.&publication\_year=2015&journal=Int.+J.+Data+Min.+Knowl.+Manag.+Process&volume=5&pages=1%E2%80%9311&doi=10.5121/IJDKP.2015.5201

https://doi.org/10.5121/IJDKP.2015.5201

Kulatilleke, G.K.; Samarakoon, S. Empirical study of Machine Learning Classifier Evaluation Metrics behavior in Massively Imbalanced and Noisy data. arXiv

, arXiv:2208.11904. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Empirical+study+of+Machine+Learning+Classifier+Evaluation+Metrics+behavior+in+Massively+Imbalanced+and+Noisy+data&author=Kulatilleke,+G.K.&author=Samarakoon,+S.&publication\_year=2022&journal=arXiv&doi=10.48550/arXiv.2208.11904

https://doi.org/10.48550/arXiv.2208.11904

Kumar, R.; Hussain, S.I. A Review of the Deep Convolutional Neural Networks for the Analysis of Facial Expressions. J. Innov. Technol.

, 6, 41–49. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=A+Review+of+the+Deep+Convolutional+Neural+Networks+for+the+Analysis+of+Facial+Expressions&author=Kumar,+R.&author=Hussain,+S.I.&publication\_year=2024&journal=J.+Innov.+Technol.&volume=6&pages=41%E2%80%9349&doi=10.29424/JIT.202403\_6(1).0004

https://doi.org/10.29424/JIT.202403\_6(1).0004

Pramerdorfer, C.; Kampel, M. Facial expression recognition using convolutional neural networks: State of the art. arXiv

, arXiv:1612.02903. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Facial+expression+recognition+using+convolutional+neural+networks:+State+of+the+art&author=Pramerdorfer,+C.&author=Kampel,+M.&publication\_year=2016&journal=arXiv&doi=10.48550/arXiv.1612.02903

https://doi.org/10.48550/arXiv.1612.02903

Mollahosseini, A.; Chan, D.; Mahoor, M.H. Going deeper in facial expression recognition using deep neural networks. In Proceedings of the 2017 IEEE Winter Conference on Applications of Computer Vision (WACV 2017), Santa Rosa, CA, USA, 24–31 March 2017. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Going+deeper+in+facial+expression+recognition+using+deep+neural+networks&conference=Proceedings+of+the+2017+IEEE+Winter+Conference+on+Applications+of+Computer+Vision+(WACV+2017)&author=Mollahosseini,+A.&author=Chan,+D.&author=Mahoor,+M.H.&publication\_year=2017&doi=10.48550/arXiv.1511.04110

https://doi.org/10.48550/arXiv.1511.04110

Minaee, S.; Minaei, M.; Abdolrashidi, A. Deep-Emotion: Facial Expression Recognition Using Attentional Convolutional Network. Sensors

, 21, 3046. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Deep-Emotion:+Facial+Expression+Recognition+Using+Attentional+Convolutional+Network&author=Minaee,+S.&author=Minaei,+M.&author=Abdolrashidi,+A.&publication\_year=2021&journal=Sensors&volume=21&pages=3046&doi=10.3390/s21093046&pmid=33925371

https://doi.org/10.3390/s21093046

https://www.ncbi.nlm.nih.gov/pubmed/33925371

Ghadekar, P.; Gupta, A.K.; Datta, J.; Singh, G.; Anand, D.S.; Oswal, P.; Sharma, D.; Khare, S. Facial Expression Recognition Based on Deep Learning-Deep Convolutional Neural Network. In Proceedings of the 2022 IEEE 7th International Conference on Recent Advances and Innovations in Engineering (ICRAIE), Mangalore, India, 1–3 December 2022; pp. 93–98. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Facial+Expression+Recognition+Based+on+Deep+Learning-Deep+Convolutional+Neural+Network&conference=Proceedings+of+the+2022+IEEE+7th+International+Conference+on+Recent+Advances+and+Innovations+in+Engineering+(ICRAIE)&author=Ghadekar,+P.&author=Gupta,+A.K.&author=Datta,+J.&author=Singh,+G.&author=Anand,+D.S.&author=Oswal,+P.&author=Sharma,+D.&author=Khare,+S.&publication\_year=2022&pages=93%E2%80%9398&doi=10.1109/ICRAIE56454.2022.10054303

https://doi.org/10.1109/ICRAIE56454.2022.10054303

Khan, A.R. Facial Emotion Recognition Using Conventional Machine Learning and Deep Learning Methods: Current Achievements. Anal. Remain. Chall. Inf.

, 13, 268. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Facial+Emotion+Recognition+Using+Conventional+Machine+Learning+and+Deep+Learning+Methods:+Current+Achievements&author=Khan,+A.R.&publication\_year=2022&journal=Anal.+Remain.+Chall.+Inf.&volume=13&pages=268&doi=10.3390/info13060268

https://doi.org/10.3390/info13060268

Christou, N.; Kanojiya, N. Human facial expression recognition with convolutional neural networks. In Proceedings of the 2019 Springer International Conference, Singapore, 22–24 February 2019; pp. 539–545. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Human+facial+expression+recognition+with+convolutional+neural+networks&conference=Proceedings+of+the+2019+Springer+International+Conference&author=Christou,+N.&author=Kanojiya,+N.&publication\_year=2019&pages=539%E2%80%93545&doi=10.1007/978-981-13-1165-9\_49

https://doi.org/10.1007/978-981-13-1165-9\_49

Punuri, S.B.; Kuanar, S.K.; Kolhar, M.; Mishra, T.K.; Alameen, A.; Mohapatra, H.; Mishra, S.R. Efficient Net-XGBoost: An Implementation for Facial Emotion Recognition Using Transfer Learning. Mathematics

, 11, 776. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Efficient+Net-XGBoost:+An+Implementation+for+Facial+Emotion+Recognition+Using+Transfer+Learning&author=Punuri,+S.B.&author=Kuanar,+S.K.&author=Kolhar,+M.&author=Mishra,+T.K.&author=Alameen,+A.&author=Mohapatra,+H.&author=Mishra,+S.R.&publication\_year=2023&journal=Mathematics&volume=11&pages=776&doi=10.3390/math11030776

https://doi.org/10.3390/math11030776

Research flowchart illustrating the objectives and methods employed.

Emotion image distribution in the training and validation sets.

Stages of facial expression recognition.

Network structure.

Confusion matrix—Case 1: data augmentation with the Shuffle function.

Confusion matrix—Case 2: data augmentation with the Shuffle and Flip-Vertical functions.

Confusion matrix—Case 3: data augmentation with the Loss Weight parameter.

Confusion matrix—Case 4: data augmentation with the Shuffle function and the Loss Weight parameter.

Similarities between feelings in the FER2013 dataset.

Confusion matrix—Case 5: data augmentation with the Flip-Vertical and Shuffle functions and the Loss Weight parameter.

Confusion matrix—Case 6: data augmentation with the Shuffle function and a larger number of images in the test set.

Application results displaying emotions (images captured and used with the subject's consent).

Distribution of data in the validation set.

Public Image \[

https://www.mdpi.com/2073-8994/17/3/397#B31-symmetry-17-00397

Private Images \[

https://www.mdpi.com/2073-8994/17/3/397#B32-symmetry-17-00397

Total Images

Results of training for the six cases.

Precision %

Accuracy—Train

Val\_Accuracy—Test

Epoch Number

Training Time

Average Time Per Epoch

1 h and 17 min

2 h and 20 min

1 h and 19 min

1 h and 21 min

2 h and 11 min

2 h and 45 min

Results for the six cases.

Results from the literature.

Pramerdorfer and Kampel \[

https://www.mdpi.com/2073-8994/17/3/397#B53-symmetry-17-00397

Mollahosseini et al. \[

https://www.mdpi.com/2073-8994/17/3/397#B54-symmetry-17-00397

Minaee et al. \[

https://www.mdpi.com/2073-8994/17/3/397#B55-symmetry-17-00397

Ghadekar et al. \[

https://www.mdpi.com/2073-8994/17/3/397#B56-symmetry-17-00397

Khan et al. \[

https://www.mdpi.com/2073-8994/17/3/397#B57-symmetry-17-00397

Christou and Kanojiya \[

https://www.mdpi.com/2073-8994/17/3/397#B58-symmetry-17-00397

Proposed method

Accuracy results from the literature \[

https://www.mdpi.com/2073-8994/17/3/397#B58-symmetry-17-00397

https://www.mdpi.com/2073-8994/17/3/397#B59-symmetry-17-00397

Accuracy (%)

EfficientNet-B0

Inception V3

Bam—ResNet 50

DenseNet121

EfficientNet-XGBoost

Deep Neural Network

#### Proposed CNN model with different data augmentation

89.25–91.16%

Testing on completely new data.

Existing Images

Correctly Labeled Images

Precision (%)

#### Disclaimer/Publisher's Note:

The statements, opinions and data contained in all publications are solely those of the individual author(s) and contributor(s) and not of MDPI and/or the editor(s). MDPI and/or the editor(s) disclaim responsibility for any injury to people or property resulting from any ideas, methods, instructions or products referred to in the content.

© 2025 by the authors. Licensee MDPI, Basel, Switzerland. This article is an open access article distributed under the terms and conditions of the Creative Commons Attribution (CC BY) license (

https://creativecommons.org/licenses/by/4.0/

https://creativecommons.org/licenses/by/4.0/

Share and Cite

mailto:?&subject=From%20MDPI%3A%20%22Leveraging%20Symmetry%20and%20Addressing%20Asymmetry%20Challenges%20for%20Improved%20Convolutional%20Neural%20Network-Based%20Facial%20Emotion%20Recognition"&body=https://www.mdpi.com/3213134%3A%0A%0ALeveraging%20Symmetry%20and%20Addressing%20Asymmetry%20Challenges%20for%20Improved%20Convolutional%20Neural%20Network-Based%20Facial%20Emotion%20Recognition%0A%0AAbstract%3A%20This%20study%20introduces%20a%20custom-designed%20CNN%20architecture%20that%20extracts%20robust%2C%20multi-level%20facial%20features%20and%20incorporates%20preprocessing%20techniques%20to%20correct%20or%20reduce%20asymmetry%20before%20classification.%20The%20innovative%20characteristics%20of%20this%20research%20lie%20in%20its%20integrated%20approach%20to%20overcoming%20facial%20asymmetry%20challenges%20and%20enhancing%20CNN-based%20emotion%20recognition.%20This%20is%20completed%20by%20well-known%20data%20augmentation%20strategies%26mdash%3Busing%20methods%20such%20as%20vertical%20flipping%20and%20shuffling%26mdash%3Bthat%20generate%20symmetric%20variations%20in%20facial%20images%2C%20effectively%20balancing%20the%20dataset%20and%20improving%20recognition%20accuracy.%20Additionally%2C%20a%20Loss%20Weight%20parameter%20is%20used%20to%20fine-tune%20training%2C%20thereby%20optimizing%20performance%20across%20diverse%20and%20unbalanced%20emotion%20classes.%20Collectively%2C%20all%20these%20contribute%20to%20an%20efficient%2C%20real-time%20facial%20emotion%20recognition%20system%20that%20outperforms%20traditional%20CNN%20models%20and%20offers%20practical%20benefits%20for%20various%20applications%20while%20also%20addressing%20the%20inherent%20challenges%20of%20facial%20asymmetry%20in%20emotion%20detection.%20Our%20experimental%20results%20demonstrate%20superior%20performance%20compared%20to%20other%20CNN%20methods%2C%20marking%20a%20step%20forward%20in%20applications%20ranging%20from%20human%26ndash%3Bcomputer\[...\]

https://x.com/intent/tweet?text=Leveraging+Symmetry+and+Addressing+Asymmetry+Challenges+for+Improved+Convolutional+Neural+Network-Based+Facial+Emotion+Recognition&hashtags=mdpisymmetry&url=https%3A%2F%2Fwww.mdpi.com%2F3213134&via=Symmetry\_MDPI

http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fwww.mdpi.com%2F3213134&title=Leveraging%20Symmetry%20and%20Addressing%20Asymmetry%20Challenges%20for%20Improved%20Convolutional%20Neural%20Network-Based%20Facial%20Emotion%20Recognition%26source%3Dhttps%3A%2F%2Fwww.mdpi.com%26summary%3DThis%20study%20introduces%20a%20custom-designed%20CNN%20architecture%20that%20extracts%20robust%2C%20multi-level%20facial%20features%20and%20incorporates%20preprocessing%20techniques%20to%20correct%20or%20reduce%20asymmetry%20before%20classification.%20The%20innovative%20characteristics%20of%20this%20%5B...%5D

http://www.facebook.com/sharer.php?u=https://www.mdpi.com/3213134

javascript:void(0);

http://www.reddit.com/submit?url=https://www.mdpi.com/3213134

http://www.mendeley.com/import/?url=https://www.mdpi.com/3213134

MDPI and ACS Style

Sălăgean, G.L.; Leba, M.; Ionica, A.C. Leveraging Symmetry and Addressing Asymmetry Challenges for Improved Convolutional Neural Network-Based Facial Emotion Recognition.

, 397. https://doi.org/10.3390/sym17030397

Sălăgean GL, Leba M, Ionica AC. Leveraging Symmetry and Addressing Asymmetry Challenges for Improved Convolutional Neural Network-Based Facial Emotion Recognition.

. 2025; 17(3):397. https://doi.org/10.3390/sym17030397

Chicago/Turabian Style

Sălăgean, Gabriela Laura, Monica Leba, and Andreea Cristina Ionica. 2025. "Leveraging Symmetry and Addressing Asymmetry Challenges for Improved Convolutional Neural Network-Based Facial Emotion Recognition"

17, no. 3: 397. https://doi.org/10.3390/sym17030397

Sălăgean, G. L., Leba, M., & Ionica, A. C. (2025). Leveraging Symmetry and Addressing Asymmetry Challenges for Improved Convolutional Neural Network-Based Facial Emotion Recognition.

(3), 397. https://doi.org/10.3390/sym17030397

Note that from the first issue of 2016, this journal uses article numbers instead of page numbers. See further details

https://www.mdpi.com/about/announcements/784

Article Metrics

https://www.mdpi.com/2073-8994/17/3/397

https://www.scopus.com/inward/citedby.uri?partnerID=HzOxMe3b&scp=105001165317&origin=inward

Web of Science

https://www.webofscience.com/api/gateway?GWVersion=2&SrcApp=PARTNER\_APP&SrcAuth=LinksAMR&KeyUT=WOS:001453836100001&DestLinkType=FullRecord&DestApp=ALL\_WOS&UsrCustomerID=7e717b028bc90856e7c55c7029afc773

Google Scholar

\[click to view\]

https://scholar.google.com/scholar\_lookup?title=Leveraging+Symmetry+and+Addressing+Asymmetry+Challenges+for+Improved+Convolutional+Neural+Network-Based+Facial+Emotion+Recognition&volume=17&doi=10.3390%2Fsym17030397&journal=Symmetry&publication\_year=2025&author=Gabriela+Laura+S%C4%83l%C4%83gean&author=Monica+Leba&author=Andreea+Cristina+Ionica

Article Access Statistics

Created with Highcharts 4.0.4 Article access statistics Article Views 7. Jan 8. Jan 9. Jan 10. Jan 11. Jan 12. Jan 13. Jan 14. Jan 15. Jan 16. Jan 17. Jan 18. Jan 19. Jan 20. Jan 21. Jan 22. Jan 23. Jan 24. Jan 25. Jan 26. Jan 27. Jan 28. Jan 29. Jan 30. Jan 31. Jan 1. Feb 2. Feb 3. Feb 4. Feb 5. Feb 6. Feb 7. Feb 8. Feb 9. Feb 10. Feb 11. Feb 12. Feb 13. Feb 14. Feb 15. Feb 16. Feb 17. Feb 18. Feb 19. Feb 20. Feb 21. Feb 22. Feb 23. Feb 24. Feb 25. Feb 26. Feb 27. Feb 28. Feb 1. Mar 2. Mar 3. Mar 4. Mar 5. Mar 6. Mar 7. Mar 8. Mar 9. Mar 10. Mar 11. Mar 12. Mar 13. Mar 14. Mar 15. Mar 16. Mar 17. Mar 18. Mar 19. Mar 20. Mar 21. Mar 22. Mar 23. Mar 24. Mar 25. Mar 26. Mar 27. Mar 28. Mar 29. Mar 30. Mar 31. Mar 1. Apr 2. Apr 3. Apr 4. Apr 5. Apr 6. Apr 0k 1k 2k 3k

For more information on the journal statistics, click

https://www.mdpi.com/journal/symmetry/stats

Multiple requests from the same IP address are counted as one view.

https://www.mdpi.com/2073-8994/17/3/397

https://www.mdpi.com/2073-8994/17/3/397

https://www.mdpi.com/2073-8994/17/3/397

https://www.mdpi.com/2073-8994/17/3/397

https://www.mdpi.com/2073-8994/17/3/397

https://www.mdpi.com/2073-8994/17/3/397

Previous Scene

https://www.mdpi.com/2073-8994/17/3/397

https://www.mdpi.com/2073-8994/17/3/397

#### Export citation file:

javascript:window.document.forms\['export-bibtex'\].submit()

javascript:window.document.forms\['export-endnote'\].submit()

javascript:window.document.forms\['export-ris'\].submit()

MDPI and ACS Style

Sălăgean, G.L.; Leba, M.; Ionica, A.C. Leveraging Symmetry and Addressing Asymmetry Challenges for Improved Convolutional Neural Network-Based Facial Emotion Recognition.

, 397. https://doi.org/10.3390/sym17030397

Sălăgean GL, Leba M, Ionica AC. Leveraging Symmetry and Addressing Asymmetry Challenges for Improved Convolutional Neural Network-Based Facial Emotion Recognition.

. 2025; 17(3):397. https://doi.org/10.3390/sym17030397

Chicago/Turabian Style

Sălăgean, Gabriela Laura, Monica Leba, and Andreea Cristina Ionica. 2025. "Leveraging Symmetry and Addressing Asymmetry Challenges for Improved Convolutional Neural Network-Based Facial Emotion Recognition"

17, no. 3: 397. https://doi.org/10.3390/sym17030397

Sălăgean, G. L., Leba, M., & Ionica, A. C. (2025). Leveraging Symmetry and Addressing Asymmetry Challenges for Improved Convolutional Neural Network-Based Facial Emotion Recognition.

(3), 397. https://doi.org/10.3390/sym17030397

Note that from the first issue of 2016, this journal uses article numbers instead of page numbers. See further details

https://www.mdpi.com/about/announcements/784

https://www.mdpi.com/2073-8994/17/3/397

, EISSN 2073-8994, Published by MDPI

https://www.mdpi.com/rss/journal/symmetry

Content Alert

https://www.mdpi.com/journal/symmetry/toc-alert

Further Information

Article Processing Charges

https://www.mdpi.com/apc

Pay an Invoice

https://www.mdpi.com/about/payment

Open Access Policy

https://www.mdpi.com/openaccess

Contact MDPI

https://www.mdpi.com/about/contact

Jobs at MDPI

https://careers.mdpi.com/

For Authors

https://www.mdpi.com/authors

For Reviewers

https://www.mdpi.com/reviewers

For Editors

https://www.mdpi.com/editors

For Librarians

https://www.mdpi.com/librarians

For Publishers

https://www.mdpi.com/publishing\_services

For Societies

https://www.mdpi.com/societies

For Conference Organizers

https://www.mdpi.com/conference\_organizers

MDPI Initiatives

https://sciforum.net/

https://www.mdpi.com/books

Preprints.org

https://www.preprints.org/

https://www.scilit.com/

SciProfiles

https://sciprofiles.com?utm\_source=mpdi.com&utm\_medium=bottom\_menu&utm\_campaign=initiative

Encyclopedia

https://encyclopedia.pub/

https://jams.pub/

Proceedings Series

https://www.mdpi.com/about/proceedings

Follow MDPI

https://www.linkedin.com/company/mdpi

https://www.facebook.com/MDPIOpenAccessPublishing

https://x.com/MDPIOpenAccess

Subscribe to receive issue release notifications and newsletters from MDPI journals

Accounting and Auditing

Acta Microbiologica Hellenica

Administrative Sciences

Adolescents

Advances in Respiratory Medicine

Aerobiology

Agriculture

AgriEngineering

Agrochemicals

AI Chemistry

AI for Engineering

AI in Education

AI in Medicine

AI Materials

Anesthesia Research

Antibiotics

Antioxidants

Applied Biosciences

Applied Mechanics

Applied Microbiology

Applied Nano

Applied Sciences

Applied System Innovation

AppliedChem

AppliedMath

AppliedPhys

Aquaculture Journal

Architecture

Astronautics

Audiology Research

Behavioral Sciences

Big Data and Cognitive Computing

Bioengineering

Biology and Life Sciences Forum

Biomechanics

Biomedicines

BioMedInformatics

Biomimetics

Biomolecules

Bioresources and Bioproducts

Blockchains

Brain Sciences

Cardiogenetics

Cardiovascular Medicine

ChemEngineering

Chemistry Proceedings

Chemosensors

Clean Technologies

Clinical and Translational Neuroscience

Clinical Bioenergetics

Clinics and Practice

Clocks & Sleep

Colloids and Interfaces

Commodities

Complexities

Complications

Computation

Computer Sciences & Mathematics Forum

Condensed Matter

Conservation

Construction Materials

Corrosion and Materials Degradation

Craniomaxillofacial Trauma & Reconstruction

Cryptography

Current Issues in Molecular Biology

Current Oncology

Dentistry Journal

Dermatopathology

Diabetology

Diagnostics

Disabilities

Drugs and Drug Candidates

Econometrics

Education Sciences

Electricity

Electrochem

Electronic Materials

Electronics

Emergency Care and Medicine

Encyclopedia

Energy Storage and Applications

Engineering Proceedings

Entropic and Disordered Matter

Environmental and Earth Sciences Proceedings

Environmental Remediation

Environments

Epidemiologia

European Burn Journal

European Journal of Investigation in Health, Psychology and Education

Family Sciences

Fermentation

Forecasting

Forensic Sciences

Fossil Studies

Foundations

Fractal and Fractional

Future Internet

Future Pharmacology

Future Transportation

Gastroenterology Insights

Gastrointestinal Disorders

Geographies

Geosciences

Geotechnics

Gout, Urate, and Crystal Deposition Disease

Green Health

Hematology Reports

Horticulturae

Hydrobiology

Infectious Disease Reports

Informatics

Information

Infrastructures

Instruments

Intelligent Infrastructure and Construction

International Journal of Cognitive Sciences

International Journal of Environmental Medicine

International Journal of Environmental Research and Public Health

International Journal of Financial Studies

International Journal of Molecular Sciences

International Journal of Neonatal Screening

International Journal of Orofacial Myology and Myofunctional Therapy

International Journal of Plant Biology

International Journal of Topology

International Journal of Translational Medicine

International Journal of Turbomachinery, Propulsion and Power

International Medical Education

ISPRS International Journal of Geo-Information

Journal of Aesthetic Medicine

Journal of Ageing and Longevity

Journal of CardioRenal Medicine

Journal of Cardiovascular Development and Disease

Journal of Clinical & Translational Ophthalmology

Journal of Clinical Medicine

Journal of Composites Science

Journal of Cybersecurity and Privacy

Journal of Dementia and Alzheimer's Disease

Journal of Developmental Biology

Journal of Experimental and Theoretical Analyses

Journal of Eye Movement Research

Journal of Functional Biomaterials

Journal of Functional Morphology and Kinesiology

Journal of Fungi

Journal of Genome Biotechnology and Genetics

Journal of Gerontology and Geriatrics

Journal of Imaging

Journal of Innovation

Journal of Intelligence

Journal of Interdisciplinary Research Applied to Medicine

Journal of Low Power Electronics and Applications

Journal of Manufacturing and Materials Processing

Journal of Marine Science and Engineering

Journal of Market Access & Health Policy

Journal of Mind and Medical Sciences

Journal of Molecular Pathology

Journal of Nanotheranostics

Journal of Nuclear Engineering

Journal of Otorhinolaryngology, Hearing and Balance Medicine

Journal of Parks

Journal of Personalized Medicine

Journal of Pharmaceutical and BioTech Industry

Journal of Phytomedicine

Journal of Respiration

Journal of Risk and Financial Management

Journal of Sensor and Actuator Networks

Journal of Superintelligence

Journal of the American Podiatric Medical Association

Journal of the Oman Medical Association

Journal of Theoretical and Applied Electronic Commerce Research

Journal of Vascular Diseases

Journal of Xenobiotics

Journal of Zoological and Botanical Gardens

Journalism and Media

Kidney and Dialysis

Kinases and Phosphatases

Laboratories

Limnological Review

Low-Altitude Economy

Machine Learning and Knowledge Extraction

Magnetochemistry

Marine Drugs

Materials Proceedings

Mathematical and Computational Applications

Mathematics

Medical Sciences

Medical Sciences Forum

Metabolites

Meteorology

Methods and Protocols

Microbiology Research

Microelectronics

Micromachines

Microorganisms

Microplastics

Modern Mathematical Physics

Multimodal Technologies and Interaction

Nanoenergy Advances

Nanomanufacturing

Nanomaterials

Neuroimaging

Neurology International

Non-Coding RNA

Nursing Reports

Nutraceuticals

Occupational Health

Parasitologia

Pathophysiology

Peace Studies

Pediatric Reports

Pharmaceuticals

Pharmaceutics

Pharmacoepidemiology

Philosophies

Physical Sciences Forum

Physiologia

Polysaccharides

Populations

Precision Oncology

Primary and Hospital Care

Proceedings

Psychiatry International

Psychoactives

Psychology International

Publications

Purification

Quantum Beam Science

Quantum Reports

Real Estate

Regional Science and Environmental Economics

Remote Sensing

Reproductive Medicine

Romanian Journal of Preventive Medicine

Scientia Pharmaceutica

Semiconductors and Heterogeneous Integration

Separations

Smart Cities

Social Sciences

Société Internationale d'Urologie Journal

Soil Systems

Spectroscopy Journal

Stratigraphy and Sedimentology

Surgical Techniques Development

Sustainability

Sustainable Chemistry

Swiss Archives of Neurology, Psychiatry and Psychotherapy

Technologies

Thalassemia Reports

Theoretical and Applied Ergonomics

Therapeutics

Time and Space

Tourism and Hospitality

Transplantology

Trauma Care

Trends in Higher Education

Trends in Public Health

Tropical Medicine and Infectious Disease

Urban Science

Venereology

Veterinary Sciences

Virtual Worlds

World Electric Vehicle Journal

Zoonotic Diseases

Select options

\[-\] accountaudit

Accounting and Auditing

\[-\] acoustics

Acta Microbiologica Hellenica

\[-\] actuators

\[-\] adhesives

Administrative Sciences

\[-\] adolescents

Adolescents

Advances in Respiratory Medicine

\[-\] aerobiology

Aerobiology

\[-\] aerospace

\[-\] agriculture

Agriculture

\[-\] agriengineering

AgriEngineering

\[-\] agrochemicals

Agrochemicals

\[-\] agronomy

AI Chemistry

AI for Engineering

AI in Education

AI in Medicine

\[-\] aimater

AI Materials

\[-\] algorithms

\[-\] allergies

\[-\] analytica

\[-\] analytics

\[-\] anatomia

\[-\] anesthres

Anesthesia Research

\[-\] animals

\[-\] antibiotics

Antibiotics

\[-\] antibodies

\[-\] antioxidants

Antioxidants

\[-\] applbiosci

Applied Biosciences

\[-\] applmech

Applied Mechanics

\[-\] applmicrobiol

Applied Microbiology

\[-\] applnano

Applied Nano

\[-\] applsci

Applied Sciences

Applied System Innovation

\[-\] appliedchem

AppliedChem

\[-\] appliedmath

AppliedMath

\[-\] appliedphys

AppliedPhys

Aquaculture Journal

\[-\] architecture

Architecture

\[-\] arthropoda

\[-\] astronautics

Astronautics

\[-\] astronomy

\[-\] atmosphere

\[-\] audiolres

Audiology Research

\[-\] automation

\[-\] bacteria

\[-\] batteries

\[-\] behavsci

Behavioral Sciences

\[-\] beverages

Big Data and Cognitive Computing

\[-\] biochem

\[-\] bioengineering

Bioengineering

\[-\] biologics

\[-\] biology

Biology and Life Sciences Forum

\[-\] biomass

\[-\] biomechanics

Biomechanics

\[-\] biomedicines

Biomedicines

\[-\] biomedinformatics

BioMedInformatics

\[-\] biomimetics

Biomimetics

\[-\] biomolecules

Biomolecules

\[-\] biophysica

\[-\] bioresourbioprod

Bioresources and Bioproducts

\[-\] biosensors

\[-\] biosphere

\[-\] biotech

\[-\] blockchains

Blockchains

\[-\] brainsci

Brain Sciences

\[-\] buildings

\[-\] businesses

\[-\] cancers

\[-\] cardiogenetics

Cardiogenetics

\[-\] cardiovascmed

Cardiovascular Medicine

\[-\] catalysts

\[-\] ceramics

\[-\] challenges

\[-\] ChemEngineering

ChemEngineering

\[-\] chemistry

\[-\] chemproc

Chemistry Proceedings

\[-\] chemosensors

Chemosensors

\[-\] children

\[-\] civileng

\[-\] cleantechnol

Clean Technologies

\[-\] climate

Clinical and Translational Neuroscience

\[-\] clinbioenerg

Clinical Bioenergetics

\[-\] clinpract

Clinics and Practice

\[-\] clockssleep

Clocks & Sleep

\[-\] coatings

\[-\] colloids

Colloids and Interfaces

\[-\] colorants

\[-\] commodities

Commodities

\[-\] complexities

Complexities

\[-\] complications

Complications

\[-\] compounds

\[-\] computation

Computation

Computer Sciences & Mathematics Forum

\[-\] computers

\[-\] condensedmatter

Condensed Matter

\[-\] conservation

Conservation

\[-\] constrmater

Construction Materials

Corrosion and Materials Degradation

\[-\] cosmetics

Craniomaxillofacial Trauma & Reconstruction

\[-\] cryptography

Cryptography

\[-\] crystals

\[-\] culture

Current Issues in Molecular Biology

\[-\] curroncol

Current Oncology

\[-\] dentistry

Dentistry Journal

\[-\] dermato

\[-\] dermatopathology

Dermatopathology

\[-\] designs

\[-\] diabetology

Diabetology

\[-\] diagnostics

Diagnostics

\[-\] dietetics

\[-\] digital

\[-\] disabilities

Disabilities

\[-\] diseases

\[-\] diversity

Drugs and Drug Candidates

\[-\] dynamics

\[-\] ecologies

\[-\] econometrics

Econometrics

\[-\] economies

\[-\] education

Education Sciences

\[-\] electricity

Electricity

\[-\] electrochem

Electrochem

\[-\] electronicmat

Electronic Materials

\[-\] electronics

Electronics

Emergency Care and Medicine

\[-\] encyclopedia

Encyclopedia

\[-\] endocrines

\[-\] energies

Energy Storage and Applications

\[-\] engproc

Engineering Proceedings

Entropic and Disordered Matter

\[-\] entropy

Environmental and Earth Sciences Proceedings

\[-\] environremediat

Environmental Remediation

\[-\] environments

Environments

\[-\] epidemiologia

Epidemiologia

\[-\] epigenomes

European Burn Journal

European Journal of Investigation in Health, Psychology and Education

Family Sciences

\[-\] fermentation

Fermentation

\[-\] fintech

\[-\] forecasting

Forecasting

\[-\] forensicsci

Forensic Sciences

\[-\] forests

\[-\] fossstud

Fossil Studies

\[-\] foundations

Foundations

\[-\] fractalfract

Fractal and Fractional

\[-\] futureinternet

Future Internet

\[-\] futurepharmacol

Future Pharmacology

\[-\] futuretransp

Future Transportation

\[-\] galaxies

\[-\] gastroent

Gastroenterology Insights

\[-\] gastrointestdisord

Gastrointestinal Disorders

\[-\] gastronomy

\[-\] genealogy

\[-\] geographies

Geographies

\[-\] geohazards

\[-\] geomatics

\[-\] geometry

\[-\] geosciences

Geosciences

\[-\] geotechnics

Geotechnics

\[-\] geriatrics

\[-\] glacies

Gout, Urate, and Crystal Deposition Disease

\[-\] grasses

\[-\] greenhealth

Green Health

\[-\] hardware

\[-\] healthcare

\[-\] hematolrep

Hematology Reports

\[-\] heritage

\[-\] histories

\[-\] horticulturae

Horticulturae

\[-\] hospitals

\[-\] humanities

\[-\] hydrobiology

Hydrobiology

\[-\] hydrogen

\[-\] hydrology

\[-\] hydropower

\[-\] hygiene

\[-\] industries

Infectious Disease Reports

\[-\] informatics

Informatics

\[-\] information

Information

\[-\] infrastructures

Infrastructures

\[-\] inorganics

\[-\] insects

\[-\] instruments

Instruments

Intelligent Infrastructure and Construction

International Journal of Cognitive Sciences

International Journal of Environmental Medicine

International Journal of Environmental Research and Public Health

International Journal of Financial Studies

International Journal of Molecular Sciences

International Journal of Neonatal Screening

International Journal of Orofacial Myology and Myofunctional Therapy

International Journal of Plant Biology

International Journal of Topology

International Journal of Translational Medicine

International Journal of Turbomachinery, Propulsion and Power

International Medical Education

\[-\] inventions

ISPRS International Journal of Geo-Information

\[-\] jaestheticmed

Journal of Aesthetic Medicine

Journal of Ageing and Longevity

Journal of CardioRenal Medicine

Journal of Cardiovascular Development and Disease

Journal of Clinical & Translational Ophthalmology

Journal of Clinical Medicine

Journal of Composites Science

Journal of Cybersecurity and Privacy

Journal of Dementia and Alzheimer's Disease

Journal of Developmental Biology

Journal of Experimental and Theoretical Analyses

Journal of Eye Movement Research

Journal of Functional Biomaterials

Journal of Functional Morphology and Kinesiology

Journal of Fungi

Journal of Genome Biotechnology and Genetics

Journal of Gerontology and Geriatrics

\[-\] jimaging

Journal of Imaging

Journal of Innovation

\[-\] jintelligence

Journal of Intelligence

Journal of Interdisciplinary Research Applied to Medicine

Journal of Low Power Electronics and Applications

Journal of Manufacturing and Materials Processing

Journal of Marine Science and Engineering

Journal of Market Access & Health Policy

Journal of Mind and Medical Sciences

Journal of Molecular Pathology

Journal of Nanotheranostics

Journal of Nuclear Engineering

Journal of Otorhinolaryngology, Hearing and Balance Medicine

Journal of Parks

Journal of Personalized Medicine

Journal of Pharmaceutical and BioTech Industry

\[-\] jphytomed

Journal of Phytomedicine

Journal of Respiration

Journal of Risk and Financial Management

Journal of Sensor and Actuator Networks

\[-\] superintelligence

Journal of Superintelligence

Journal of the American Podiatric Medical Association

Journal of the Oman Medical Association

Journal of Theoretical and Applied Electronic Commerce Research

Journal of Vascular Diseases

Journal of Xenobiotics

Journal of Zoological and Botanical Gardens

\[-\] journalmedia

Journalism and Media

\[-\] kidneydial

Kidney and Dialysis

\[-\] kinasesphosphatases

Kinases and Phosphatases

\[-\] knowledge

\[-\] laboratories

Laboratories

\[-\] languages

\[-\] limnolrev

Limnological Review

\[-\] lipidology

\[-\] liquids

\[-\] literature

\[-\] logistics

Low-Altitude Economy

\[-\] lubricants

\[-\] lymphatics

Machine Learning and Knowledge Extraction

\[-\] machines

\[-\] macromol

\[-\] magnetism

\[-\] magnetochemistry

Magnetochemistry

\[-\] marinedrugs

Marine Drugs

\[-\] materials

\[-\] materproc

Materials Proceedings

Mathematical and Computational Applications

\[-\] mathematics

Mathematics

Medical Sciences

Medical Sciences Forum

\[-\] medicina

\[-\] medicines

\[-\] membranes

\[-\] metabolites

Metabolites

\[-\] meteorology

Meteorology

\[-\] methane

Methods and Protocols

\[-\] metrics

\[-\] metrology

\[-\] microbiolres

Microbiology Research

\[-\] microelectronics

Microelectronics

\[-\] micromachines

Micromachines

\[-\] microorganisms

Microorganisms

\[-\] microplastics

Microplastics

\[-\] microwave

\[-\] minerals

\[-\] modelling

Modern Mathematical Physics

\[-\] molbank

\[-\] molecules

\[-\] multimedia

Multimodal Technologies and Interaction

\[-\] muscles

\[-\] nanoenergyadv

Nanoenergy Advances

\[-\] nanomanufacturing

Nanomanufacturing

\[-\] nanomaterials

Nanomaterials

\[-\] network

\[-\] neuroglia

\[-\] neuroimaging

Neuroimaging

\[-\] neurolint

Neurology International

\[-\] neurosci

\[-\] nitrogen

Non-Coding RNA

\[-\] nursrep

Nursing Reports

\[-\] nutraceuticals

Nutraceuticals

\[-\] nutrients

\[-\] obesities

\[-\] occuphealth

Occupational Health

\[-\] organics

\[-\] organoids

\[-\] osteology

\[-\] pandemics

\[-\] parasitologia

Parasitologia

\[-\] particles

\[-\] pathogens

\[-\] pathophysiology

Pathophysiology

\[-\] peacestud

Peace Studies

\[-\] pediatrrep

Pediatric Reports

\[-\] pharmaceuticals

Pharmaceuticals

\[-\] pharmaceutics

Pharmaceutics

\[-\] pharmacoepidemiology

Pharmacoepidemiology

\[-\] pharmacy

\[-\] philosophies

Philosophies

\[-\] photochem

\[-\] photonics

\[-\] phycology

\[-\] physchem

Physical Sciences Forum

\[-\] physics

\[-\] physiologia

Physiologia

\[-\] platforms

\[-\] pollutants

\[-\] polymers

\[-\] polysaccharides

Polysaccharides

\[-\] populations

Populations

\[-\] poultry

\[-\] powders

\[-\] precisoncol

Precision Oncology

Primary and Hospital Care

\[-\] proceedings

Proceedings

\[-\] processes

\[-\] prosthesis

\[-\] proteomes

\[-\] psychiatryint

Psychiatry International

\[-\] psychoactives

Psychoactives

\[-\] psycholint

Psychology International

\[-\] publications

Publications

\[-\] purification

Purification

Quantum Beam Science

\[-\] quantumrep

Quantum Reports

\[-\] quaternary

\[-\] radiation

\[-\] reactions

\[-\] realestate

Real Estate

\[-\] receptors

\[-\] recycling

Regional Science and Environmental Economics

\[-\] religions

\[-\] remotesensing

Remote Sensing

\[-\] reports

\[-\] reprodmed

Reproductive Medicine

\[-\] resources

\[-\] rheumato

\[-\] robotics

Romanian Journal of Preventive Medicine

\[-\] ruminants

\[-\] scipharm

Scientia Pharmaceutica

\[-\] sclerosis

Semiconductors and Heterogeneous Integration

\[-\] sensors

\[-\] separations

Separations

\[-\] signals

\[-\] sinusitis

\[-\] smartcities

Smart Cities

Social Sciences

Société Internationale d'Urologie Journal

\[-\] societies

\[-\] software

\[-\] soilsystems

Soil Systems

\[-\] spectroscj

Spectroscopy Journal

\[-\] standards

\[-\] stratsediment

Stratigraphy and Sedimentology

\[-\] stresses

\[-\] surfaces

\[-\] surgeries

Surgical Techniques Development

\[-\] sustainability

Sustainability

\[-\] suschem

Sustainable Chemistry

Swiss Archives of Neurology, Psychiatry and Psychotherapy

\[-\] symmetry

\[-\] systems

\[-\] targets

\[-\] taxonomy

\[-\] technologies

Technologies

\[-\] telecom

\[-\] textiles

\[-\] thalassrep

Thalassemia Reports

Theoretical and Applied Ergonomics

\[-\] therapeutics

Therapeutics

\[-\] timespace

Time and Space

\[-\] tomography

\[-\] tourismhosp

Tourism and Hospitality

\[-\] transplantology

Transplantology

\[-\] traumacare

Trauma Care

\[-\] higheredu

Trends in Higher Education

Trends in Public Health

\[-\] tropicalmed

Tropical Medicine and Infectious Disease

\[-\] universe

\[-\] urbansci

Urban Science

\[-\] vaccines

\[-\] vehicles

\[-\] venereology

Venereology

Veterinary Sciences

\[-\] vibration

\[-\] virtualworlds

Virtual Worlds

\[-\] viruses

World Electric Vehicle Journal

\[-\] zoonoticdis

Zoonotic Diseases

© 1996-2026 MDPI (Basel, Switzerland) unless otherwise stated

https://www.mdpi.com/2073-8994/17/3/397

Disclaimer/Publisher's Note: The statements, opinions and data contained in all publications are solely those of the individual author(s) and contributor(s) and not of MDPI and/or the editor(s). MDPI and/or the editor(s) disclaim responsibility for any injury to people or property resulting from any ideas, methods, instructions or products referred to in the content.

Terms and Conditions

https://www.mdpi.com/about/terms-and-conditions

Privacy Policy

https://www.mdpi.com/about/privacy

We use cookies on our website to ensure you get the best experience.

Read more about our cookies

https://www.mdpi.com/about/privacy

https://www.mdpi.com/accept\_cookies

mailto:?&subject=From%20MDPI%3A%20%22Leveraging%20Symmetry%20and%20Addressing%20Asymmetry%20Challenges%20for%20Improved%20Convolutional%20Neural%20Network-Based%20Facial%20Emotion%20Recognition"&body=https://www.mdpi.com/3213134%3A%0A%0ALeveraging%20Symmetry%20and%20Addressing%20Asymmetry%20Challenges%20for%20Improved%20Convolutional%20Neural%20Network-Based%20Facial%20Emotion%20RecognitionThis%20study%20introduces%20a%20custom-designed%20CNN%20architecture%20that%20extracts%20robust%2C%20multi-level%20facial%20features%20and%20incorporates%20preprocessing%20techniques%20to%20correct%20or%20reduce%20asymmetry%20before%20classification.%20The%20innovative%20characteristics%20of%20this%20research%20lie%20in%20its%20integrated%20approach%20to%20overcoming%20facial%20asymmetry%20challenges%20and%20enhancing%20CNN-based%20emotion%20recognition.%20This%20is%20completed%20by%20well-known%20data%20augmentation%20strategies%E2%80%94using%20methods%20such%20as%20vertical%20flipping%20and%20shuffling%E2%80%94that%20generate%20symmetric%20variations%20in%20facial%20images%2C%20effectively%20balancing%20the%20dataset%20and%20improving%20recognition%20accuracy.%20Additionally%2C%20a%20Loss%20Weight%20parameter%20is%20used%20to%20fine-tune%20training%2C%20thereby%20optimizing%20performance%20across%20diverse%20and%20unbalanced%20emotion%20classes.%20Collectively%2C%20all%20these%20contribute%20to%20an%20efficient%2C%20real-time%20facial%20emotion%20recognition%20system%20that%20outperforms%20traditional%20CNN%20models%20and%20offers%20practical%20benefits%20for%20various%20applications%20while%20also%20addressing%20the%20inherent%20challenges%20of%20facial%20asymmetry%20in%20emotion%20detection.%20Our%20experimental%20results%20demonstrate%20superior%20performance%20compared%20to%20other%20CNN%20methods%2C%20marking%20a%20step%20forward%20in%20applications%20ranging%20from%20human%E2%80%93computer%20interaction%20to\[...\]

https://x.com/intent/tweet?text=Leveraging+Symmetry+and+Addressing+Asymmetry+Challenges+for+Improved+Convolutional+Neural+Network-Based+Facial+Emotion+Recognition&hashtags=mdpisymmetry&url=https%3A%2F%2Fwww.mdpi.com%2F3213134&via=Symmetry\_MDPI

http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fwww.mdpi.com%2F3213134&title=Leveraging%20Symmetry%20and%20Addressing%20Asymmetry%20Challenges%20for%20Improved%20Convolutional%20Neural%20Network-Based%20Facial%20Emotion%20Recognition%26source%3Dhttps%3A%2F%2Fwww.mdpi.com%26summary%3DThis%20study%20introduces%20a%20custom-designed%20CNN%20architecture%20that%20extracts%20robust%2C%20multi-level%20facial%20features%20and%20incorporates%20preprocessing%20techniques%20to%20correct%20or%20reduce%20asymmetry%20before%20classification.%20The%20innovative%20characteristics%20of%20this%20%5B...%5D

http://www.facebook.com/sharer.php?u=https://www.mdpi.com/3213134

javascript:void(0);

http://www.reddit.com/submit?url=https://www.mdpi.com/3213134

http://www.mendeley.com/import/?url=https://www.mdpi.com/3213134

http://www.citeulike.org/posturl?url=https://www.mdpi.com/3213134

https://www.mdpi.com/3213134

https://www.mdpi.com/2073-8994/17/3/397

https://www.mdpi.com/2073-8994/17/3/397

https://www.mdpi.com/3213134

https://www.mdpi.com/2073-8994/17/3/397

Back to Top Top

https://www.mdpi.com/2073-8994/17/3/397

All MDPI websites use third-party website tracking technologies to provide and continually improve our services. I agree and may revoke or change my consent at any time with effect for the future.

https://www.mdpi.com/about/privacy

https://www.mdpi.com/about/terms-and-conditions

More Information

https://www.mdpi.com/2073-8994/17/3/397

Powered by Usercentrics Consent Management

https://www.usercentrics.com/consent-management-platform-powered-by-usercentrics/?utm\_source=banner\_uc&utm\_medium=referral&utm\_content=v3

