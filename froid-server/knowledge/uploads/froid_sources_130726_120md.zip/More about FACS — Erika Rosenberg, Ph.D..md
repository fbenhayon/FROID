# More about FACS — Erika Rosenberg, Ph.D.

https://www.erikarosenberg.com/more-about-facs

https://www.erikarosenberg.com/cart

https://www.erikarosenberg.com/tutorial

NEW! Try my new tutorial - Facial Expressions of Emotion 101

Skip to Content

https://www.erikarosenberg.com/more-about-facs#page

Erika Rosenberg, Ph.D.

https://www.erikarosenberg.com/

https://www.erikarosenberg.com/about

Compassion Meditation

https://www.erikarosenberg.com/compassion-meditation

https://www.erikarosenberg.com/consulting

FACS Training

https://www.erikarosenberg.com/facs-training

https://www.erikarosenberg.com/events-1

https://www.erikarosenberg.com/resources

Facial Expressions of Emotion 101

https://www.erikarosenberg.com/tutorial

https://www.erikarosenberg.com/more-about-facs

Get email updates

https://www.erikarosenberg.com/mailing-list-subscribe-form

Open Menu Close Menu

Erika Rosenberg, Ph.D.

https://www.erikarosenberg.com/

https://www.erikarosenberg.com/about

Compassion Meditation

https://www.erikarosenberg.com/compassion-meditation

https://www.erikarosenberg.com/consulting

FACS Training

https://www.erikarosenberg.com/facs-training

https://www.erikarosenberg.com/events-1

https://www.erikarosenberg.com/resources

Facial Expressions of Emotion 101

https://www.erikarosenberg.com/tutorial

https://www.erikarosenberg.com/more-about-facs

Get email updates

https://www.erikarosenberg.com/mailing-list-subscribe-form

Open Menu Close Menu

https://www.erikarosenberg.com/about

Compassion Meditation

https://www.erikarosenberg.com/compassion-meditation

https://www.erikarosenberg.com/consulting

FACS Training

https://www.erikarosenberg.com/facs-training

https://www.erikarosenberg.com/events-1

https://www.erikarosenberg.com/resources

Facial Expressions of Emotion 101

https://www.erikarosenberg.com/tutorial

https://www.erikarosenberg.com/more-about-facs

Get email updates

https://www.erikarosenberg.com/mailing-list-subscribe-form

FACS Background

Facial Action Coding System (FACS) is the comprehensive, anatomically-based facial measurement system developed by Ekman & Friesen.

FACS has been used in a wide range of applied and basic research contexts, from research on emotion, communication, and psychopathology to health psychology and forensics.

For more information about FACS and its applications, please see my book with Paul Ekman,

What the Face Reveals: Basic and Applied Studies of Spontaneous Expression Using the Facial Action Coding System (FACS) (Series in Affective Science).

https://smile.amazon.com/What-Face-Reveals-Spontaneous-Expression/dp/0195179641?sa-no-redirect=1

What is FACS?

The Facial Action Coding System (FACS), first developed by Paul Ekman and Wallace Friesen in 1978 and revised by Ekman, Friesen, & Hager in 2002, is a comprehensive, anatomically-based system for coding all observable facial behavior.

Describing facial movement

FACS is first and foremost a system for describing facial action. FACS describes facial movement on the basis of elemental units called action units or AUs. Each AU represents the movement that occurs when underlying muscle fibers contract. For instance, AU1, which occurs when frontalis, pars medialis contracts, lifts the inner corner of the eyebrow. To learn each AU, coders learn the appearance changes associated with each action, practice performing the AU, and learn the intensity scoring for the action.

No interpretation of emotion

As FACS coders describe every observable change in facial movement on the basis of AUs — they do not make emotion judgments. Rather, coders simply indicate which AUs moved to produced the changes observed in the face. FACS coders rely on direct observation of movement as well as observed changes in facial morphology; such as, furrows, creases, bulges of skin, etc., to make inferences about which muscles moved.

FACS coding is quite objective

Indeed, the power of FACS stems from its descriptive nature. Facial scientists often refer to a set of actions that occur on the face simultaneously as “facial events,” rather than calling them facial expressions. It is more descriptive. The word “expression” suggests that something from the inside becomes observable on the outside. Yet not every facial behavior expresses an internal state — most probably do not.

Any interpretations made about what these changes mean occur post-coding. This is crucial, as it means FACS coding is quite objective. Coders need not interpret what a given event means or might convey. Rather, the coder simply uses AUs to describe the movements he or she saw.

The FACS coder has a daunting task — to describe all facial events in terms of the AUs that comprise it.

Slow motion and frame-by-frame viewing are required for this purpose, always alternating with real time viewing. As such, FACS coding is very time intensive. Fully applied, FACS coding takes on average 100 minutes to code 1 minute of behavior. The exact timing varies depending on how active the target's face is and the complexity of the facial events.

One could write volumes about FACS. For more information about FACS and its applications, please see my book with Paul Ekman,

What the Face Reveals: Basic and Applied Studies of Spontaneous Expression Using the Facial Action Coding System (FACS) (Series in Affective Science).

https://smile.amazon.com/What-Face-Reveals-Spontaneous-Expression/dp/0195179641?sa-no-redirect=1

Apply for Training

https://www.erikarosenberg.com/is-facs-training-right-for-you

Erika Rosenberg, Ph.D.

mailto:erika@erikarosenberg.com

https://www.youtube.com/channel/UC4ojjtZ3Gc3Iy8uZzqF1pjw

https://www.linkedin.com/in/erika-rosenberg-145500/

https://www.facebook.com/ErikaRosenbergPhD/

https://www.erikarosenberg.com/about

FACS Training

https://www.erikarosenberg.com/facs-training

Compassion Training

https://www.erikarosenberg.com/compassion-meditation

https://www.erikarosenberg.com/resources

https://www.erikarosenberg.com/contact

#### Get updates on new trainings, classes, and more:

Email Address

NEW: Facial Expressions of Emotion 101

Learn the 7 universal emotions in just 30 minutes. Tutorial includes science-backed training to read faces and sharpen your real-world connections.

https://www.erikarosenberg.com/tutorial

&gWwOgQlLa6S &gWwOgQlLa6S

