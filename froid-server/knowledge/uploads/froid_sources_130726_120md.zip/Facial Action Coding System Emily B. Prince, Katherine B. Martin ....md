# Facial Action Coding System Emily B. Prince, Katherine B. Martin ...

https://local.psy.miami.edu/faculty/dmessinger/c\_c/rsrcs/rdgs/emot/FACSChapter\_SAGEEncyclopedia.pdf

Facial Action Coding System Emily B. Prince, Katherine B. Martin, & Daniel S. Messinger

The Facial Action Coding System (FACS) is a widely used protocol for recognizing and

labelling facial expression by describing the movement of muscles of the face. FACS is used to objectively measure the frequency and intensity of facial expressions without assigning any emotional meaning to those muscle movements. Instead FACS breaks down facial expressions into their smallest discriminable movements called Action Units. Each Action Unit creates a distinct change in facial appearance, such as an eyebrow lift or nose wrinkle. FACS coders can identify the Action Units which are present on the face when viewing still images or videos. Psychological research has used FACS to examine a variety of research questions including social-emotional development, neuropsychiatric disorders, and deception. In the course of this report we provide an overview of FACS and the Action Units, its reliability as a measure, and how it has been applied in some key areas of psychological research.  What is FACS?

First published by Paul Ekman and Wallace Friesen in 1978, and updated in 2002, FACS was designed to collect empirical data on facial expressions without introducing emotional interpretation. Previous coding systems focused on the message underlying expressions (e.g. is this a happy or sad expression?). Ekman and Friesen argued that this was a subjective approach. Raters didn’t have a standardized system for determining the emotional state; instead, they relied on their own judgements and experiences. FACS offers a more objective measurement system which is divorced from emotional valuation from the beginning. Instead of interpreting the message the expression is conveying, FACS coders focus on describing facial behaviors. Interpretation can be added later when researchers examine which facial behaviors are related to emotional situations or self-reports.  How does FACS work?

To create FACS, Ekman and Friesen began by electrically stimulating each individual muscle of the face and attempting to replicate those movements voluntarily. FACS Action Units are defined as the smallest movements of the face which can be reliably distinguished from another and each one is associated with one or more muscle movements. Readers interested in a comprehensive list of the FACS Action Units can seek out the updated FACS manual published by Ekman, Friesen, and Hager in 2002. The FACS manual includes codes for 27 Action Units in the face, 25 head and eye position codes, and an additional 28 codes that include miscellaneous movements (such as showing the tongue) and visibility codes.

The 27 facial Action Units are broken down into upper and lower facial movements. The upper facial Action Units include brow raising (Action Units 1 and 2 for inner and outer edges of the brow respectively), brow lowering (4), eyelid raising (5) and cheek raising (6). Lower facial actions are more complex and include vertical, horizontal, oblique and orbital Action Units. An example of a vertical Action Unit would be number 15 which pulls the corners of the lips straight down, while an oblique Action Unit would be Action Unit 12 which pulls the lip corners up and out. Most facial expressions include a combination of upper and lower Action Units, and some combinations are more common than others. Head and eye movement codes are broader and less commonly used but can provide important emotional information about what’s happening on the face. They include head tilting, turning and general eye direction.

In addition to the occurrence of each Action Unit, coders can also rate the intensity. Action Unit intensity is rated on a scale of evidence from A (trace levels of visibility) to E (maximal). Trace intensity means that the Action Unit is barely visible on the face, and intensity progresses along the scale to slight, marked, pronounced, severe, extreme and finally maximum.  The requirements for reaching each level of intensity vary across Action Units.

Some researchers may use intensity ratings as cut-offs for coding (e.g. anything that is rated a B or above is present, but trace Action Units are not coded).   Applying FACS (Coding)

When researchers use FACS, they can either comprehensively code all Action Units present in the video or image of interest, or selectively choose which Action Units to code. Each method has its benefits and drawbacks. Comprehensive coding means that investigators can ask more exploratory questions and interpret null results more easily. However, comprehensive coding is also time consuming; a one second video clip can take fifteen minutes for an experienced FACS coder to comprehensively code. When researchers use selective coding, they choose the Action Units of interest before coding begins. Selective coding is quicker, but it also depends on the researcher having an a priori hypothesis about which Action Units are important for the question being investigated.  FACS Certification

FACS is a complex system and requires a significant investment of time and energy to learn. The FACS 2002 training manual can be purchased from the Paul Ekman Group, LLC. This 370 page self-instructional digital text covers each Action Unit in detail including photographs and videos. It also provides guidance on scoring criteria, frequent Action Unit combinations, and how to distinguish between frequently confused Action Units. In addition to the manual, FACS 2002 comes with a series of practice photos and videos and a program which can check the learner’s coding. Using the FACS 2002 manual, it is possible for a person to teach himself or herself FACS individually; however, many people find it easier to learn FACS in a group setting. The time it takes to become reliable on FACS varies based on amount of effort spent and individual differences in coders. However, the creators suggest that with 3 to 4 practice sessions a week, most people are able to become reliable in 3 months. For those interested in becoming reliable in a structured group format, there is a 1-week intensive course offered approximately once a year. The course covers the complete contents of the manual, provides live examples of different Action Units both by the instructor and fellows students, and includes nightly homework and quizzes. This intense focus on FACS may also decrease the amount of time it takes to become reliable. Reliability is measured through the FACS Final Test, also provided by the Paul Ekman Group. It consists of 34 short video segments taken from actual conversations. The test items are meant to be representative of the kinds of research materials coders will encounter.  Test-takers’ answers are compared to those of FACS experts to measure reliability and provide suggestions for improvement.  Reliability of FACS

Only a handful of studies have directly examined the reliability of the FACS protocol. Researchers using FACS often state that their coders passed the FACS Final Test, and report inter-rater reliability for the overall coding, but not for individual Action Units. This makes it difficult to determine whether certain Action Units are less reliable than others. Complicating the issue, reliability may be measured along several metrics: the presence or absence of the Action Unit, the timing at which it appears on the face, and its intensity. For example, if two people were coding Action Unit 1 (raising the inner portion of the eyebrow) they would need to agree whether it happened, when it happened, and to what extent. Sayette and colleagues used videos from over 100 participants reacting to different stimuli and comprehensively coded them. They then counted how often each Action Unit appeared and determined the inter-rater reliability for 19 Action Units that appeared in the videos for 48 frames or more. They found good to excellent interrater agreement for the majority of the Action Units, where the coders needed to have marked the presence or absence of an Action Unit within half a second of each other. Several Action Units, including narrowing of the eyes (Action Unit 7) and lip pressing (22),

had much lower reliability, possibly because they are frequently confused with similar Action Units like eye constriction (6) and lip tightening (24).   FACS in Infants

In developmental research, FACS has been used to examine how infants express emotion with their mothers and communicate enjoyment and displeasure in activities. Harriet Oster’s group has created a FACS manual specific to infants, called Baby FACS. The coding system is similar to adult FACS, but it takes into account the unique morphology of infant faces, including the buccal fat pads that give infants their chubby cheeks. It adds several additional Action Units that are collapsed into single Action Units in adults, and provides guidance on how adult Action Units appear on infant faces.    FACS in Research Emotional Expression in FACS

FACS is used as a shared language among researchers to describe facial expressions and explore how they relate to emotional experiences and reports. Ekman, Friesen and Hager have outlined some general guidelines about Action Units which typically co-occur and are frequently associated with the emotions of surprise, fear, happiness, sadness, disgust and anger.  These associations have allowed researchers to analyze complex facial expressions using FACS and assess the emotional meaning of the Action Units involved.  For example, smiles occur across a variety of emotional contexts, not just enjoyment, but how they are paired with other Action Units can provide insight the emotions in those contexts. In a study where people lied about an enjoyable experience, Ekman and colleagues found that liars who were smiling were also likely to have short-lived, trace-level Action Units frequently associated with disgust, sadness, or anger. Ekman makes the argument that smiling acts as a mask for the liars and their true emotions leak through in these micro-expressions.

FACS has also been used to examine how emotional expressions mediate responses to suffering and relate to long-term social outcomes. In a study on compassionate meditation, researchers examined expressions of sadness before and after three months of meditation training. Participants trained in compassionate meditation had more Action Units associated with sadness when viewing videos of human suffering. The group who did not receive the compassion training was not only less sad, but also showed more “rejecting” Action Units associated with anger and disgust. In a longitudinal study of women from the 1950’s and 60’s, researchers used FACS to measure intensity of positive expression in college yearbook photos.  They found that how happy the woman appeared in the picture was associated with social outcomes over thirty years later such as reports of well-being and marital status.  Another study using Facebook profile pictures found similar results: male and female participants who smiled more intensely in their picture during their first year of college had higher life satisfaction at the time of graduation. These studies illuminate the relationship of facial movement both to emotional states and their role in predicting important life outcomes.  Cross-Cultural Research

Early in the 1970s, Ekman and others, ran a series of cross-cultural experiments in which participants viewed pictures of posed facial expressions. Researchers showed angry, fearful, disgusted, sad, joyful and contemptuous expressions to people from multiple countries, including a preliterate culture in New Guinea, and found that there was strong agreement about the emotions tied to the expressions, and the social situations in which those expressions might be present. This suggests that these emotions are universally recognizable and consistent across cultures. However, there are several important limitations to these experiments. Researchers often used forced-choice tests where participants were labelling expressions from a limited number of options. The pictures were typically posed and hand-picked by the

researchers to represent each emotion, rather than relying on naturalistic photographs. Many studies were within-subject designs which meant that participants could potentially use a process of elimination to determine which emotion matched each expression. These limitations bring the universality of emotional expression into question, and, in fact, when they are addressed in other studies, the findings are less robust than Ekman and other’s original work.  More research needs to be done in this field in order to understand how emotions are expressed—as well as recognized—across cultures.  Eye Constriction

In Charles Darwin’s The Expression of the Emotions in Man and Animals, he proposed that smiles that included eye constriction (also known as Duchenne smiles) indexed strong positive emotion. In FACS coding, eye constriction is coded as Action Unit 6, and involves wrinkling around the corners of the eyes and raising of the cheeks. One of Ekman and Friesen’s key findings with FACS has been that smiles indicating genuine enjoyment are more likely to include eye constriction. Self-reported happiness correlates with the amount of time adults spend Duchenne smiling, and in enjoyable situations people are also more likely to have a Duchenne smile. Ekman used these findings to argue that Duchenne and non-Duchenne smiles are two discrete emotional expressions, one representing genuine enjoyment and the other a social signal that is unrelated to enjoyment.

However, research conducted by Daniel Messinger and colleagues suggests that eye constriction intensifies both positive and negative expressions in infants. Eye constriction has been associated with the intensity of smiling action. Naïve raters who have not received FACS training rate infants with Duchenne smiles as happier than those who are smiling without eye constriction. There also is a temporal progression from non-Duchenne smiling to Duchenne smiling suggesting that positive emotion may be increasing over time. Darwin also suggested that eye constriction may not be limited to positive expressions and Messinger’s work has supported this theory. New research with infants has shown that Action Unit 6 intensifies negative expressions. For naïve raters, greater eye constriction is associated with greater perceived negative emotion. These results suggest that eye constriction has a key communicative role; it intensifies the positive and negative expressions to which it is paired.   Clinical Research and FACS

FACS has been used to study the emotional experience of participants in clinical situations, such as smoking cessation studies and treatment for depression. These studies show that accessing cigarettes leads to expressions associated with positive affect while a delay in being able to smoke once the cigarette is in hand increases expressions related to negative affect.  People with depression are less able to recognize positive emotional expressions in others, and, FACS coding has shown, they are also less likely to produce positive facial expressions themselves. By using FACS, researchers have been able to objectively measure this clinically relevant symptom of depression. In one study, clinically depressed participants were filmed while answering questions about their current feelings of depression. The FACS coders found that the patients who endorsed the strongest feelings of depression were less likely to smile (Action Unit 12) and depress the corners of their lips (Action Unit 15) and more likely to use Action Units associated with suppressing emotional expression (e.g. Action Unit 24, pressing the lips together).  They were less openly sharing affect with the interviewer, and instead may have used actions like the lip press to mask their feelings of depression. Importantly, naive coders, who were not trained in FACS, could not distinguish between the high and low depression participants. These findings suggest that depressed individuals use nonverbal cues to convey their emotional experiences and that these signals are not always consciously recognizable by the conversational partner.

Automated Measurement of FACS

Because FACS is time and energy intensive, there has been a push within the research

community to develop automated systems of FACS coding. Automated coding of facial

expressions and their corresponding intensities uses a combination of computer vision and

pattern recognition techniques. There are two approaches to automated FACS coding: one

which models the face and one which does not.  In the facial modelling system, researchers

apply automated facial image analysis using active appearance models (AAM) and support

vector machine (SVM) classifiers. AAMs extract and represent shape and appearance features

from a video sequence. After AAMs determine the shape and appearance of the face, SVM

classifiers detect Action Units and quantify their intensity. This kind of facial modeling system

has been applied in many studies, including the study of depressed patients and Messinger’s

work on eye constriction in infants described above. In the second type of automated coding,

the face is not explicitly modeled; instead the facial area is tracked and SVM classifiers are

applied directly with a face model.  In both cases, the software is trained on specific Action Units

on sample faces, which is then applied to test faces, the actual data to be coded, in order to

measure those Action Units. As in manual coding, reliability is generally higher for posed than

genuine facial expressions, but even then, many studies have reported a mean agreement with

human coders of over 90%. These automated systems are being rapidly refined and several are

commercially available. They have the potential to dramatically reduce the burden on human

FACS coders and expand the use of comprehensive FACS coding.

FACS is an established, widely used protocol for objectively recognizing and labelling facial expressions by describing the movement of individual muscles of the face. FACS provides a way to objectively measure the frequency and intensity of facial expressions without applying emotional labels.  The objectivity and reliability of FACS make it possible for researchers to use this system as a shared language between studies and across disciplines. FACS has been used extensively in developmental research, cross-cultural research, and clinical research. Researches have used FACS to analyze complex facial expressions and assess the emotional meaning of the Action Units involved. Since FACS is the premiere coding system for facial expressions, recent efforts have been underway to automate the measurement of facial expressions to reduce the burden on human coders and expand the use of FACS beyond behavioral research disciplines.

Further Readings

Bartlett, M. S., Littlewort, G., Frank, M., Lainscsek, C., Fasel, I., & Movellan, J. (2006). Fully automatic facial action recognition in spontaneous behavior. In Automatic Face and Gesture Recognition, 2006. FGR 2006. 7th International Conference on (pp. 223–230).

Cohn, J. F., Ambadar, Z., & Ekman, P. (2007). Observer-based measurement of facial expression with the Facial Action Coding System. The Handbook of Emotion Elicitation and Assessment, 203–221.

Ekman, P., & Friesen, W. V. (1978). Manual for the facial action coding system. Consulting Psychologists Press.

Ekman, P., & Rosenberg, E. L. (1997). What the face reveals: Basic and applied studies of spontaneous expression using the Facial Action Coding System (FACS). Oxford University Press.

Girard, J. M., Cohn, J. F., Jeni, L. A., Sayette, M. A., & De la Torre, F. (2014). Spontaneous facial expression in unscripted social interactions can be measured automatically. Behavior Research Methods, 1–12.

Mattson, W. I., Cohn, J. F., Mahoor, M. H., Gangi, D. N., & Messinger, D. S. (2013). Darwin’s Duchenne: Eye constriction during infant joy and distress. PLoS ONE, 8(11). doi: 10.1371/journal.pone.0080161.

Messinger, D.S., Mattson, W.I., Mahoor, M.H., & Cohn, J.F. (2012). The eyes have it: Making positive expressions more positive and negative expressions more negative. Emotion, 12(3), 430-436.

Oster, H. (2006). Baby FACS: Facial Action Coding System for infants and young children. Unpublished Monograph and Coding Manual. New York University.

Rosenberg, E. L., Zanesco, A. P., King, B. G., Aichele, S. R., Jacobs, T. L., Bridwell, D. A., … Saron, C. D. (2015). Intensive Meditation Training Influences Emotional Responses to Suffering. Emotion. Advance online publication. http://dx.doi.org/10.1037/emo0000080

Sayette, M. A., Cohn, J. F., Wertz, J. M., Perrott, M. A., & Parrott, D. J. (2001). A psychometric evaluation of the facial action coding system for assessing spontaneous expression. Journal of Nonverbal Behavior, 25(3), 167–185.

Waters, A. J., Shiffman, S., Sayette, M. A., Paty, J. A., Gwaltney, C. J., & Balabanis, M. H. (2004). Cue-provoked craving and nicotine replacement therapy in smoking cessation. Journal of Consulting and Clinical Psychology, 72(6), 1136.

