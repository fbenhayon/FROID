# Effects of the duration of expressions on the recognition of microexpressions - PMC - NIH

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/

Effects of the duration of expressions on the recognition of microexpressions - PMC

Skip to main content

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/#main-content

An official website of the United States government

Here's how you know

Here's how you know

Official websites use .gov

website belongs to an official government organization in the United States.

Secure .gov websites use HTTPS

( Locked padlock icon ) or

means you've safely connected to the .gov website. Share sensitive information only on official, secure websites.

https://www.ncbi.nlm.nih.gov/myncbi/

Publications

https://www.ncbi.nlm.nih.gov/myncbi/collections/bibliography/

Account settings

https://www.ncbi.nlm.nih.gov/account/settings/

Search… Search NCBI

Primary site navigation

#### Logged in as:

https://www.ncbi.nlm.nih.gov/myncbi/

Publications

https://www.ncbi.nlm.nih.gov/myncbi/collections/bibliography/

Account settings

https://www.ncbi.nlm.nih.gov/account/settings/

https://pmc.ncbi.nlm.nih.gov/

Search PMC Full-Text Archive

Search in PMC

Journal List

https://pmc.ncbi.nlm.nih.gov/journals/

https://pmc.ncbi.nlm.nih.gov/about/userguide/

View on publisher site

Download PDF

Add to Collections

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/

As a library, NLM provides access to scientific literature. Inclusion in an NLM database does not imply endorsement of, or agreement with, the contents by NLM or the National Institutes of Health.

#### Learn more:

PMC Disclaimer

https://pmc.ncbi.nlm.nih.gov/about/disclaimer/

PMC Copyright Notice

https://pmc.ncbi.nlm.nih.gov/about/copyright/

J Zhejiang Univ Sci B

. 2012 Mar;13(3):221–230. doi:

10.1631/jzus.B1100063

https://doi.org/10.1631/jzus.B1100063

Search in PMC

https://pmc.ncbi.nlm.nih.gov/search/?term="J%20Zhejiang%20Univ%20Sci%20B"\[jour\]

Search in PubMed

https://pubmed.ncbi.nlm.nih.gov/?term="J%20Zhejiang%20Univ%20Sci%20B"\[jour\]

View in NLM Catalog

https://www.ncbi.nlm.nih.gov/nlmcatalog?term="J%20Zhejiang%20Univ%20Sci%20B"\[Title%20Abbreviation\]

Add to search

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/?term=%22J%20Zhejiang%20Univ%20Sci%20B%22\[jour\]

Effects of the duration of expressions on the recognition of microexpressions

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/#FN01

Xun-bing Shen

https://pubmed.ncbi.nlm.nih.gov/?term="Shen%20XB"\[Author\]

Xun-bing Shen

State Key Laboratory of Brain and Cognitive Science, Institute of Psychology, Chinese Academy of Sciences, Beijing 100101, China

Find articles by

Xun-bing Shen

https://pubmed.ncbi.nlm.nih.gov/?term="Shen%20XB"\[Author\]

https://pubmed.ncbi.nlm.nih.gov/?term="Wu%20Q"\[Author\]

State Key Laboratory of Brain and Cognitive Science, Institute of Psychology, Chinese Academy of Sciences, Beijing 100101, China

Find articles by

https://pubmed.ncbi.nlm.nih.gov/?term="Wu%20Q"\[Author\]

Xiao-lan Fu

https://pubmed.ncbi.nlm.nih.gov/?term="Fu%20XL"\[Author\]

Xiao-lan Fu

State Key Laboratory of Brain and Cognitive Science, Institute of Psychology, Chinese Academy of Sciences, Beijing 100101, China

Find articles by

Xiao-lan Fu

https://pubmed.ncbi.nlm.nih.gov/?term="Fu%20XL"\[Author\]

Author information

Article notes

Copyright and License information

State Key Laboratory of Brain and Cognitive Science, Institute of Psychology, Chinese Academy of Sciences, Beijing 100101, China

Corresponding Author

†E-mail: fuxl@psych.ac.cn

Received 2011 Mar 2; Accepted 2011 Aug 29.

Copyright © Zhejiang University and Springer-Verlag Berlin Heidelberg 2012

PMC Copyright notice

https://pmc.ncbi.nlm.nih.gov/about/copyright/

#### PMCID: PMC3296074 PMID:

https://pubmed.ncbi.nlm.nih.gov/22374615/

Objective: The purpose of this study was to investigate the effects of the duration of expressions on the recognition of microexpressions, which are closely related to deception. Methods: In two experiments, participants were briefly (from 20 to 300 ms) shown one of six basic expressions and then were asked to identify the expression. Results: The results showed that the participants' performance in recognition of microexpressions increased with the duration of the expressions, reaching a turning point at 200 ms before levelling off. The results also indicated that practice could improve the participants' performance. Conclusions: The results of this study suggest that the proper upper limit of the duration of microexpressions might be around 1/5 of a second and confirmed that the ability to recognize microexpressions can be enhanced with practice.

Duration of expressions, Microexpressions, Microexpression training tool (METT)

1. Introduction

During interpersonal communication, it is important to be aware of others' emotions (Matsumoto et al.,

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/#B25

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/#B9

). As a Chinese saying goes, “Look at the weather when you step out; look at men's faces when you step in.” However, not everyone shows their feelings on their faces. Some individuals may suppress true emotion and express a false facial expression. There are also some situations in which social norms force people to conceal, mask, or inhibit true feelings in ways depending on politeness, context, culture or their status (Ekman,

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/#B6

). Fortunately, the suppressed expressions can be expressed subconsciously in the form of microexpressions and therefore can be detected by a skilled observer (Ekman and Friesen,

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/#B12

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/#B11

A microexpression is a brief and subtle facial movement which usually lasts for from 1/25 to 1/5 of a second revealing an emotion a person is trying to conceal (Ekman and Friesen,

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/#B12

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/#B7

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/#B9

). It expresses one of the six universal emotions: disgust, anger, fear, sadness, happiness, and surprise. This kind of facial expression usually occurs in high stake situations, where people have something valuable to gain or lose (Ekman et al.,

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/#B17

). According to Ekman et al. (

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/#B17

), a microexpression is considered to reflect a human's real intent, especially one of a hostile nature. A microexpression, therefore, can be an essential behavioral clue for lie detection and can be employed as a means of detecting a dangerous demeanor (Metzinger,

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/#B28

; Schubert,

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/#B34

; Weinberger,

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/#B38

). Some extreme actions like terrorist attacks around the world necessitate the use of various technologies to detect dangerous individuals and prevent such actions. Analysis of microexpressions was found to be a suitable approach (Weinberger,

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/#B38

Haggard and Isaacs (

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/#B19

) first discovered microexpressions which they termed “micromomentary” expressions, and Paul EKMAN then formally named them microexpressions (Ekman and Friesen,

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/#B12

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/#B8

). Today, there are two main research groups in this field: one led by Paul EKMAN and including Mark G. FRANK and Maureen O′SULLIVAN, and another led by Porter (Porter and ten Brinke,

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/#B31

). Although few peer-reviewed studies about microexpressions have been published (Porter and ten Brinke,

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/#B31

; Vrij et al.,

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/#B35

; Matsumoto and Hwang,

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/#B24

), applications of microexpressions seem to be booming in the USA (Hoffman,

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/#B20

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/#B27

A microexpression and a macroexpression differ only in their duration (Ekman and Friesen,

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/#B12

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/#B7

). However, there have been at least six estimates of the duration of a microexpression: (1) “A micro expression flashes on and off the face in less than one-quarter of a second” (Ekman,

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/#B7

); (2) “Microexpressions (that last 1/3 sec. or less)” (Ekman and Rosenberg,

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/#B15

); (3) “They last for less than half a second” (Frank et al.,

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/#B18

); “Microexpressions are extremely quick facial expressions of emotion that appear on the face for less than 1/2 a s” (Matsumoto and Hwang,

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/#B24

); (4) “Microexpressions (1/25–1/5 of a second)” (Porter and ten Brinke,

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/#B31

), and “perhaps expressions last well under a second-perhaps 1/5 to 1/25 of a second” (Ekman and Friesen,

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/#B14

); (5) “The duration of a microexpression is from 1/3 to 1/25 seconds” (Polikovsky et al.,

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/#B30

); (6) “Participants were shown images for durations in the range of microexpressions (15 ms and 30 ms)” (Clark et al.,

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/#B3

). Thus, there is a lack of consensus about the time range of the duration of a microexpression. The difference in duration might not be large, but for a fleeting thing like a microexpression, the difference should be taken into account. Therefore, the appropriate upper and lower limits of duration of microexpressions should be clarified. For this purpose, we can ask participants in a study to distinguish between microexpressions and macroexpressions, which differ only in terms of duration (the former are short; the latter are long). Supposing that the accuracy of recognizing a microexpression is equal to that of recognizing a macroexpression of longer duration, for the participants there should be no difference between microexpressions and macroexpressions even when they are of different durations (for example, they may think that 1 s happiness is the same as 3 s happiness). Then why bother to use a different name for the same thing (i.e., why not call the happiness of 1 s and 3 s the same macroexpression)? We can use the duration at and beyond which the accuracy of recognition of a microexpression is not significantly different from that of a macroexpression as the critical time point to distinguish a microexpression from a macroexpression, and this duration can be regarded as a proper upper limit of duration of microexpressions.

Based on the hypothesis of level of processing (Craik and Lockhart,

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/#B5

), we can say that the longer is the duration of expression, the deeper is the processing, and therefore the higher is the accuracy of recognition. Thus, according to this hypothesis and the analysis above, for microexpressions of different durations, there should be a turning point after which there will be no significant difference between the recognition accuracy of a microexpression and a macroexpression (where the level of processing for a microexpression is not different from that of a macroexpression). Thus, after that time point, there will be a plateau phase of recognition accuracy in which it would be meaningless to differentiate microexpressions from macroexpressions. Therefore, we take this point as an upper limit for microexpressions. The lower limit of duration of microexpressions should be determined by physiological constraints (how fast the facial muscles can make a complete expression) and the threshold of conscious perception (how long an expression must last for people to consciously perceive it).

Ekman and Friesen (

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/#B13

) developed a test called the brief affect recognition test (BART), in which one of the six emotions (happiness, disgust, anger, fear, surprise, and sadness) was presented for 1/100th to 1/25th of a second (it was processed subconsciously). In the present study, we employed this paradigm, which we called the BART condition, to measure a person's ability to recognize brief expressions. According to Matsumoto et al. (

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/#B25

), this test has the drawback of producing afterimages that affect judgments and reduce the ecological validity of the test (it is unlike real life because there are no preceding or following expressions). In 2003, Ekman (

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/#B10

) published a microexpression training tool (METT), in which he eliminated these defects by inserting an expression between two neutral expressions. We also employed this paradigm, which we called the METT paradigm.

To our knowledge, there has been no empirical research that compares the two paradigms. We think that there should be an empirical test to find out whether they differ significantly. If participants respond identically to the two paradigms (e.g., in terms of the accuracy of recognition), then there is no need to add two neutral images. However, if they respond differently, then it would be important to find out whether the responses differ at all levels of duration of microexpressions or only at shorter levels of duration. And if the latter was the case, then it would be important to determine how short a duration is required to cause a difference in response. In addition, Warren et al. (

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/#B37

) noted that there has been no valid study of the METT. Thus, it is necessary to validate the METT paradigm and compare it with a good reliability and validity test such as BART, which can be used as a valid criterion for evaluating METT. Therefore, we employed the two paradigms in our study. However, the main aims of this study were to investigate the effect of the duration of expressions on the recognition ability of fleeting expressions (microexpressions) and to determine a proper upper limit of the duration of microexpressions.

2. Experiment 1

To find out how the duration of expressions may affect the recognition of microexpressions, we conducted an experiment in which the duration of exposure to expression pictures was 40, 120, 200, or 300 ms. We employed the two paradigms mentioned above.

## Materials and methods

### Participants

Eleven healthy university students (seven females, four males, mean age 23.55 years, standard deviation (SD) 1.75 years) attended the experiment and received 20 CNY for their participation. All the participants reported normal or corrected-to-normal vision. None was aware of the purpose of the experiment.

### Materials and procedure

A Lenovo computer with a 17-inch cathode-ray tube (CRT) monitor running at a refresh rate of 85 Hz and the software package E-Prime (version 1.1) were used for stimuli presentation and data collection.

The target stimuli were pictures of six basic expressions posed by two human models which were selected from the DFAT-504 database (Kanade et al.,

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/#B22

) and trimmed to 192 pixels×220 pixels. All stimuli were presented on a uniform silver gray background, which remained silver gray throughout the experiment. Before the formal experiment, there were two practice runs. Each run contained six pictures of facial expressions including happiness, disgust, anger, fear, sadness, and surprise. Each picture was presented on the screen for 2 s. Participants were asked to identify each expression by selecting from among the six emotional labels. After giving their answers, participants were given feedback to inform them of the correct answer or to confirm a correct answer. At the end of each practice run, the program reported the total accuracy rate. The program would not continue until the accuracy rate of recognition of microexpressions reached 100%.

Errors made by the participants had two sources: first, that the participants did not recognize the expression shown in the picture, or second, that they did not fully process the pictures during the brief exposure time. The practice runs eliminated the first possibility. After recognition practice, two experimental conditions (the BART and METT paradigm conditions) were tested.

In the BART condition, a “+” as the fixation appeared at the center of the computer monitor screen for 1 s; then one of the six basic expressions was presented in the center of the screen for 40, 120, 200, or 300 ms. Participants were asked to select one of the six emotional labels using a mouse. Under the condition of the METT paradigm, a neutral expression was first presented in the center of the screen for 2 s. Then one of the six basic expressions flashed briefly for 40, 120, 200, or 300 ms. Exposures of from 40 to 200 ms are deemed to be microexpressions (Ekman,

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/#B9

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/#B11

). Finally, the neutral expression was presented for another 2 s. At the end of the presentation the participants had to identify the fleeting expression by selecting one of the six emotional labels.

After the practice runs involving recognizing the two models' expressions, twelve trials were run without feedback on accuracy to familiarize the participants with the formal experimental procedures. Then, the formal experiments were run with the two conditions (BART and METT, blocked). No feedback was given during each formal experiment. Each of the two formal experimental blocks consisted of 384 trials (4 durations×2 models×6 basic emotions×8 replicates).

## Results

A 2 conditions (BART and METT paradigm)×4 durations (40, 120, 200, and 300 ms)×6 expressions (disgust, anger, fear, sadness, happiness, and surprise) repeated measures analysis of variance (ANOVA) was conducted with the participants' accuracy score (%) entered as the dependent variable.

The mean accuracies of the two conditions are shown in Fig.

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/#F1

. The main effect of condition was not significant \[

(1, 10)=0.962,

=0.088\]. There was a significant main effect for duration \[

(3, 30)=109.027,

=0.916\]. The main effect of expression type was also significant \[

(5, 50)=8.698,

=0.465\]. The interactions of condition and duration, and duration and expression type were significant \[

(3, 30)=18.795,

(15, 150)=2.076,

=0.172\]. All other effects were not significant. The accuracy of recognition of expressions increased as the duration increased and the curve leveled off after a duration of 200 ms (Fig.

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/#F1

). A post-hoc pairwise comparison of the four levels of duration showed that the participants' performance showed no significant difference only between the durations of 200 and 300 ms (

=0.444; all other

<0.01). Furthermore, we tested the effect of condition separately at each duration level to find out the difference between the two conditions. The only significant effect was found at 40 ms duration (

=0.006, all other

Open in a new tab

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/figure/F1/

Mean accuracy for the BART condition and METT paradigm as a function of duration

Chance performance is 16.7% (1/6)

To investigate the degree to which the participants could recognize the six expressions, a confusion matrix of recognition of the six expressions was calculated (Table

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/#T1

), which collapsed across the conditions of BART and METT. For the purpose of exploring the accuracy of each expression at each of the four levels of duration, the detailed accuracy data are given in Table

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/#T2

Confusion matrix of the recognition of microexpressions in Experiment 1

| Expression | Mean answer rate (%) ||||||

| ^^ | Happiness | Disgust | Anger | Fear | Surprise | Sadness |

| --- | --- | --- | --- | --- | --- | --- |

| Happiness | 86.8

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/#T1FN1

| 2.1 | 1.3 | 7.7 | 3.3 | 1.8 |

| Disgust | 2.7 | 69.9

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/#T1FN1

| 21.4 | 8.4 | 4.2 | 19.0 |

| Anger | 1.1 | 13.4 | 63.8

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/#T1FN1

| 2.9 | 1.1 | 9.6 |

| Fear | 3.6 | 6.1 | 4.0 | 57.0

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/#T1FN1

| 7.3 | 5.8 |

| Surprise | 5.0 | 2.8 | 2.9 | 13.2 | 82.7

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/#T1FN1

| Sadness | 0.8 | 5.8 | 6.5 | 10.8 | 1.4 | 58.2

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/#T1FN1

Open in a new tab

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/table/T1/

The number in the diagonal line is the mean accuracy rate of recognition of each expression which collapsed across the conditions of BART and METT

Accuracy of recognition of each expression under two conditions (BART and METT paradigm) in Experiment 1

| Expression | Accuracy of recognition (%) ||||||||||

| ^^ | BART ||||| | METT paradigm ||||

| ^^ | 40 ms | 120 ms | 200 ms | 300 ms | Average

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/#T2FN1

| 40 ms | 120 ms | 200 ms | 300 ms | Average

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/#T2FN1

| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |

| Happiness | 89.3 | 89.3 | 93.8 | 94.9 | 91.8 | 69.4 | 80.9 | 85.9 | 91.5 | 81.9 |

| Disgust | 64.8 | 72.7 | 72.9 | 71.6 | 70.5 | 57.5 | 75.1 | 74.0 | 71.1 | 69.4 |

| Anger | 60.9 | 62.0 | 69.9 | 67.1 | 65.0 | 35.3 | 64.9 | 76.3 | 74.5 | 62.8 |

| Fear | 43.3 | 55.2 | 58.2 | 55.2 | 53.0 | 44.0 | 64.5 | 67.2 | 69.5 | 61.3 |

| Surprise | 83.6 | 85.9 | 87.1 | 92.8 | 87.4 | 60.3 | 78.5 | 85.9 | 88.1 | 78.2 |

| Sadness | 54.1 | 63.8 | 60.4 | 68.2 | 61.6 | 45.0 | 54.7 | 55.8 | 64.8 | 55.1 |

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/#T2FN1

| 66.0 | 71.5 | 73.7 | 75.0 | | 51.9 | 69.8 | 74.2 | 76.6 | |

Open in a new tab

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/table/T2/

The average numbers are recognition accuracy scores which are averaged by durations (columns) or expressions (rows)

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/#T1

, the accuracy of recognition of expressions of each participant was computed by calculating the ratio of the cases in which one facial expression was classified correctly as one of the six expressions and the total number of classifications for that facial expression. Then, the accuracy rates of all participants were averaged to gain the mean accuracy for each expression. For instance, in this experiment the number of times that one participant labeled the facial expression 'happiness' correctly (122) was divided by the total number of classifications for that facial expression (128). So, the recognition accuracy for happiness for this participant was 95.3%, and so on. Finally, the accuracy rates of all participants were averaged to give the mean accuracy of 86.8% for 'happiness' in Experiment 1. The percentages in the diagonal line are the mean accuracies of recognition for each expression across the two conditions.

## Discussion

This experiment investigated the effects of the duration of expressions on the recognition of microexpressions. In contrast to general “macroexpressions”, the participants' performance was impaired by the short duration of the microexpressions. As their performance showed no significant difference only after durations of 200 and 300 ms, the duration of 200 ms appeared to be a critical turning point in defining microexpressions.

The participants showed confusion between anger and disgust, fear and surprise, and sadness and disgust (Table

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/#T1

). Happiness was rarely mistaken for other expressions and therefore was the easiest expression to recognize, while anger and fear were distinguished relatively poorly (Tables

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/#T1

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/#T2

3. Experiment 2

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/#B11

) reported that if people had as little as 40 min of microexpression training, they could, on average, improve their performance from about 30% to 40% from the pretest to the posttest in an METT test. In Experiment 2, to test the effects of practice and to find out whether people would still be able to identify microexpressions when the presentation duration was below the lower limit of the duration of microexpressions as defined by Ekman and Friesen (

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/#B14

), the participants were required to achieve 100% accuracy in two consecutive runs during a practice session to ensure intensive practice and recognition of expressions presented for 20 ms.

Moreover, the experiment aimed to further test the effects of the duration of expressions on the performance of recognition of microexpressions and to find the proper upper limit of microexpressions. Eight levels of duration (20, 40, 80, 120, 160, 200, 240, and 280 ms) were employed in this experiment.

## Materials and methods

### Participants

Another twelve healthy university students attended the experiments and each received 20 CNY for their participation. Participants (eight females, four males) had a mean age of 22.67 years (SD=3.03 years). All the participants reported normal or corrected-to-normal vision. None reported being aware of the purpose of the experiment.

### Materials and procedure

The materials and the procedures were similar to those used in Experiment 1, except for the following changes. Two different models' (one male and one female) six basic expressions were used and the practice of expression recognition did not cease until participants had correctly identified all six basic expressions in two consecutive runs (once classification accuracy reached 100%, the program did not proceed to the next run immediately but repeated the previous run to eliminate the possibility of a correct guess). In addition, to make the practice more intensive, a block of mixed recognition practice was added, in which the two models' expressions were mixed. Only when the participants had achieved 100% recognition of the model's six expressions in two successive runs would the program advance. In both the BART and METT paradigm conditions, the levels of duration of the six basic expressions were changed to eight levels: 20, 40, 80, 120, 160, 200, 240, and 280 ms.

## Results

The mean accuracies of the two conditions are shown in Fig.

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/#F2

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/#T3

. A 2 conditions×8 durations×6 expressions repeated measures ANOVA was used to analyze the data. Each of the factors and the combination of factors had significant effects. There were significant main effects for condition, duration, and expression type \[

(1, 11)=51.932,

(7, 77)=104.416,

(5, 55)=13.022,

=0.542\]. The interactions between condition and duration, condition and expression type, duration and expression type, and the second-order interaction were also significant \[

(7, 77)=69.679,

(5, 55)=4.578,

(35, 385)=4.358,

(35, 385)=3.224,

=0.227\]. The method of pairwise comparisons was used for the eight levels of duration. The results indicated that there were no significant differences between pairs of levels of duration after 160 ms (including 160 ms, all

>0.455). Furthermore, the simple effect analysis for the effect of duration in the BART condition showed that there were only two significant effects for pairs of 20 and 240 ms (

=0.024), and 40 and 240 ms (

=0.003). An analysis of simple effects of duration in the condition of the METT paradigm revealed no significant differences in pairs of duration after 120 ms (all

>0.147). A simple effect analysis was also employed to investigate the effect of condition within each level of duration. There were significant simple effects before 160 ms (all

<0.02), and no significant differences at 200, 240, or 280 ms (all

>0.139). The two curves (BART and METT) were almost superimposed at 200, 240, and 280 ms (Fig.

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/#F2

Open in a new tab

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/figure/F2/

Mean accuracy for the BART and METT paradigm conditions across durations

Chance performance is 16.7% (1/6)

Accuracy of recognition of each expression under two conditions (BART and METT paradigm) in Experiment 2

| Expression | Accuracy of recognition (%) |||||||||

| ^^ | 20 ms | 40 ms | 80 ms | 120 ms | 160 ms | 200 ms | 240 ms | 280 ms | Average

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/#T3FN1

| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |

| Happiness | 98.0 | 98.0 | 97.9 | 99.0 | 99.0 | 96.0 | 100.0 | 98.0 | 98.2 |

| Disgust | 85.6 | 93.8 | 97.9 | 92.8 | 97.0 | 96.9 | 95.0 | 95.0 | 94.3 |

| Anger | 73.1 | 69.9 | 80.4 | 85.7 | 86.6 | 83.4 | 86.6 | 84.6 | 81.3 |

| Fear | 74.1 | 82.6 | 82.5 | 87.7 | 88.8 | 86.6 | 96.0 | 88.7 | 85.9 |

| Surprise | 99.0 | 98.0 | 98.0 | 96.9 | 98.0 | 99.0 | 100.0 | 99.0 | 98.5 |

| Sadness | 82.5 | 81.3 | 87.8 | 90.8 | 95.8 | 90.8 | 92.8 | 93.9 | 89.5 |

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/#T3FN1

| 85.4 | 87.3 | 90.8 | 92.2 | 94.2 | 92.1 | 95.1 | 93.2 |

METT paradigm

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/#T3FN1

Open in a new tab

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/table/T3/

The average numbers are recognition accuracy scores which are averaged across durations (columns) or expressions (rows)

To explore the effects of practice, we compared the results from the two conditions in Experiments 1 and 2 (Fig.

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/#F3

). Under the condition of the METT paradigm, the accuracy rates for the levels of 20 ms (Experiment 2) and 40 ms (Experiments 1 and 2) were compared with the accuracy expected by chance, which was 1/6 (if the participants did not recognize anything, they would by chance obtain the correct answer one in six times simply by guessing one of the six expressions). An independent sample

-test was employed to calculate the values of

for the difference between the means for each of the three accuracy levels and the accuracy expected by chance. The results showed all the comparisons were significant \[

(11)=8.349,

(10)=5.022,

(11)=20.638,

Open in a new tab

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/figure/F3/

Accuracy of recognition of microexpressions as a function of the duration of expressions in Experiments 1 and 2 under the two corresponding conditions

(a) BART condition; (b) METT paradigm condition

## Discussion

Again, the duration of expressions had significant effects on the recognition of microexpressions. Furthermore, the participants' performance improved with practice (Fig.

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/#F3

). However, the increasing trends did not differ between the conditions of the two experiments. The results also showed that, with considerable practice, participants could identify microexpressions even when the duration of expressions was below the lower limit of microexpressions as defined by Ekman (40 ms). The results suggest that the perception of human facial expression information is very fast and can be tuned by experience. The pattern of recognition accuracy found in this experiment was similar to that found by Matsumoto et al. (

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/#B25

). However, the accuracy of participants in our study was much higher, perhaps because we employed fewer models (two). In general, the expression of surprise was the easiest to recognize, followed by that of happiness. Fear was the most difficult expression to recognize. These results were similar to those of McAndrew (

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/#B26

It could be argued that our experiments employed pictures of small size which resulted in poor performance in recognizing the expressions. However, there is evidence to suggest that image size does not affect the recognition of expressions (Ekman et al.,

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/#B16

4. General discussion

We explored mainly the upper limit of duration of microexpressions. In both experiments, the duration of the expressions affected the recognition of the microexpressions. Training in recognizing expressions also played an important role in the identification of the microexpressions. The results indicated that there was a turning point at 200 ms in Experiment 1 and at 160 ms in Experiment 2, suggesting that the critical time point differentiating microexpressions from macroexpressions was about 200 ms and most likely less than 200 ms.

The results showed that there was a large difference in the accuracy of recognition of microexpressions between the conditions of BART and METT, particularly at short durations (40 ms in Experiment 1 and less than 160 ms in Experiment 2). The reason may lie in the neutral image under the condition of METT, which played the role of a mask, preventing the fleeting expression from remaining on the retina. Thus, for a short duration, the processing of microexpressions could be more impaired by a mask (the neutral images) under the condition of METT paradigm, compared to the condition of BART without a mask. With an increase in duration, the effects of afterimage of a brief expression may decrease (Breitmeyer and Ogmen,

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/#B2

) and the information of the microexpression may already be transferred to more durable memory storage. Thus, the mask may then have little effect on the processing of microexpressions under the condition of the METT paradigm. Consequently, the performance under the two conditions showed no significant difference when the duration of the microexpressions was longer. The simple effect analysis showed that the two conditions were different only after a short exposure (40 ms) when there had been no extensive practising (in Experiment 1). When the extent of practice was increased (in Experiment 2), the difference between the two conditions persisted until 160 ms, suggesting that adding two neutral images, one before and one after the microexpression, was necessary when the duration was short. Thus, for the purpose of testing the ability to recognize microexpressions with a duration of less than 200 ms, the METT paradigm was appropriate because it was more sensitive to the change of duration which was the only difference between microexpressions and macroexpressions (it also had a wider range of accuracy).

The ability to identify microexpressions is related to the detection of deception. The main aim of microexpression studies is to find indicators of deception via microexpressions. Unfortunately, evidence about the link between microexpressions and deception is far from conclusive. However, microexpressions may be the most promising approach to detecting deception (Ekman,

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/#B11

). According to Weinberger (

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/#B38

), the Transportation Security Administration in the USA has already employed a technique called screening passengers by observation techniques (SPOT) which is largely based on the findings from microexpression research. The U.S. Department of Defense has funded David MASUMOTO, a longtime collaborator with Paul EKMAN, in his work on microexpressions, for what he calls “behavior-detection techniques” (Mervis,

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/#B27

). Now there are at least 3 000 behavior detection officers deployed at 161 airports in USA (Lord,

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/#B23

). Frank et al. (

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/#B18

) pointed out that there is a physiological basis for microexpressions: a pyramidal motor system drives voluntary facial actions and an extrapyramidal motor system drives the more involuntary and emotional facial actions \[which can also be viewed as the physiological basis of the Darwin's inhibition hypothesis (Porter and ten Brinke,

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/#B31

)\]. Thus, it is reasonable to regard the analysis of microexpressions as a useful and promising tool for detecting deception.

There has been some debate and criticism about microexpression analysis and its applications (Committee on Science, Space and Technology,

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/#B4

). First, many scientists have argued that microexpressions and their applications have not been subjected to controlled scientific tests (Lord,

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/#B23

; Vrij et al.,

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/#B35

; Weinberger,

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/#B38

). Empirical studies are needed to establish the validation for linking microexpressions to deception. Also, the application of microexpressions to airport security is not very effective as less than 1% of suspects have subsequently been arrested (Weinberger,

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/#B38

). An appropriate attitude to microexpressions may be similar to that proposed by Porter and ten Brinke (

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/#B32

), who concluded that nonverbal cues can only assist investigators to detect deception.

Many aspects of microexpressions need to be elucidated in the future including the lower limit, individual differences in expression and recognition of microexpressions (Bond and DePaulo,

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/#B1

; O′Sullivan et al.,

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/#B29

; Wang and Fu,

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/#B36

; Warren et al.,

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/#B37

), effective methods of training and the retention of training effects (Hurley,

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/#B21

; Matsumoto and Hwang,

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/#B24

), and automatic brief facial expression analysis systems (Polikovsky et al.,

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/#B30

; Wu et al.,

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/#B39

). As for individual differences, in groups closely related to deception detection, such as crime interrogators, national security personnel, visa interviewers, sales personnel, negotiators, and mental health professionals, the expression and recognition of microexpressions might not be the same as for other people. While microexpressions have some valuable applications in the field of security, they may also have applications in healthcare and forensic contexts (Porter et al.,

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/#B33

). To use microexpressions widely, it is important to design and develop an automatic brief facial expression analysis system in the field of computer vision to aid trained or untrained people to detect microexpressions and improve hit rates. The questions and debates about microexpressions can be solved by conducting much more empirical research which will fill the gap between knowledge (production features, dynamic features, recognition of microexpressions filmed in real life situations, etc.) and applications (e.g. aviation security), and establish a more stable connection between microexpressions and deception (the main purpose of studies on microexpressions).

In conclusion, this study explored the upper limit of duration of microexpressions and had two major findings. Firstly, to some degree, a short training program can improve lay individuals' ability to recognize microexpressions. Secondly, the accuracy of recognition of microexpressions is a function of the duration of the expressions and reaches a turning point at 200 ms (perhaps less than 200 ms) and then levels off, suggesting that the proper upper limit of duration of microexpressions may be around 1/5 of a second. Much more research is needed to move towards a more complete understanding of microexpressions.

Acknowledgments

The authors wish to express sincere appreciation to Dr. Bo WANG (Department of Psychology, Central University of Finance and Economics, Beijing, China), Ke-ren LI SHEN, and Christopher KAUSCH (Jacobs University Bremen, Germany) for their assistance with English language editing.

Project partially supported by the National Basic Research Program (973) of China (No. 2011CB302201) and the National Natural Science Foundation of China (No. 61075042)

Bond CF, Jr, DePaulo BM. Individual differences in judging deception: accuracy and bias. Psychol Bull. 2008;134(4):477–492. doi: 10.1037/0033-2909.134.4.477. \[

https://doi.org/10.1037/0033-2909.134.4.477

https://pubmed.ncbi.nlm.nih.gov/18605814/

Google Scholar

https://scholar.google.com/scholar\_lookup?journal=Psychol%20Bull&title=Individual%20differences%20in%20judging%20deception:%20accuracy%20and%20bias&author=CF%20Bond&author=BM%20DePaulo&volume=134&issue=4&publication\_year=2008&pages=477-492&pmid=18605814&doi=10.1037/0033-2909.134.4.477&

Breitmeyer B, Ogmen H. Visual Masking: Time Slices Through Conscious and Unconscious Vision. New York, USA: Oxford University Press; 2006. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Visual%20Masking:%20Time%20Slices%20Through%20Conscious%20and%20Unconscious%20Vision&author=B%20Breitmeyer&author=H%20Ogmen&publication\_year=2006&

Clark T, Winkielman P, McIntosh D. Autism and the extraction of emotion from briefly presented facial expressions: stumbling at the first step of empathy. Emotion. 2008;8(6):803–809. doi: 10.1037/a0014124. \[

https://doi.org/10.1037/a0014124

https://pubmed.ncbi.nlm.nih.gov/19102591/

Google Scholar

https://scholar.google.com/scholar\_lookup?journal=Emotion&title=Autism%20and%20the%20extraction%20of%20emotion%20from%20briefly%20presented%20facial%20expressions:%20stumbling%20at%20the%20first%20step%20of%20empathy&author=T%20Clark&author=P%20Winkielman&author=D%20McIntosh&volume=8&issue=6&publication\_year=2008&pages=803-809&pmid=19102591&doi=10.1037/a0014124&

Committee on Science, Space and Technology. Behavioral Science and Security: Evaluating TSA's SPOT Program. 2011. \[June 1, 2011\]. Available from

http://democrats.science.house.gov/hearing/behavioral-science-and-security-evaluating-tsa%E2%80%99s-spot-program

http://democrats.science.house.gov/hearing/behavioral-science-and-security-evaluating-tsa%E2%80%99s-spot-program

Craik FIM, Lockhart RS. Levels of processing: a framework for memory research. J Verb Learn Verb Behav. 1972;11(6):671–684. doi: 10.1016/S0022-5371(72)80001-X. \[

https://doi.org/10.1016/S0022-5371(72)80001-X

Google Scholar

https://scholar.google.com/scholar\_lookup?journal=J%20Verb%20Learn%20Verb%20Behav&title=Levels%20of%20processing:%20a%20framework%20for%20memory%20research&author=FIM%20Craik&author=RS%20Lockhart&volume=11&issue=6&publication\_year=1972&pages=671-684&doi=10.1016/S0022-5371(72)80001-X&

Ekman P. Universals and Cultural Differences in Facial Expressions of Emotion. In: Cole J, editor. Nebraska Symposium on Motivation. Vol. 19. Lincoln, USA: University of Nebraska Press; 1972. pp. 207–283. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Nebraska%20Symposium%20on%20Motivation&author=P%20Ekman&publication\_year=1972&

Ekman P. Telling Lies: Clues to Deceit in the Marketplace, Marriage, and Politics. 3rd Ed. New York, USA: W.W. Norton; 2001. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Telling%20Lies:%20Clues%20to%20Deceit%20in%20the%20Marketplace,%20Marriage,%20and%20Politics&author=P%20Ekman&publication\_year=2001&

Ekman P. Darwin, deception, and facial expression. Ann N Y Acad Sci. 2003;1000(1):205–221. doi: 10.1196/annals.1280.010. \[

https://doi.org/10.1196/annals.1280.010

https://pubmed.ncbi.nlm.nih.gov/14766633/

Google Scholar

https://scholar.google.com/scholar\_lookup?journal=Ann%20N%20Y%20Acad%20Sci&title=Darwin,%20deception,%20and%20facial%20expression&author=P%20Ekman&volume=1000&issue=1&publication\_year=2003&pages=205-221&pmid=14766633&doi=10.1196/annals.1280.010&

Ekman P. Emotions Revealed: Recognizing Faces and Feelings to Improve Communication and Emotional Life. New York, USA: Times Books; 2003. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Emotions%20Revealed:%20Recognizing%20Faces%20and%20Feelings%20to%20Improve%20Communication%20and%20Emotional%20Life&author=P%20Ekman&publication\_year=2003&

Ekman P. MicroExpression Training Tool (METT) 2003. \[June 1, 2011\]. Available from

http://www.paulekman.com/micros

http://www.paulekman.com/micros

Ekman P. Lie Catching and Microexpressions. In: Martin C, editor. The Philosophy of Deception. New York, USA: Oxford University Press; 2009. pp. 118–133. \[

https://doi.org/10.1093/acprof:oso/9780195327939.003.0008

Google Scholar

https://scholar.google.com/scholar\_lookup?title=The%20Philosophy%20of%20Deception&author=P%20Ekman&publication\_year=2009&

Ekman P, Friesen W. Nonverbal leakage and clues to deception. Psychiatry. 1969;32(1):88–106. doi: 10.1080/00332747.1969.11023575. \[

https://doi.org/10.1080/00332747.1969.11023575

https://pubmed.ncbi.nlm.nih.gov/5779090/

Google Scholar

https://scholar.google.com/scholar\_lookup?journal=Psychiatry&title=Nonverbal%20leakage%20and%20clues%20to%20deception&author=P%20Ekman&author=W%20Friesen&volume=32&issue=1&publication\_year=1969&pages=88-106&pmid=5779090&doi=10.1080/00332747.1969.11023575&

Ekman P, Friesen W. Nonverbal Behavior and Psychopathology. In: Friedman RJ, Katz HM, editors. The Psychology of Depression: Contemporary Theory and Research. New York: Wiley; 1974. pp. 203–224. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=The%20Psychology%20of%20Depression:%20Contemporary%20Theory%20and%20Research&author=P%20Ekman&author=W%20Friesen&publication\_year=1974&

Ekman P, Friesen WV. Unmasking the Face. New Jersey, USA: Prentice Hall; 1975. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Unmasking%20the%20Face&author=P%20Ekman&author=WV%20Friesen&publication\_year=1975&

Ekman P, Rosenberg EL. What the Face Reveals: Basic and Applied Studies of Spontaneous Expression Using the Facial Action Coding System (FACS) New York, USA: Oxford University Press; 2005. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=What%20the%20Face%20Reveals:%20Basic%20and%20Applied%20Studies%20of%20Spontaneous%20Expression%20Using%20the%20Facial%20Action%20Coding%20System%20(FACS)&author=P%20Ekman&author=EL%20Rosenberg&publication\_year=2005&

Ekman P, Brattesani K, O′Sullivan M, Friesen W. Does image size affect judgments of the face? J Nonverb Behav. 1979;4(1):57–61. doi: 10.1007/BF00986913. \[

https://doi.org/10.1007/BF00986913

Google Scholar

https://scholar.google.com/scholar\_lookup?journal=J%20Nonverb%20Behav&title=Does%20image%20size%20affect%20judgments%20of%20the%20face?&author=P%20Ekman&author=K%20Brattesani&author=M%20O%E2%80%B2Sullivan&author=W%20Friesen&volume=4&issue=1&publication\_year=1979&pages=57-61&doi=10.1007/BF00986913&

Ekman P, Rolls E, Perrett D, Ellis H. Facial expressions of emotion: an old controversy and new findings: discussion. Philos Trans R Soc Lond B Biol Sci. 1992;335(1273):63–69. doi: 10.1098/rstb.1992.0008. \[

https://doi.org/10.1098/rstb.1992.0008

https://pubmed.ncbi.nlm.nih.gov/1348139/

Google Scholar

https://scholar.google.com/scholar\_lookup?journal=Philos%20Trans%20R%20Soc%20Lond%20B%20Biol%20Sci&title=Facial%20expressions%20of%20emotion:%20an%20old%20controversy%20and%20new%20findings:%20discussion&author=P%20Ekman&author=E%20Rolls&author=D%20Perrett&author=H%20Ellis&volume=335&issue=1273&publication\_year=1992&pages=63-69&pmid=1348139&doi=10.1098/rstb.1992.0008&

Frank MG, Maccario CJ, Govindaraju V. Behavior and Security. In: Paul Seidenstat FXS, editor. Protecting Airline Passengers in the Age of Terrorism. Santa Barbara, California: Greenwood Pub Group; 2009. pp. 86–106. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Protecting%20Airline%20Passengers%20in%20the%20Age%20of%20Terrorism&author=MG%20Frank&author=CJ%20Maccario&author=V%20Govindaraju&publication\_year=2009&

Haggard EA, Isaacs KS. Micro-momentary Facial Expressions as Indicators of Ego Mechanisms in Psychotherapy. In: Gottschalk LA, Auerbach AH, editors. Methods of Research in Psychotherapy. New York: Appleton-Century-Crofts; 1966. pp. 154–165. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Methods%20of%20Research%20in%20Psychotherapy&author=EA%20Haggard&author=KS%20Isaacs&publication\_year=1966&

Hoffman J. Exhibition: how faces share feelings. Nature. 2008;452(7186):413. doi: 10.1038/452413a. \[

https://doi.org/10.1038/452413a

Google Scholar

https://scholar.google.com/scholar\_lookup?journal=Nature&title=Exhibition:%20how%20faces%20share%20feelings&author=J%20Hoffman&volume=452&issue=7186&publication\_year=2008&pages=413&doi=10.1038/452413a&

Hurley CM. The Effects of Motivation and Training Format on the Ability to Detect Hidden Emotions. New York, USA: State University of New York at Buffalo; 2010. PhD Thesis. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=The%20Effects%20of%20Motivation%20and%20Training%20Format%20on%20the%20Ability%20to%20Detect%20Hidden%20Emotions&author=CM%20Hurley&publication\_year=2010&

Kanade T, Tian Y, Cohn J. Comprehensive Database for Facial Expression Analysis. Fourth IEEE International Conference on Automatic Face and Gesture Recognition (FG′00); Grenoble, France. 2000. pp. 484–490. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?Kanade%20T,%20Tian%20Y,%20Cohn%20J.%20Comprehensive%20Database%20for%20Facial%20Expression%20Analysis.%20Fourth%20IEEE%20International%20Conference%20on%20Automatic%20Face%20and%20Gesture%20Recognition%20(FG%E2%80%B200);%20Grenoble,%20France.%202000.%20pp.%20484%E2%80%93490.

Lord SM. Aviation Security: Efforts to Validate TSA's Passenger Screening Behavior Detection Program Underway, but Opportunities Exist to Strengthen Validation and Address Operational Challenges. PA, USA: DIANE Publishing Co.; 2010. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Aviation%20Security:%20Efforts%20to%20Validate%20TSA%E2%80%99s%20Passenger%20Screening%20Behavior%20Detection%20Program%20Underway,%20but%20Opportunities%20Exist%20to%20Strengthen%20Validation%20and%20Address%20Operational%20Challenges&author=SM%20Lord&publication\_year=2010&

Matsumoto D, Hwang H. Evidence for training the ability to read microexpressions of emotion. Motiv Emot. 2011;35(2):181–191. doi: 10.1007/s11031-011-9212-2. \[

https://doi.org/10.1007/s11031-011-9212-2

Google Scholar

https://scholar.google.com/scholar\_lookup?journal=Motiv%20Emot&title=Evidence%20for%20training%20the%20ability%20to%20read%20microexpressions%20of%20emotion&author=D%20Matsumoto&author=H%20Hwang&volume=35&issue=2&publication\_year=2011&pages=181-191&doi=10.1007/s11031-011-9212-2&

Matsumoto D, LeRoux J, Wilson-Cohn C, Raroque J, Kooken K, Ekman P, Yrizarry N, Lovewinger S, Uchida H, Yee A, et al. A new test to measure emotion recognition ability: Matsumoto and Ekman's Japanese and Caucasian Brief Affect Recognition Test (JACBART) J Nonverb Behav. 2000;24(3):179–209. doi: 10.1023/A:1006668120583. \[

https://doi.org/10.1023/A:1006668120583

Google Scholar

https://scholar.google.com/scholar\_lookup?journal=J%20Nonverb%20Behav&title=A%20new%20test%20to%20measure%20emotion%20recognition%20ability:%20Matsumoto%20and%20Ekman%E2%80%99s%20Japanese%20and%20Caucasian%20Brief%20Affect%20Recognition%20Test%20(JACBART)&author=D%20Matsumoto&author=J%20LeRoux&author=C%20Wilson-Cohn&author=J%20Raroque&author=K%20Kooken&volume=24&issue=3&publication\_year=2000&pages=179-209&doi=10.1023/A:1006668120583&

McAndrew FT. A cross-cultural study of recognition thresholds for facial expressions of emotion. J Cross-Cult Psychol. 1986;17(2):211–224. doi: 10.1177/0022002186017002005. \[

https://doi.org/10.1177/0022002186017002005

Google Scholar

https://scholar.google.com/scholar\_lookup?journal=J%20Cross-Cult%20Psychol&title=A%20cross-cultural%20study%20of%20recognition%20thresholds%20for%20facial%20expressions%20of%20emotion&author=FT%20McAndrew&volume=17&issue=2&publication\_year=1986&pages=211-224&doi=10.1177/0022002186017002005&

Mervis J. DOD funds new views on conflict with its first Minerva grants. Science. 2009;323(5914):576–577. doi: 10.1126/science.323.5914.576. \[

https://doi.org/10.1126/science.323.5914.576

https://pubmed.ncbi.nlm.nih.gov/19179505/

Google Scholar

https://scholar.google.com/scholar\_lookup?journal=Science&title=DOD%20funds%20new%20views%20on%20conflict%20with%20its%20first%20Minerva%20grants&author=J%20Mervis&volume=323&issue=5914&publication\_year=2009&pages=576-577&pmid=19179505&doi=10.1126/science.323.5914.576&

Metzinger T. Exposing lies. Sci Am Mind. 2006;17(5):32–37. doi: 10.1038/scientificamericanmind1006-32. \[

https://doi.org/10.1038/scientificamericanmind1006-32

Google Scholar

https://scholar.google.com/scholar\_lookup?journal=Sci%20Am%20Mind&title=Exposing%20lies&author=T%20Metzinger&volume=17&issue=5&publication\_year=2006&pages=32-37&doi=10.1038/scientificamericanmind1006-32&

O′Sullivan M, Frank M, Hurley C, Tiwana J. Police lie detection accuracy: the effect of lie scenario. Law Hum Behav. 2009;33(6):530–538. doi: 10.1007/s10979-008-9166-4. \[

https://doi.org/10.1007/s10979-008-9166-4

https://pubmed.ncbi.nlm.nih.gov/19242785/

Google Scholar

https://scholar.google.com/scholar\_lookup?journal=Law%20Hum%20Behav&title=Police%20lie%20detection%20accuracy:%20the%20effect%20of%20lie%20scenario&author=M%20O%E2%80%B2Sullivan&author=M%20Frank&author=C%20Hurley&author=J%20Tiwana&volume=33&issue=6&publication\_year=2009&pages=530-538&pmid=19242785&doi=10.1007/s10979-008-9166-4&

Polikovsky S, Kameda Y, Ohta Y. Facial Micro-expressions Recognition Using High Speed Camera and 3D-Gradient Descriptor. 3rd International Conference on Crime Detection and Prevention (ICDP 2009); London, UK. 2010. pp. 1–6. \[

https://doi.org/10.1049/ic.2009.0244

Google Scholar

https://scholar.google.com/scholar\_lookup?Polikovsky%20S,%20Kameda%20Y,%20Ohta%20Y.%20Facial%20Micro-expressions%20Recognition%20Using%20High%20Speed%20Camera%20and%203D-Gradient%20Descriptor.%203rd%20International%20Conference%20on%20Crime%20Detection%20and%20Prevention%20(ICDP%202009);%20London,%20UK.%202010.%20pp.%201%E2%80%936.

Porter S, ten Brinke L. Reading between the lies. Psychol Sci. 2008;19(5):508–514. doi: 10.1111/j.1467-9280.2008.02116.x. \[

https://doi.org/10.1111/j.1467-9280.2008.02116.x

https://pubmed.ncbi.nlm.nih.gov/18466413/

Google Scholar

https://scholar.google.com/scholar\_lookup?journal=Psychol%20Sci&title=Reading%20between%20the%20lies&author=S%20Porter&author=L%20ten%20Brinke&volume=19&issue=5&publication\_year=2008&pages=508-514&pmid=18466413&doi=10.1111/j.1467-9280.2008.02116.x&

Porter S, ten Brinke L. The truth about lies: what works in detecting high stakes deception? Leg Criminol Psychol. 2010;15(1):57–75. doi: 10.1348/135532509X433151. \[

https://doi.org/10.1348/135532509X433151

Google Scholar

https://scholar.google.com/scholar\_lookup?journal=Leg%20Criminol%20Psychol&title=The%20truth%20about%20lies:%20what%20works%20in%20detecting%20high%20stakes%20deception?&author=S%20Porter&author=L%20ten%20Brinke&volume=15&issue=1&publication\_year=2010&pages=57-75&doi=10.1348/135532509X433151&

Porter S, Juodis M, ten Brinke L, Klein R, Wilson K. Evaluation of the effectiveness of a brief deception detection training program. J Forensic Psychiatry Psychol. 2009;21(1):66–76. doi: 10.1080/14789940903174246. \[

https://doi.org/10.1080/14789940903174246

Google Scholar

https://scholar.google.com/scholar\_lookup?journal=J%20Forensic%20Psychiatry%20Psychol&title=Evaluation%20of%20the%20effectiveness%20of%20a%20brief%20deception%20detection%20training%20program&author=S%20Porter&author=M%20Juodis&author=L%20ten%20Brinke&author=R%20Klein&author=K%20Wilson&volume=21&issue=1&publication\_year=2009&pages=66-76&doi=10.1080/14789940903174246&

Schubert S. A look tells all. Sci Am Mind. 2006;17(5):26–31. doi: 10.1038/scientificamericanmind1006-26. \[

https://doi.org/10.1038/scientificamericanmind1006-26

Google Scholar

https://scholar.google.com/scholar\_lookup?journal=Sci%20Am%20Mind&title=A%20look%20tells%20all&author=S%20Schubert&volume=17&issue=5&publication\_year=2006&pages=26-31&doi=10.1038/scientificamericanmind1006-26&

Vrij A, Granhag PA, Porter S. Pitfalls and opportunities in nonverbal and verbal lie detection. Psychol Sci Public Interest. 2010;11(3):89–121. doi: 10.1177/1529100610390861. \[

https://doi.org/10.1177/1529100610390861

https://pubmed.ncbi.nlm.nih.gov/26168416/

Google Scholar

https://scholar.google.com/scholar\_lookup?journal=Psychol%20Sci%20Public%20Interest&title=Pitfalls%20and%20opportunities%20in%20nonverbal%20and%20verbal%20lie%20detection&author=A%20Vrij&author=PA%20Granhag&author=S%20Porter&volume=11&issue=3&publication\_year=2010&pages=89-121&pmid=26168416&doi=10.1177/1529100610390861&

Wang B, Fu X. Gender difference in the effect of daytime sleep on declarative memory for pictures. J Zhejiang Univ-Sci B. 2009;10(7):536–546. doi: 10.1631/jzus.B0820384. \[

https://doi.org/10.1631/jzus.B0820384

PMC free article

https://pmc.ncbi.nlm.nih.gov/articles/PMC2704972/

https://pubmed.ncbi.nlm.nih.gov/19585672/

Google Scholar

https://scholar.google.com/scholar\_lookup?journal=J%20Zhejiang%20Univ-Sci%20B&title=Gender%20difference%20in%20the%20effect%20of%20daytime%20sleep%20on%20declarative%20memory%20for%20pictures&author=B%20Wang&author=X%20Fu&volume=10&issue=7&publication\_year=2009&pages=536-546&pmid=19585672&doi=10.1631/jzus.B0820384&

Warren G, Schertler E, Bull P. Detecting deception from emotional and unemotional cues. J Nonverb Behav. 2009;33(1):59–69. doi: 10.1007/s10919-008-0057-7. \[

https://doi.org/10.1007/s10919-008-0057-7

Google Scholar

https://scholar.google.com/scholar\_lookup?journal=J%20Nonverb%20Behav&title=Detecting%20deception%20from%20emotional%20and%20unemotional%20cues&author=G%20Warren&author=E%20Schertler&author=P%20Bull&volume=33&issue=1&publication\_year=2009&pages=59-69&doi=10.1007/s10919-008-0057-7&

Weinberger S. Airport security: intent to deceive? Nature. 2010;465(7297):412–415. doi: 10.1038/465412a. \[

https://doi.org/10.1038/465412a

https://pubmed.ncbi.nlm.nih.gov/20505706/

Google Scholar

https://scholar.google.com/scholar\_lookup?journal=Nature&title=Airport%20security:%20intent%20to%20deceive?&author=S%20Weinberger&volume=465&issue=7297&publication\_year=2010&pages=412-415&pmid=20505706&doi=10.1038/465412a&

Wu Q, Shen X, Fu X. Micro-expression and its applications. Adv Psychol Sci. 2010;18(9):1359–1368. (in Chinese) \[

Google Scholar

https://scholar.google.com/scholar\_lookup?journal=Adv%20Psychol%20Sci&title=Micro-expression%20and%20its%20applications&author=Q%20Wu&author=X%20Shen&author=X%20Fu&volume=18&issue=9&publication\_year=2010&pages=1359-1368&

Articles from Journal of Zhejiang University. Science. B are provided here courtesy of

Zhejiang University Press

View on publisher site

https://doi.org/10.1631/jzus.B1100063

PDF (409.3 KB)

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/pdf/JZUSB13-0221.pdf

Collections

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/

Similar articles

Cited by other articles

Links to NCBI Databases

On this page

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/#abstract1

1. Introduction

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/#sec1

2. Experiment 1

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/#sec2

3. Experiment 2

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/#sec8

4. General discussion

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/#sec14

Acknowledgments

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/#ack1

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/#fn-group1

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/#ref-list1

Download .nbib .nbib

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/

Format: AMA APA MLA NLM

Add to Collections

Create a new collection

\[x\] existing

Add to an existing collection

Name your collection \*

Choose a collection

Unable to load your collection due to an error

Please try again

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/

Follow NCBI

NCBI on X (formerly known as Twitter)

https://twitter.com/ncbi

NCBI on Facebook

https://www.facebook.com/ncbi.nlm

NCBI on LinkedIn

https://www.linkedin.com/company/ncbinlm

NCBI on GitHub

https://github.com/ncbi

NCBI RSS feed

https://ncbiinsights.ncbi.nlm.nih.gov/

Connect with NLM

NLM on X (formerly known as Twitter)

https://twitter.com/nlm\_nih

NLM on Facebook

https://www.facebook.com/nationallibraryofmedicine

NLM on YouTube

https://www.youtube.com/user/NLMNIH

\[National Library of Medicine 8600 Rockville Pike Bethesda, MD 20894\](https://www.google.com/maps/place/8600+Rockville+Pike,+Bethesda,+MD+20894/%4038.9959508,            -77.101021,17z/data%3D!3m1!4b1!4m5!3m4!1s0x89b7c95e25765ddb%3A0x19156f88b27635b8!8m2!3d38.9959508!            4d-77.0988323)

Web Policies

https://www.nlm.nih.gov/web\_policies.html

https://www.nih.gov/institutes-nih/nih-office-director/office-communications-public-liaison/freedom-information-act-office

HHS Vulnerability Disclosure

https://www.hhs.gov/vulnerability-disclosure-policy/index.html

https://support.nlm.nih.gov/?pagename=cloudpmc-viewer%3Apmc%3Aarticle%3Ajournal

Accessibility

https://www.nlm.nih.gov/accessibility.html

https://www.nlm.nih.gov/careers/careers.html

https://www.nlm.nih.gov/

https://www.nih.gov/

https://www.hhs.gov/

https://www.usa.gov/

Back to Top

