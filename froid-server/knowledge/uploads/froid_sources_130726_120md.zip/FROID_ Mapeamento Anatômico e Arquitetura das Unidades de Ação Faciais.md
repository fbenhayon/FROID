# FROID: Mapeamento Anatômico e Arquitetura das Unidades de Ação Faciais

O objetivo desse notebook é contribuir excelentemente para a criação do FROID estabelecer a arquitetura completa fornecendo os parâmetros e providencias necessárias para a criação do sistema que vai ajudar profissionais a identificas as coerencias entre expressoes faciais da fala do conteudo daquilo que é falado assim como sua substancia e mensagem e, deverá ter seu código desenvolvido pelos mais inteligentes e habilidosos do planeta. chamo a todas essas fontes para que possamos realizar um trabalho de substanciar o FROID com os recursos mais modernos e inteligentes necessários a se tornar a melhor e mais inteligente ferramenta para a frequency recognitiois of internal dynamics do universo.

Facial Action Coding System

(FACS), desenvolvido originalmente por Paul Ekman e Wallace V. Friesen, é o sistema anatômico e comportamental mais rigoroso para classificar os movimentos faciais humanos \[1\]. O sistema decompõe qualquer expressão facial nas suas menores unidades de movimento anatomicamente discerníveis, conhecidas como Unidades de Ação (Action Units ou AUs) \[1\]. Estas AUs não são meramente rótulos de emoções, mas representam a contração ou o relaxamento fundamental de músculos faciais específicos (ou grupos de músculos) que alteram a configuração e a topografia da pele \[1, 2\].

Abaixo está o descritivo exaustivo e técnico de todas as Unidades de Ação (AUs), Descritores de Ação (ADs) e códigos acessórios documentados para o mapeamento da dinâmica interna humana:

Unidades de Ação da Face Superior (Upper Face AUs)

Esta região é crítica para a detecção de estados cognitivos, surpresa, medo e afeto verdadeiro:

#### AU 0 (Neutral face):

Face em estado de repouso absoluto, caracterizando ausência de ativação \[2\].

#### AU 1 (Inner Brow Raiser):

Elevação da parte interna das sobrancelhas, criando rugas horizontais no centro da testa, acionada pelo músculo

Frontalis, pars medialis

#### AU 2 (Outer Brow Raiser):

Elevação da parte externa das sobrancelhas, acionada pelo músculo

Frontalis, pars lateralis

#### AU 4 (Brow Lowerer):

Abaixamento e aproximação das sobrancelhas, gerando rugas verticais ou oblíquas na glabela, acionada pelos músculos

Corrugator supercilii, Depressor supercilii

#### AU 5 (Upper Lid Raiser):

Elevação da pálpebra superior que alarga a abertura ocular e expõe a esclera, acionada pelo músculo

Levator palpebrae superioris

e músculo tarsal superior \[2-4\].

#### AU 6 (Cheek Raiser):

Elevação das bochechas que estreita a fenda ocular e cria rugas laterais ("pés de galinha"), sendo o marcador técnico do sorriso genuíno (Duchenne), acionada pelo músculo

Orbicularis oculi, pars orbitalis

#### AU 7 (Lid Tightener):

Tensionamento das pálpebras (principalmente a inferior), acionado pelo músculo

Orbicularis oculi, pars palpebralis

Unidades de Ação da Face Inferior (Lower Face AUs)

Esta região apresenta alta complexidade motora devido à flexibilidade labial e mandibular, agrupando movimentos horizontais, verticais e orbitais:

#### AU 8 (Lips toward each other):

Lábios movendo-se um em direção ao outro para fechamento, acionada pelo músculo

Orbicularis oris

#### AU 9 (Nose Wrinkler):

Enrugamento da ponte do nariz, com elevação das asas nasais e do centro do lábio superior, acionada pelo

Levator labii superioris alaeque nasi

#### AU 10 (Upper Lip Raiser):

Elevação do lábio superior que aprofunda o sulco nasolabial, acionada pelo

Levator labii superioris

caput infraorbitalis

#### AU 11 (Nasolabial Deepener):

Aprofundamento do sulco nasolabial sem elevação pronunciada, acionado pelo

Zygomaticus minor

#### AU 12 (Lip Corner Puller):

Tração dos cantos dos lábios obliquamente para cima e para fora (o movimento primário do sorriso), acionada pelo

Zygomaticus major

#### AU 13 (Sharp lip puller / Cheek Puffer):

Tração dos cantos dos lábios com inchaço das bochechas, acionada pelo

Levator anguli oris

(também conhecido como

#### AU 14 (Dimpler):

Tensionamento dos cantos da boca que forma covinhas puxando os cantos para dentro contra os dentes, acionada pelo

#### AU 15 (Lip Corner Depressor):

Tração dos cantos da boca para baixo, assumindo forma de arco invertido associado à tristeza, acionada pelo

Depressor anguli oris

Triangularis

) \[2, 3, 5\].

#### AU 16 (Lower Lip Depressor):

Depressão ou rebaixamento isolado do lábio inferior, acionada pelo

Depressor labii inferioris

#### AU 17 (Chin Raiser):

Elevação da pele do queixo e empurrão do lábio inferior para cima, criando protuberâncias no queixo, acionada pelo músculo

#### AU 18 (Lip Pucker):

Projeção e ajuntamento dos lábios para a frente (fazer "bico"), acionada pelos

Incisivii labii superioris

Incisivii labii inferioris

#### AU 19 (Tongue show):

Exposição ou projeção da língua \[2\].

#### AU 20 (Lip stretcher):

Estiramento horizontal dos lábios em direção às orelhas, comum no medo, acionada pelo

com auxílio do

#### AU 21 (Neck tightener):

Tensionamento e visualização das cordas/tendões do pescoço, acionado pelo músculo

#### AU 22 (Lip Funneler):

Projeção dos lábios faneando-os em formato de funil, acionada pelo

Orbicularis oris

#### AU 23 (Lip Tightener):

Estreitamento e tensão das margens vermelhas dos lábios (lábios apertados), acionado pelo

Orbicularis oris

#### AU 24 (Lip Pressor):

Compressão mecânica de um lábio contra o outro, sinalizando contenção emocional, acionada pelo

Orbicularis oris

#### AU 25 (Lips part):

Separação dos lábios ou abertura leve, causada pelo relaxamento do

Orbicularis oris

, ou contração do

Depressor labii inferioris

#### AU 26 (Jaw Drop):

Queda relaxada da mandíbula inferior, envolvendo relaxamento do

e do pterigóideo interno com o músculo

#### AU 27 (Mouth Stretch):

Abaixamento forçado da mandíbula que alonga e abre a boca ao máximo, acionada pelos

Pterigóideos

#### AU 28 (Lip Suck):

Sucção ou enrolamento dos lábios para dentro da boca sobre os dentes, acionada pelo

Orbicularis oris

Descritores de Ação e Comportamentos Grosseiros (Gross Behaviors e ADs)

Estes são movimentos onde a base muscular isolada não é especificada de modo idêntico, mas representam deslocamentos mecânicos importantes da face e mandíbula:

#### AU 29 (Jaw thrust):

Impulso forçado da mandíbula inferior para a frente \[6\].

#### AU 30 (Jaw sideways):

Deslocamento da mandíbula para os lados \[6\].

#### AU 31 (Jaw clencher):

Cerração ou aperto maxilar visível, acionado pelo músculo

#### AU 32 (\[Lip\] bite):

O ato de morder o próprio lábio \[6\].

#### AU 33 (\[Cheek\] blow):

Sopro inflando os tecidos ou expirando o ar \[6\].

#### AU 34 (\[Cheek\] puff):

Inchar as bochechas com ar \[6\].

#### AU 35 (\[Cheek\] suck):

Sugar as bochechas para dentro \[6\].

#### AU 36 (\[Tongue\] bulge):

Língua gerando uma protuberância visível contra as bochechas ou lábios \[6\].

#### AU 37 (Lip wipe):

O ato comportamental de limpar os lábios \[6\].

#### AU 38 (Nostril dilator):

Expansão das asas nasais para tomada profunda de ar, acionada pelo

Nasalis (pars alaris)

#### AU 39 (Nostril compressor):

Compressão e estreitamento das asas nasais, acionada pelo

Nasalis (pars transversa)

Depressor septi nasi

#### AU 40 (Sniff):

Farejar ou respiração nasal curta e audível \[6\].

#### AU 50 (Speech):

Modificação estrutural gerada unicamente pelo ato de falar \[6\].

#### Códigos de Atividades Acessórias (AUs 80 a 98):

Incluem eventos biomecânicos auxiliares como

(80 - Engolir),

(81 - Mastigar),

Shoulder shrug

(82 - Dar de ombros),

Head shake back and forth

(84 - Balançar a cabeça em negação),

Head nod up and down

(85 - Acenar a cabeça afirmativamente),

Partial flash

Shiver/tremble

(97 - Calafrios/tremores) e

Fast up-down look

(98 - Olhar rápido de cima a baixo) \[6\].

Unidades de Movimentos Oculares e Estados das Pálpebras

#### Mapeiam minúcias mecânicas diretamente nos olhos:

#### AU 41 (Lid droop):

Queda passiva da pálpebra superior via relaxamento do

Levator palpebrae superioris

#### AU 42 (Slit):

Estreitamento ativo dos olhos até formar fendas, acionado pelo

Orbicularis oculi

#### AU 43 (Eyes closed):

Fechamento ocular induzido pela ausência de tensão e relaxamento do

Levator palpebrae superioris

#### AU 44 (Squint):

Estrabismo intencional ou olhar semicerrado combinando os músculos

Corrugator supercilii

Orbicularis oculi

#### AU 45 (Blink):

Piscar involuntário ou comum, ocorrendo pelo relaxamento do

Levator palpebrae

superior seguido pela contração da parte palpebral do

Orbicularis oculi

#### AU 46 (Wink):

Piscadela intencional de um único olho, acionada isoladamente pelo

Orbicularis oculi

Posições de Cabeça, Códigos Oculares e Visibilidade (Head, Eye and Visibility Codes)

Tais componentes captam mudanças direcionais necessárias para validar reações de aversão, desvio ou indisponibilidade visual para a IA:

#### Movimentos de Cabeça (AUs 51 a 58):

Categorizam de forma granular o deslocamento espacial contendo Head turn left (51), Head turn right (52), Head up (53), Head down (54), Head tilt left (55), Head tilt right (56), Head forward (57) e Head back (58) \[3\].

#### Movimentos Oculares (AUs 61 a 64):

Identificam a transição exclusiva do globo ocular sem deslocamento da cabeça: Eyes turn left (61), Eyes turn right (62), Eyes up (63) e Eyes down (64) \[3\].

#### Códigos de Visibilidade ou Obstrução (AUs 70 a 74):

#### Acionados pela IA para invalidar a leitura caso a região esteja comprometida:

Brows and forehead not visible

Eyes not visible

Lower face not visible

Entire face not visible

(73) e imagens não classificáveis -

