# Diferença entre IDM vs IPM

1. Diferença Fundamental

Significado

O que mede?

Analogia Clínica

Índice de Potência Motivacional

INTENSIDADE

global da voz. Indica o nível de ativação, engajamento e "combustível" emocional disponível no momento.

velocímetro

do carro. Mostra quão rápido o motor está girando (alta energia vs. embotamento).

Índice de Desvio Multimodal

DESEQUILÍBRIO

da energia em zonas específicas. Indica se a energia está fluindo para padrões adaptativos (positivos) ou desadaptativos (negativos/conflito).

alinhamento das rodas

. Mostra se o carro está indo na direção certa ou se está derrapando para o lado errado.

2. Utilidade Prática Conjunta (Matriz de Interpretação)

A potência do FROID está em cruzar esses dois dados. Veja os 4 cenários clínicos possíveis:

IPM (Energia)

IDM (Direção/Zona)

Interpretação Clínica

Ação Sugerida

A. Fluxo Saudável

Positivo (Verde/Azul)

Paciente engajado e resolvendo conflitos. Energia fluindo para recursos positivos.

Reforçar, validar e aprofundar o insight.

B. Sofrimento Ativo

Negativo Extremo (Vermelho)

Paciente em crise, raiva explosiva, choro intenso ou ansiedade aguda. Há energia, mas está direcionada ao conflito.

Conter, acolher a emoção, reduzir a ativação antes de interpretar.

C. Embotamento/Defesa

Baixo (Queda brusca)

Neutro ou Levemente Negativo

Paciente "desligou". Dissociação, shutdown ou resistência passiva. A energia colapsou.

Estimular suavemente, checar conexão terapêutica, não forçar conteúdo.

D. Falsa Calma

Negativo Profundo (Latente)

Perigoso. Paciente parece calmo, mas o IDM mostra conflito profundo reprimido (somatização).

Investigar resistências, pois a energia está "presa" internamente.

3. Como isso aparece no Gráfico Mapa Zonal?

#### Linha Central (DR):

Representa o ponto de equilíbrio (Zero).

#### Barras (IDM):

O tamanho e a cor da barra mostram

o paciente está desviado do equilíbrio (Conflito vs. Recurso).

#### Contexto (IPM):

O valor do IPM (exibido no topo como "Base Line: XX.X") diz

quanta força

está sendo usada nesse desvio.

Um IDM de -0.20 com IPM baixo pode ser apenas uma tristeza pensativa. O mesmo IDM de -0.20 com IPM altíssimo indica uma crise depressiva ativa ou luto agudo.

