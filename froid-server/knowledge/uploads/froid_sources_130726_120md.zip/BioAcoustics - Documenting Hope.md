# BioAcoustics - Documenting Hope

https://documentinghope.com/bioacoustics/

For screen-reader mode - click the first button of the website

Use Website In a Screen-Reader Mode

Accessibility Screen-Reader Guide, Feedback, and Issue Reporting | New window

https://accessibe.com/blog/knowledgebase/screen-reader-guide

Skip to Content ↵ ENTER

https://documentinghope.com/bioacoustics/#acsbContent

Simplify Text

Shop & Support

https://documentinghope.com/shop/

Find A Practitioner

https://documentinghope.com/practitioners/

Healing Together

https://healing.documentinghope.com/register

https://conference.documentinghope.com/

https://documentinghope.com/my-account/

https://documentinghope.com/cart/

Shop & Support

https://documentinghope.com/shop/

Find A Practitioner

https://documentinghope.com/practitioners/

Healing Together

https://healing.documentinghope.com/register

https://conference.documentinghope.com/

https://documentinghope.com/my-account/

https://documentinghope.com/about-us/

https://documentinghope.com/about-us/

About The Epidemic

https://documentinghope.com/about-the-epidemic/

https://documentinghope.com/about-us/staff/

Board of Directors

https://documentinghope.com/about-us/board-of-directors/

Professional Advisory Board

https://documentinghope.com/professional-advisory-board/

Medical and Scientific Advisory Board

https://documentinghope.com/medical-and-scientific-advisory-board/

Get Involved

https://documentinghope.com/about-us/get-involved/

2025 Impact Report

https://documentinghope.com/2025-impact-report/

https://documentinghope.com/category/conditions/

https://documentinghope.com/resources/

Join Our Community

https://healing.documentinghope.com/register/

Health Coach Training Program

https://documentinghope.com/product/health-coach-training-program/

Free Guides

https://documentinghope.com/resources/ebooks/

Expert Interviews

https://documentinghope.com/free-webinars/

https://documentinghope.com/articles/

Therapies & Supports

https://documentinghope.com/category/therapies-supports/

Root Causes & Stressors

https://documentinghope.com/category/root-causes-stressors/

Reference Library

https://documentinghope.com/category/reference-library/

Brain Under Attack

https://documentinghope.com/suggested-books/brain-under-attack-a-resource-for-parents-and-caregivers-of-children-with-pans-pandas-and-autoimmune-encephalitis/

Suggested Books

https://documentinghope.com/resources/books/

Newsletter Signup

https://documentinghope.com/newsletter-signup/

Success Stories

https://documentinghope.com/success-stories/

Our Research

https://documentinghope.com/our-research/

The FLIGHT – Autism Study

https://documentinghope.com/the-flight-study/

The CHIRP Study

https://documentinghope.com/the-chirp-study/

Elimination of Autism Symptoms with Specific Carbohydrate Diet Case Report

https://documentinghope.com/elimination-of-autism-symptoms-with-specific-carbohydrate-diet-case-report/

Documenting Hope Publishes Peer-Reviewed Paper on Autism Symptoms Reversal

https://documentinghope.com/documenting-hope-publishes-peer-reviewed-paper-on-autism-symptoms-reversal-2/

Medical & Scientific Literature

https://documentinghope.com/resources/research/

Medical and Scientific Advisory Board

https://documentinghope.com/medical-and-scientific-advisory-board/

Documenting Your Own Hope with a Case Report

https://documentinghope.com/documenting-your-own-hope-with-a-case-report/

https://documentinghope.com/our-partners/

Our Partners

https://documentinghope.com/our-partners/

Companies That Care

https://documentinghope.com/companies-that-care/

Research Partners

https://documentinghope.com/our-partners/research-partners/

Business Partners

https://documentinghope.com/our-partners/business-partners/

Mission-Aligned Partners

https://documentinghope.com/our-partners/mission-aligned-partners/

Practitioner Partners

https://documentinghope.com/our-partners/practitioner-partners/

https://documentinghope.com/bioacoustics/

2026 Conference

https://documentinghope.com/conference/

Fisher Island 2025

https://documentinghope.com/fisher-2025/

2024 Documenting Hope Conference Videos

https://documentinghope.com/product/2024-documenting-conference-videos-full-package-including-bonus-lectures/

2023 Documenting Hope Conference Videos

https://documentinghope.com/product/2024-documenting-hope-learning-series-full/

https://documentinghope.com/find-help/

Find A Practitioner

https://documentinghope.com/practitioners/

Shop & Support

https://documentinghope.com/shop/

https://documentinghope.com/my-account/

https://documentinghope.com/donate/

https://documentinghope.com/about-us/

https://documentinghope.com/about-us/

About The Epidemic

https://documentinghope.com/about-the-epidemic/

https://documentinghope.com/about-us/staff/

Board of Directors

https://documentinghope.com/about-us/board-of-directors/

Professional Advisory Board

https://documentinghope.com/professional-advisory-board/

Medical and Scientific Advisory Board

https://documentinghope.com/medical-and-scientific-advisory-board/

Get Involved

https://documentinghope.com/about-us/get-involved/

2025 Impact Report

https://documentinghope.com/2025-impact-report/

https://documentinghope.com/category/conditions/

https://documentinghope.com/resources/

Join Our Community

https://healing.documentinghope.com/register/

Health Coach Training Program

https://documentinghope.com/product/health-coach-training-program/

Free Guides

https://documentinghope.com/resources/ebooks/

Expert Interviews

https://documentinghope.com/free-webinars/

https://documentinghope.com/articles/

Therapies & Supports

https://documentinghope.com/category/therapies-supports/

Root Causes & Stressors

https://documentinghope.com/category/root-causes-stressors/

Reference Library

https://documentinghope.com/category/reference-library/

Brain Under Attack

https://documentinghope.com/suggested-books/brain-under-attack-a-resource-for-parents-and-caregivers-of-children-with-pans-pandas-and-autoimmune-encephalitis/

Suggested Books

https://documentinghope.com/resources/books/

Newsletter Signup

https://documentinghope.com/newsletter-signup/

Success Stories

https://documentinghope.com/success-stories/

Our Research

https://documentinghope.com/our-research/

The FLIGHT – Autism Study

https://documentinghope.com/the-flight-study/

The CHIRP Study

https://documentinghope.com/the-chirp-study/

Elimination of Autism Symptoms with Specific Carbohydrate Diet Case Report

https://documentinghope.com/elimination-of-autism-symptoms-with-specific-carbohydrate-diet-case-report/

Documenting Hope Publishes Peer-Reviewed Paper on Autism Symptoms Reversal

https://documentinghope.com/documenting-hope-publishes-peer-reviewed-paper-on-autism-symptoms-reversal-2/

Medical & Scientific Literature

https://documentinghope.com/resources/research/

Medical and Scientific Advisory Board

https://documentinghope.com/medical-and-scientific-advisory-board/

Documenting Your Own Hope with a Case Report

https://documentinghope.com/documenting-your-own-hope-with-a-case-report/

https://documentinghope.com/our-partners/

Our Partners

https://documentinghope.com/our-partners/

Companies That Care

https://documentinghope.com/companies-that-care/

Research Partners

https://documentinghope.com/our-partners/research-partners/

Business Partners

https://documentinghope.com/our-partners/business-partners/

Mission-Aligned Partners

https://documentinghope.com/our-partners/mission-aligned-partners/

Practitioner Partners

https://documentinghope.com/our-partners/practitioner-partners/

https://documentinghope.com/bioacoustics/

2026 Conference

https://documentinghope.com/conference/

Fisher Island 2025

https://documentinghope.com/fisher-2025/

2024 Documenting Hope Conference Videos

https://documentinghope.com/product/2024-documenting-conference-videos-full-package-including-bonus-lectures/

2023 Documenting Hope Conference Videos

https://documentinghope.com/product/2024-documenting-hope-learning-series-full/

https://documentinghope.com/find-help/

Find A Practitioner

https://documentinghope.com/practitioners/

Shop & Support

https://documentinghope.com/shop/

https://documentinghope.com/my-account/

https://documentinghope.com/donate/

https://documentinghope.com/articles/

Therapies & Supports

https://documentinghope.com/category/therapies-supports/

Mind, Body & Spirit Therapies

https://documentinghope.com/category/therapies-supports/mind-body-spirit-therapies/

Human BioAcoustics

https://documentinghope.com/category/therapies-supports/mind-body-spirit-therapies/human-bioacoustics/

BioAcoustics

BioAcoustics

This excerpt is taken with permission from Envisioning a Bright Future: Interventions That Work for Children and Adults with Autism Spectrum Disorders, edited by Patricia S. Lemer.

History of BioAcoustics

In 1978 audiologist David Kemp began conducting research on otoacoustic emissions. This phenomenon, identified in the late 1940s, states that the ear not only takes in and sends sound to the brain, but also emits a sound, most likely from the cochlea\[i\].

About the same time, Sharry Edwards, a college student, was searching for an explanation for why she heard sounds emanating from the people around her. She claimed to be able to identify people by their sound, and believed that each person resonates at a unique frequency. Three different sound laboratories conducted independent testing of Edward's voice; all confirmed that she could produce a pure tone sine wave with her voice.

Edwards postulated that if key frequencies are out-of-balance in the ear, then they are also out-of-balance in the voice. For over thirty years Edwards has increased her unique knowledge of the voice-ear connection and concluded that the voice is a hologram of the body's emotional, physical and spiritual components. Eventually her knowledge led to the development of the science of Human BioAcoustics™.\[ii\]

The Tomatis Effect

Over 50 years ago, Dr. Alfred Tomatis discovered the “Tomatis Effect”, a set of three laws that identified a “

voice-ear-brain” connection

https://documentinghope.com/category/therapies-supports/neurodevelopmental-therapies/auditory-therapy/

. Specifically, these laws state:

The voice only contains the harmonics that the ear can hear.

If you give the possibility to the ear to correctly hear the distorted frequencies of sound that are not well heard, these are immediately and unconsciously restored into the voice.

The imposed audition sufficiently maintained over time results in permanently modifying the audition and phonation.

These laws were validated in 1957 at the French Academy of Sciences.

Dorinne Davis' Contribution

After working with both The Tomatis Method, and BioAcoustics, Dorinne Davis, and audiologist specializing in sound based therapy, conducted research into the connection between otoacoustic emissions and vocal analysis from BioAcoustics.

Spontaneous otoacoustic emissions from the ear were evaluated and compared with a frequency analysis obtained through voice analysis. One hundred percent correlation between the stressed frequencies of the ear and voice was noted. From this research, an addendum of two new laws to the “Tomatis Effect” was suggested.

Davis Addendum to the Tomatis Effect

With 100% correlation, two new laws are suggested as an addition to Dr. Tomatis' laws.

The ear emits the same stressed frequencies that are emitted by the voice.

When complementary or supplementary frequencies of stressed frequencies are introduced via sound vibration to the ear, vocal patterns regain coherence.

What Is BioAcoustics?

Human BioAcoustics uses a “voiceprint” to evaluate a person's state of health by analyzing the frequencies of all cellular structures in the body, and their relationship to each other. After evaluating the voiceprint, and identifying imbalances, a qualified sound-health practitioner suggests a combination of specific frequencies that are programmed into an instrument designed to support an individual's overall well-being.

BioAcoustics is a proto-science with unlimited potential for many wellness fields. It is a useful tool for those practicing integrative medicine, as well as for professionals in nutrition, sports medicine, occupational and physical therapy, and, of course, optometry.

BioAcoustics is the study of the frequencies all living systems produce. It uses voice spectral analysis, a scientific method for identifying and interpreting the complex frequency interactions constantly occurring in the body. BioAcoustics™ is based on the principle that the body requires a full range of harmonious frequencies, working cooperatively, in order to be healthy.

Everything in an individual's body is impacted by sound: every single cell in the body continuously emits and absorbs sound vibrations that affect the entire body\[i\]. Every element, pathogen, bacteria, hormone and nutritional factor also manifests a unique vibration, defined by BioAcoustics as its Frequency Equivalent™. Every person's body vibrates with its own unique combination of frequencies. Combined, they produce a distinctive and unique sound blueprint or “voiceprint,” representing the totality of those frequencies at that moment in time.

Restoring Health

A BioAcoustics Research Associate (BARA) analyzes the voiceprint and identifies frequencies to help a person's body makes changes that support and maintain its overall balance and harmony. BioAcoustics depends upon both individual Frequency Equivalents™, and the relationships among them, to identify imbalances and restore an individual's balance and health.

Frequency Equivalents interact with each other. For example, when you combine the Frequency Equivalents of calcium and magnesium, the result is the Frequency Equivalent of phosphorus, an element that is necessary for calcium and magnesium metabolism. BioAcoustics explores the potential that the body is a mathematical matrix of predictable frequency relationships.

When a person listens to combinations of specific sound frequencies, programmed into a tone box, his/her brain supports the body to self-correct frequencies that are “out of balance” by sending information back to the brain via the nervous, circulatory, soft tissue, and cellular network.

Who Can Benefit?

BioAcoustics is particularly useful in relieving symptoms related to a variety of seemingly diverse conditions in people of all ages.

Testing and Equipment

BioAcoustics uses a computerized voice analyzer to capture a 30-second sample of the frequencies of a subject's voice in a “voiceprint” known as his/her Signature Sound™. Because the voice produces what the ear hears, a BioAcoustics' voiceprint also reflects the voice-ear-brain connection.

The BARA prints a graphic representation of the results and reviews it. Computer analysis identifies vibrational discordance: frequencies that are out-of-balance, or “in stress,” as well as those that are not supporting the body sufficiently. For instance, a particular vitamin, mineral, or hormone level may show up as too low or high. People who have similar traumas, illnesses, syndromes, psychologies, diseases and toxins have similar, if not identical vocal anomalies.

After evaluating the voiceprint, and identifying imbalances, the next step is for the BARA to establish a protocol of frequency combinations chosen specifically for that individual.

The BARA tests this protocol with the individual connected to biofeedback equipment that monitors his/her body responses. These formulated frequencies are then programmed into a portable tone box that the person listens to at home. Instruments show that BioAcoustics individualized binaural beat frequencies entrain the brain, thus facilitating positive change.

The Bioacoustics voiceprint and tone box are extraordinary tools. The voiceprint can be:

Explanatory

– pinpointing long standing health issues, such as the Frequency Equivalents of nutritional deficiencies and toxicity. The voiceprint can also identify Frequency Equivalents of invaders, like toxins or pathogens, as well as system problems, such as muscle weaknesses. The voiceprint of a three-year-old with autism, who wasn't progressing, showed the Frequency Equivalents of high levels of fluoride. After taking a history, the practitioner discovered that the family drank only fluoridated water, and that the child liked to eat his fluoride-containing toothpaste.

– identifying imbalances even when a person has no symptoms, because stress in the body manifests itself at an acoustical level before showing up physically. This program determines if a child's stressed Frequency Equivalents are related to factors such as mercury toxicity.

The tone box is

Supportive –

resolving a person's innate weaknesses, and even facilitating better absorption of ingested substances, by using the tone box to re-pattern the brain. The end-product is wellness. For example, after listening to a sound Frequency Equivalent of vitamin C, one child who refused and spit out vitamin C pills and liquid drops, ingested them without difficulty.

Voiceprints are not intended to be used as medical information. However, patients can share the results with their physicians for additional interpretation, if they so desire.

Frequency and Duration

Children with autism may make changes both physiologically and psychologically by listening at home daily to the tone box containing their unique protocols. The length of individual protocols varies, as does the frequency. Patients should repeat their BioAcoustics voiceprints to measure changes. The practitioner then reformulates the frequency combinations to address the current needs.

BioAcoustics facilities are located throughout the United States and in six other countries. About 3,000 people are trained in this technique, but only about 40% use it in a medical practice. Approximately a third learned BioAcoustics to take care of ill family members. To locate a practitioner in your area, go to

www.soundhealthoptions.com

http://www.soundhealthoptions.com/

\[i\] Wheeler, M. Signal Discovery? , Smithsonian Magazine, March 2004.

\[i\] Martin, F.N., Introduction to Audiology, Prentice-Hall, Englewood Cliffs, NJ, 1986:278.

\[ii\] Edwards, S. Subtle Energy Medicine: The Potential of Math as Medicine. Albany, OH: Sound Health, Inc.

About Patricia S. Lemer LPC MEd

Patricia S. Lemer is a licensed professional counselor, holding a Masters of Education in counseling and learning disabilities from Boston College and a Masters in Business from Johns Hopkins University. She practiced as an educational diagnostician for over 40 years.

She was a co-founder and served as Executive Director of the international non-profit organization Developmental Delay Resources (DDR). After DDR merged with Epidemic Answers, she became Chairman of the Board. When she retired from the board, she became an emeritus board member.

She is the author of three books, the most recent of which is Outsmarting Autism, Updated and Expanded: Build Healthy Foundations for Communication, Socialization, and Behavior at All Ages (North Atlantic Books, 2019).

Lemer wrote over 50 editorials for "New Developments," the quarterly newsletter of Developmental Delay Resources (DDR), from 1995 - 2009. When DDR wound down, she wrote an online blog, "After the Diagnosis, Then What?" from 2009-2017. Her articles and blogs have been updated and archived on the Epidemic Answers website.

Since 2019, Patricia Lemer has recorded a bimonthly podcast, "The Autism Detective." In these hour-long shows, she interviews parents and professionals about their experiences in maximizing the potential of individuals on the autism spectrum. Over 100 episodes are available on Spotify and other online platforms. To learn more, go to PatriciaLemer.com and

OutsmartingAutism.com

https://www.outsmartingautism.com/

http://www.patricialemer.com/

Still Looking for Answers?

Documenting Hope Practitioner Directory to find a practitioner near you.

https://documentinghope.com/practitioners/

Join us inside our online membership community for parents,

Healing Together

https://healing.documentinghope.com/register/

, where you'll find even more healing resources, expert guidance, and a community to support you every step of your child's healing journey.

More To Explore

Outsmarting Autism: Expanded and Updated

https://documentinghope.com/suggested-books/outsmarting-autism-expanded-and-updated/

Auditory Therapy

https://documentinghope.com/category/therapies-supports/neurodevelopmental-therapies/auditory-therapy/

Vibrational Therapy

https://documentinghope.com/category/therapies-supports/mind-body-spirit-therapies/vibrational-therapy/

Human BioAcoustics

https://documentinghope.com/webinar/human-bioacoustics/

Join Healing Together

The official science-backed healing program from Documenting Hope!

https://healing.document694stg.wpenginepowered.com/register

Table of Contents

History of BioAcoustics

https://documentinghope.com/bioacoustics/#HistoryofBioAcoustics

The Tomatis Effect

https://documentinghope.com/bioacoustics/#TheTomatisEffect

Dorinne Davis' Contribution

https://documentinghope.com/bioacoustics/#DorinneDavisContribution

What Is BioAcoustics?

https://documentinghope.com/bioacoustics/#WhatIsBioAcoustics

Restoring Health

https://documentinghope.com/bioacoustics/#RestoringHealth

Who Can Benefit?

https://documentinghope.com/bioacoustics/#WhoCanBenefit

Testing and Equipment

https://documentinghope.com/bioacoustics/#TestingandEquipment

Frequency and Duration

https://documentinghope.com/bioacoustics/#FrequencyandDuration

https://documentinghope.com/bioacoustics/#Resources

About Patricia S. Lemer LPC MEd

https://documentinghope.com/bioacoustics/#AboutPatriciaSLemerLPCMEd

Still Looking for Answers?

https://documentinghope.com/bioacoustics/#StillLookingforAnswers

More To Explore

https://documentinghope.com/bioacoustics/#MoreToExplore

Join Healing Together

https://documentinghope.com/bioacoustics/#JoinHealingTogether

Latest Articles

Elimination of Autism Symptoms with Specific Carbohydrate Diet Case Report

https://documentinghope.com/elimination-of-autism-symptoms-with-specific-carbohydrate-diet-case-report/

The New Childhood Epidemics

https://documentinghope.com/the-new-childhood-epidemics/

Costs of the Epidemic

https://documentinghope.com/costs-of-the-epidemic/

Herbal Medicine Main Info Page

https://documentinghope.com/herbal-medicine-main-info-page/

A Resource for Families in Crisis

https://documentinghope.com/resource-for-families-in-crisis/

Join our email list to get free healing resources delivered right to your inbox.

Email address\*\*

Send Me Free Resources!

Follow Along on Social

https://www.facebook.com/DocumentingHope/

https://x.com/documentinghope

https://instagram.com/documentinghope

https://www.youtube.com/channel/UC\_ZHXwyx8jIhJbUD2GXCTnw

https://documentinghope.com/about-us/

https://documentinghope.com/contact-us/

Get Involved

https://documentinghope.com/get-involved/

Student Account

https://documentinghope.com/my-account/

Donor Dashboard

https://documentinghope.com/donor-dashboard/

Update Directory Profile

https://documentinghope.com/update-practitioner-directory-profile/

This information is not a substitute for medical advice, treatment, diagnosis, or consultation with a medical professional. It is intended for general informational purposes only and should not be relied on to make determinations related to treatment of a medical condition. Documenting Hope has not verified and does not guarantee the accuracy of the information provided in this document.

© Copyright 2013-2026 Documenting Hope. All rights reserved.

Privacy Policy

https://documentinghope.com/privacy-policy/

Terms of Service

https://documentinghope.com/terms-of-use/

https://documentinghope.com/disclaimer/

Website by fuseStarter

https://fusestarter.com/

Notifications

previous next slideshow

