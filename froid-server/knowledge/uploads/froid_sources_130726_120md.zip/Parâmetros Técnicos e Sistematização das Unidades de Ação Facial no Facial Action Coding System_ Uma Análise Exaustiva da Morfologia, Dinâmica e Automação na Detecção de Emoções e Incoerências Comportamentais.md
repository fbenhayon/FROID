# Parâmetros Técnicos e Sistematização das Unidades de Ação Facial no Facial Action Coding System: Uma Análise Exaustiva da Morfologia, Dinâmica e Automação na Detecção de Emoções e Incoerências Comportamentais

O Facial Action Coding System (FACS) representa o esforço mais rigoroso e influente da ciência comportamental para objetivar a medição dos movimentos faciais humanos.\[1, 2, 3\] Desenvolvido originalmente por Paul Ekman e Wallace V. Friesen em 1978, e substancialmente atualizado em 2002 com a colaboração de Joseph C. Hager, o sistema foi construído sobre as bases anatômicas lançadas pelo anatomista sueco Carl-Herman Hjortsjö.\[3\] A premissa fundamental do FACS é a decomposição de qualquer expressão facial em suas unidades mínimas de movimento anatomicamente discerníveis, denominadas Unidades de Ação (Action Units ou AUs). Diferente de sistemas de codificação anteriores que dependiam de inferências subjetivas sobre o significado das expressões — como rotular uma face como "triste" ou "alegre" — o FACS opera em um nível puramente descritivo, mapeando como as contrações musculares alteram a configuração da superfície da pele, criam rugas, deslocam características faciais e alteram a geometria das aberturas oculares e bucais.\[4, 5, 6\]

Esta abordagem técnica permite que pesquisadores separem a observação física do movimento da interpretação psicológica posterior. O sistema identifica que, embora o rosto humano possua uma complexidade muscular vasta, nem todos os movimentos musculares são visíveis ou podem ser isolados voluntariamente.\[4\] Assim, as AUs não são meramente sinônimos de músculos individuais; em alguns casos, uma única AU pode representar a ação de vários músculos que produzem uma mudança de aparência única e inseparável, enquanto em outros, um único músculo pode ser dividido em múltiplas AUs se diferentes partes dele puderem ser contraídas de forma independente para criar efeitos visuais distintos.\[4, 7\] O manual resultante, com mais de 500 páginas, detalha não apenas a anatomia de cada movimento, mas também os critérios de intensidade, a duração temporal e as regras de combinação que permitem distinguir entre expressões emocionais genuínas e simulações sociais, bem como identificar o fenômeno do vazamento emocional em contextos de decepção.\[7, 8\]

Fundamentos Biomecânicos e a Neurofisiologia da Expressão Facial

A eficácia do FACS como ferramenta de mapeamento reside na sua compreensão profunda da biomecânica facial. Os músculos da face são únicos no corpo humano porque, em vez de moverem ossos em articulações, eles se inserem diretamente na derme ou em outros músculos faciais.\[2, 4\] Quando estas fibras se contraem, elas puxam a pele, criando as dobras, protuberâncias e sulcos que o FACS utiliza como indicadores técnicos.\[6, 9\] O sistema cataloga aproximadamente 44 Unidades de Ação mímicas, além de uma série de Descritores de Ação (ADs) que abrangem movimentos globais da mandíbula, cabeça e olhos que, embora não puramente mímicos, alteram significativamente a percepção da expressão.\[3, 7, 10\]

A distinção entre o controle voluntário e involuntário da face é um parâmetro técnico crucial para a detecção de incoerências. As expressões emocionais genuínas são frequentemente mediadas pelo sistema motor extrapiramidal, resultando em contrações musculares que são difíceis de replicar conscientemente.\[5, 11\] Por outro lado, expressões sociais ou fingidas são coordenadas pelo sistema motor piramidal (córtex motor), que muitas vezes não consegue ativar os chamados "músculos confiáveis", como a porção orbital do orbicularis oculi (AU 6) ou a porção medial do frontal (AU 1), sem o estímulo emocional real.\[7\] Esta dicotomia neuroanatômica é o que permite ao FACS identificar sorrisos falsos ou emoções mascaradas, pois a ausência ou presença dessas unidades específicas serve como um selo técnico de autenticidade ou de esforço consciente de simulação.\[3, 11\]

A Taxonomia das Unidades de Ação da Face Superior

A face superior, compreendendo a fronte, as sobrancelhas e as pálpebras, é a região onde ocorrem alguns dos sinais mais sutis de estados cognitivos e emocionais. O FACS divide esta área em unidades que controlam a elevação, o abaixamento e o tensionamento dos tecidos em torno das órbitas oculares.\[9, 10, 12\]

Action Unit (AU)

Nome Técnico no FACS

Base Muscular Anatômica

Mudanças de Aparência e Marcadores de Superfície

Inner Brow Raiser

Frontalis, pars medialis

Eleva a parte interna das sobrancelhas; cria rugas horizontais no centro da testa; as sobrancelhas podem assumir uma forma oblíqua. \[3, 9, 10\]

Outer Brow Raiser

Frontalis, pars lateralis

Eleva a parte externa das sobrancelhas; cria rugas horizontais nas laterais da testa; aumenta a distância entre a sobrancelha e a pálpebra superior. \[3, 10, 13\]

Brow Lowerer

Corrugator supercilii, Depressor supercilii, Procerus

Puxa as sobrancelhas para baixo e para o centro; cria rugas verticais ou oblíquas entre as sobrancelhas (glabela); aproxima as sobrancelhas. \[3, 10, 12\]

Upper Lid Raiser

Levator palpebrae superioris, Superior tarsal muscle

Eleva a pálpebra superior; expõe a esclera acima da íris; a pálpebra superior parece "arregalada". \[3, 10, 14\]

Cheek Raiser

Orbicularis oculi, pars orbitalis

Eleva as bochechas; estreita a abertura ocular; cria rugas laterais ("pés de galinha"); eleva a pálpebra inferior sem tensioná-la. \[3, 9, 10\]

Lid Tightener

Orbicularis oculi, pars palpebralis

Tensiona e eleva as pálpebras inferiores; estreita a fenda palpebral; pode criar uma protuberância na pálpebra inferior. \[3, 9, 10\]

O mapeamento técnico da AU 1 e AU 2 demonstra a precisão do sistema. Embora ambas façam parte do músculo frontal, o FACS as trata separadamente porque é possível elevar apenas as bordas internas das sobrancelhas (comum em tristeza e medo) ou apenas as bordas externas (comum em surpresa fingida ou descrença).\[12, 13, 15\] A AU 6 é talvez a unidade mais crítica para a psicologia positiva, pois sua ativação involuntária junto com a AU 12 (sorriso) é o marcador técnico do sorriso de Duchenne, distinguindo-o do sorriso voluntário ou "Pan-Am", onde apenas os cantos da boca são puxados.\[3, 16\]

Dinâmica das Unidades de Ação da Face Inferior

A face inferior é significativamente mais complexa em termos de possibilidades de movimento, devido à flexibilidade dos lábios e da mandíbula. O FACS organiza estas ações em categorias funcionais: movimentos verticais, horizontais, oblíquos e orbitais, permitindo a codificação de expressões de nojo, desprezo, raiva e satisfação.\[5, 12\]

Action Unit (AU)

Nome Técnico no FACS

Músculo de Base

Caracterização do Movimento e Impacto na Face Inferior

Nose Wrinkler

Levator labii superioris alaeque nasi

Enruga a ponte do nariz; eleva as asas do nariz; eleva o centro do lábio superior; cria rugas oblíquas no nariz. \[3, 10, 12\]

Upper Lip Raiser

Levator labii superioris

Eleva o lábio superior; aprofunda o sulco nasolabial; expõe os dentes superiores. \[3, 10, 12\]

Lip Corner Puller

Zygomaticus major

Puxa os cantos da boca obliquamente para cima e para fora; alonga a boca; acentua as bochechas. \[3, 10, 12\]

Tensiona os cantos da boca; cria covinhas ou depressões angulares; puxa os cantos da boca para dentro contra os molares. \[3, 10, 12\]

Lip Corner Depressor

Depressor anguli oris

Puxa os cantos da boca para baixo; a linha da boca assume uma forma de arco invertido; associado a tristeza e amargura. \[3, 10, 12\]

Chin Raiser

Eleva a pele do queixo e empurra o lábio inferior para cima; cria protuberâncias no queixo; importante em expressões de dúvida e determinação. \[3, 10, 12\]

Lip Stretcher

Risorius com Platysma

Puxa os cantos da boca horizontalmente para trás; alonga a boca para os lados; comum em expressões de medo. \[3, 10, 12\]

Lip Tightener

Orbicularis oris

Estreita as margens vermelhas dos lábios; os lábios parecem mais finos e apertados; sinal de raiva ou concentração. \[3, 10, 12\]

Lip Pressor

Orbicularis oris

Pressiona os lábios um contra o outro; impede a fala; sinal de controle emocional ou supressão. \[3, 10, 12\]

Esta taxonomia permite identificar nuances finas, como a diferença entre o nojo visceral (predominantemente AU 9, com enrugamento nasal) e o nojo social ou desprezo leve (onde a AU 10 ou a assimetria da AU 12/14 predominam).\[7, 17\] A combinação de movimentos orbitais como a AU 23 e AU 24 é um indicador técnico frequente de que um indivíduo está tentando conter uma resposta verbal ou emocional negativa, servindo como um parâmetro para a detecção de conflitos internos.\[7, 12\]

Parâmetros de Intensidade e Escalonamento da Resposta Facial

Um dos maiores avanços técnicos do FACS foi a introdução de uma escala de intensidade padronizada, que permite aos codificadores quantificar o grau de ativação de cada Unidade de Ação. A intensidade não é medida apenas pela força da contração, mas pela extensão das mudanças de aparência geradas na superfície facial.\[3, 16, 18\] O sistema utiliza um esquema de cinco pontos, representado pelas letras A a E, anexadas ao número da AU.\[3, 15\]

#### A - Traço (Trace):

Representa a evidência mínima de movimento. Frequentemente identificada como o "vazamento" em microexpressões, onde o músculo começa a se contrair mas é interrompido ou suprimido. É o nível mais difícil de detectar e exige análise quadro a quadro.\[3, 15\]

#### B - Leve (Slight):

Uma ativação claramente visível, mas que não causa uma deformação significativa na geometria facial. É a intensidade típica de expressões sociais sutis ou reações internas moderadas.\[3, 15\]

#### C - Marcada ou Pronunciada (Marked):

Uma ativação forte que altera visivelmente a forma das características faciais e cria rugas ou sulcos bem definidos. É o padrão-ouro para o reconhecimento de emoções prototípicas.\[3, 15\]

#### D - Grave ou Extrema (Severe):

Indica uma contração muito poderosa, quase no limite da capacidade muscular. Comumente vista em estados de dor intensa, pânico ou raiva explosiva.\[3, 15\]

#### E - Máxima (Maximum):

O limite anatômico absoluto da contração para aquele indivíduo. É uma medida relativa à morfologia do sujeito, representando o deslocamento máximo possível da pele e tecidos.\[3, 15\]

Este escalonamento é fundamental para a análise de incoerência: uma discrepância entre uma afirmação verbal de alta intensidade ("Estou furioso!") e uma AU 23 ou 24 de intensidade "A" sugere que a emoção não é genuinamente sentida ou está sendo simulada para efeito dramático.\[5, 19\] Além da intensidade, o FACS incorpora modificadores de lateralidade:

para direita,

para esquerda,

para unilateral sem lado especificado, e

para bilateral mas assimétrico.\[3, 14, 15\] A assimetria é um parâmetro técnico vital; expressões emocionais espontâneas e intensas tendem a ser bilaterais e simétricas, enquanto expressões forçadas ou controladas (como o escárnio) são frequentemente mais fortes em um lado da face.\[20, 21, 22\]

A Dimensão Temporal: Onset, Apex e Offset na Autenticidade Comportamental

A análise estática de fotografias é insuficiente para capturar a complexidade do comportamento humano. Por isso, o FACS moderno enfatiza a dinâmica temporal da expressão, dividindo cada evento em fases cronológicas precisas que servem como parâmetros de autenticidade.\[18, 23, 24\]

As expressões faciais são processos dinâmicos que evoluem através de três estágios:

#### Início (Onset):

O intervalo entre o estado neutro e o início da estabilização da intensidade máxima. Um

muito rápido (menos de 100ms) pode indicar uma reação reflexiva ou uma microexpressão, enquanto um

artificialmente lento pode sugerir uma expressão deliberadamente construída.\[11, 23, 25\]

Ápice (Apex):

O período durante o qual a contração muscular mantém sua intensidade máxima. Em expressões genuínas, o ápice tende a ser estável e fluido. Flutuações na intensidade durante o ápice ("multi-apex") podem sinalizar ambivalência emocional ou a tentativa de suprimir a expressão.\[23, 24, 26\]

#### Fim (Offset):

O retorno da face ao estado neutro ou a transição para uma nova AU. Sorrisos que "desligam" abruptamente (curto

) são universalmente percebidos como menos autênticos e menos confiáveis do que aqueles que desaparecem gradualmente.\[11, 23\]

Estudos indicam que a percepção de autenticidade está diretamente ligada à trajetória dinâmica. Por exemplo, em entrevistas de emprego, candidatos cujos sorrisos exibiam

longos foram julgados como mais competentes e motivados do que aqueles com sorrisos de transição rápida.\[11\] Esta métrica temporal é o que permite detectar o "sorriso de Martin Scorsese" no Oscar de 2003, citado na literatura como um exemplo clássico de falsidade porque a transição da decepção para o sorriso ocorreu em milissegundos, violando as expectativas perceptivas de uma resposta emocional orgânica.\[11\]

Microexpressões e o Vazamento de Emoções Ocultas

As microexpressões representam um dos parâmetros mais sofisticados do FACS para a detecção de incoerência. Definidas como expressões completas ou fragmentadas que duram entre

de segundo, elas são o resultado de uma falha momentânea no sistema de inibição cortical.\[27, 28, 29\] Quando um indivíduo tenta esconder um sentimento — por exemplo, ocultando a raiva sob uma máscara de calma durante uma negociação — a emoção reprimida "vaza" através de uma microexpressão rápida de AU 4 ou AU 23.\[5\]

O reconhecimento dessas microexpressões exige um treinamento técnico exaustivo, geralmente superior a 100 horas, pois o olho humano médio não está habituado a processar informações visuais nessa velocidade.\[7, 8, 16\] O FACS mapeia esses vazamentos identificando "unidades de ação competidoras": a presença simultânea de AUs de felicidade (AU 12) e traços de AUs de tristeza (AU 1 ou 15) ou nojo (AU 9) é o indicador técnico definitivo de que a expressão apresentada é uma "máscara".\[5\] A análise quadro a quadro de vídeos em alta velocidade é a ferramenta padrão para capturar esses eventos, permitindo identificar o momento exato em que a verdade emocional sobrepõe-se à narrativa verbal.\[7, 29\]

Combinações de Unidades de Ação e a Classificação de Emoções Universais

Embora o FACS tenha sido projetado para ser puramente descritivo, sua aplicação mais comum é o mapeamento das sete emoções universais identificadas por Ekman através de culturas diversas. Para isso, utiliza-se o EMFACS (Emotion FACS), um subconjunto de regras que identifica combinações específicas de AUs que sinalizam estados afetivos prototípicos.\[8, 30\]

Emoção Universal

Combinações de Unidades de Ação (AUs)

Insights Técnicos e Marcadores de Coerência

O "Duchenne Marker" (AU 6) é essencial. Sem a contração da pálpebra inferior e a elevação da bochecha, o sorriso é classificado como voluntário/não-sentido. \[3, 7\]

A elevação oblíqua das sobrancelhas internas (AU 1) combinada com o abaixamento dos cantos da boca (AU 15) é quase impossível de falsificar com precisão. \[3, 7\]

1 + 2 + 5 + 26/27

Caracterizada por um movimento rápido e simétrico. Se durar mais de um segundo, é provável que seja uma paródia ou surpresa fingida. \[3, 7, 15\]

1 + 2 + 4 + 5 + 7 + 20 + 25

Combina o arregalar de olhos (AU 5) com o esticamento horizontal dos lábios (AU 20), criando uma tensão facial multidirecional. \[3, 7, 15\]

4 + 5 + 7 + 23/24

O foco está no olhar fixo (AU 5/7) e no estreitamento dos lábios (AU 23), que sinaliza a preparação para a agressão ou a supressão do grito. \[3, 7\]

9 / 10 + 17

O enrugamento do nariz (AU 9) é o sinal mais confiável. A AU 10 é frequentemente usada como uma versão mais leve ou controlada do nojo. \[3, 7, 15\]

R12A / R14A (Unilateral)

É a única emoção universal definida por sua assimetria. O puxão unilateral do canto da boca é o marcador técnico do desdém. \[3, 7, 15\]

A identificação dessas combinações permite não apenas classificar a emoção, mas também medir sua pureza. Combinações que misturam elementos de duas emoções (como 6+12+1+4) são codificadas como "blends" ou mesclas emocionais, comuns em situações de nostalgia (alegria e tristeza) ou crueldade (alegria e raiva).\[17, 18, 30\] A precisão do FACS em distinguir essas misturas é o que o torna superior a sistemas categóricos simples.\[5, 17, 19\]

Detecção de Incoerências entre Expressão Facial e Discurso Verbal

A detecção de incoerências é a aplicação prática mais crítica do FACS em contextos forenses, clínicos e de segurança. O sistema parte do princípio de que o rosto e a voz são canais de comunicação paralelos que, em estados de honestidade, devem exibir sincronia e redundância.\[1, 7, 26\] Quando ocorre uma dissonância, o FACS fornece parâmetros para identificar onde a falha está ocorrendo.

Marcadores de Engano e Conflito

#### Dessincronia de Tempo:

Em uma reação genuína, a expressão facial começa frações de segundo antes da fala ou simultaneamente a ela. Se uma pessoa afirma estar "muito surpresa" e a expressão de surpresa (AUs 1+2+5) aparece apenas após o início da frase, há uma incoerência técnica na integração sensório-motora, sugerindo que a expressão foi fabricada após o processamento cognitivo da mentira.\[11, 24\]

#### Morfologia do Sorriso:

O uso de sorrisos como máscaras é o tipo mais comum de vazamento. O FACS identifica o "sorriso falso" pela ausência da AU 6 e pela presença de microexpressões de AUs antagônicas, como o tensionamento das pálpebras (AU 7) ou a compressão dos lábios (AU 24), que revelam o esforço para conter a verdadeira emoção negativa.\[5\]

#### Vazamento em Músculos Confiáveis:

Como a AU 1 (sobrancelha interna) e a AU 23 (lábio estreitado) são difíceis de controlar voluntariamente, sua aparição durante um discurso de teor neutro ou positivo é um indicador de "vazamento emocional". Isso ocorre porque o sistema extrapiramidal dispara a contração muscular antes que o controle consciente (piramidal) consiga suprimi-la totalmente.\[7\]

#### Assimetria e Sincronia Bilateral:

Expressões de emoções verdadeiras tendem a ser mais simétricas. A detecção de uma AU 12 ou AU 14 significativamente mais forte em um lado da face durante um depoimento pode indicar que o indivíduo está sentindo desprezo pela situação ou pelo interrogador, contradizendo um discurso de cooperação.\[20, 21, 22\]

Esses parâmetros permitem que o FACS alcance uma precisão de até 80% na detecção de decepção em estudos controlados, superando largamente a intuição de observadores não treinados.\[7\] A técnica exige que o codificador monitore constantemente o "nível de base" (baseline) do sujeito, para garantir que características anatômicas permanentes não sejam confundidas com sinais de incoerência.\[2, 12\]

Parâmetros de Superfície: Mapeamento de Rugas, Sulcos e Deformações Cutâneas

A codificação manual do FACS depende da observação detalhada das mudanças na topografia da face. O manual descreve "sinais de aparência" específicos para cada Unidade de Ação, que servem como evidência física da contração muscular oculta.\[9, 16, 31\]

Elemento Topográfico

Unidade de Ação (AU) Associada

Significado Técnico na Codificação

Rugas da Fronte

AU 1 e AU 2

A AU 1 cria rugas horizontais curtas no centro; a AU 2 cria rugas que atravessam toda a testa. A distinção valida qual parte do frontal está ativa. \[9, 13, 32\]

Rugas Glabelares

Rugas verticais ou oblíquas entre as sobrancelhas. Sua profundidade é usada para medir a intensidade de estados de concentração ou dor. \[9, 16, 31\]

Pés de Galinha

Rugas radiantes dos cantos externos dos olhos. Essencial para validar a autenticidade do sorriso e da dor. \[3, 9, 31\]

Sulco Nasolabial

AU 9, 10, 11, 12

O sulco aprofunda-se e muda de forma. Na AU 9, ele sobe em direção ao nariz; na AU 12, ele é puxado para fora em uma curva. \[10, 12, 17\]

Protuberância do Queixo

A pele do queixo assume uma textura granulada ou empurrada para cima. Indicador de dúvida, tristeza ou esforço físico. \[3, 12, 33\]

Estes sinais são fundamentais porque o FACS ignora mudanças de cor (rubor), lágrimas ou suor, concentrando-se puramente na deformação mecânica do tecido.\[4, 14\] Em indivíduos mais velhos, onde rugas permanentes estão presentes, o codificador deve procurar o aprofundamento dessas rugas ou a criação de novas dobras transitórias para marcar a ocorrência de uma AU.\[2, 9, 12\] A análise automatizada por computador utiliza filtros de frequência para detectar essas mudanças de textura em microescala, permitindo a identificação de movimentos de intensidade "A" que seriam invisíveis a olho nu.\[1, 5, 32\]

Mapeamento Digital e Automação: O Futuro da Codificação Facial

Devido à natureza laboriosa da codificação manual, houve um impulso massivo para automatizar o FACS através da visão computacional e inteligência artificial. Este campo introduziu novos parâmetros técnicos baseados em grafos faciais e landmarks geométricos.\[18, 26, 34\]

O Padrão de 68 Pontos de Referência (Landmarking)

A automação moderna mapeia a face em uma grade de 68 pontos (landmarks), que cobrem as sobrancelhas, os olhos, o nariz, os lábios e o contorno da mandíbula.\[34, 35, 36, 37\]

#### O mapeamento técnico das AUs para esses pontos segue algoritmos matemáticos:

#### Vectores de Deslocamento:

A ativação da AU 1 é medida pela mudança na coordenada

dos pontos 20, 21, 22, 23, 24 e 25 em relação ao ponto de referência central do nariz.\[34\]

#### Geometria de Distância Euclidiana:

A distância

entre os pontos da pálpebra superior e inferior é usada para codificar a AU 5 (aumento da distância) ou AU 7/43 (diminuição da distância).\[26, 34\]

#### Cálculo de Gradientes:

A curvatura dos lábios (AU 12 vs AU 15) é determinada pelo gradiente de inclinação entre o centro da boca (ponto 62/66) e os cantos (ponto 48/54).\[34\]

Para sistemas de tempo real, a eficiência é aumentada através da remoção de redundância. Em vez de rastrear todos os 3.083 segmentos possíveis entre os 68 pontos, algoritmos otimizados focam em cerca de 1.178 segmentos únicos que possuem a maior correlação estatística com a ativação das AUs principais.\[34\] Modelos baseados em Deep Learning, como Redes Neurais Convolucionais (CNNs) e LSTMs, são então treinados nesses dados para reconhecer não apenas a presença de uma AU, mas também sua intensidade e fase temporal com precisão que rivaliza com especialistas humanos.\[18, 26, 34\]

Aplicações Clínicas, Científicas e as Limitações do Sistema

O FACS não é apenas uma ferramenta de laboratório; ele possui aplicações vastas que demonstram a profundidade da informação revelada pela face. Na medicina, o FACS tem sido fundamental para o desenvolvimento do Pain Catastrophizing Scale e de sistemas automáticos de detecção de dor, permitindo que profissionais de saúde monitorem o sofrimento em pacientes que não podem se comunicar, como recém-nascidos ou idosos com demência avançada.\[3, 16, 31\]

Em psiquiatria, o sistema é utilizado para identificar "afeto plano" em pacientes esquizofrênicos ou para prever a remissão de depressão grave, observando a reativação de AUs de felicidade genuína (AU 6+12) em resposta a estímulos positivos.\[7, 16, 19\] Na antropologia, o FACS permitiu provar a universalidade das expressões emocionais, comparando as AUs de populações isoladas na Nova Guiné com as de estudantes universitários no Japão e nos Estados Unidos, demonstrando que o "alfabeto facial" é uma característica biológica da espécie humana, e não apenas um aprendizado cultural.\[38, 39\]

Limitações Estruturais e Considerações Éticas

Apesar de sua abrangência, o FACS possui limitações técnicas claras. Ele é um sistema de medição do "veículo do sinal" (o que a face faz), e não um leitor de mentes. A inferência do "significado da mensagem" (o que a pessoa sente) deve ser feita com cautela, integrando o contexto situacional e as variações individuais de personalidade.\[6, 39\] Além disso, o FACS não captura:

#### Vasodilatação:

O rubor de vergonha ou a palidez de choque, que são sinais autonômicos potentes.\[4, 14\]

#### Sinais Oculares Sutis:

Exceto pela abertura palpebral e direção do olhar, ele não mede a dilatação da pupila, um indicador chave de excitação e carga cognitiva.\[3, 4, 14\]

#### Variações Macroscópicas:

Como suor, lágrimas ou secreções, que frequentemente acompanham emoções extremas.\[4, 14\]

A ética na aplicação do FACS, especialmente em sistemas automatizados de vigilância ou recrutamento, é um tema de debate crescente. A capacidade de detectar microexpressões sem o consentimento ou conhecimento do indivíduo levanta questões sobre privacidade mental e o direito à "máscara social", essencial para a convivência humana equilibrada.\[7\]

Conclusões sobre a Sistematização do Comportamento Facial

A arquitetura do Facial Action Coding System transformou o rosto humano de uma "caixa preta" de mistérios emocionais em um sistema de dados legível e quantificável. Através do mapeamento exaustivo das Unidades de Ação, o FACS fornece os parâmetros técnicos necessários para decompor a complexidade das expressões em elementos binários e graduais, permitindo uma análise científica sem precedentes da comunicação não verbal.\[2, 3, 18\]

A verdadeira potência do sistema não reside apenas na classificação das sete emoções universais, mas na sua capacidade de revelar a estrutura da mentira e do conflito interno. Ao monitorar a intensidade, a simetria e a dinâmica temporal das AUs, o FACS expõe a assincronia entre o que é dito e o que é sentido, servindo como uma ferramenta indispensável para qualquer campo que dependa da compreensão da verdade humana. Seja através de codificadores humanos treinados por centenas de horas ou de algoritmos de inteligência artificial baseados em 68 landmarks, o legado de Paul Ekman continua a ser o padrão definitivo para ler os sinais mais íntimos e automáticos que nossa biologia projeta para o mundo exterior.

--------------------------------------------------------------------------------

Classifying Facial Actions - PMC - NIH,

https://pmc.ncbi.nlm.nih.gov/articles/PMC3008166/

https://pmc.ncbi.nlm.nih.gov/articles/PMC3008166/

CalliFACS: The common marmoset Facial Action Coding System - PMC - NIH,

https://pmc.ncbi.nlm.nih.gov/articles/PMC9113598/

https://pmc.ncbi.nlm.nih.gov/articles/PMC9113598/

Facial Action Coding System - Wikipedia,

https://en.wikipedia.org/wiki/Facial\_Action\_Coding\_System

https://en.wikipedia.org/wiki/Facial\_Action\_Coding\_System

Facial Action Coding System,

https://web.cs.wpi.edu/~matt/courses/cs563/talks/face\_anim/ekman.html

https://web.cs.wpi.edu/~matt/courses/cs563/talks/face\_anim/ekman.html

Facial Action Coding System Emily B. Prince, Katherine B. Martin ...,

https://local.psy.miami.edu/faculty/dmessinger/c\_c/rsrcs/rdgs/emot/FACSChapter\_SAGEEncyclopedia.pdf

https://local.psy.miami.edu/faculty/dmessinger/c\_c/rsrcs/rdgs/emot/FACSChapter\_SAGEEncyclopedia.pdf

More about FACS — Erika Rosenberg, Ph.D.,

https://www.erikarosenberg.com/more-about-facs

https://www.erikarosenberg.com/more-about-facs

Facial Action Coding System (FACS) Explained - EmotionIntell - EIA Group,

https://www.eiagroup.com/resources/facial-expressions/facial-action-coding-system-facs/

https://www.eiagroup.com/resources/facial-expressions/facial-action-coding-system-facs/

Facial Action Coding System - Paul Ekman Group,

https://www.paulekman.com/facial-action-coding-system/

https://www.paulekman.com/facial-action-coding-system/

Untitled - Paul Ekman Group,

https://www.paulekman.com/wp-content/uploads/2013/07/Classifying-Facial-Action.pdf

https://www.paulekman.com/wp-content/uploads/2013/07/Classifying-Facial-Action.pdf

FACS (Facial Action Coding System),

https://www.cs.cmu.edu/~face/facs.htm

https://www.cs.cmu.edu/~face/facs.htm

The Temporal Dynamics of Facial Expressions | Emotion Researcher,

https://emotionresearcher.com/the-temporal-dynamics-of-facial-expressions/

https://emotionresearcher.com/the-temporal-dynamics-of-facial-expressions/

Facial Action Coding System | PDF | Nature - Scribd,

https://www.scribd.com/document/325603628/Facial-Action-Coding-System-1

https://www.scribd.com/document/325603628/Facial-Action-Coding-System-1

Facial Action Coding System (FACS) Cheat Sheet,

https://melindaozel.com/facs-cheat-sheet/

https://melindaozel.com/facs-cheat-sheet/

The Facial Action Coding System for Characterization of Human ...,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full

FACS (Facial Action Coding System) - RealEye.io,

https://www.realeye.io/features/online-webcam-facial-coding/facial-action-coding-system-facs

https://www.realeye.io/features/online-webcam-facial-coding/facial-action-coding-system-facs

Machine Perception Laboratory,

https://inc.ucsd.edu/mplab/grants/project1/research/face-detection.html

https://inc.ucsd.edu/mplab/grants/project1/research/face-detection.html

Recognizing Action Units for Facial Expression Analysis - PMC,

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/

Facial Action Coding System Overview - Emergent Mind,

https://www.emergentmind.com/topics/facial-action-coding-system-facs

https://www.emergentmind.com/topics/facial-action-coding-system-facs

Automated Facial Action Coding System for Dynamic Analysis of Facial Expressions in Neuropsychiatric Disorders - PMC,

https://pmc.ncbi.nlm.nih.gov/articles/PMC3402717/

https://pmc.ncbi.nlm.nih.gov/articles/PMC3402717/

Determining the threshold for asymmetry detection in facial expressions - PMC - NIH,

https://pmc.ncbi.nlm.nih.gov/articles/PMC4392713/

https://pmc.ncbi.nlm.nih.gov/articles/PMC4392713/

Leveraging Symmetry and Addressing Asymmetry Challenges for Improved Convolutional Neural Network-Based Facial Emotion Recognition - MDPI,

https://www.mdpi.com/2073-8994/17/3/397

https://www.mdpi.com/2073-8994/17/3/397

Facial Asymmetry: A New Biometric - Carnegie Mellon University Robotics Institute,

https://www.ri.cmu.edu/pub\_files/pub2/liu\_yanxi\_2001\_2/liu\_yanxi\_2001\_2.pdf

https://www.ri.cmu.edu/pub\_files/pub2/liu\_yanxi\_2001\_2/liu\_yanxi\_2001\_2.pdf

Dynamics of facial actions for assessing smile genuineness - PMC,

https://pmc.ncbi.nlm.nih.gov/articles/PMC7785114/

https://pmc.ncbi.nlm.nih.gov/articles/PMC7785114/

Variable-state Latent Conditional Random Fields for Facial Expression Recognition and Action Unit Detection - iBUG,

https://ibug.doc.ic.ac.uk/media/uploads/bv\_cvxbook.pdf

https://ibug.doc.ic.ac.uk/media/uploads/bv\_cvxbook.pdf

A dynamic approach to the recognition of 3D facial expressions and their temporal models - SciSpace,

https://scispace.com/pdf/a-dynamic-approach-to-the-recognition-of-3d-facial-uszrpszv1u.pdf

https://scispace.com/pdf/a-dynamic-approach-to-the-recognition-of-3d-facial-uszrpszv1u.pdf

Efficient Dynamic Emotion Recognition from Facial Expressions Using Statistical Spatio-Temporal Geometric Features - MDPI,

https://www.mdpi.com/2504-2289/9/8/213

https://www.mdpi.com/2504-2289/9/8/213

Effects of the duration of expressions on the recognition of microexpressions - PMC - NIH,

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/

https://pmc.ncbi.nlm.nih.gov/articles/PMC3296074/

Demystifying Mental Health by Decoding Facial Action Unit Sequences - MDPI,

https://www.mdpi.com/2504-2289/8/7/78

https://www.mdpi.com/2504-2289/8/7/78

Spontaneous Facial Expressions and Micro-expressions Coding: From Brain to Face,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full

FACS – Knowledge and References - Taylor & Francis,

https://taylorandfrancis.com/knowledge/Engineering\_and\_technology/Biomedical\_engineering/FACS/

https://taylorandfrancis.com/knowledge/Engineering\_and\_technology/Biomedical\_engineering/FACS/

Quantifying pain in humans using the Index of Facial Pain Expression (IFPE) Kenneth M. Prkachin Joshua Rash University of Northe,

https://psyc.ucalgary.ca/ifpe/e/images/IFPE%20Manual.pdf

https://psyc.ucalgary.ca/ifpe/e/images/IFPE%20Manual.pdf

Classifying Facial Action,

https://proceedings.neurips.cc/paper/1116-classifying-facial-action.pdf

https://proceedings.neurips.cc/paper/1116-classifying-facial-action.pdf

What Is The Core Value Of Automated Facial Landmark Detection? Eliminate Bias & Boost Clinical Precision - HonestBee,

https://honestbeeltd.com/faqs/what-is-the-core-value-of-automated-facial-landmark-detection-algorithms-compared-to-manual-annotation-in-clinical-research

https://honestbeeltd.com/faqs/what-is-the-core-value-of-automated-facial-landmark-detection-algorithms-compared-to-manual-annotation-in-clinical-research

FACS-Based Graph Features for Real-Time Micro-Expression ...,

https://pmc.ncbi.nlm.nih.gov/articles/PMC8321161/

https://pmc.ncbi.nlm.nih.gov/articles/PMC8321161/

Face landmark detection guide | Google AI Edge,

https://ai.google.dev/edge/mediapipe/solutions/vision/face\_landmarker

https://ai.google.dev/edge/mediapipe/solutions/vision/face\_landmarker

Landmark-Based Facial Feature Construction and Action Unit Intensity Prediction,

https://www.researchgate.net/publication/350032444\_Landmark-Based\_Facial\_Feature\_Construction\_and\_Action\_Unit\_Intensity\_Prediction

https://www.researchgate.net/publication/350032444\_Landmark-Based\_Facial\_Feature\_Construction\_and\_Action\_Unit\_Intensity\_Prediction

Facial Expression Recognition using Facial Landmarks: A novel approach - Advances in Science, Technology and Engineering Systems Journal,

https://www.astesj.com/publications/ASTESJ\_050504.pdf

https://www.astesj.com/publications/ASTESJ\_050504.pdf

Facial-Expression.pdf - Paul Ekman Group,

https://www.paulekman.com/wp-content/uploads/2013/07/Facial-Expression.pdf

https://www.paulekman.com/wp-content/uploads/2013/07/Facial-Expression.pdf

The Facial Expression Coding System (FACES): A Users Guide - University of California, Berkeley,

https://esilab.berkeley.edu/wp-content/uploads/2017/12/FACES-manual.pdf

https://esilab.berkeley.edu/wp-content/uploads/2017/12/FACES-manual.pdf

