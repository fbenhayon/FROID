# FROID_Plano_Financeiro_DEFINITIVO.docx

Frequency Recognition of Internal Dynamics

Plano Financeiro Definitivo

Fluxo de Caixa, Precificação e Valor por Consulta

20 dias úteis | Máximo 6 consultas/dia | Câmbio 1 USD = R$ 5,00

Versão Final — Abril 2026 — Confidencial

1. Síntese Executiva

Investimento inicial necessário

Break-even EBITDA mensal

Mês 14 (~280 profissionais)

Payback do investimento

Mês 20 (~760 profissionais)

MRR no mês 24

R$ 1.762.000

ARR projetado (mês 24 anualizado)

R$ 21.144.000

EBITDA no mês 24

R$ 915.155 (52% margem)

Caixa acumulado no mês 24

R$ 3.132.453

Margem bruta média (assinatura)

Margem bruta média (avulso)

Número de profissionais no mês 24

2. Custo Variável por Sessão — Cálculo Final (50 min)

Todos os valores em USD foram multiplicados pelo câmbio de R$ 5,00. Os custos abaixo representam o custo marginal de cada sessão adicional para o FROID.

Profissional

Análise Facial

Análise Vocal

NLP / Linguagem

Transcrição (Whisper)

GPU Compute

Armazenamento

Infraestrutura (rateio)

CUSTO TOTAL / SESSÃO

3. Precificação Comercial Final
3.1 Tabela de Preços

Profissional

Assinatura mensal

Sessões inclusas / mês

Preço avulso / sessão excedente

Custo efetivo / sessão na assinatura

Margem bruta (avulso)

Margem bruta (assinatura)

3.2 Lógica das Sessões Inclusas

#### As sessões inclusas foram calibradas com base no volume médio e na margem-alvo:

Essencial (40 sessões): cobre 2 consultas/dia em 20 dias úteis. Profissional com agenda leve opera 100% dentro da assinatura

Profissional (30 sessões): deliberadamente abaixo da média para gerar receita de excedentes (R$ 69,90/sessão com margem de 69%). Um profissional com 3 consultas/dia usará 60 sessões, pagando 30 excedentes = R$ 2.097 adicional

Premium (40 sessões): mesmo número do Essencial, mas o alto valor da assinatura (R$ 3.997) já garante margem de 58% mesmo com uso pleno

4. Custo FROID por Consulta — Todos os Cenários

A tabela abaixo mostra o custo FROID que o profissional paga por cada consulta realizada, considerando a assinatura mensal + sessões excedentes. Premissa: 20 dias úteis por mês, máximo 6 consultas/dia (120/mês).

4.1 Plano Essencial (R$ 297/mês, 40 sessões inclusas)

Consultas/mês

Custo total/mês

CUSTO / CONSULTA

% de consulta R$ 250

% de consulta R$ 400

% de consulta R$ 600

CONCLUSÃO: O Plano Essencial nunca ultrapassa 4,4% do valor de qualquer consulta. Viável para 100% dos profissionais.

4.2 Plano Profissional (R$ 1.497/mês, 30 sessões inclusas)

Consultas/mês

Custo total/mês

CUSTO / CONSULTA

% de consulta R$ 250

% de consulta R$ 400

% de consulta R$ 600

% de consulta R$ 1.000

CONCLUSÃO: Recomendado para consultas a partir de R$ 400 (impacto de 13-16%). Ideal para consultas R$ 600+ (impacto < 11%).

4.3 Plano Premium (R$ 3.997/mês, 40 sessões inclusas)

Consultas/mês

Custo total/mês

CUSTO / CONSULTA

% de consulta R$ 400

% de consulta R$ 600

% de consulta R$ 800

% de consulta R$ 1.000

CONCLUSÃO: Exclusivo para psiquiatras e clínicas premium com consultas acima de R$ 800 (impacto 12-16%). Em consultas de R$ 1.000+, o impacto fica na faixa de 10-13%.

5. Fluxo de Caixa — Marcos Principais

R$ 1.081.620

R$ 1.762.000

Caixa acum.

Quase break-even

5.1 Necessidade de Capital

O ponto de maior consumo de caixa (vale da morte) ocorre no mês 14, quando o caixa acumulado atinge R$ -1.527.949. Considerando o investimento inicial de R$ 500.000, o projeto necessita de capital total de R$ 1.53 milhões para sobreviver até o payback. Isso pode ser financiado com:

Investimento seed de R$ 500.000 + rodada pré-Series A de R$ 1.000.000 no mês 6-8

Ou investimento único de R$ 1.600.000 com reserva de contingência

Ou modelo bootstrapped com lançamento apenas do Plano Essencial (menor queima de caixa)

5.2 Cenário Bootstrap — Apenas Plano Essencial

Se o FROID lançar inicialmente apenas o Plano Essencial (100% open-source, custo de R$ 3,05/sessão), o custo variável cai drasticamente. Com 200 profissionais pagando R$ 297/mês, a receita mensal seria R$ 59.400 com custo variável de apenas R$ 5.124 (uso médio de 60 sessões por profissional × R$ 3,05 × 0,70 uso × 40 sessões). A margem bruta de 91% nesse cenário permite break-even com custos fixos reduzidos (equipe menor) em apenas 80-100 profissionais.

6. Recomendação Final de Precificação
6.1 Regra de Ouro para o Profissional

O FROID deve representar no máximo 10% do valor da consulta do profissional para ser sustentável. Com base nesse princípio:

Plano FROID

Valor Mínimo da Consulta

Público Ideal

Impacto no Preço

Todo profissional de saúde mental

Acrescentar R$ 10–15 à consulta

Profissional

Psiquiatras, psicólogos com consulta R$ 400+

Acrescentar R$ 50–70 à consulta

Clínicas premium, psiquiatras de alto valor

Acrescentar R$ 100–140 à consulta

6.2 Estratégia de Go-to-Market

FASE 1 (Mês 1-6): Lançar somente o Plano Essencial a R$ 297/mês. Margem altíssima (91% bruta), baixo risco, valida product-market fit

FASE 2 (Mês 7-12): Adicionar Plano Profissional a R$ 1.497/mês com integração Hume AI. Oferecer 30 dias gratuitos do Profissional para assinantes Essencial

FASE 3 (Mês 13-18): Lançar Plano Premium a R$ 3.997/mês. Focar em clínicas e instituições com vendas consultivas

Desconto anual: 2 meses grátis na assinatura anual (equivale a 17% de desconto)

Early adopters (100 primeiros): 40% de desconto nos primeiros 6 meses

6.3 Métricas de Acompanhamento

CAC (Custo de Aquisição de Cliente): alvo < R$ 1.500 no Essencial, < R$ 5.000 no Profissional

LTV (Lifetime Value): alvo > 12 meses de retenção = LTV Essencial R$ 3.564 | Prof R$ 17.964 | Premium R$ 47.964

LTV/CAC: alvo > 3x para todos os planos

Churn mensal: alvo < 5% para Essencial, < 3% para Profissional e Premium

NPS (Net Promoter Score): alvo > 50

FROID — Plano Financeiro Definitivo v1.0

Abril 2026 — Confidencial

