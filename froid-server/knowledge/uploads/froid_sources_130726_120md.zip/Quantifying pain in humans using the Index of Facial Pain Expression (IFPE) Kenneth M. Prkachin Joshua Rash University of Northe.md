# Quantifying pain in humans using the Index of Facial Pain Expression (IFPE) Kenneth M. Prkachin Joshua Rash University of Northe

https://psyc.ucalgary.ca/ifpe/e/images/IFPE%20Manual.pdf

Quantifying pain in humans using the Index of Facial Pain Expression (IFPE)

Kenneth M. Prkachin

Joshua Rash

University of Northern British Columbia

Chapter 1.  Detecting and quantifying the facial expression of pain

For more than two decades, scientists have conducted intensive and detailed analyses of the facial expression of pain (see Craig, Prkachin & Grunau, in press, for a general review).  This work has been pursued for a variety of reasons.  In early studies, investigators sought a means of quantifying pain that was more objective than more commonly used measures, such as verbal reports and pain thresholds.  There was also a desire to explore methods that were thought to be less susceptible to conscious and willing distortion.  In the latter part of the 20th century, this interest paralleled the rapid growth of the field of emotion, in which investigations began to make heavy use of measures of facial expression.

As this interest developed, more scientists and clinicians were drawn to the topic as it became apparent that the communication of pain by changes in facial expression could be important in health care and more broadly in social interaction (Prkachin & Craig, 1994; Prkachin, 2009, Williams, 2002).  Substantive questions, such as how early do infants register pain (Grunau & Craig, 1987) or how can we infer its presence in people with verbal communication disorders (Hadjistavropoulos, LaChappelle, MacLeod, Snider & Craig, 2000; Kunz, Scharmann, Hemmeter, Schepelmann,  & Lautenbacher, 2007) appeared to be addressable at least in part by analysis of facial expression.

Two key methodological developments were critical for the development of this area.  The first was technological: the development of widely-available video recording technology.  The availability of a means for recording and preserving events involving pain at a reasonable price, along with increasingly sophisticated abilities, such as frame-by-frame analysis, computerized enhancement and the boom in development of software made an increasing variety of applications and increasing sophistication available to most investigators with a modest budget.  The second was the development of systematic protocols for reducing the complexity of facial actions to reliable quantification.  The Facial Action Coding System (FACS; Ekman & Friesen, 1978) was one of two comprehensive systems developed in the 1970’s to facilitate observation, quantification and study of the face.  The other system, developed by Carroll Izard, called the Maximally Discriminative Facial Coding System , or MAX (Izard, 1979), had similar objectives but followed a different set of principles for rendering observations and quantification.  Although MAX provided a set of codes for pain, the FACS system, for a variety of reasons, was preferentially adopted by pain researchers and has provided the basis for the most influential studies in this field.

FACS identifies 44 actions that the face is capable of performing.  The actions are defined in terms of the underlying muscular actions that go into producing them and descriptions of the appearance changes that they produce on the face.  Any facial

action is thus “decomposed” into its constituent units by an observer who has undergone specific and intensive training in their identification.  FACS provides a basis for both identifying individual actions contributing to a facial expression and quantifying them according to their magnitude.

The bulk of the research that has addressed the question of how the face communicates information about pain has done so by applying FACS to records of people experiencing pain.  Although there is some variation from study to study in what actions appear as most likely when people are experiencing pain, there is a general consensus that a limited and distinct set of actions is involved.  This manual is based on the system that we have developed in our laboratory over the years (Prkachin, 1992; Prkachin & Solomon, 2008; Rocha, Prkachin, Beaumont,  Hardy, & Zumbo, 2003) .  It is possible to work from the published literature and use FACS to code for pain expression.  However, FACS is a laborious procedure, requiring many hours to learn the system.  It is probably even more challenging to apply than to learn as it requires great perceptual acuity and the application of many complex decisions.  Given that the bulk of information about pain that is conveyed by the face is available in a limited number of actions, it is both possible and desirable to move toward a system of reduced complexity and burden.  This manual and training program represent our attempt to do so.

Chapter 2.  The principles of coding using the Index of Facial Pain Expression

Numerous studies, including our own, have employed the Facial Action Coding System (FACS) to catalogue the changes that take place on the face when a person is in pain.  There is considerable agreement about the nature of the changes that occur on the face that encode and communicate pain, although there are some areas in which studies are not entirely consistent (see Craig, Prkachin & Grunau, in press; Prkachin, 1992; Prkachin & Solomon, 2008, Williams, 2002).

The IFPE is derived from this literature and consequently is based on the same general principles as FACS.  Using FACS, observers decompose any given action into its underlying muscular basis.  In other words, a facial action is observed and then, based on learning how the facial muscular anatomy produces facial appearance changes, the observer identifies which facial muscles or muscle groups produced the action.  In the FACS system, the appearance changes produced by individual muscles or groups of muscles acting in a unitary fashion are called Action Units (AUs). Observers do not code by labeling the muscles involved.  Rather, each AU has a unique number and description.  For example, encircling the eye opening (orbit) is a large muscle called orbicularis oculi.  Orbicularis oculi has two components, an inner and an outer ring, that can act separately.  The contraction of the inner ring muscle produces characteristic appearance changes among which are a narrowing of the eye opening and drawing of the skin beneath the eye in an upward and medial direction.  In the FACS system, this action is designated AU7: lid-tightener.  Contraction of the outer component of the ring muscle produces similar, but identifiably distinct changes—most notably features like crows' feet wrinkles and an upward-drawing motion of the cheek. This action is designated AU6: cheek-raiser.  Both AU6 and AU7 are involved in the expression of pain.

The other dimension identified in FACS is the intensity of facial actions.  The appearance changes produced by actions of the facial muscles range from barely perceptible, through obvious to extreme.  In the expression of facial emotions and related states, intensity is potentially of great importance; perhaps nowhere moreso than in the facial expression of pain.  The IFPE includes provisions for gauging the intensity of facial expressions of pain that are also based on the principles of FACS.

In using FACS to study the facial expression of pain, it has been our desire to develop a technique that is simplified, less time-consuming and, ideally, possible to apply reliably in real time.  The IFPE takes steps in this direction by limiting focus to only those actions that the empirical literature consistently shows are linked in a quantitative manner with pain.  On empirical and conceptual grounds, it also collapses some distinctions that are made in FACS.  For example, as noted above, in FACS a distinction is made between AUs 6 (Cheek Raise) and 7 (Lid Tighten).  In the empirical literature,

both actions have been shown to encode pain.  Students learning FACS often have considerable difficulty distinguishing the actions reliably.  For this reason, and also because both actions are based on action of the same underlying muscle, the IFPE allows the observer to ignore the often-subtle appearance change distinctions between these two AUs.  Instead, a more generic action called "orbit tightening" is identified.

Thus, the IFPE requires the observer to identify the presence and intensity of four facial actions: brow lowering (B), orbit tightening (O) levator tightening (L) and closing of the eye (C).  In order to learn and apply the system, it is first necessary to learn their FACS criteria.  In the sections that follow, each of the four core pain-related facial actions will be described, retaining close correspondence with the FACS system. FACS and the IFPE are visual processes and learning how to identify the requisite appearance changes requires visual examples.  Selected videos depicting the actions are used for this purpose.

In order to appreciate how individual action units are performed, it is necessary to understand a little of the facial anatomy.  Therefore, for each pain-related action, a brief characterization of the muscle groups involved will be presented, followed by a description of the key changes they produce in the appearance of the face.

Chapter 3: Pain-related action:  Brow lowering (FACS AU 4)

Figure 1, below, provides a schematic of the muscular bases of the brow lowering actions associated with pain and the nature of the movements that they produce.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Figure 1.  Muscular bases and actions of the brow-lowering movement (FACS AU 4). Lighter arrows show the direction of movement produced by AU4.  Figure adapted from

Ekman, P., Friesen, W.V. & Hager, J.C. (2002).  Facial Action Coding System.  The manual on CD ROM.  Salt Lake City, UT: Network Information Research Corporation.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Brow lowering is produced by three muscles in the upper face—depressor glabellae, depressor supercilii and corrugator.  Each muscle is fixed to the skull in the region of the area between the eyebrows.  The individual strands attach to the facial skin in the forehead, above the eyebrow, or more medially, closer to the center of the forehead and to the inner corner of each brow.  The muscular bases can be seen associated with the number 4 in the left panel of Figure 1.  The right panel shows the direction of the movements produced by this action.

#### The FACS-based appearance changes associated with this action include:

The eyebrows are lowered

The eyebrows are drawn closer together

Vertical wrinkles may appear between the eyebrows or deepen in people in whom they are permanent

An oblique wrinkle or bulge may appear, running from the middle of the forehead above the middle of the eyebrow to the inner corner of the brow

An example of brow lowering is given in Figure 2.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Figure 2.  Brow lowering.  Notice the apparent drawing down and together of the brows and the vertical wrinkle appearing between them.  The fourth appearance change— oblique wrinkling above the eyebrow is not present.  From Ekman, P., Friesen, W.V. &

Hager, J.C. (2002).  Facial Action Coding System.  The manual on CD ROM.  Salt Lake

City, UT: Network Information Research Corporation.  P. 17.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Intensity scoring.  All the pain-related actions vary in intensity.  The FACS system for scoring intensity describes the movements according to a five-point intensity scale, beginning with a “trace” of the action (A), a “slight” action (B) and ranging up to “maximum” (E).  Following are the specific FACS criteria for each intensity category:

A: the appearance changes indicating brow lowering are present, but not strong enough to score B

B: either the inner portion of the brow is lowered slightly or the brows are pulled together slightly

C:  the brows are lowered and pulled together.  Either one of the lowering or pulling together movements is marked.  The criteria for scoring intensity D are

D: the brows are lowered and pulled together and at least one is severe

E: the lowering or pulling together of the brows is at a maximum (i.e., you cannot

imagine how it could possibly be stronger).

The descriptions of the appearance changes defining the different intensity levels are somewhat subjective, but the distinctions can be made reliably with sufficient experience.  Effectively coding the intensity dimensions becomes possible only by exposure to examples.

To learn the distinctive changes in facial appearance that are produced by each of the pain-related facial actions, we have prepared a series of brief videos.  The videos show a model producing the action; beginning by displaying the basic movement and then going on to show differences in the intensity of the action.  We have tried to sample actions demonstrating the full intensity range from A to E; however, in some cases there are not examples of each intensity.  Studying these videos carefully will allow you to calibrate yourself.

\*\*On the IFPE website, please navigate your way to Module 1 → video 1 - brow

lowerer and review the first demonstration video showing the pain-related action of brow lowering now.\*\*

Chapter 4.  Pain-related action: Cheek Raising and Lid Compression (FACS AU 6)

Cheek raising and lid compression are produced by a muscle in the upper face – obicularis oculi (pars orbitalis). This is a circular band of muscle surrounding the outer eye orbit. The outer perimeter of this muscle extends into the eyebrow and below the lower eye furrow into the upper portion of the cheek. Constriction of this muscle diminishes its circumference, drawing skin from the temple and the cheeks towards the eyes. The muscular basis can be seen associated with the number 6 in the left panel of Figure 1. Figure 3, below, repeats the right hand panel of Figure 1, showing the directions of movement associated with contraction of orbicularis oculi, pars orbitalis. This muscle produces a unique facial action that is not to be confused with the muscle associated with the number 7 on the left panel of Figure 1.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Figure 3.  Muscular bases and actions of the cheek-raising/lid compression movement (FACS AU 6).  Lighter arrows show the direction of movement produced by AU 6.

Figure adapted from Ekman, P., Friesen, W.V. & Hager, J.C. (2002).  Facial Action Coding System.  The manual on CD ROM.  Salt Lake City, UT: Network Information

Research Corporation.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

#### The FACS-based appearance changes associated with this action include:

Skin is drawn towards the eye away from the temple and the cheeks

The infraorbital triangle (see below) is lifted, pulling the cheeks upward.

The skin surrounding the eye is pushed towards the eye socket, narrowing the eye aperture and wrinkling the skin below the eye.

Crow’s feet lines or wrinkles may appear, extending radially from the outer corners of the eye aperture.

The furrow of the lower eyelid deepens and the eyebrows lower.

An example of cheek raising/lid compression is given in Figure 4.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Figure 4.  Cheek raising/lid compression.  The principal evidence of this action is the prominent appearance of the infraorbital triangle, narrowing of the eye aperture, wrinkling of the skin below the eyes and furrowing of the lower eyelid.  From Ekman, P.,

Friesen, W.V. & Hager, J.C. (2002).  Facial Action Coding System.  The manual on CD ROM.  Salt Lake City, UT: Network Information Research Corporation.  P. 32.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Intensity scoring.

A: the appearance changes indicating cheek raising and lid compression are present, but not strong enough to score B

B: Marked change on either criterion 1 or 2 below or slight on both 1 and 2 is

sufficient to score B

1. Crow’s feet or wrinkles appear or become more prominent, or

2. The infraorbital triangle is raised.  This is indicated by cheek raising, deepening of the infraorbital furrow, bagging  or wrinkling under the eyes.

C:  The crow’s feet wrinkling and infraorbital triangle raising for criterion B are

both present and at least marked, but the evidence is less than the criteria stated

D:  The crow’s feet wrinkling and infraorbital triangle raising for criterion B are

both present and at least severe, but the evidence is less than criteria stated for

E: The crow’s feet wrinkling and infraorbital triangle raising are both present, with

the infraorbital triangle and cheek raising in the maximum range.

The videos that go with this training program provide examples of the features that help define the intensity levels which will allow you to calibrate yourself.

\*\*On the IFPE website, please go to Module 1 →  video 2 cheek raiser and lid

compressor and review the second component of the training videos showing the pain-related action of cheek-raising and lid compression now.\*\*

Chapter 5.  Pain-related action: Lid Tightening (FACS AU 7)

Like the second pain-related action , lid tightening is also produced by the contraction of the ring muscle that circles the eye orbit.  In this case, however, it is the inner portion of orbicularis oculi (pars palpebralis) that produces the movement. Unlike cheek-raising/lid compression, the muscle responsible for lid tightening is narrower in circumference and runs the length of the inner eye orbit near the eyelids. The contraction of this muscle bunches the fibers encircling the eye.  This results in the upper and lower eyelids and some adjacent skin below the eye being pulled together and towards the inner (medial) eye corner. This action has the effect of making someone appear as though they are squinting. The muscular basis can be seen associated with the number 7 in the left panel of Figure 1.  Figure 5, below, repeats the right hand panel of Figure 1, showing the directions of movement associated with contraction of orbicularis oculi, pars palpebralis.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Figure 5.  Muscular bases and actions of the lid tightening movement (FACS AU 7). Lighter arrows show the direction of movement produced by AU 7.  Figure adapted from

Ekman, P., Friesen, W.V. & Hager, J.C. (2002).  Facial Action Coding System.  The manual on CD ROM.  Salt Lake City, UT: Network Information Research Corporation.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

#### The FACS-based appearance changes associated with this action include:

The eyelids are tightened, narrowing the eye aperture to form a squinting appearance

The lower lid is raised, covering more of the eyeball than is usually covered.

The shape of the lower eyelid may change from a  U to an ∩ shape

Raising the lower lid causes a bulge to appear on the lower eyelid

The lower eyelid furrow may become evident as a line or wrinkle, or if the furrow is a permanent part of the face, it becomes deeper.

An example of lid tightening is given in Figure 6.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Figure 6.  Lid tightening.  The principal evidence of this action is the narrowing of the eye aperture and the raising of the lower lid.  From Ekman, P., Friesen, W.V. & Hager,

J.C. (2002).  Facial Action Coding System.  The manual on CD ROM.  Salt Lake City,

UT: Network Information Research Corporation.  P. 28.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Intensity scoring.

A: appearance changes indicating lid tightening are present, but not strong enough to score B

B:    1. There is a slight narrowing of the eye aperture that is due primarily to the

lower  lid, or

1. the lower lid is raised and the skin below the eye is draw up and/or

medially towards the inner corner of the eye slightly.

A slight bulge or pouch of the lower eyelid skin emerges as it is pushed

If the lower lid does not move up, then criterion 1 must be must be marked not slight and criterion 3 must be met.

C:  At least two features for B, narrowing the eye aperture, raising the lower lid,

or bulging/pouching of the lower eyelid are present and at least one is marked,

but the evidence is less than the criteria for D.

D:  Narrowing of the eye aperture, raising of the lower lid, and bulging/pouching

of the lower eyelid are all present and at least one of these is severe, but the

evidence is less than the criteria for E.

E:    1. The narrowing of the eye aperture and raising and stretching of the lower

lid are present and in the maximum range, hiding most of the iris and pulling skin

below  the lower eyelid towards the root of the nose, and

2. tension in the eyelids and the bagging, bulging, or tensing of the lower

eyelid is present and severe.

Cheek-raising/lid compression and lid tightening are both derived from contraction of orbicularis oculi. This can make the two actions difficult to dissociate. Furthermore, both actions share appearance changes of narrowing the eye aperture and changing the appearance of the skin below the lower eyelid. However, there are some apparent differences:

The most important difference is evidenced in the infraorbital triangle. The infraorbital triangle is raised in cheek-raising/lid compression but not in lid tightening: evident in more prominent raised cheeks and a more prominent or deepened infra-orbital furrow which takes on a more horizontal or crescent shape.

The bagging or wrinkling of the skin below the eye occurs more, extending further down the face, in cheek-raising/lid compression than in lid tightening.

The presence of crow’s feet occurs with cheek-raising/lid compression, but not, or only to a limited extent (a few lines or wrinkles) with lid tightening.

A bulge may appear in the lower eyelid skin in both actions although it is due to a different action (pulling of the skin over the eyeball in lid tightening, or pushing of the skin up by the drawing in action of cheek-raising/lid compression. The differences are distinct.

\*\*On the IFPE website, please navigate your way to Module 1 → video 3 - Lid

Tightener and review the demonstration videos showing the pain-related action of lid tightening. Pay close attention to the differences and similarities between this action and cheek-raising/lid-compression.\*\*

Chapter 6.  Pain-related action: Nose Wrinkling (FACS AU 9)

Figure 7, below, provides a schematic of the muscles of the mid-face and the movements they produce. Of particular interest is the muscular basis of the nose wrinkling action labeled 9 and the upper lip raising action labeled 10.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Figure 7. Muscular bases and actions of the lower face: nose wrinkling movement (FACS AU 9) and lip raising movement (FACS AU 10). Figure adapted from Ekman, P.,

Friesen, W. V. & Hager, J. C. (2002). Facial Action Coding System.  The manual on CD ROM.  Salt Lake City, UT: Network Information Research Corporation.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Wrinkling of the nose is produced by levator labii superioris alaeque nasi (Latin for “lifter of the upper lip and wing of the nose”). This muscle innervates the skull between the inner eyebrow and the bridge of the nose. The strands of muscle run horizontally down each side of the nasal bridge and connect to the soft tissue of the face at the upper lip, just below the nasal openings. Contraction of this muscle pulls skin along the side of the nose upwards towards the root of the nose causing wrinkles to

appear along the side of the nose and across the root of the nose. The muscular bases can be seen associated with the number 9 in the left panel of Figure 7. The right panel shows the direction of movement beginning at the line associated with the number 9 and moving towards the root of the nose at the encircled innervating point labeled 9.

#### The FACS-based appearance changes associated with this action include:

Skin along the side of the nose is pulled upwards towards the root of the nose causing wrinkles to appear along the side and root of the nose.

The infraorbital triangle is drawn upwards causing the infraorbital furrow to wrinkle (or, if it is permanently etched, to deepen), and bunching or bagging the skin around the lower eyelid.

The medial portion of the eyebrows are lowered

Pulls the center of the upper lip upwards. In an intense action the lips will part

Figure 8 provides an example of a strong nose-wrinkling action.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Figure 8.  Nose-wrinkling (FACS AU 9).  Taken from Ekman, P., Friesen, W. V. & Hager,

J. C. (2002). Facial Action Coding System.  The manual on CD ROM.  Salt Lake City,

UT: Network Information Research Corporation. P. 93.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Intensity scoring.

A: the appearance changes indicating nose wrinkling are present, but not strong

enough to score B (e.g., a trace of infraorbital triangle raise with skin drawn

medially towards the eyes). Faint wrinkles on the nose are insufficient evidence as these may appear or deepen when skin is tightened by other facial actions.

B: The skin from the medial portion of the infraorbital triangle to the side of the

nose is slightly drawn medially and upwards towards the bridge of the nose.

C: at least marked evidence of medial infraorbital triangle raise that draws skin

towards the nasal bridge to form nose wrinkles, but the evidence is less than the criteria for D.

D: at least severe evidence of medial infraorbital triangle raise that draws skin

towards the nasal bridge to form nose wrinkles, but the evidence is less than the criteria for E. The lips are usually pulled apart in intensity D and above.

E: nose wrinkling, infraorbital triangle raise drawing the skin towards the nasal

bridge, and deepening infraorbital furrow are in the maximum range. The lips are

usually parted during expression of higher intensity nose wrinkling.

Nose wrinkling often involves some degree of brow lowering making the distinction between it and brow lowering difficult. In making the distinction between these actions, be aware that nose wrinkling involves primarily the nose wrinkling movement; whereas brow lowering involves a medial and angular movement of the eyebrows in addition to the pulling-down action.

\*\*On the IFPE website, please navigate your way to Module 1 → Video 4 - Nose

Wrinkler and review the demonstration video showing the pain-related action of nose wrinkling\*\*

Chapter 7.  Pain-related action: Upper Lip Raising (FACS AU 10)

Raising the upper lip is also produced by the levator muscle; in this case levator labii superioris. Levator labii superioris is a broad sheet of muscle innervating the skull beneath the lower eyelid at the zygomatic bone. The strands of muscle run down the length of the cheek connecting to soft tissue at the upper lip. This muscle is close to the muscle that produces nose wrinkling, but a little more lateral. Contraction pulls the skin of the cheeks upwards, drawing the center of the upper lip straight up. The muscular bases can be seen associated with the number 10 in the left panel of Figure 7. The right panel shows the direction of movement beginning at the line associated with the number 10 and moving towards the encircled innervating point labeled 10.

#### The FACS-based appearance changes associated with this action include:

The upper lip is raised. The center of the upper lip is drawn straight up, the outer portions of the upper lip are also drawn up but not to the same degree as is the center.

Angular bends occur in the upper lip and at the side of the nasal passage resulting in an upside down U shape (see Figure 9).

The infraorbital triangle is pushed up causing the infraorbital furrow to wrinkle, or deepen if already evident in neutral.

The nasolabial furrow is deepened with the upper portion being furrowed, producing pouching at, and around, the upper lip and the nasal passages

resulting in a  appearance (Figure 9).

Widening and raising of the nostril wings.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Figure 9.  Upper-lip raising (FACS AU 10).  Note the notched appearance of the

nasolabial furrow.  Taken from Ekman, P., Friesen, W. V. & Hager, J. C. (2002). Facial

Action Coding System.  The manual on CD ROM.  Salt Lake City, UT: Network

Information Research Corporation.  P. 95.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Intensity scoring.

A: the appearance changes indicating upper lip raising are present, but not

strong enough to score B (e.g., a trace of pouching or bulging of the inner corner

of the infraorbital triangle).

B: Slight pouching or bulging of the infraorbital triangle. If this pouch is

permanent, it must increase slightly.

C: at least marked evidence of pouching or bulging of the inner corner of the

infraorbital triangle, with lip raising evident and at least some other appearance-based FACS changes present, but the evidence is less than that for D.

D: at least severe evidence of pouching or bulging of the inner corner of the

infraorbital triangle, with all appearance-based FACS changes being present, but the evidence is less than that for E.

E: All appearance-based FACS changes are present and extreme to maximum.

Note that levator action can be lateralized: much stronger on one side of the face than the other; sometimes, even present on one side but not the other.  Be sure to scan both sides of the face for evidence of upper lip raising.  When an action is lateralized, the intensity you score should be the intensity on the side of the face that has the strongest expression.

\*\*On the IFPE website, please navigate your way to Module 1 – Video 5 - Upper Lip Raiser and review the demonstration video showing the pain-related action of upper lip raising. Pay close attention to the differences and similarities between this action and nose-wrinkling.\*\*

Chapter 8.  Pain-related action: Eye closure.

The final distinct, pain-related facial action is closing of the eyes.  Eye closure is a product of relaxation in the levator palpebrae muscle. This muscle innervates behind the eye socket and attaches itself beneath the upper eyelid  and above the lower eyelid. When levator palpebrae contracts it raises the upper eyelid and lowers the lower eyelid effectively opening the eye.  When relaxed the eyelids close. Thus, unlike that which has been seen in the other pain-related actions, in eye closure, when the muscle relaxes, the pain-related action occurs.

#### The FACS-based appearance changes associated with this action include:

The eyelid droops down reducing the eye aperture.

Surface exposure of the upper eyelid increases. More of the upper eyelid becomes visible as the muscle of the upper eyelid relaxes.

The eyelid may not just be drooped, but may exhibit limited tightening of the lids in conjunction with the pain-related actions of cheek raising/orbit closure and lid tightening .

Eye closure is distinct from blinking. The eyelids remain closed or appear to pause in the closed position during eye closure. This is in contrast to the occurrence of a blink where the eyelids close and open quickly without pause.  In general, to score eye closure, the eyelid has to be closed for a duration of one-half second or more.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Figure 10.  Eye closure (FACS AU 43).  Taken from Ekman, P., Friesen, W. V. & Hager,

J. C. (2002). Facial Action Coding System.  The manual on CD ROM.  Salt Lake City,

UT: Network Information Research Corporation.  P. 62.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

The occurrence of eye closure is usually quite obvious.  Consequently, there are no demonstration videos of this action.  The key issues to be concerned with for coding are 1) only code eye closure when you see the eye closing movement (in other words, if the action has already taken place when you are supposed to code, do not code it) and 2) you should be certain that the eye closure you have seen has lasted more than one-half second (to distinguish the action from a blink).  There will be examples of eye closure when you get a chance to look at the practice videos (see Chapter 11).

Chapter 9: Familiarization with naturally occurring facial expressions of pain

Archetypal video-clips portraying the pain-related actions of brow lowering, cheek raising and lid compression, lid tightening, nose wrinkling, and upper lip raising have been carefully selected with the purpose of familiarizing users of the manual with naturally occurring pain-related actions. One video has been selected for each pain-related action occurring at each of the five intensities. Thus, there are 25 video-clips in total, five for each pain-related action.

The familiarization video-clips have been rendered in a standard four segment format: real time, isolated in slow motion, slow motion, and again in real time. First the expression is presented in real-time to allow the viewer to appreciate just how quickly natural expressions of pain occur and how difficult they can be to detect. Next the same video-clip is presented in slow motion with the pain-related-action being isolated. Pain-related actions are isolated by removing all of the extraneous facial features, allowing the viewer to focus on and appreciate the specified pain-related action. Following this, the same video clip is shown in slow motion to allow the viewer to consciously block out all extraneous facial features themselves. Finally, progress can be tracked by viewing the video-clip once again in real time.

Keep in mind that it is easier to detect more intense facial responses of pain than it is to detect the more subtle weaker intensity facial responses. For this reason, it may be beneficial to start in reverse order at intensity E, descending to intensity A.

\*\*On the IFPE website, please go to “Module 2 – Familiarization” and begin viewing the familiarization clips for each of the pain-related actions.\*\*

Chapter 10.  Scoring pain expression

Psychometric studies suggest that the bulk of information about pain conveyed by the face is carried in the six facial actions described in the foregoing sections.  Our system for quantifying pain expression involves aggregation of a person’s scores on four indices: brow lowering, orbit tightening, levator tightening and eye closure.  Having read and studied the actions associated with the first and last pain-related actions, FACS AUs 4 and 43, you now have some familiarity with the scoring of brow lowering and eye closure.  It is important to remember that brow lowering varies according to intensity and that intensity variation can be captured in the A – E scoring system.  By contrast, in the IFPE, eye closure is either present or it is not.  Thus, the two actions have a different scoring format—intensity scoring for brow lowering and binary scoring for eye closure.

Here we introduce the terms “orbit tightening” and “levator tightening” to describe how we have reduced and simplified the scoring of the other four pain-related actions.

Cheek-raising/lid compression (AU 6)  and lid tightening (AU 7) often co-occur during pain. This co-occurrence is more likely when the intensity of pain expressed is greater. Because their co-occurrence is frequent, because observers have difficulty discriminating these movements reliably and because the actions are based essentially on the same muscle—orbicularis oculi—when scoring pain expression, we do not distinguish the one action from the other.  Instead, only the single summary action “orbit tightening” is scored.

Exactly the same issues hold for nose-wrinkling (AU 9) and upper-lip raising (AU 10).  Consequently, by the same reasoning, when scoring pain expression, only the single summary action, “levator tightening” is scored.

The decision to collapse these four actions into two summary categories reduces greatly the number of discriminations and decisions that an observer is required to make and thus improves the reliability of the overall coding system.  The coding principle is the same for each action.  Observe for evidence of any of the actions and allocate the highest intensity rating of any action observed to its respective category. For example, if you observe evidence of cheek-raising/lid compression alone and it meets the criteria for intensity ‘C,’ then you would code the value ‘C’ for orbit tightening. If you observe evidence of lid-tightening alone and it meets the criteria for intensity ‘B,’ then you would code ‘B’ for orbit tightening.  If you saw evidence of cheek-raising/lid compression at intensity ‘D’ and evidence of lid tightening at intensity ‘B,’ then you would code ‘D’ for orbit tightening.

The logic and principles for scoring levator tightening are the same.  If you observe evidence of nose-wrinkling alone and it meets the criteria for intensity ‘D,’ then

you should code ‘D’ for levator tightening.  If you observe upper lip raising alone at intensity ‘C’ then the score for levator tightening should be ‘C.’  If you observe nose-wrinkling at intensity ‘E’ and upper lip raising at intensity ‘D’ then the score for levator tightening should be ‘E.’

In all cases, make independent judgments of the four component pain actions: brow lowering, orbit tightening, levator tightening and eye closure.  In other words, to score brow lowering, you have to be satisfied that the criteria for brow lowering (e.g., the brow has been drawn down and/or in by the muscles involved in FACS AU 4 and the action is not better accounted for as a component of AU 9—nose wrinkling) have been met.  The same holds for scoring orbit and levator tightening.

The mechanics of scoring pain expression

There can be a variety of contexts for measuring pain expression (studies of experimental pain, studies of clinical pain, clinical assessment).  Inexpensive technology both for obtaining video recordings and processing them with computer software is widely available most places.  Having a video recording of the face during some potentially painful event is the only basic requirement for coding pain expression using the system described in this manual.  Pain coding in real time, using a trained observer not relying on video review is possible (Prkachin et al, 2002), but the specificity and detail of observation available with the present system are not possible.

There are options for the degree of precision in coding.  The simplest is to record and define a single event (for example, a response to a single painful stimulus) and then to quantify the facial response as the maximum response observed during the event. For example, the event may be a trial of exposure to the cold pressor test, where the subject immerses his or her arm in ice-water until they can no longer tolerate it.  In such circumstances a single pain expression may occur or a series, varying in intensity. Using event-based coding, the observer would have to decide when the maximum intensity expression took place and then perform the overall quantification.  The most intense mode of analysis is frame-by-frame.  In frame-by-frame analysis the observer quantifies the intensity of all components of pain expression for each frame of video over a specified time interval.  Frame-by-frame analysis is resource intensive, in some ways working against the intent of the current system to diminish the time and effort associated with coding.  On the other hand, only frame-by-frame analysis can provide comprehensive and precise quantification of the dynamics of pain expression.

Whichever approach is adopted, the observer will need to have a process for making and storing observations.  A simple approach is to set up an Excel file such as that shown in Table 1.  Each individual study will have its own unique features

determining the data fields to include.  The important feature is to be able to associate action codes and their intensity with individual and event markers.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Table 1.  An example of an Excel file structure for pain action coding.

ID Sex Segment Brow Orbit Levator Eye

LB048 F Active Flexion B D B N

LB048 F Passive Flexion D E D Y

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

We recommend coding intensity using the alphabetic rather than numeric categories.  This will maintain consistency with the FACS process from which the present system is derived.  It is a simple matter to convert alphabetic to numeric codes after initial processing.  When converting from alphabetic to numeric codes, translate the scores for brow lowering, orbit tightening and levator contraction as follows: A=1, B=2, C=3, D=4, E=5.  For eye closure, a code of Y (yes) is given a score of 1; N (no) gets 0.  The numeric scores for each action are then simply summed, yielding the index of facial pain expression (IFPE) score, which can range from 0 to 16 for any individual action.

When undertaking coding, observe the event in real time first.  This will allow you to make initial hypotheses about the actions involved and their intensity.  Then you can review the video record in slow or stop action or frame-by-frame.  Systematically consider the four core actions—brow lowering, orbit tightening, levator contraction and eye closure—in that order.  Likewise, your coding record should represent the four actions in order, as depicted in the score sheet in Table 1.

Avoid the temptation to make inferences about things you have not seen.  It seems to be a natural human tendency to draw conclusions about what the person you see is doing based on your theories or hunches.  This is particularly the case when you are observing for evidence of pain—people like to guess about the meaning of particular movements, or what they think should be happening.  Resist this temptation and stick as strictly as you can to objective description.

Chapter 11.  Practice scoring.

The videos located under the "Module 3 - Practice Clips" tab on the IFPE website can be used for practice scoring. Please click on the " Module 3 - Practice Clips" tab where you will find a scoring guide along with 47 practice clips located in 5-sets.  Each practice clip is a brief clip showing one, some, or all of the pain-related actions along with their frame-by-frame recordings.  Use the system described in Chapter 9 to score each of the actions.  Please score each action using your own scoring guide and then compare your scores to scores obtained by FACS trained raters.  Try to score the videos independently, before viewing the scoring guide.  Scores obtained by FACS trained raters are located in the "scoring guide" link under the "Module 3 - Practice Clips" tab.

Chapter 12.  Final test

The final task is to have the user rate facial expressions for pain and then gauge the accuracy of these ratings as compared to FACS trained coders. A total of 25 test clips have been prepared and rated by FACS trained coders for just this purpose. Final test clips are located under the tab “Module 4 –Final Test” along with an IFPE Final Test Scoring Sheet.

An IFPE final test scoring spreadsheet has been created which can be located by clicking on the "scoring sheet" link located on the “Module 4 –final test” tab. Located under the same tab are 25 videos (Parts 1 through 3) containing the IFPE final test clips along with their frame-by-frame images. When ready to begin the final test, open the final test scoring spreadsheet. This spreadsheet is set up with one column for name of the test clip, five columns for rating pain related actions, three columns for rating pain at the associated muscle groups, one column for noting eye closure, and a final column to score the global Index of Facial Pain Expression rating.

Start by watching final Test Clip 1. Use the test clip and frame-by frame images, if needed, to rate the presence of the five pain-related actions and the associated alphabetic intensity code. Next, transform the ratings of the pain-related actions into numeric codes for the corresponding muscle groups. For example, if you observe nose-wrinkling at intensity ‘E’ and upper lip raising at intensity ‘D’ then the score for levator tightening should be ‘E’ which converts into an intensity of ‘5.’ If no score is present enter a ‘0.’ Finally, sum the scores for the muscle groups Brow, Orbital, Levator, and Eye Closure to generate a Global IFPE score.

Once you have completed the Final Test, save it using your unique participant code and then e-mail it to Josh Rash at  jarash@ucalgary.ca.  You can set up a time with Josh to return to the laboratory for one final short visit and you will be finished.

Thank you again for all of your hard work!

Craig, K.D., Prkachin, K.M. & Grunau, R.V.E. (in press).  The facial expression of pain.

In D.C. Turk & R. Melzack (Eds.), Handbook of pain assessment (Third ed).  New York:

Ekman, P., & Friesen, W.V. (1978). Facial Action Coding System: A technique for the  measurement of facial movement.  Palo Alto, CA: Consulting Psychologists Press.

Grunau, R.V.E., & Craig, K.D. (1987).  Pain expression in neonates: facial action and cry.

Pain, 28, 395-410.

Hadjistavropoulos, T., LaChappelle, D.L., MacLeod, F.K., Snider, B. & Craig,  K.D. (2000).

Measuring movement-exacerbated pain in cognitively-impaired frail elders.  Clinical Journal of  Pain, 16, 54-63.

Izard, C .E. (1979).  The Maximally Discriminative Facial Movement Coding System.  Newark,

Delaware: Instructional Resources Center, University of Delaware.

Kunz, M., Scharmann, S., Hemmeter, U., Schepelmann, K., & Lautenbacher, S. (2007).  The

facial expression of pain in patients with dementia.  Pain, 133, 221-228.

Prkachin, K.M.  (1992).  The consistency of facial expressions of pain:  a comparison across

modalities.  Pain, 51, 297-306.

Prkachin, K.M., (2009).  Assessing pain by facial expression:  Facial expression as

nexus.  Pain Research and Management, 14, 53-58.

Prkachin, K.M. & Craig, K.D. (1994).  Expressing pain: The communication and interpretation

of facial pain signals. Journal of Nonverbal Behavior, 19, 191-205.

Prkachin, K. M., Hughes, E., Schultz, I., Joy, P., & Hunt, D. (2002). Real-time

assessment of pain behavior during clinical assessment of low back pain patients. Pain, 95(1), 23-30.

Prkachin, K.M. & Solomon, P.E. (2008).  The structure, reliability and validity of pain

expression: evidence from patients with shoulder pain.  Pain. 139, 267-274.

Rocha, E., Prkachin, K.M., Beaumont, S.L., Hardy, C., & Zumbo, B.D. (2003).  Pain reactivity

and illness behavior in kindergarten-aged children.  Journal of Pediatric Psychology, 28, 47-57.

Williams, A. C. deC. (2002).  Facial expression of pain: An evolutionary account.  Brain and Behavioral Science, 25, 439-445.

