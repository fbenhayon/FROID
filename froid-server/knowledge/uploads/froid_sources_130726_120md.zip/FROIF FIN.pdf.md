# FROIF FIN.pdf

Frequency Recognition of Internal Dynamics

Plano Financeiro Definitivo

Fluxo de Caixa, Precificação e Valor por Consulta

20 dias úteis | Máximo 6 consultas/dia | Câmbio 1 USD = R$ 5,00

Versão Final — Abril 2026 — Confidencial

FROID — Plano Financeiro Definitivo

Confidencial  |  Pág. 2

1. Síntese Executiva

Indicador Valor

Investimento inicial necessário R$ 500.000

Break-even EBITDA mensal Mês 14 (~280 profissionais)

Payback do investimento Mês 20 (~760 profissionais)

MRR no mês 24 R$ 1.762.000

ARR projetado (mês 24 anualizado) R$ 21.144.000

EBITDA no mês 24 R$ 915.155 (52% margem)

Caixa acumulado no mês 24 R$ 3.132.453

Margem bruta média (assinatura) 57–59%

Margem bruta média (avulso) 69–76%

Número de profissionais no mês 24 1.000

2. Custo Variável por Sessão — Cálculo Final (50 min)

Todos os valores em USD foram multiplicados pelo câmbio de R$ 5,00. Os custos abaixo representam o custo marginal de cada sessão adicional para o FROID.

Componente Essencial Profissional Premium

Análise Facial R$ 0,00 R$ 11,25 R$ 11,25

Análise Vocal R$ 0,00 R$ 5,35 R$ 21,35

NLP / Linguagem R$ 0,00 R$ 0,25 R$ 4,70

Transcrição (Whisper) R$ 0,00 R$ 1,50 R$ 1,50

GPU Compute R$ 2,20 R$ 2,20 R$ 2,20

Armazenamento R$ 0,10 R$ 0,20 R$ 0,40

Infraestrutura (rateio) R$ 0,75 R$ 0,75 R$ 0,75

CUSTO TOTAL / SESSÃO R$ 3,05 R$ 21,50 R$ 42,15

FROID — Plano Financeiro Definitivo

Confidencial  |  Pág. 3

3. Precificação Comercial Final
3.1 Tabela de Preços

Essencial Profissional Premium

Assinatura mensal R$ 297 R$ 1.497 R$ 3.997

Sessões inclusas / mês 40 30 40

Preço avulso / sessão excedente

R$ 12,90 R$ 69,90 R$ 139,90

Custo efetivo / sessão na assinatura

R$ 7,43 R$ 49,90 R$ 99,93

Margem bruta (avulso) 76% 69% 70%

Margem bruta (assinatura) 59% 57% 58%

3.2 Lógica das Sessões Inclusas

#### As sessões inclusas foram calibradas com base no volume médio e na margem-alvo:

Essencial (40 sessões): cobre 2 consultas/dia em 20 dias úteis. Profissional com agenda leve opera 100% dentro da assinatura

Profissional (30 sessões): deliberadamente abaixo da média para gerar receita de excedentes (R$ 69,90/sessão com margem de 69%). Um profissional com 3 consultas/dia usará 60 sessões, pagando 30 excedentes = R$ 2.097 adicional

Premium (40 sessões): mesmo número do Essencial, mas o alto valor da assinatura (R$ 3.997) já garante margem de 58% mesmo com uso pleno

4. Custo FROID por Consulta — Todos os Cenários

A tabela abaixo mostra o custo FROID que o profissional paga por cada consulta realizada, considerando a assinatura mensal + sessões excedentes. Premissa: 20 dias úteis por mês, máximo 6 consultas/dia (120/mês).

4.1 Plano Essencial (R$ 297/mês, 40 sessões inclusas)

2/dia 3/dia 4/dia 5/dia 6/dia

Consultas/mês 40 60 80 100 120

Excedentes 0 20 40 60 80

Custo total/mês R$ 297 R$ 555 R$ 813 R$ 1.071 R$ 1.329

CUSTO / CONSULTA R$ 7,43 R$ 9,25 R$ 10,16 R$ 10,71 R$ 11,08

% de consulta R$ 250 3,0% 3,7% 4,1% 4,3% 4,4%

% de consulta R$ 400 1,9% 2,3% 2,5% 2,7% 2,8%

% de consulta R$ 600 1,2% 1,5% 1,7% 1,8% 1,8%

FROID — Plano Financeiro Definitivo

Confidencial  |  Pág. 4

CONCLUSÃO: O Plano Essencial nunca ultrapassa 4,4% do valor de qualquer consulta. Viável para 100% dos profissionais.

4.2 Plano Profissional (R$ 1.497/mês, 30 sessões inclusas)

2/dia 3/dia 4/dia 5/dia 6/dia

Consultas/mês 40 60 80 100 120

Excedentes 10 30 50 70 90

Custo total/mês R$ 2.196 R$ 3.594 R$ 4.992 R$ 6.390 R$ 7.788

CUSTO / CONSULTA R$ 54,90 R$ 59,90 R$ 62,40 R$ 63,90 R$ 64,90

% de consulta R$ 250 22,0% 24,0% 25,0% 25,6% 26,0%

% de consulta R$ 400 13,7% 15,0% 15,6% 16,0% 16,2%

% de consulta R$ 600 9,2% 10,0% 10,4% 10,7% 10,8%

% de consulta R$ 1.000 5,5% 6,0% 6,2% 6,4% 6,5%

CONCLUSÃO: Recomendado para consultas a partir de R$ 400 (impacto de 13-16%). Ideal para consultas R$ 600+ (impacto < 11%).

FROID — Plano Financeiro Definitivo

Confidencial  |  Pág. 5

4.3 Plano Premium (R$ 3.997/mês, 40 sessões inclusas)

2/dia 3/dia 4/dia 5/dia 6/dia

Consultas/mês 40 60 80 100 120

Excedentes 0 20 40 60 80

Custo total/mês R$ 3.997 R$ 6.795 R$ 9.593 R$ 12.391 R$ 15.189

CUSTO / CONSULTA R$ 99,93 R$ 113,25 R$ 119,91 R$ 123,91 R$ 126,58

% de consulta R$ 400 25,0% 28,3% 30,0% 31,0% 31,6%

% de consulta R$ 600 16,7% 18,9% 20,0% 20,7% 21,1%

% de consulta R$ 800 12,5% 14,2% 15,0% 15,5% 15,8%

% de consulta R$ 1.000 10,0% 11,3% 12,0% 12,4% 12,7%

CONCLUSÃO: Exclusivo para psiquiatras e clínicas premium com consultas acima de R$ 800 (impacto 12-16%). Em consultas de R$ 1.000+, o impacto fica na faixa de 10-13%.

5. Fluxo de Caixa — Marcos Principais

Mês 1 Mês 6 Mês 12 Mês 14 Mês 18 Mês 20 Mês 24

Usuários 15 60 200 280 500 660 1.000

MRR R$ 6.855 R$ 38.420 R$ 232.400

R$ 1.081.620

R$ 1.762.000

EBITDA (R$ 108k) (R$ 86k) (R$ 12k) R$ 12k R$ 311k R$ 465k R$ 915k

Caixa acum.

(R$ 608k) (R$ 1,08M) (R$ 1,49M) (R$ 1,52M) (R$ 766k) R$ 49k R$ 3,13M

Marco Início  Quase break-even

EBITDA + Aceleração PAYBACK Escala

5.1 Necessidade de Capital

O ponto de maior consumo de caixa (vale da morte) ocorre no mês 14, quando o caixa acumulado atinge R$ -1.527.949. Considerando o investimento inicial de R$ 500.000, o projeto necessita de capital total de R$ 1.53 milhões para sobreviver até o payback. Isso pode ser financiado com:

Investimento seed de R$ 500.000 + rodada pré-Series A de R$ 1.000.000 no mês 6-8

Ou investimento único de R$ 1.600.000 com reserva de contingência

Ou modelo bootstrapped com lançamento apenas do Plano Essencial (menor queima de caixa)

5.2 Cenário Bootstrap — Apenas Plano Essencial

Se o FROID lançar inicialmente apenas o Plano Essencial (100% open-source, custo de R$ 3,05/sessão), o custo variável cai drasticamente. Com 200 profissionais pagando R$ 297/mês, a receita mensal seria R$ 59.400 com custo variável de apenas R$ 5.124 (uso médio de 60 sessões por profissional × R$ 3,05 × 0,70 uso × 40 sessões). A margem bruta de 91% nesse cenário permite break-even com custos fixos reduzidos (equipe menor) em apenas 80-100 profissionais.

FROID — Plano Financeiro Definitivo

Confidencial  |  Pág. 6

FROID — Plano Financeiro Definitivo

Confidencial  |  Pág. 7

6. Recomendação Final de Precificação
6.1 Regra de Ouro para o Profissional

O FROID deve representar no máximo 10% do valor da consulta do profissional para ser sustentável. Com base nesse princípio:

Plano FROID Valor Mínimo da Consulta Público Ideal Impacto no Preço

Essencial R$ 110 Todo profissional de saúde mental

Acrescentar R$ 10–15 à consulta

Profissional R$ 640 Psiquiatras, psicólogos com consulta R$ 400+

Acrescentar R$ 50–70 à consulta

Premium R$ 1.270 Clínicas premium, psiquiatras de alto valor

Acrescentar R$ 100–140 à consulta

6.2 Estratégia de Go-to-Market

FASE 1 (Mês 1-6): Lançar somente o Plano Essencial a R$ 297/mês. Margem altíssima (91% bruta), baixo risco, valida product-market fit

FASE 2 (Mês 7-12): Adicionar Plano Profissional a R$ 1.497/mês com integração Hume AI. Oferecer 30 dias gratuitos do Profissional para assinantes Essencial

FASE 3 (Mês 13-18): Lançar Plano Premium a R$ 3.997/mês. Focar em clínicas e instituições com vendas consultivas

Desconto anual: 2 meses grátis na assinatura anual (equivale a 17% de desconto)

Early adopters (100 primeiros): 40% de desconto nos primeiros 6 meses

6.3 Métricas de Acompanhamento

CAC (Custo de Aquisição de Cliente): alvo < R$ 1.500 no Essencial, < R$ 5.000 no Profissional

LTV (Lifetime Value): alvo > 12 meses de retenção = LTV Essencial R$ 3.564 | Prof R$ 17.964 | Premium R$ 47.964

LTV/CAC: alvo > 3x para todos os planos

Churn mensal: alvo < 5% para Essencial, < 3% para Profissional e Premium

NPS (Net Promoter Score): alvo > 50

FROID — Plano Financeiro Definitivo v1.0

Abril 2026 — Confidencial

