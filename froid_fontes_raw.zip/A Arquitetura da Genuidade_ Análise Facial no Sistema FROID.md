# A Arquitetura da Genuidade: Análise Facial no Sistema FROID

O sistema FROID diferencia sorrisos genuínos de sorrisos sociais através de uma análise matemática e biomecânica rigorosa baseada no \*Facial Action Coding System\* (FACS) e na dinâmica temporal das expressões \[1-3\]. A distinção não se baseia em uma percepção subjetiva, mas na identificação de unidades de ação específicas e na origem neurológica dos movimentos musculares \[4-6\].

Abaixo estão detalhados os processos técnicos utilizados pelo FROID para essa diferenciação:

### 1. A Matriz Bio-Anatômica: AU 6 e AU 12
A base da diferenciação reside na combinação de Unidades de Ação (AUs). O FROID analisa 468 \*landmarks\* faciais para identificar estas ativações \[2, 7\]:

\*   \*\*Sorriso Genuíno (Sorriso de Duchenne):\*\* É identificado pela combinação obrigatória das \*\*AUs 6 + 12\*\* \[5, 8\]. A AU 12 (\*Lip Corner Puller\*) traciona os cantos dos lábios obliquamente para cima, enquanto a AU 6 (\*Cheek Raiser\*) eleva as bochechas, estreita a fenda ocular e cria as rugas conhecidas como "pés de galinha" ao redor dos olhos \[9-12\].
\*   \*\*Sorriso Social (Sorriso de "Pan-Am" ou Dissimulado):\*\* Caracteriza-se pela ativação isolada da \*\*AU 12\*\*, sem a presença da AU 6 \[5, 8, 13\]. O paciente puxa os cantos da boca de forma voluntária, mas não há o engajamento da musculatura ao redor dos olhos \[8, 14\].

### 2. Neurofisiologia: Sistemas Piramidal vs. Extrapiramidal
O FROID utiliza a ciência neurológica para atribuir um "score de genuinidade" à expressão \[3, 15\]. As expressões emocionais autênticas são mediadas pelo \*\*sistema motor extrapiramidal\*\* (involuntário), que ativa "músculos confiáveis" como a porção orbital do \*orbicularis oculi\* (AU 6), que é extremamente difícil de contrair voluntariamente sem um estímulo emocional real \[3, 4, 16\]. Em contraste, sorrisos sociais são coordenados pelo \*\*sistema motor piramidal\*\* (córtex motor), que controla a musculatura voluntária \[4\]. Quando a AU 6 está ausente em um sorriso, o algoritmo do FROID classifica a expressão como uma "fachada social" \[8\].

### 3. Dinâmica Temporal: Onset, Apex e Offset
A autenticidade também é medida pela trajetória do movimento muscular através de um Modelo de Markov Oculto (HMM) de 4 estados \[3, 7, 17\]:

\*   \*\*Início (Onset):\*\* Sorrisos genuínos apresentam um \*onset\* fluido e suave, onde as contrações de diferentes partes da face tendem a atingir o pico simultaneamente \[18-20\]. Sorrisos forçados costumam ter inícios mais lentos, irregulares ou "truncados" \[18, 20\].
\*   \*\*Ápice (Apex):\*\* O FROID aplica a \*\*Regra do Apex\*\*, exigindo que a expressão atinja um cume de intensidade estável para ser validada \[7, 19, 21\]. Flutuações bruscas durante o ápice indicam ambivalência ou tentativa de supressão \[19\].
\*   \*\*Fim (Offset):\*\* O desaparecimento gradual da expressão é marcador de sinceridade, enquanto sorrisos que "desligam" ou desaparecem abruptamente (curto \*offset\*) são sinalizados como menos autênticos \[19, 22\].

### 4. Motor de Dissonância e Cruzamento Multimodal
O diferencial estratégico do FROID é não analisar a face isoladamente \[23, 24\]. Ele utiliza a regra de dissonância chamada \*\*"Sorriso Falso (Falsa Calma)"\*\* \[25, 26\]:

\*   Se o paciente verbaliza estar feliz e apresenta um sorriso (AU 12), mas o sistema detecta a \*\*ausência da AU 6\*\* e, simultaneamente, o motor bioacústico identifica \*\*tensão na voz\*\* (picos na Zona 7 de raiva ou Zona 3 de tristeza), o sistema dispara um alerta visual instantâneo \[25-27\].
\*   Neste cenário de contradição, a fórmula mestre do \*\*Índice de Desvio Multimodal (IDM)\*\* aplica um \*\*Multiplicador Facial de Dissonância ($M\_{fac}$) de 2.5\*\* \[28, 29\]. Isso faz com que o desvio de energia "exploda" graficamente no dashboard (iluminando a zona em vermelho), provando que o paciente está usando o sorriso como uma máscara para esconder conflitos internos profundos \[23, 29-31\].

### 5. Intensidade e Assimetria
O sistema também avalia a intensidade de cada componente do sorriso em uma escala de \*\*A (traço mínimo)\*\* a \*\*E (máximo)\*\* \[10, 32\]. Um sorriso onde a AU 12 tem intensidade forte (C ou D) mas a AU 6 é apenas um traço (A) sugere dissimulação \[33\]. Além disso, o FROID monitora a \*\*Assimetria Facial\*\* (D-face / S-face); expressões genuínas tendem a ser bilaterais e simétricas, enquanto sorrisos controlados ou de desprezo costumam ser mais fortes em apenas um lado da face \[3, 33, 34\].