# Regra do Apex: Arquitetura da Autenticidade Facial no FROID

A regra do Apex é um parâmetro técnico e científico fundamental na arquitetura de decodificação facial do FROID, projetado para garantir que apenas expressões emocionalmente autênticas e significativas sejam validadas pelo sistema \[1, 2\]. Desenvolvida pelos mais inteligentes e habilidosos especialistas para substanciar o FROID com o máximo rigor, essa regra atua como um filtro biomecânico que distingue reações neurais genuínas de ruídos musculares ou simulações superficiais \[3, 4\].

Abaixo detalho como a regra do Apex garante essa autenticidade através de diferentes mecanismos:

### 1. Definição do Ápice como Ponto de Validação
O "Apex" (ápice) é definido tecnicamente como o ponto de maior excursão ou mudança em uma Unidade de Ação (AU), representando o momento em que a contração muscular atinge sua intensidade máxima \[5, 6\]. Na lógica operacional do FROID, uma expressão facial é considerada presente e válida \*\*se, e somente se, o ápice for detectado\*\* \[2, 7\]. Isso impede que micromovimentos aleatórios ou artefatos de imagem sejam erroneamente classificados como estados emocionais, exigindo que o motor de IA identifique claramente o cume da intenção muscular \[3, 8\].

### 2. Estabilidade vs. Fluutuação (Detecção de Dissimulação)
A regra do Apex analisa a trajetória temporal da contração muscular para diferenciar o controle voluntário do involuntário:
\*   \*\*Expressões Genuínas:\*\* Em reações emocionais autênticas, o ápice tende a ser estável, fluido e mantido por um período orgânico \[9\].
\*   \*\*Expressões Simuladas ou Suprimidas:\*\* Quando um paciente tenta mascarar uma emoção, a regra detecta flutuações bruscas de intensidade durante a fase de pico, conhecidas como "multi-ápices" \[9\]. Essas oscilações sinalizam ambivalência emocional ou o esforço do sistema motor piramidal (voluntário) para conter a ativação do sistema extrapiramidal (involuntário), denunciando a falta de autenticidade no comportamento \[4, 9\].

### 3. Integração ao Modelo HMM de 4 Estados
A regra do Apex é integrada a um Modelo de Markov Oculto (HMM) que divide cada evento facial em quatro fases cronológicas precisas: \*\*neutral → onset (início) → apex (ápice) → offset (fim)\*\* \[1, 9\]. A autenticidade é garantida pela análise da transição entre essas fases. Sorrisos sociais, por exemplo, costumam ter inícios e fins (offsets) truncados ou excessivamente rápidos, enquanto a regra do Apex exige uma evolução fluida para validar a sinceridade da alegria de Duchenne (combinação genuína das AUs 6 e 12) \[9-11\].

### 4. Filtragem de Microexpressões e Vazamentos
A regra é sensível o suficiente para validar microexpressões que duram entre 40 e 200 milissegundos \[3, 12\]. Mesmo em vazamentos emocionais extremamente rápidos, o sistema FROID busca a confirmação do ápice muscular ($Apex\_Confidence > 0.75$) antes de emitir um alerta de dissonância no dashboard \[13, 14\]. Isso assegura que o profissional receba apenas informações de conflitos internos que possuam uma assinatura neuromuscular completa, eliminando falsos positivos e permitindo uma intervenção terapêutica baseada em dados inquestionáveis \[1, 3\].

### 5. Calibragem de Intensidade e Sincronia
Através da regra do Apex, o FROID quantifica a intensidade da expressão em uma escala de \*\*A (traço mínimo)\*\* a \*\*E (máximo)\*\* \[15, 16\]. Para garantir a autenticidade, o sistema exige que diferentes partes da face (como olhos e boca) atinjam seus ápices de forma síncrona \[11\]. Se houver uma dessincronia temporal — por exemplo, uma expressão de surpresa onde a abertura da boca ocorre muito depois do erguer das sobrancelhas — a regra do Apex sinaliza uma incoerência na integração sensório-motora, sugerindo que a expressão foi fabricada cognitivamente e não sentida organicamente \[17\].