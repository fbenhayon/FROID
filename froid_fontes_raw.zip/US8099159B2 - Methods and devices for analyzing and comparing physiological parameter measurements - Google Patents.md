---
sourceFile: "US8099159B2 - Methods and devices for analyzing and comparing physiological parameter measurements - Google Patents"
exportedBy: "Kortex"
exportDate: "2026-06-29T01:00:28.789Z"
---

# US8099159B2 - Methods and devices for analyzing and comparing physiological parameter measurements - Google Patents

1b81c430-3ab0-4d08-b99a-48b359be97de

US8099159B2 - Methods and devices for analyzing and comparing physiological parameter measurements - Google Patents

38208d20-423a-4b47-ad61-540999bd1ac2

https://patents.google.com/patent/US8099159B2/en

US8099159B2 - Methods and devices for analyzing and comparing physiological parameter measurements - Google Patents

https://patents.google.com/patent/US8099159B2/en

Include patents

Include non-patent literature

Search within

Search within the title, abstract, claims, or full patent document

: You can restrict your search to a specific field using field names.

Use TI= to search in the title, AB= for the abstract, CL= for the claims, or TAC= for all three. For example, TI=(safety belt).

Search by Cooperative Patent Classifications (CPCs)

: These are commonly used to represent ideas in place of keywords, and can also be entered in a search term box. If you're searching for seat belts, you could also search for B60R22/00 to retrieve documents that mention safety belts or body harnesses. CPC=B60R22 will match documents with exactly this CPC, CPC=B60R22/low matches documents with this CPC or a child classification of this CPC.

https://support.google.com/faqs/answer/7049475

Title Abstract Claims Full Document

Include child classifications

Find patents

Keywords and boolean syntax (USPTO or EPO format)

: seat belt searches these two words, or their plurals and close synonyms. "seat belt" searches this exact phrase, in order. -seat -belt searches for documents not containing either word.

For searches using boolean logic

, the default operator is AND with left associativity.

this means safety OR seat belt is searched as (safety OR seat) AND belt. Each word automatically includes plurals and close synonyms. Adjacent words that are implicitly ANDed together, such as (safety belt), are treated as a phrase when generating synonyms.

https://support.google.com/faqs/answer/7049475

with ALL of the words

with the EXACT PHRASE

with AT LEAST ONE of the words

WITHOUT the words

Chemistry searches

match terms (trade names, IUPAC names, etc. extracted from the entire document, and processed from .MOL files.)

Substructure (use SSS=) and similarity (use ~) searches are limited to one per search at the top-level AND condition. Exact searches can be used multiple times throughout the search query.

Searching by SMILES or InChi key requires no special syntax. To search by SMARTS, use SMARTS=.

To search for multiple molecules, select "Batch" in the "Type" menu. Enter multiple molecules separated by whitespace or by comma.

https://support.google.com/faqs/answer/7049475

Chemistry Type

Substructure

Patent numbers

https://patents.google.com/import

Search specific patents by importing a CSV or list of patent publication or application numbers.

Display advanced search options

Sorry, we couldn't find this patent number.

Search tools Text Classification Chemistry Measure Numbers Full documents Title Abstract Claims All Any Exact Not Add AND condition These CPCs and their children These exact CPCs Add AND condition

https://support.google.com/faqs/answer/7049475#zippy=%2Csearching-by-chemistry

Exact Exact Batch Similar Substructure Substructure (SMARTS) Full documents Claims only Add AND condition Add AND condition

Application Numbers Publication Numbers Either

US, EP, WO, JP, CN

Add AND condition

Methods and devices for analyzing and comparing physiological parameter measurements

Abstract translated from

Methods and devices that are capable of measuring physiological parameters of at least two contact points and determining whether the measured parameters reflect favorable or unfavorable physiological responses are disclosed herein. Specifically, the present invention encompasses a method that can non-invasively monitor physiological parameters of at least two contact points before and after a stimulus is applied to a subject and compare the measured parameters to determine whether the physiological state of the subject is favorable or unfavorable.

Images ( 0)

Classifications machine-classified cpc-machine-classified fterm-machine-classified fterm-family-classified

The classifications are assigned by a computer and are not a legal conclusion.

Google has not performed a legal analysis and makes no representation as to the accuracy of the classifications listed.

The CPC classifications are assigned by a computer and are not a legal conclusion.

Google has not performed a legal analysis and makes no representation as to the accuracy of the classifications listed.

The F-term classifications are assigned based on a patent family member containing these classification codes.

The F-term classifications are assigned by a computer and are not a legal conclusion.

Google has not performed a legal analysis and makes no representation as to the accuracy of the classifications listed.

https://patents.google.com/patent/US8099159B2/en

HUMAN NECESSITIES

https://patents.google.com/patent/US8099159B2/en

MEDICAL OR VETERINARY SCIENCE; HYGIENE

https://patents.google.com/patent/US8099159B2/en

DIAGNOSIS; SURGERY; IDENTIFICATION

https://patents.google.com/patent/US8099159B2/en

Measuring for diagnostic purposes; Identification of persons

https://patents.google.com/patent/US8099159B2/en

Detecting, measuring or recording for diagnosis by means of electric currents or magnetic fields; Measuring using microwaves or radio waves

https://patents.google.com/patent/US8099159B2/en

Measuring electrical impedance or conductance of a portion of the body

https://patents.google.com/patent/US8099159B2/en

Measuring skin impedance

https://patents.google.com/patent/US8099159B2/en

Measuring galvanic skin response

Health & Medical Sciences

https://patents.google.com/patent/US8099159B2/en

Life Sciences & Earth Sciences

https://patents.google.com/patent/US8099159B2/en

US8099159B2

United States

Patent ( having previously published pre-grant publication)

Download PDF

https://patentimages.storage.googleapis.com/f0/4a/a9/39be375bb20d34/US8099159.pdf

Find Prior Art

https://patents.google.com/patent/US8099159B2/en

https://patents.google.com/patent/US8099159B2/en

Vaughn Cook

https://patents.google.com/patent/US8099159B2/en

Current Assignee

The listed assignees may be inaccurate.

Google has not performed a legal analysis and makes no representation or warranty as to the accuracy of the list.

Worldwide applications

https://patents.google.com/patent/US8099159B2/en

Application number: US11/521,417

Filing date: 2006-09-13

Legal status: Active

https://patents.google.com/patent/US8099159B2/en

Application number: PCT/US2006/036119

Filing date: 2006-09-14

Legal status: Ceased

Application US11/521,417 events

A timeline of key events for this patent application, including priority claims, publications, legal status, reassignments, and litigation.

Google has not performed a legal analysis and makes no representation as to the accuracy or completeness of the events listed.

Application filed by Zyto Corp

https://patents.google.com/patent/US8099159B2/en

Priority to US11/521,417

https://patents.google.com/patent/US8099159B2/en

Priority to PCT/US2006/036119

https://patents.google.com/patent/US8099159B2/en

Assigned to ZYTO CORP.

https://patents.google.com/patent/US8099159B2/en

ASSIGNMENT OF ASSIGNORS INTEREST (SEE DOCUMENT FOR DETAILS).

Assignors: COOK, VAUGHN

Publication of US20070066874A1

https://patents.google.com/patent/US8099159B2/en

Application granted

Publication of US8099159B2

https://patents.google.com/patent/US8099159B2/en

Adjusted expiration

Patent citations (12)

https://patents.google.com/patent/US8099159B2/en#patentCitations

Cited by (72)

https://patents.google.com/patent/US8099159B2/en#citedBy

Legal events

https://patents.google.com/patent/US8099159B2/en#legalEvents

Similar documents

https://patents.google.com/patent/US8099159B2/en#similarDocuments

Priority and Related Applications

https://patents.google.com/patent/US8099159B2/en#relatedApplications

External links

https://patft.uspto.gov/netacgi/nph-Parser?Sect1=PTO1&Sect2=HITOFF&p=1&u=/netahtml/PTO/srchnum.html&r=1&f=G&l=50&d=PALL&s1=8099159.PN.

USPTO PatentCenter

https://patentcenter.uspto.gov/applications/11521417

USPTO Assignment

https://assignment.uspto.gov/patent/index.html#/patent/search/resultFilter?searchInput=8099159

https://worldwide.espacenet.com/publicationDetails/biblio?CC=US&NR=8099159B2&KC=B2&FT=D

Global Dossier

https://globaldossier.uspto.gov/result/application/US/11521417/1

https://patents.stackexchange.com/questions/tagged/US8099159

Description translated from

Priority of U.S. Provisional patent application Ser. No. 60/717,538 filed on Sep. 14, 2005 is claimed.

FIELD OF THE INVENTION

The present invention relates generally to methods and devices for measuring and evaluating physiological parameters of a living subject.

BACKGROUND OF THE INVENTION

Many have studied the effects of stress and other stimuli on the human body for years. Most refer to stress as a state of mental, emotional, or other psychological strain placed upon one's body. In reality, stress can be any substance or occurrence that places an undue tension or strain on one's physiological and psychological state. A simplistic example is a body's response to the common cold. As a person is exposed to and contracts the common cold virus, the virus will multiply and challenge the body's normal functions by placing an undue stress upon the body. Once the virus is eliminated, the body may return once again to its steady state or normal state. Similarly, emotional disturbances can lead to serious stress responses, often greater than physiological ones. There have been many who have developed methods and devices for analyzing the affects of stress on the human body. Specifically, most have focused on the affects of mental strains or stresses, however, others have focused specifically on physiological stresses.

Around 1950, Dr. Voll, a German doctor studied the electrical properties of acupuncture points and how these properties change as a reflection of stress on the body. Dr. Voll believed that the body responds in a measurable way to stresses that are momentarily placed in proximity to the body. In particular, acupuncture points are situated along acupuncture meridians within a subject's body. The meridians are energetic pathways that traverse along a subject's body. It is believed that acupuncture points relate to various organs and body systems and are more electrically sensitive than surrounding tissue. Measuring the activity around the acupuncture points can help predict whether problems are occurring or will occur within a subject and possibly which bodily organs will be affected.

Other methods and devices for measuring physiological parameters of individuals have been utilized for many years. For example, Galvanic Skin Response (GSR) devices, also known as electrodermal response (EDR), have been used to obtain biofeedback from individuals. Specifically, GSR measures the electrical resistance of the skin and interprets the measurements as an image of activity in certain parts of the body, i.e. biofeedback. Those who have studied human galvanic skin responses believe the more relaxed a person is, the dryer the person's skin will be, thus the higher the skin's electrical resistance will be. When a person is under stress the hand sweats and the resistance goes down. This process has been commonly used in psychophysiology experiments to infer the emotional state of a subject and has also been used in lie detectors, i.e. polygraph devices.

Other known devices have been devised to test specific physiological parameters of a person, such as electroencephalogram (EEG) machines. The EEG machines have been designed to monitor the brain wave activity of a patient. Additionally, some devices measure skin temperature which can be helpful in detecting certain circulatory disorders. Another machine commonly used is an electromyogram (EMG) machines which measures muscle tension in a living subject. Other devices have been employed to monitor heart rate and blood pressure, both of which change in response to stress, arrhythmia and hypertension. As previously mentioned, a lot of emphasis has been placed on monitoring anxiety states of people. These measurements can be adapted in lie detector devices to determine whether a person is telling the truth.

These previous devices have attempted to measure specific physiological parameters but have been met with varying degrees of success. One major down fall is the devices are tailored for measuring a specific physiological parameter. Yet, they offer no real solution for evaluating the physiological measurements or patterns and how it affects a person. For example, most methods and devices are not diverse in its measurements and teach measuring only a specific location for measuring the parameters, i.e. the face. Others believe obtaining biofeedback data can help you train body to over come certain disabilities, i.e. mind over matter.

As such, devices and methods that measure and evaluate stress responses in a living subject thereby providing the subject with beneficial information continues to be sought through ongoing research and development efforts.

SUMMARY OF THE INVENTION

Accordingly, the present invention is drawn towards methods that evaluate stress response patterns in living subjects. Such a method may include locating at least two contact points on an area of skin of the subject and measuring physiological parameters of the at least two contact points to determine a baseline reading. The baseline reading is typically a real-time dynamic baseline reading indicating the physiological state of the at least two contact points at any given moment. Once the baseline reading is determined, an external stimulus can be applied to the subject. Any stimulus may be applied to a subject but non-limiting examples can be verbal statements and images, electroshock, thermal, pressure, emotional activity, odor, subliminal, verbal and visual stimulus. After applying at least one external stimulus the physiological parameters of the at least two contact points can be re-measured to determine a stress response. Subsequently, the dynamic baseline reading and the stress response can be compared to determine whether the stress response is indicative of either a symmetrical stress response pattern or an asymmetrical stress response pattern. Once the stress response pattern is determined, the pattern can be assigned to a specific category. Specifically, the symmetrical stress response pattern can be assigned to a category that is a favorable stress response and the asymmetric stress response pattern can be assigned to a category that is an unfavorable stress response.

In one embodiment, the present invention encompasses a method of analyzing stress measurements of a living subject. Such a method may include taking at least two physiological measurements before and after an external stimulus is applied to the subject, comparing the physiological measurements taken before and after the application of the stimulus and determining whether the physiological measurements diverge, converge or remain unchanged with respect to each other, thereby indicating whether the physiological measurement responses are favorable or unfavorable to the subject.

In an alternative embodiment, the present invention also contemplates a method of determining the physiological state of a living subject, which may comprise measuring the physiological responses of at least two contact points on a subject before and after an external stimulus is applied to the subject and comparing the measured physiological responses to determine whether the physiological responses reflect a favorable or an unfavorable physiological state of the subject. If the physiological state is unfavorable, a trained person skilled in the art would be able to analyze the results and suggest options for returning the physiological state to a more favorable status.

The present invention also contemplates a device for measuring physiological parameters of a living subject. Specifically, such a device can be a sensor device configured for measuring physiological parameters of at least two contact points of skin of a living subject. The device may include a measuring element configured to contact at least two contact points on a subject and to measure a sequence of physiological parameters of these contact points. Additionally, a computing source having an algorithm for determining whether the measurements are a favorable stress response based on a positive sequence or an unfavorable stress response based on a negative sequence. Further, at least one sensor may be coupled to the measuring element for conveying the physiological parameter measurements to a computing source.

There has thus been outlined, rather broadly, the more important features of the invention so that the detailed description thereof that follows may be better understood, and so that the present contribution to the art may be better appreciated. Other features of the present invention will become clearer from the following detailed description of the invention, taken with the accompanying drawing and claims, or may be learned by the practice of the invention.

BRIEF DESCRIPTION OF THE DRAWINGS

FIG. 1 is a graphic representation of a symmetric response in accordance with one embodiment of the present invention.

FIG. 2 is another graphic representation of a symmetric response in accordance with another embodiment of the present invention.

FIG. 3 is a graphic representation of an asymmetric response in accordance with one embodiment of the present invention.

FIG. 4 is a schematic drawing of a hand cradle having measuring elements in accordance with one embodiment of the present invention.

FIG. 5 illustrates a block diagram depicting a system for evaluating stress response patterns in a subject.

The drawings will be described further in connection with the following detailed description. Further, the numerical values used to graph the representation of particular responses is not considered to be an accurate representation of values conducted tests on a subject but are merely used to demonstrate numerically how particular responses are determined.

DETAILED DESCRIPTION

Before particular embodiments of the present invention are disclosed and described, it is to be understood that this invention is not limited to the particular process and materials disclosed herein as such may vary to some degree. It is also to be understood that the terminology used herein is used for the purpose of describing particular embodiments only and is not intended to be limiting.

DEFINITIONS

In describing and claiming the present invention, the following terminology will be used.

The singular forms “a,” “an,” and “the” include plural referents unless the context clearly dictates otherwise. Thus, for example, reference to “a stressor” includes reference to one or more of such stressors, and reference to “a parameter” includes reference to one or more of such parameters.

As used herein, “stress” refers to any reaction that occurs in the body as a result of internal and external stimuli. Generally, the term stress is not only inclusive of emotional nervousness but can also be any physical reaction on the body.

As used herein, “stressor” refers to any stimulus that causes a reaction in a living subject. In accordance with some embodiments of the present invention, a stressor is referred to as an external stimulus, i.e. electrostatic shock.

As used herein, “stress response” refers to a subject's reaction after a stimulus or stressor has been applied to the subject. According, to some aspects of the present invention the stress responses can be measured in microsiemens (μS) or degrees Fahrenheit. The stress response can be categorized as either favorable or unfavorable to the subject.

As used herein, “biofeedback” refers to a technique or process that uses instrumentation to give a person immediate and constant feedback of change in his/her bodily function of which he/she is usually unaware. For example, a biofeedback process can measure bodily functions, like breathing, heart rate, blood pressure, skin temperature, and muscle tension.

As used herein, “physiological parameter” relates to one of many variables of measuring or evaluating bodily function of a subject. Such a variable can have a measure that is indicative of a quantity or function that cannot itself be precisely determined by direct methods, for example, blood pressure and pulse rate are parameters of cardiovascular function.

As used herein, “baseline” refers to information or a value that represents a normal steady state level, or an initial level, of a measurable quantity, used for comparison with values representing response to stimuli. The measurements of the baseline and response values refer to the same individual or system. In accordance with the present invention the baseline is generally a dynamic baseline reading.

As used herein, “symmetric” refers to values of common measurements that on a graphic scale move in the same orientation or move closer together. A symmetric response refers to a substantially balanced physiological parameter.

As used herein, “asymmetric” refers to non-symmetrical or unbalanced responses. In other words, the values of common measurements on a graphic scale will move farther apart from each other.

Any numerical data may be presented herein in a range format. It is to be understood that such range format is used merely for convenience and brevity and should be interpreted flexibly to include not only the numerical values explicitly recited as the limits of the range, but also to include all the individual numerical values or sub-ranges encompassed within that range as if each numerical value and sub-range is explicitly recited.

For example, a response range of 0.5 to 400 should be interpreted to include not only the explicitly recited response limits of 0.5 and 400, but also to include individual responses within that range, such as 0.5, 0.7, 1.0, 5.2, 8.4, 11.6, 14.2, 100, 200, 300, and sub-ranges such as 0.5-2.5, 4.8-7.2, 6-14.9, 55, 85, 100-200, 117, 175, 200-300, 225, 250, and 300-400, etc. This interpretation should apply regardless of the breadth of the range or the characteristic being described.

THE INVENTION

The present invention encompasses methods and devices that are capable of measuring physiological parameters of at least two contact points and determining whether the measured responses of those parameters reflect favorable or unfavorable physiological responses. Specifically, the present invention contemplates a method that may include locating at least two contact points on a subject and measuring the physiological parameters of said subject to obtain a baseline response reading. Once the baseline reading is obtained an external stimulus may be applied to the subject. Re-measuring the same contact points can then be performed to determine the magnitude of response to the stimulus and comparing the re-measured parameters with the baseline reading to determine whether the response pattern is favorable or unfavorable to the subject.

As noted in the background section, many have studied and designed devices for measuring parameters of the body. Specifically, there are those that believe physiological parameters of acupuncture points are the only contact points that provide viable biofeedback. However, it has recently been discovered by the inventor of the present invention there are various contact points or areas which can be sampled and evaluated which are capable of providing an individual important personal biofeedback. Accordingly, the contact points can be acupuncture points found anywhere on a subject's body. Alternatively, the contact points may be any dermal area located on the subject's forearms, thighs, calves, shoulders, back, neck, head, and hands, to name a few. In one exemplary embodiment the area of contact can be the hand. The present invention requires at least two points of contact but can use multiple contact points. Specifically, the present invention contemplates locating at least one contact point found on each finger of a hand and measuring all fingers to obtain the physiological baseline reading and stress response.

The physiological parameters most often measured are variables that can provide some form of biological feedback to the subject. Particularly, the parameters are variables that are indicative of a quantity or function that cannot itself be precisely determined by direct measurement methods, for example, blood pressure and pulse rate are parameters of cardiovascular function. Specifically, there is no true method or device that can measure bodily functions, i.e. the cardiovascular function, apart from measuring parameters of that system, i.e. blood pressure. According to one aspect of the present invention, the physiological parameters may include galvanic skin response (GSR), skin temperature, moisture content, blood pressure, respiratory movement, muscle tension and eye movements. Other physiological parameters or signals that may be measured which are not specifically referenced herein are blood oxygen content and brain waves. In one preferred embodiment, the physiological parameter can be a subject's galvanic skin response function.

The initial step in the above mentioned method is to non-invasively measure the physiological parameters of the contact points thereby obtaining and establishing a personal baseline reading. According to some aspects, the baseline is a series of values that represent a normal steady state, or an initial state of an individual which can be used for comparing values representing stress responses after applying a stimulus. Notably, every individual is unique, thus baselines obtained will vary with each individual. In one embodiment the method contemplates taking multiple cutaneous physiological measurements in tandem at each designated contact point. The initial step of measuring each contact point may be repeated multiple times prior to applying any type of a stimulus to the subject, such that a more accurate physiological baseline can be obtained. In one embodiment of the present invention the baseline is a real-time dynamic baseline reading. Once a reliable personal baseline has been established at least one stressor and preferably multiple stressors may be applied to the subject. Notably, each person functions different and the concentration or amount of stimulus applied may vary for each individual.

A stressor or also referred to herein as a stimulus can help provide valuable and measurable data to the subject. The stimulus can be an internal stressor and more preferably an external stressor. Suitable internal stressors can be any substance that produces some form of a physiological change within the subject. For example, an internal stimulus can be used, such as a drug cause physiological changes from within the subject's body. Preferably, an external stimulus may be used to gauge possible changes in a subject's established baseline. Multiple successive stressors are typically applied to the subject and the baseline can be tracked pursuant to application of each stressor. The stressors can be constant or varying in strength depending on the resistance and the specific characteristics of the subject. Suitable external stressors may include electroshock, thermal, pressure, emotional, odor, subliminal, verbal and visual stimulus. In a preferred embodiment the stressor can be an electromagnetic wave used to measure the galvanic skin responses of an individual.

The response to external stimulus can be indicative of the certain health conditions of the subject. For example, galvanic skin responses can indicate whether the subject is in a relaxed state or stressed state. As noted above, galvanic skin responses are changes in the electrical properties of the subject's skin. The change in electrical properties occurs due to a stressor and the individual's physiological state. The human skin can conduct small amounts of electricity, thus when a low electrical current is applied to the skin, a change in electric conductance or the resistance of the skin can be measured in μS. The electrical conductance of human skin is typically categorized as either phasic or tonic conductance. Phasic conductance refers to stimulus related changes in skin conductance. Meaning, the change in electrical skin conductance can be stimulated by any type of stimuli, i.e. temperature, water content, odor, etc. On the other hand, tonic skin conductance refers to electrical skin conductance at a steady state or in the absence of stimuli. By evaluating the change in these two types of skin conductance it is believed that certain measurable values can signify certain physiological states of particular organs or of the subject in general.

Comparing and evaluating the measured parameters can predict the physiological patterns or the stress levels of an individual. In particular the methods recited herein can determine whether stress responses are favorable or unfavorable responses to a person. As previously discussed, the method contemplates testing at least two contact points on an area of skin of a person to determine a physiological baseline. Typically, the baseline reflects the physiological state of the individual at a substantially steady state or in other words in the absence of a stimulus. Once a baseline has been determined, a stimulus is applied to the individual and the same contact points are re-measured and the deviation between the baseline and stress response is calculated. This deviation can be known as a deviation ratio. The numerical values of the deviation ratio may indicate whether the stress responses are favorable or unfavorable responses to a subject. Generally, a positive deviation ratio indicates that the response is symmetric (favorable) and a negative deviation ratio indicates that the response is asymmetric (unfavorable).

Referring now to FIGS. 1-3 , are depicted graphical representations of symmetric and asymmetric responses. In particular, FIG. 1 , reveals a GSR baseline and stress response reading for each contact points (

). The baseline reading indicates that under normal conditions the subject has a GSR reading of about 10 μS and 15 μS for contact points (

), respectively. After a stimulus is applied, the GSR shifted to 20 and 25, respectively. The shifting of these two successive points on a graphic scale in a substantially same direction and by substantially the same amount, indicates that the responses are symmetric or in other words the deviation ratio is positive. FIG. 2 , shows a GSR parameter reading of 10 and 15 μS for contacts points (

). After the stimulus is applied the response yielded values of 11 and 14 for contact points (

). The numerical value of each contact point move closer towards one another, thereby indicating another symmetric response or alternatively, a positive deviation ratio response. In contrast, FIG. 3 shows baseline values for contact points (

) as 10 and 15 μS. Subsequent to the application of an external stimulus, the individual subconsciously responds with values of 11 and 25 μS for contact points (

), respectively. These two successive points move away from each other on the graphic scale, indicating an asymmetric response or a negative deviation value.

Once the responses have been measured and the deviation values have been calculated by an algorithm, the responses can be categorized as being either favorable or unfavorable to a subject. A favorable stress response is indicative of measured values that either converge toward each other or remain substantially unchanged, i.e. symmetric. An unfavorable stress response is indicative of measured values that diverge from each other, i.e. asymmetric. Further a favorable response can imply that the individual is substantially healthy. While an unfavorable response can suggest or predict that the individual will become unhealthy and may require drugs or nutritional supplements to improve the unhealthy condition. At the least, an unfavorable response may indicate that the person should undergo more treatments or evaluations to determine why the responses are unfavorable.

If an individual receives an unfavorable response, vitamin supplements may be consumed by the individual to combat the stressors that may be affecting the body. For example, if a subject has contracted the common cold virus and after evaluating his/her physiological state, then the individual may consume a supplemental material that can aid in the elimination and combating of the virus. Further, the contact points of the individual may be retested to determine whether the supplement is helping to obtain a more favorable stress response and whether the supplemental dosage is proper. In this manner a person may be able to eliminate those supplements that lack the beneficial results needed.

The present invention also contemplates a device or a sensor device used to evaluate physiological stress patterns or the physiological state of the individual. Such a device can generally measure the physiological parameters of at least two cutaneous contact points of a living subject. The device may include a measuring element which has been configured to contact the at least two contact points and to measure a sequence of physiological parameters of the subject. The measuring element may be any substrate that can contact the dermal layer or may be coupled to a plurality of sensor devices. For example, FIG. 4 illustrates a

hand cradle

https://patents.google.com/patent/US8099159B2/en

having a plurality of measuring

https://patents.google.com/patent/US8099159B2/en

coupled to a

rigid substrate member

https://patents.google.com/patent/US8099159B2/en

and each measuring element can be coupled to at least one sensor (not shown) configured to test the galvanic skin responses in the individual's hand can be employed. In this example the measuring element can be comprised of any material that can conduct energy and the substrate member may be any solid or rigid material such as plastic or metal. A more complex device may include multiple measuring elements having a plurality of sensors coupled thereto and configured to monitor and measure the variances in the phasic and tonic skin conductance properties. In other embodiments, the device can be configured to monitor and test other physiological parameters as described herein. For example, the measuring element may be coupled to at least one thermometer capable of detecting and measuring minute changes in skin temperature. In an alternative embodiment the measuring element may be coupled to other sensors configured to measure or monitor changes in various physiological parameters such as respiratory air flow, respiratory excursions, muscle movements, heart pulses, blood pressure and blood oxygen content levels.

Furthermore, the sensors may also be coupled to a computing source and configured for conveying physiological parameter measurements from the measuring element to the computer source. Typically, the sensor is coupled to the computing source via direct wire or telemetry, however, the sensor may be coupled to the computing source via other data communication means. Various telemetry systems may be used such as wireless transmission systems. Suitable wireless systems may include standard of IEEE 802.11, IEEE 802.15, Bluetooth, Ultra Wide Band, Radio Frequency or other mesh networks, such as BAN, WPAN, and WLAN.

Generally, the computing source has a user interface for operating and receiving information from the measuring elements. In one embodiment of the present invention the computing source may include an algorithm for determining whether the physiological measurements are favorable or unfavorable stress responses based upon a positive or negative sequence, respectively. Typically, the favorable and unfavorable stress responses are converted into a signature and are compared to pre-designated signatures stored in a library included with the computer source.

In one embodiment, the computing source may include a library having pre-designated signatures representing certain physiological parameter responses. Generally, the algorithm associated with the present device can be configured to compare the physiological responses with the pre-designated signatures thereby predicting whether the responses are favorable or unfavorable and possibly provide remedial feedback to the subject. Optionally, the remedial feedback may provide specific therapeutic remedies or nutritional supplements that may be taken in order to shift the responses into a favorable category.

FIG. 5 depicts a block diagram of

https://patents.google.com/patent/US8099159B2/en

that can evaluate stress response patterns in a patient. The system may include a

https://patents.google.com/patent/US8099159B2/en

to be tested, a

hand cradle

https://patents.google.com/patent/US8099159B2/en

computing source

https://patents.google.com/patent/US8099159B2/en

. As previously described herein, the hand cradle can monitor and test galvanic skin responses, physiological parameters, of the patient at a normal steady state to obtain a baseline with the aid of sensors and measuring elements (not shown). Once a baseline response is established, an

external stimulus

https://patents.google.com/patent/US8099159B2/en

can be applied to the patient. The handle cradle measures the patient's galvanic skin response subsequent to the applied stimulus. A communications means

, such as direct wire or wireless communication means, can convey the responses and data to the computing source. The computing source typically contains an

https://patents.google.com/patent/US8099159B2/en

https://patents.google.com/patent/US8099159B2/en

. The algorithm can be configured to process the galvanic skin responses with the baseline reading to determine whether the physiological measurements are favorable or unfavorable stress responses. Typically, the favorable and unfavorable stress responses are converted by the algorithm into a signature and are compared to pre-designated signatures stored in the library included with the computer source. Once compared, the responses may be assigned a category of either symmetric (favorable)

https://patents.google.com/patent/US8099159B2/en

or asymmetric (unfavorable)

https://patents.google.com/patent/US8099159B2/en

. These responses may be manifested to the patient or a certified operator via an output device, such as a monitor, thereby the providing the patient with the information such that appropriate therapy actions may be taken if needed.

It is to be understood that the above-described arrangements are only illustrative of the application of the principles of the present invention. Numerous modifications and alternative arrangements may be devised by those skilled in the art without departing from the spirit and scope of the present invention. Thus, while the present invention has been fully described above with particularity and detail in connection with what is presently deemed to be the most practical and preferred embodiments of the invention, it will be apparent to those of ordinary skill in the art that numerous modifications, including, but not limited to, variations in size, materials, shape, form, function and manner of operation, assembly and use may be made without departing from the principles and concepts set forth herein.

A human subject manifesting classic symptoms of a common cold can be tested with a number of stressors associated with the common cold. The test can include stressors of various viruses and alternative therapeutic substances (drugs, nutritional supplements, etc.) known to have an affect in either fighting viruses, treating symptoms of the common cold, or generally supporting the immune system. By monitoring the subject's physiological parameter before and after an applied stimulus, a certified operator may be able to infer cause and effect based upon the stress responses and may at least be able to narrow the field of possibilities for further investigation. If, however, virus samples are used as stressors, those that correlate with asymmetrical deviation responses will be suspect as the cause. Subsequent testing with therapeutic substances as stressors, i.e. those that correlate with asymmetrical deviation response, will be weighed more heavily in clinical decisions regarding therapy.

Claims (20) Hide Dependent translated from

A method of evaluating stress response patterns in a living subject, comprising the steps of:

locating at least two contact points on an area of skin of the subject;

measuring physiological parameters of the at least two contact points to determine individual respective baseline readings of each of the at least two contact points;

calculating a baseline response differential between the individual baseline readings of the at least two contact points;

applying an external stimulus to the subject;

re-measuring the physiological parameters of the at least two contact points after the applied external stimulus to determine individual respective stress response readings of each of the at least two contact points;

calculating a post-stimulus response differential between the individual post-stimulus readings of the at least two contact points;

comparing the baseline response differential against the post-stimulus response differential to identify a biological preference to the external stimulus by determining one of a symmetrical stress response pattern and an asymmetrical stress response pattern in the response differentials.

The method of claim 1 , wherein the at least two contact points are located on an area of skin on a hand of the subject.

The method of claim 1 , wherein the physiological parameters are selected from a group consisting of galvanic skin response (GSR), temperature, moisture content, and pressure parameters.

The method of claim 1 , wherein the baseline readings are a real-time dynamic baseline reading.

The method of claim 1 , wherein the step of measuring is accomplished by a hand cradle device.

The method of claim 1 , wherein the symmetrical stress response pattern is indicative of response differentials that either converge toward each other or remain substantially unchanged.

The method of claim 1 , wherein the asymmetrical stress response pattern is indicative of response differentials that diverge from each other.

The method of claim 1 , wherein the external stimulus is selected from a group consisting of electroshock, thermal, pressure, emotional, odor, subliminal, verbal and visual stimulus.

The method of claim 1 , wherein the step of comparing is accomplished by a computer source including an algorithm configured to determine one of a symmetrical stress response pattern and an asymmetrical stress response pattern to identify a biological preference to the external stimulus.

The method of claim 1 , wherein the steps of measuring and re-measuring are accomplished by a non-invasive measuring technique.

A system for measuring physiological parameters of at least two contact points of skin of a living subject, comprising:

a measuring element configured to contact the at least two contact points and to measure a sequence of the physiological parameters of the subject, the sequence comprising:

individual respective baseline readings of each of the at least two contact points before the application of an external stimulus to the living subject; and

individual respective stress response readings of each of the at least two contact points after the application of the external stimulus to the living subject;

a computing source having:

an algorithm for comparing a baseline response differential between the individual baseline readings of the at least two contact points against a post-stimulus response differential between the respective individual stress response readings of the same contact points after the applied external stimulus; and

an algorithm for determining one of a symmetrical stress response pattern and an asymmetrical stress response pattern between the baseline and post-stimulus response differentials; and

at least one sensor coupled to the measuring element for conveying the physiological parameter measurements to the computing source.

The system of claim 11 , wherein the computing source includes a library which stores pre-designated signatures representing certain physiological parameter measurements and an algorithm that compares the measurements with the pre-designated signatures to determine whether the response differentials indicate a favorable response or an unfavorable response.

The system of claim 11 , wherein the at least one sensor is an electrode configured to measure galvanic skin responses.

The system of claim 11 , wherein the sensor is further coupled to the computing source via direct wire or telemetry.

The system of claim 14 , wherein the telemetry is a wireless transmission of data utilizing the standard of IEEE 802.11, IEEE 802.15, Bluetooth, Ultra Wide Band, Radio Frequency or other mesh networks.

The system of claim 11 , wherein the measuring element is a hand cradle device having multiple finger contact points.

The system of claim 11 , wherein the sensor detects changes in GSR, temperature, moisture content and pressure relating to the at least two contact points.

#### A method of analyzing stress measurements of a living subject, comprising:

taking a physiological measurement from at least two contact points on an area of skin of the subject before and after an external stimulus is applied to the subject;

calculating a baseline and a post-stimulus response differential between the at least two contact points taken before and after the application of the stimulus, respectively; and

determining whether the baseline and post-stimulus response differentials converge or remain substantially unchanged, thereby indicating that the response to the external stimulus is favorable, or whether the baseline and post-stimulus response differential diverge, thereby indicating that the response to the external stimulus is unfavorable.

A method of determining the physiological state of a living subject, comprising the steps of:

measuring the physiological responses of each of at least two contact points on the subject before and after an external stimulus is applied to the subject; and

comparing baseline and post-stimulus response differentials in the physiological responses between the at least two contact points as measured both before and after the external stimulus, respectively, to determine whether a change in the response differential reflects a favorable or an unfavorable physiological state of the subject.

The method of claim 1 , further comprising assigning the symmetrical stress response pattern to a category that is a favorable stress response and the asymmetric stress response pattern to a category that is an unfavorable stress response.

Patent Citations (12)

Publication number Priority date Publication date Assignee Title

https://patents.google.com/patent/US8099159B2/en

- 1982-04-26 1987-08-04 Vincent Cornellier Biomonitoring stress management method and device

https://patents.google.com/patent/US8099159B2/en

1996-03-15 1997-10-14 Zawilinski; Kenneth Michael Emotional response analyzer system with multimedia display

https://patents.google.com/patent/US8099159B2/en

1996-07-30 1998-04-21 Gero; Jeffrey Biofeedback apparatus

https://patents.google.com/patent/US8099159B2/en

1995-09-13 1998-06-23 Anbar; Michael Telethermometric psychological evaluation by monitoring of changes in skin perfusion induced by the autonomic nervous system

US6325763B1

https://patents.google.com/patent/US8099159B2/en

- 2000-01-03 2001-12-04 Kenneth Raymond Pfeiffer Portable differential thermal biofeedback device

US6527700B1

https://patents.google.com/patent/US8099159B2/en

- 1999-10-29 2003-03-04 Joseph A. Manico Management of physiological and psychological state of an individual using biophilic images

US20030236451A1

https://patents.google.com/patent/US8099159B2/en

2002-04-03 2003-12-25 The Procter & Gamble Company Method and apparatus for measuring acute stress

US6743182B2

https://patents.google.com/patent/US8099159B2/en

2001-05-25 2004-06-01 The Mclean Hospital Corporation Method for determining attention deficit hyperactivity disorder (ADHD) medication dosage and for monitoring the effects of (ADHD) medication

US20040143170A1

https://patents.google.com/patent/US8099159B2/en

- 2002-12-20 2004-07-22 Durousseau Donald R. Intelligent deception verification system

US6837615B2

https://patents.google.com/patent/US8099159B2/en

- 2002-03-19 2005-01-04 John Scott Newman Method of evaluating level of anxiety of person based on skin temperature

US20050154264A1

https://patents.google.com/patent/US8099159B2/en

2004-01-08 2005-07-14 International Business Machines Corporation Personal stress level monitor and systems and methods for using same

US20070249914A1

https://patents.google.com/patent/US8099159B2/en

- 2001-12-21 2007-10-25 The University Of Chicago System and method for identification of false statements

Family To Family Citations

Cited by examiner, † Cited by third party

Cited By (72)

Publication number Priority date Publication date Assignee Title

US20100191124A1

https://patents.google.com/patent/US8099159B2/en

- 2007-04-17 2010-07-29 Prokoski Francine J System and method for using three dimensional infrared imaging to provide psychological profiles of individuals

US20130109930A1

https://patents.google.com/patent/US8099159B2/en

- 2011-10-31 2013-05-02 Eyal YAFFE-ERMOZA Polygraph

WO2013163090A1

https://patents.google.com/patent/US8099159B2/en

- 2012-04-23 2013-10-31 Sackett Solutions & Innovations, LLC Cognitive biometric systems to monitor emotions and stress

US20140276064A1

https://patents.google.com/patent/US8099159B2/en

- 2012-08-30 2014-09-18 Kabushiki Kaisha Toshiba Ultrasound probe and ultrasound diagnosis apparatus

US20150230726A1

https://patents.google.com/patent/US8099159B2/en

- 2013-05-14 2015-08-20 Enzymes, Inc. Comprehensive health assessment tool for identifying acquired errors of metabolism

US9936250B2

https://patents.google.com/patent/US8099159B2/en

2015-05-19 2018-04-03 The Nielsen Company (Us), Llc Methods and apparatus to adjust content presented to an individual

US10818380B1

https://patents.google.com/patent/US8099159B2/en

2013-05-01 2020-10-27 Amy Kathleen Davis Moore Methods for identifying and treating errors in biochemical pathways

US11642039B1

https://patents.google.com/patent/US8099159B2/en

2018-11-11 2023-05-09 Kimchi Moyer Systems, methods, and apparatuses for analyzing galvanic skin response based on exposure to electromagnetic and mechanical waves

US11642038B1

https://patents.google.com/patent/US8099159B2/en

2018-11-11 2023-05-09 Kimchi Moyer Systems, methods and apparatus for galvanic skin response measurements and analytics

Family To Family Citations

US7586888B2

https://patents.google.com/patent/US8099159B2/en

- 2005-02-17 2009-09-08 Mobitrum Corporation Method and system for mesh network embedded devices

US7630736B2

https://patents.google.com/patent/US8099159B2/en

- 2005-10-11 2009-12-08 Mobitrum Corporation Method and system for spatial data input, manipulation and distribution via an adaptive wireless transceiver

JP4497081B2

https://patents.google.com/patent/US8099159B2/en

- 2005-10-31 2010-07-07 トヨタ自動車株式会社 Human condition detection device

US7801058B2

https://patents.google.com/patent/US8099159B2/en

- 2006-07-27 2010-09-21 Mobitrum Corporation Method and system for dynamic information exchange on mesh network devices

US8305936B2

https://patents.google.com/patent/US8099159B2/en

2006-07-27 2012-11-06 Mobitrum Corporation Method and system for dynamic information exchange on a mesh network in a vehicle

US8305935B2

https://patents.google.com/patent/US8099159B2/en

- 2006-07-27 2012-11-06 Mobitrum Corporation Method and system for dynamic information exchange on location aware mesh network devices

USRE47894E1

https://patents.google.com/patent/US8099159B2/en

2006-07-27 2020-03-03 Iii Holdings 2, Llc Method and system for dynamic information exchange on location aware mesh network devices

US8427979B1

https://patents.google.com/patent/US8099159B2/en

2006-07-27 2013-04-23 Mobitrum Corporation Method and system for dynamic information exchange on location aware mesh network devices

US8411590B2

https://patents.google.com/patent/US8099159B2/en

2006-07-27 2013-04-02 Mobitrum Corporation Mesh network remote control device

US20080320029A1

https://patents.google.com/patent/US8099159B2/en

- 2007-02-16 2008-12-25 Stivoric John M Lifeotype interfaces

US8679008B2

https://patents.google.com/patent/US8099159B2/en

- 2007-02-16 2014-03-25 Galvanic Limited Biosensor device and method

US20090024049A1

https://patents.google.com/patent/US8099159B2/en

2007-03-29 2009-01-22 Neurofocus, Inc. Cross-modality synthesis of central nervous system, autonomic nervous system, and effector data

WO2008137579A1

https://patents.google.com/patent/US8099159B2/en

2007-05-01 2008-11-13 Neurofocus, Inc. Neuro-informatics repository system

WO2008137581A1

https://patents.google.com/patent/US8099159B2/en

2007-05-01 2008-11-13 Neurofocus, Inc. Neuro-feedback based stimulus compression device

US8392253B2

https://patents.google.com/patent/US8099159B2/en

2007-05-16 2013-03-05 The Nielsen Company (Us), Llc Neuro-physiology and neuro-behavioral based stimulus targeting system

WO2008141340A1

https://patents.google.com/patent/US8099159B2/en

- 2007-05-16 2008-11-20 Neurofocus, Inc. Audience response measurement and tracking system

US20090030287A1

https://patents.google.com/patent/US8099159B2/en

- 2007-06-06 2009-01-29 Neurofocus Inc. Incented response assessment at a point of transaction

US8494905B2

https://patents.google.com/patent/US8099159B2/en

- 2007-06-06 2013-07-23 The Nielsen Company (Us), Llc Audience response analysis using simultaneous electroencephalography (EEG) and functional magnetic resonance imaging (fMRI)

US20090036755A1

https://patents.google.com/patent/US8099159B2/en

- 2007-07-30 2009-02-05 Neurofocus, Inc. Entity and relationship assessment and extraction using neuro-response measurements

CN101815467B

https://patents.google.com/patent/US8099159B2/en

2007-07-30 2013-07-17 神经焦点公司 Neuro-response stimulus and stimulus attribute resonance estimator

US8131355B2

https://patents.google.com/patent/US8099159B2/en

- 2007-08-01 2012-03-06 James Hoyt Clark Automated skin electrical resistance measurement device and method

US8386313B2

https://patents.google.com/patent/US8099159B2/en

- 2007-08-28 2013-02-26 The Nielsen Company (Us), Llc Stimulus placement system using subject neuro-response measurements

US8635105B2

https://patents.google.com/patent/US8099159B2/en

- 2007-08-28 2014-01-21 The Nielsen Company (Us), Llc Consumer experience portrayal effectiveness assessment system

US8392254B2

https://patents.google.com/patent/US8099159B2/en

2007-08-28 2013-03-05 The Nielsen Company (Us), Llc Consumer experience assessment system

US8392255B2

https://patents.google.com/patent/US8099159B2/en

2007-08-29 2013-03-05 The Nielsen Company (Us), Llc Content based selection and meta tagging of advertisement breaks

US8494610B2

https://patents.google.com/patent/US8099159B2/en

- 2007-09-20 2013-07-23 The Nielsen Company (Us), Llc Analysis of marketing and entertainment effectiveness using magnetoencephalography

US20090083129A1

https://patents.google.com/patent/US8099159B2/en

2007-09-20 2009-03-26 Neurofocus, Inc. Personalized content delivery using neuro-response priming data

https://patents.google.com/patent/US8099159B2/en

- 2007-12-10 2008-12-29 Hadasit Med Res Service Method and system for detection of pre-fainting conditions

US20090189739A1

https://patents.google.com/patent/US8099159B2/en

- 2008-01-25 2009-07-30 Mobitrum Corporation Passive voice enabled rfid devices

US20090196852A1

https://patents.google.com/patent/US8099159B2/en

- 2008-02-04 2009-08-06 Watkinson D Tobin Compositions and methods for diagnosing and treating immune disorders

US20110207988A1

https://patents.google.com/patent/US8099159B2/en

- 2008-10-31 2011-08-25 Nexstim Oy Method, apparatus and computer program for non-invasive brain stimulation when target muscles are suitably active

WO2010051037A1

https://patents.google.com/patent/US8099159B2/en

- 2008-11-03 2010-05-06 Bruce Reiner Visually directed human-computer interaction for medical applications

US9357240B2

https://patents.google.com/patent/US8099159B2/en

- 2009-01-21 2016-05-31 The Nielsen Company (Us), Llc Methods and apparatus for providing alternate media for video decoders

US8464288B2

https://patents.google.com/patent/US8099159B2/en

- 2009-01-21 2013-06-11 The Nielsen Company (Us), Llc Methods and apparatus for providing personalized media in video

US8270814B2

https://patents.google.com/patent/US8099159B2/en

- 2009-01-21 2012-09-18 The Nielsen Company (Us), Llc Methods and apparatus for providing video with embedded media

US20100250325A1

https://patents.google.com/patent/US8099159B2/en

2009-03-24 2010-09-30 Neurofocus, Inc. Neurological profiles for market matching and stimulus presentation

US20110046502A1

https://patents.google.com/patent/US8099159B2/en

- 2009-08-20 2011-02-24 Neurofocus, Inc. Distributed neuro-response data collection and analysis

US8655437B2

https://patents.google.com/patent/US8099159B2/en

2009-08-21 2014-02-18 The Nielsen Company (Us), Llc Analysis of the mirror neuron system for evaluation of stimulus

US10987015B2

https://patents.google.com/patent/US8099159B2/en

- 2009-08-24 2021-04-27 Nielsen Consumer Llc Dry electrodes for electroencephalography

US8209224B2

https://patents.google.com/patent/US8099159B2/en

2009-10-29 2012-06-26 The Nielsen Company (Us), Llc Intracluster content management using neuro-response priming data

US9560984B2

https://patents.google.com/patent/US8099159B2/en

2009-10-29 2017-02-07 The Nielsen Company (Us), Llc Analysis of controlled and automatic attention for introduction of stimulus material

US20110106750A1

https://patents.google.com/patent/US8099159B2/en

2009-10-29 2011-05-05 Neurofocus, Inc. Generating ratings predictions using neuro-response data

US8335715B2

https://patents.google.com/patent/US8099159B2/en

- 2009-11-19 2012-12-18 The Nielsen Company (Us), Llc. Advertisement exchange using neuro-response data

US8335716B2

https://patents.google.com/patent/US8099159B2/en

- 2009-11-19 2012-12-18 The Nielsen Company (Us), Llc. Multimedia advertisement exchange

US20110213217A1

https://patents.google.com/patent/US8099159B2/en

- 2010-02-28 2011-09-01 Nellcor Puritan Bennett Llc Energy optimized sensing techniques

US20110237971A1

https://patents.google.com/patent/US8099159B2/en

- 2010-03-25 2011-09-29 Neurofocus, Inc. Discrete choice modeling using neuro-response data

WO2011133548A2

https://patents.google.com/patent/US8099159B2/en

2010-04-19 2011-10-27 Innerscope Research, Inc. Short imagery task (sit) research method

US8655428B2

https://patents.google.com/patent/US8099159B2/en

2010-05-12 2014-02-18 The Nielsen Company (Us), Llc Neuro-response data synchronization

US20120010488A1

https://patents.google.com/patent/US8099159B2/en

- 2010-07-01 2012-01-12 Henry Barry J Method and apparatus for improving personnel safety and performance using logged and real-time vital sign monitoring

US8392250B2

https://patents.google.com/patent/US8099159B2/en

2010-08-09 2013-03-05 The Nielsen Company (Us), Llc Neuro-response evaluated stimulus in virtual reality environments

US8392251B2

https://patents.google.com/patent/US8099159B2/en

2010-08-09 2013-03-05 The Nielsen Company (Us), Llc Location aware presentation of stimulus material

US8396744B2

https://patents.google.com/patent/US8099159B2/en

2010-08-25 2013-03-12 The Nielsen Company (Us), Llc Effective virtual reality environments for presentation of marketing materials

US8712827B2

https://patents.google.com/patent/US8099159B2/en

- 2011-02-09 2014-04-29 Pulsar Informatics, Inc. Normalized contextual performance metric for the assessment of fatigue-related incidents

KR101258203B1

https://patents.google.com/patent/US8099159B2/en

- 2011-02-24 2013-04-25 상명대학교 산학협력단 cradle device for sensing bio-electric signal and portable device for analyzing the bio-electric signal

US9451303B2

https://patents.google.com/patent/US8099159B2/en

2012-02-27 2016-09-20 The Nielsen Company (Us), Llc Method and system for gathering and computing an audience's neurologically-based reactions in a distributed framework involving remote storage and computing

US9569986B2

https://patents.google.com/patent/US8099159B2/en

2012-02-27 2017-02-14 The Nielsen Company (Us), Llc System and method for gathering and analyzing biometric user feedback for use in social media and advertising applications

US9292858B2

https://patents.google.com/patent/US8099159B2/en

2012-02-27 2016-03-22 The Nielsen Company (Us), Llc Data collection system for aggregating biologically based measures in asynchronous geographically distributed public environments

US9060671B2

https://patents.google.com/patent/US8099159B2/en

2012-08-17 2015-06-23 The Nielsen Company (Us), Llc Systems and methods to gather and analyze electroencephalographic data

US20150245777A1

https://patents.google.com/patent/US8099159B2/en

- 2012-10-19 2015-09-03 Basis Science, Inc. Detection of emotional states

US9320450B2

https://patents.google.com/patent/US8099159B2/en

2013-03-14 2016-04-26 The Nielsen Company (Us), Llc Methods and apparatus to gather and analyze electroencephalographic data

US9622702B2

https://patents.google.com/patent/US8099159B2/en

2014-04-03 2017-04-18 The Nielsen Company (Us), Llc Methods and apparatus to gather and analyze electroencephalographic data

US10874340B2

https://patents.google.com/patent/US8099159B2/en

- 2014-07-24 2020-12-29 Sackett Solutions & Innovations, LLC Real time biometric recording, information analytics and monitoring systems for behavioral health management

JP6921711B2

https://patents.google.com/patent/US8099159B2/en

2017-10-31 2021-08-18 キヤノン株式会社 Image processing equipment, image processing methods, and programs

Cited by examiner, † Cited by third party, ‡ Family to family citation

Similar Documents

Publication Publication Date Title

US8099159B2

https://patents.google.com/patent/US8099159B2/en

2012-01-17 Methods and devices for analyzing and comparing physiological parameter measurements

Bari et al.

https://patents.google.com/patent/US8099159B2/en

2018 Electrodermal responses to discrete stimuli measured by skin conductance, skin potential, and skin susceptance

https://patents.google.com/patent/US8099159B2/en

2015 Assessment of biofeedback training for emotion management through wearable textile physiological monitoring system

https://patents.google.com/patent/US8099159B2/en

2024 Non-invasive techniques for muscle fatigue monitoring: A comprehensive survey

Wijsman et al.

https://patents.google.com/patent/US8099159B2/en

2011 Towards mental stress detection using wearable physiological sensors

Ahuja et al.

https://patents.google.com/patent/US8099159B2/en

2003 GSR and HRV: its application in clinical diagnosis

Greco et al.

https://patents.google.com/patent/US8099159B2/en

2019 Assessment of muscle fatigue during isometric contraction using autonomic nervous system correlates

Rocha et al.

https://patents.google.com/patent/US8099159B2/en

2017 Weighted-cumulated S-EMG muscle fatigue estimator

US20200160962A1

https://patents.google.com/patent/US8099159B2/en

2020-05-21 Application of real signal time variation wavelet analysis

Jessee et al.

https://patents.google.com/patent/US8099159B2/en

2018 Effects of load on the acute response of muscles proximal and distal to blood flow restriction

Ashwin et al.

https://patents.google.com/patent/US8099159B2/en

2022 Stress detection using wearable physiological sensors and machine learning algorithm

Kong et al.

https://patents.google.com/patent/US8099159B2/en

2023 Differentiating between stress-and EPT-induced electrodermal activity during dental examination

https://patents.google.com/patent/US8099159B2/en

2014 Physiological signals based quantitative evaluation method of the pain

Gandhi et al.

https://patents.google.com/patent/US8099159B2/en

2015 Mental stress assessment-a comparison between HRV based and respiration based techniques

Fang et al.

https://patents.google.com/patent/US8099159B2/en

2024 Validation of webe band during physical activities

Mohamad Saadon et al.

https://patents.google.com/patent/US8099159B2/en

2019 Electrically evoked wrist extensor muscle fatigue throughout repetitive motion as measured by mechanomyography and near-infrared spectroscopy

Krasnodębska et al.

https://patents.google.com/patent/US8099159B2/en

2024 Analysis of the relationship between emotion intensity and electrophysiology parameters during a voice examination of opera singers

WO2006008334A1

https://patents.google.com/patent/US8099159B2/en

2006-01-26 Method and device for identifying, measuring and analyzing abnormal neurological responses

Bairagi et al.

https://patents.google.com/patent/US8099159B2/en

2018 A novel method for stress measuring using EEG signals

Kang et al.

https://patents.google.com/patent/US8099159B2/en

2020 Multi bio-signal based algorithm using EMD and FFT for stress analysis

https://patents.google.com/patent/US8099159B2/en

2010 Wireless medical sensor measurements of fatigue in patients with multiple sclerosis

CN101495026A

https://patents.google.com/patent/US8099159B2/en

2009-07-29 Methods and devices for analyzing and comparing physiological parameter measurements

WO2023200377A1

https://patents.google.com/patent/US8099159B2/en

2023-10-19 Sensor for sensing electrical parameters of body surface layer

Chaudhari et al.

https://patents.google.com/patent/US8099159B2/en

2024 Investigating EMG fatigue markers of biceps muscle: a comparative study through mono fractal and band power analysis

Regueiro et al.

https://patents.google.com/patent/US8099159B2/en

2019 Electroencephalographic (EEG) Analysis of Individuals Experiencing Acute Mental Stress

Priority And Related Applications

Priority Applications (2)

Application Priority date Filing date Title

US11/521,417

https://patents.google.com/patent/US8099159B2/en

2005-09-14 2006-09-13 Methods and devices for analyzing and comparing physiological parameter measurements

PCT/US2006/036119

https://patents.google.com/patent/US8099159B2/en

2005-09-14 2006-09-14 Methods and devices for analyzing and comparing physiological parameter measurements

Applications Claiming Priority (2)

Application Filing date Title

US71753805P 2005-09-14

US11/521,417

https://patents.google.com/patent/US8099159B2/en

2006-09-13 Methods and devices for analyzing and comparing physiological parameter measurements

Legal Events

Date Code Title Description

2006-12-04 AS Assignment

: ZYTO CORP., UTAH

Free format text

: ASSIGNMENT OF ASSIGNORS INTEREST;ASSIGNOR:COOK, VAUGHN;REEL/FRAME:018637/0815

Effective date

2011-12-28 STCF Information on status: patent grant

Free format text

: PATENTED CASE

2015-07-06 FPAY Fee payment

Year of fee payment

2019-07-17 MAFP Maintenance fee payment

Free format text

: PAYMENT OF MAINTENANCE FEE, 8TH YR, SMALL ENTITY (ORIGINAL EVENT CODE: M2552); ENTITY STATUS OF PATENT OWNER: SMALL ENTITY

Year of fee payment

2023-07-13 MAFP Maintenance fee payment

Free format text

: PAYMENT OF MAINTENANCE FEE, 12TH YR, SMALL ENTITY (ORIGINAL EVENT CODE: M2553); ENTITY STATUS OF PATENT OWNER: SMALL ENTITY

Year of fee payment

Data provided by IFI CLAIMS Patent Services

Learn more about data coverage, search syntax and other features.

https://support.google.com/faqs/answer/6390996

Send feedback about technical issues or feature requests for Google Patents.

Send Feedback

https://patents.google.com/patent/US8099159B2/en

Public Datasets

https://console.cloud.google.com/marketplace/product/google\_patents\_public\_datasets/google-patents-public-data

https://www.google.com/policies/terms/

Privacy Policy

https://www.google.com/privacy/privacy-policy.html

https://support.google.com/websearch/

