---
sourceFile: "FACS-Based Graph Features for Real-Time Micro-Expression ..."
exportedBy: "Kortex"
exportDate: "2026-06-29T01:00:27.864Z"
---

# FACS-Based Graph Features for Real-Time Micro-Expression ...

284cff4e-2b01-4f0b-90b0-69952b8d8a85

FACS-Based Graph Features for Real-Time Micro-Expression ...

07819c26-7eca-4e22-87a1-d4f459b26224

https://pmc.ncbi.nlm.nih.gov/articles/PMC8321161/

Checking your browser - reCAPTCHA

Checking your browser before accessing pmc.ncbi.nlm.nih.gov ...

https://www.google.com/recaptcha/challengepage/

if you are not automatically redirected after 5 seconds.

Try again later

Your computer or network may be sending automated queries. To protect our users, we can't process your request right now. For more details visit

our help page

https://support.google.com/websearch/answer/86640

