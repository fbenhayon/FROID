---
sourceFile: "Determining the threshold for asymmetry detection in facial expressions - PMC - NIH"
exportedBy: "Kortex"
exportDate: "2026-06-29T01:00:27.747Z"
---

# Determining the threshold for asymmetry detection in facial expressions - PMC - NIH

f82a2fcc-ab2b-4a67-b066-bc4d26d2bb84

Determining the threshold for asymmetry detection in facial expressions - PMC - NIH

4b662b93-41e4-45c6-9d54-f80a06bbbd60

https://pmc.ncbi.nlm.nih.gov/articles/PMC4392713/

Checking your browser - reCAPTCHA

Checking your browser before accessing pmc.ncbi.nlm.nih.gov ...

https://www.google.com/recaptcha/challengepage/

if you are not automatically redirected after 5 seconds.

Try again later

Your computer or network may be sending automated queries. To protect our users, we can't process your request right now. For more details visit

our help page

https://support.google.com/websearch/answer/86640

