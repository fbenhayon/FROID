---
sourceFile: "Landmark-Based Facial Feature Construction and Action Unit Intensity Prediction"
exportedBy: "Kortex"
exportDate: "2026-06-29T01:00:28.147Z"
---

# Landmark-Based Facial Feature Construction and Action Unit Intensity Prediction

e693fdaa-5763-43ac-bebe-decfc991a471

Landmark-Based Facial Feature Construction and Action Unit Intensity Prediction

d22f67bd-4c13-4825-8da8-67a3edea7352

https://www.researchgate.net/publication/350032444\_Landmark-Based\_Facial\_Feature\_Construction\_and\_Action\_Unit\_Intensity\_Prediction

(PDF) Landmark-Based Facial Feature Construction and Action Unit Intensity Prediction

Article PDF Available

Landmark-Based Facial Feature Construction and Action Unit Intensity Prediction

Mathematical Problems in Engineering

https://www.researchgate.net/journal/Mathematical-Problems-in-Engineering-1563-5147

2021(4):1-12

10.1155/2021/6623239

https://doi.org/10.1155/2021/6623239?urlappend=%3Futm\_source%3Dresearchgate.net%26utm\_medium%3Darticle

https://www.researchgate.net/deref/https%3A%2F%2Fcreativecommons.org%2Flicenses%2Fby%2F4.0%2F

https://www.researchgate.net/scientific-contributions/Jialei-Ma-2191385277

https://www.researchgate.net/scientific-contributions/Jialei-Ma-2191385277

This person is not on ResearchGate, or hasn't claimed this research yet.

Xiansheng Li

https://www.researchgate.net/scientific-contributions/Xiansheng-Li-2186363522

Xiansheng Li

https://www.researchgate.net/scientific-contributions/Xiansheng-Li-2186363522

This person is not on ResearchGate, or hasn't claimed this research yet.

Yuanyuan Ren

https://www.researchgate.net/scientific-contributions/Yuanyuan-Ren-2186332848

Yuanyuan Ren

https://www.researchgate.net/scientific-contributions/Yuanyuan-Ren-2186332848

This person is not on ResearchGate, or hasn't claimed this research yet.

https://www.researchgate.net/scientific-contributions/Ran-Yang-2178162372

https://www.researchgate.net/scientific-contributions/Ran-Yang-2178162372

This person is not on ResearchGate, or hasn't claimed this research yet.

Show all 5 authors

https://www.researchgate.net/

https://www.researchgate.net/

Download full-text PDF

https://www.researchgate.net/journal/Mathematical-Problems-in-Engineering-1563-5147/publication/350032444\_Landmark-Based\_Facial\_Feature\_Construction\_and\_Action\_Unit\_Intensity\_Prediction/links/616d9d83951b3574c6634391/Landmark-Based-Facial-Feature-Construction-and-Action-Unit-Intensity-Prediction.pdf

Read full-text

https://www.researchgate.net/publication/350032444\_Landmark-Based\_Facial\_Feature\_Construction\_and\_Action\_Unit\_Intensity\_Prediction#read

Download full-text PDF

https://www.researchgate.net/journal/Mathematical-Problems-in-Engineering-1563-5147/publication/350032444\_Landmark-Based\_Facial\_Feature\_Construction\_and\_Action\_Unit\_Intensity\_Prediction/links/616d9d83951b3574c6634391/Landmark-Based-Facial-Feature-Construction-and-Action-Unit-Intensity-Prediction.pdf

Read full-text

https://www.researchgate.net/publication/350032444\_Landmark-Based\_Facial\_Feature\_Construction\_and\_Action\_Unit\_Intensity\_Prediction#read

Download citation

https://www.researchgate.net/publication/350032444\_Landmark-Based\_Facial\_Feature\_Construction\_and\_Action\_Unit\_Intensity\_Prediction/citation/download

Copy link Link copied

Read full-text

https://www.researchgate.net/publication/350032444\_Landmark-Based\_Facial\_Feature\_Construction\_and\_Action\_Unit\_Intensity\_Prediction#read

Download citation

https://www.researchgate.net/publication/350032444\_Landmark-Based\_Facial\_Feature\_Construction\_and\_Action\_Unit\_Intensity\_Prediction/citation/download

Copy link Link copied

Citations (21)

https://www.researchgate.net/publication/350032444\_Landmark-Based\_Facial\_Feature\_Construction\_and\_Action\_Unit\_Intensity\_Prediction#citations

References (32)

https://www.researchgate.net/publication/350032444\_Landmark-Based\_Facial\_Feature\_Construction\_and\_Action\_Unit\_Intensity\_Prediction#references

Figures (11)

https://www.researchgate.net/publication/350032444\_Landmark-Based\_Facial\_Feature\_Construction\_and\_Action\_Unit\_Intensity\_Prediction#figures

Abstract and Figures

Human face recognition has been widely used in many fields, including biorobots, driver fatigue monitoring, and polygraph tests. However, the end-to-end models fit by most of the existing algorithms perform poorly in interpretation because complex classifiers are constructed using facial images directly. In addition, in some of the models, dynamic characteristics of subjects as individuals are not fully considered, so dynamic information is not extracted. In order to solve these problems, this paper proposes an action unit intensity prediction model. The three-dimensional coordinates of 68 landmarks of human faces are obtained based on the convolutional experts constrained local model (CE-CLM), which enables the construction of dynamic facial features. Based on the error analysis of the CE-CLM algorithm, dimension reduction of the constructed features is performed by the principal components analysis (PCA). The radial basis function (RBF) neural network is also constructed to train the action unit prediction models. The proposed method is verified by the experiments, and the overall mean square error (MSE) of the proposed method is 0.01826. Lastly, the network construction process is optimized, so that for the same training samples, the models are fitted using fewer iterations. The number of iterations is decreased by 27 on average. In summary, this paper provides a method to rapidly construct action unit (AU) intensity prediction models and constructs automatic AU intensity estimation models for facial images.

The coordinate system where the center of the camera lens is the origin. …

https://www.researchgate.net/figure/The-coordinate-system-where-the-center-of-the-camera-lens-is-the-origin\_fig1\_350032444

Comparison of different basic feature construction methods. …

https://www.researchgate.net/figure/Comparison-of-different-basic-feature-construction-methods\_fig2\_350032444

Diagram of a triangle. …

https://www.researchgate.net/figure/Diagram-of-a-triangle\_fig3\_350032444

Distribution of 68 landmarks and feature construction. …

https://www.researchgate.net/figure/Distribution-of-68-landmarks-and-feature-construction\_fig4\_350032444

https://www.researchgate.net/figure/The-process-of-calculating-di-j\_fig5\_350032444

The process of calculating di,j. …

https://www.researchgate.net/figure/The-process-of-calculating-di-j\_fig5\_350032444

Figures - available from: Mathematical Problems in Engineering

This content is subject to copyright.

Terms and conditions

https://www.hindawi.com/terms/

Discover the world's research

25+ million members

160+ million publication pages

2.3+ billion citations

Join for free

https://www.researchgate.net/signup.SignUp.html

Publisher Full-text 1

Public Full-text 1

Access to this full-text is provided by Wiley.

https://help.researchgate.net/hc/en-us/articles/24012471222545#publisherfulltexts

Content available from Mathematical Problems in Engineering

This content is subject to copyright.

Terms and conditions

https://www.hindawi.com/terms/

Research Article

Landmark-Based Facial Feature Construction and Action Unit

Intensity Prediction

Xiansheng Li,

Yuanyuan Ren ,

and Qichao Zhao

School of T ransportation, Jilin University, Changchun 130022, China

Beijing KINGFAR Co., Ltd., Beijing 100085, China

Correspondence should be addressed to Yuanyuan Ren; renyy@jlu.edu.cn

Received 23 November 2020; Accepted 2 March 2021; Published 12 March 2021

Academic Editor: Fu-Kwun Wang

Copyright © 2021 Jialei Ma et al. is is an open access article distributed under the Creative Commons Attribution License, which

permits unrestricted use, distribution, and reproduction in any medium, provided the original work is properly cited.

Human face recognition has been widely used in many ﬁelds, including biorobots, driver fatigue monitoring, and polygraph tests.

However, the end-to-end models ﬁt by most of the existing algorithms perform poorly in interpretation because complex

classiﬁers are constructed using facial images directly. In addition, in some of the models, dynamic characteristics of subjects as

individuals are not fully considered, so dynamic information is not extracted. In order to solve these problems, this paper proposes

an action unit intensity prediction model. e three-dimensional coordinates of 68 landmarks of human faces are obtained based

on the convolutional experts constrained local model (CE-CLM), which enables the construction of dynamic facial features. Based

on the error analysis of the CE-CLM algorithm, dimension reduction of the constructed features is performed by the principal

components analysis (PCA). e radial basis function (RBF) neural network is also constructed to train the action unit prediction

models. e proposed method is veriﬁed by the experiments, and the overall mean square error (MSE) of the proposed method is

0.01826. Lastly, the network construction process is optimized, so that for the same training samples, the models are ﬁtted using

fewer iterations. e number of iterations is decreased by 27 on average. In summary, this paper provides a method to rapidly

construct action unit (AU) intensity prediction models and constructs automatic AU intensity estimation models for

facial images.

Introduction

e human face is a carrier of multiple information types. It

can not only directly show personal information (e.g., age,

gender, and race) but also indirectly convey various emo-

tions (e.g., pleasure, anger, sorrow, and joy). Moreover, a

facial expression of emotion is one of the important types of

interpersonal communication. According to Mehrabian

et al. \[1\], in human interactions, 55% of the information is

conveyed by facial expressions.

e facial action coding system (FACS) has been widely

used in research on facial information. It was ﬁrst developed

by Ekman and Friesen in 1975 \[2\] and then improved in

2002 \[3\]. In the FACS, a unique set of basic facial muscle

actions is deﬁned and denoted as the action unit (AU). e

FACS involves 44 visible AUs linked to facial muscular

movements \[4\], including 33 independent AUs and 11

additional nonstrictly deﬁned action descriptors (ADs) \[5\],

which are given in T ables 1 and 2, respectively.

e FACS is comprehensive and objective. Any facial

expression of emotion is generated by activating one or more

groups of facial muscles. Also, each possible facial expression

can be represented as a combination of diﬀerent AUs. Due to

the complex deﬁnition of coding rules in FACS, AU an-

notations can be completed only by FACS-certiﬁed coders.

In order to meet the FACS coding requirements, the FACS-

certiﬁed coders need to be professionally and strictly trained

for at least 100 hours \[4\]. In addition, manual coding of facial

images is a tedious and time-consuming process; for in-

stance, even a well-trained coder needs about one hour to

complete the facial coding of a one-minute video clip \[6\].

With the aim of solving the problem of time-consuming

and ineﬃcient facial coding, researchers have considered

using computer technology for the purpose of coding

Mathematical Problems in Engineering

V olume 2021, Article ID 6623239, 12 pa ges

https://doi.org/10.1155/2021/6623239

https://www.researchgate.net/deref/mailto%3Arenyy%40jlu.edu.cn

https://www.researchgate.net/publication/350032444\_Landmark-Based\_Facial\_Feature\_Construction\_and\_Action\_Unit\_Intensity\_Prediction#pfb

https://www.researchgate.net/publication/350032444\_Landmark-Based\_Facial\_Feature\_Construction\_and\_Action\_Unit\_Intensity\_Prediction#pfb

https://www.researchgate.net/publication/350032444\_Landmark-Based\_Facial\_Feature\_Construction\_and\_Action\_Unit\_Intensity\_Prediction#pfb

https://www.researchgate.net/publication/350032444\_Landmark-Based\_Facial\_Feature\_Construction\_and\_Action\_Unit\_Intensity\_Prediction#pfb

https://www.researchgate.net/publication/350032444\_Landmark-Based\_Facial\_Feature\_Construction\_and\_Action\_Unit\_Intensity\_Prediction#pfb

https://www.researchgate.net/publication/350032444\_Landmark-Based\_Facial\_Feature\_Construction\_and\_Action\_Unit\_Intensity\_Prediction#pf2

https://www.researchgate.net/publication/350032444\_Landmark-Based\_Facial\_Feature\_Construction\_and\_Action\_Unit\_Intensity\_Prediction#pf2

https://www.researchgate.net/publication/350032444\_Landmark-Based\_Facial\_Feature\_Construction\_and\_Action\_Unit\_Intensity\_Prediction#pfb

https://www.researchgate.net/publication/350032444\_Landmark-Based\_Facial\_Feature\_Construction\_and\_Action\_Unit\_Intensity\_Prediction#pfb

https://www.researchgate.net/deref/https%3A%2F%2Forcid.org%2F0000-0001-7802-2128

https://www.researchgate.net/deref/https%3A%2F%2Fcreativecommons.org%2Flicenses%2Fby%2F4.0%2F

https://www.researchgate.net/deref/https%3A%2F%2Fcreativecommons.org%2Flicenses%2Fby%2F4.0%2F

https://www.researchgate.net/deref/https%3A%2F%2Fdoi.org%2F10.1155%2F2021%2F6623239

automation. is study aims to realize automatic AU in-

tensity prediction by constructing facial landmark-based

facial features, thereby improving the accuracy and eﬃ-

ciency of facial coding.

e rest of this article is organized as follows. In Section

2, the relative literature is reviewed, and the existing AU

intensity estimation algorithms are analyzed. In Section 3,

feature construction and dimension reduction of the AU

sample library are conducted by facial feature analysis based

on which a neural network model for AU intensity esti-

mation is constructed and trained. In Section 4, the trained

network model is optimized based on the experimental

result to reduce training time. Lastly, in Section 5, the main

conclusions are stated, and future research directions are

Literature Review

Remarkable progress has been made in the ﬁeld of automatic

recognition of facial expressions over the past two decades

\[7, 8\]. According to the previous studies on facial expression

recognition, the two main tasks in the facial expression

recognition process are facial information description and

machine learning model design \[9, 10\]. e purpose of facial

information description is to obtain a set of features from the

original facial images, ensuring that similarity of features of

diﬀerent faces expressing the same information is more

similar than that of the same faces expressing diﬀerent

information.

Facial landmark detection is the basic way to describe

facial information. ere are many well-developed algo-

rithms for facial landmark detection. e active shape model

(ASM) \[11\], where the range of landmarks is constrained

based on Mahalanobis distance, is the earliest algorithm for

landmark model construction. It not only contributes to

facial landmark detection but can also apply to gesture

detection and body movement detection. By adding texture

information to the ASM during the shape feature statistics,

the active appearance model (AAM) \[12\] that can locate the

landmarks more accurately based on shape features has been

constructed, but its real-time performance has been un-

satisfactory. In contrast, the constrained local model (CLM)

\[13\] makes a balance between accuracy and real-time per-

formance using the advantages and disadvantages of the

ASM and AAM. It achieves a higher computing eﬃciency by

changing the global texture features in the AAM into the

texture features near the landmarks of the average faces of

the public.

e enhancement of computing eﬃciency brings an

increasingly complex structure of machine learning models.

Mahoor et al. \[14\] classiﬁed combined AUs using the sparse

representation (SR) classiﬁer. Both Wang and Lien \[15\] and

Valstar and Pantic \[16\] constructed the AU recognition

models using the hidden Markov model (HMM). In a study

by Kaltwang et al. \[17\], relevance vector regression was used

to predict the AU intensity. e support vector machine

(SVM) model was used by Mahoor et al. \[18\] and Valstar

et al. \[19\] for emotion recognition. Savran et al. \[4\] predicted

the AU intensity using the support vector regression (SVR).

Recently, widely applied neural networks have become

dominant in model construction. e deep neural networks

were used by Liu et al. \[20\], Gudi et al. \[21\], and Zhao et al.

\[22\] to build the AU recognition models.

Hitherto, most of the studies on automated AU analysis

have focused on AU recognition, including simple AU

recognition \[23\], combined AU recognition \[24\], AU-

emotion coupled recognition \[25\], and AU dependence

T able 1: List of AUs.

AU number FACS name

1 Inner brow raiser

2 Outer brow raiser

4 Brow lowerer

5 Upper lid raiser

6 Cheek raiser

7 Lid tightener

8 Lips toward each other

9 Nose wrinkler

10 Upper lip raiser

11 Nasolabial furrow deepener

12 Lip corner puller

13 Cheek puﬀer

15 Lip corner depressor

16 Lower lip depressor

17 Chin raiser

18 Lip puckerer

20 Lip stretcher

22 Lip funneler

23 Lip tightener

24 Lip pressor

25 Lips part depressor

26 Jaw drop

27 Mouth stretch

28 Lip suck

38 Nostril dilator

39 Nostril compressor

41 Lid droop

43 Eyes closed

AU, action unit; FACS, facial action coding system.

T able 2: More grossly deﬁned AUs.

AU number FACS name

19 T ongue out

21 Neck tightener

29 Jaw thrust

30 Jaw sideways

31 Jaw clencher

32 Lip bite

33 Cheek blow

34 Cheek puﬀ

35 Cheek suck

36 T ongue bulge

37 Lip wipe

AU, action unit; FACS, facial action coding system.

2 Mathematical Problems in Engineering

https://www.researchgate.net/publication/350032444\_Landmark-Based\_Facial\_Feature\_Construction\_and\_Action\_Unit\_Intensity\_Prediction#pf2

https://www.researchgate.net/publication/350032444\_Landmark-Based\_Facial\_Feature\_Construction\_and\_Action\_Unit\_Intensity\_Prediction#pf3

https://www.researchgate.net/publication/350032444\_Landmark-Based\_Facial\_Feature\_Construction\_and\_Action\_Unit\_Intensity\_Prediction#pf6

https://www.researchgate.net/publication/350032444\_Landmark-Based\_Facial\_Feature\_Construction\_and\_Action\_Unit\_Intensity\_Prediction#pf7

https://www.researchgate.net/publication/350032444\_Landmark-Based\_Facial\_Feature\_Construction\_and\_Action\_Unit\_Intensity\_Prediction#pfb

https://www.researchgate.net/publication/350032444\_Landmark-Based\_Facial\_Feature\_Construction\_and\_Action\_Unit\_Intensity\_Prediction#pfb

https://www.researchgate.net/publication/350032444\_Landmark-Based\_Facial\_Feature\_Construction\_and\_Action\_Unit\_Intensity\_Prediction#pfb

https://www.researchgate.net/publication/350032444\_Landmark-Based\_Facial\_Feature\_Construction\_and\_Action\_Unit\_Intensity\_Prediction#pfb

https://www.researchgate.net/publication/350032444\_Landmark-Based\_Facial\_Feature\_Construction\_and\_Action\_Unit\_Intensity\_Prediction#pfb

https://www.researchgate.net/publication/350032444\_Landmark-Based\_Facial\_Feature\_Construction\_and\_Action\_Unit\_Intensity\_Prediction#pfb

https://www.researchgate.net/publication/350032444\_Landmark-Based\_Facial\_Feature\_Construction\_and\_Action\_Unit\_Intensity\_Prediction#pfb

https://www.researchgate.net/publication/350032444\_Landmark-Based\_Facial\_Feature\_Construction\_and\_Action\_Unit\_Intensity\_Prediction#pfb

https://www.researchgate.net/publication/350032444\_Landmark-Based\_Facial\_Feature\_Construction\_and\_Action\_Unit\_Intensity\_Prediction#pfb

https://www.researchgate.net/publication/350032444\_Landmark-Based\_Facial\_Feature\_Construction\_and\_Action\_Unit\_Intensity\_Prediction#pfb

https://www.researchgate.net/publication/350032444\_Landmark-Based\_Facial\_Feature\_Construction\_and\_Action\_Unit\_Intensity\_Prediction#pfb

https://www.researchgate.net/publication/350032444\_Landmark-Based\_Facial\_Feature\_Construction\_and\_Action\_Unit\_Intensity\_Prediction#pfb

https://www.researchgate.net/publication/350032444\_Landmark-Based\_Facial\_Feature\_Construction\_and\_Action\_Unit\_Intensity\_Prediction#pfb

https://www.researchgate.net/publication/350032444\_Landmark-Based\_Facial\_Feature\_Construction\_and\_Action\_Unit\_Intensity\_Prediction#pfb

https://www.researchgate.net/publication/350032444\_Landmark-Based\_Facial\_Feature\_Construction\_and\_Action\_Unit\_Intensity\_Prediction#pfb

https://www.researchgate.net/publication/350032444\_Landmark-Based\_Facial\_Feature\_Construction\_and\_Action\_Unit\_Intensity\_Prediction#pfb

https://www.researchgate.net/publication/350032444\_Landmark-Based\_Facial\_Feature\_Construction\_and\_Action\_Unit\_Intensity\_Prediction#pfb

https://www.researchgate.net/publication/350032444\_Landmark-Based\_Facial\_Feature\_Construction\_and\_Action\_Unit\_Intensity\_Prediction#pfb

https://www.researchgate.net/publication/350032444\_Landmark-Based\_Facial\_Feature\_Construction\_and\_Action\_Unit\_Intensity\_Prediction#pfb

https://www.researchgate.net/publication/350032444\_Landmark-Based\_Facial\_Feature\_Construction\_and\_Action\_Unit\_Intensity\_Prediction#pfb

recognition \[26\]. However, little attention has been paid to

the AU intensity prediction. Compared with the AU rec-

ognition, AU intensity prediction represents a more chal-

lenging task \[27\]. Due to the complexity of AU detection,

including large numbers of categories, more subtle models,

and minor diﬀerences between AUs, an automatic facial AU

analysis still remains an open challenge in both AU rec-

ognition and AU intensity prediction \[28\].

#### AU Intensity Prediction Model

## Facial Landmark Localization Method. Facial muscles

contract and stretch when humans convey emotions

through facial expressions, which causes the corresponding

facial regions to change in shape or location. erefore, facial

images contain a large amount of emotional information. In

this study, the emotional information contained in facial

images is identiﬁed based on the changes in the locations of

facial landmarks.

e convolutional experts constrained local model (CE-

CLM) \[29\] is used to recognize the three-dimensional in-

formation of facial landmarks. By combining the advantages

of the convolutional neural network and the original CLM

algorithm, the CE-CLM achieves high robustness against

interference factors, such as sunlight, angle, and obstruction.

e input is a facial image, the human face in which is locked

down by means of the human face detection algorithm.

Next, three-dimensional facial alignment is conducted using

the trained average face model. e exact location of each of

68 landmarks is determined using the local constraint al-

gorithm. Lastly, the three-dimensional coordinates of all 68

facial landmarks are determined. As shown in Figure 1, the

coordinate origin is the center of the camera lens. e optical

axis of the camera denotes the z-axis, where the direction of

the camera pointing to the face represents a positive di-

rection. e direction perpendicular to the lens center

represents the positive direction of the y-axis; the direction

from the lens center horizontally to the right represents the

positive direction of the x-axis.

## Construction of Complete Facial Information Feature.

After obtaining the three-dimensional coordinates of 68

facial landmarks using the CE-CLM algorithm, the complete

facial information features are constructed. Points in space

can diﬀer signiﬁcantly due to their diﬀerences in the origin

and direction of each axis when building the coordinate

system. erefore, constructing the features based on the

relationship between the points in space, the change in

sample features caused by diﬀerent coordinate system

construction methods can be avoided.

### Feature Construction Method. e facial features

constructed based on the relations between facial land-

marks can be divided into three following groups: the

Euclidean distance between two points, the angle formed

by a point and two other points, and the perpendicular

distance from a point to the line between two other

points, as shown in Figure 2. e angle formed between a

point and two other points varies in a small range. Be-

cause of the principle of triangle similarity, angles cannot

fully express the three-dimensional facial information.

According to the calculation equation of a triangle area,

the perpendicular distance from a point to the line between

two other points that is shown in Figure 3 can be calculated

∵ S △ ABC � 1

2 BC × A D � 1

2 CA × BE � 1

∴ BC: CA: AB � 1

According to equation (1), this distance is equivalent

to the Euclidean distance between two points, but the

dimension ( C 3

68 � 50 116) constructed based on the per-

pendicular distance from one point to the line between

two other points is far larger than that of the Euclidean

distance between two points ( C 2

68 � 22 78). From the

engineering perspective, the distance from a point to a

straight line increases the computation complexity

without introducing an eﬀective feature. For this reason,

it is not used as one of the facial features in this work. As

shown in Figure 4, the facial features with 2278 di-

mensions are constructed based on the Euclidean dis-

tances between 68 facial landmarks.

### Feature Construction Optimization. Considering the

huge advantages of the convolutional neural networks in

image processing, researchers have recently placed em-

phasis on AU recognition based on the prior model

constructed using static images. However, the static

image feature-based methods can only obtain represen-

tative geometric facial features from images, such as

texture, color, and shape. ey can present individual

diﬀerences well but cannot focus on a certain AU of the

whole group or give a summary of the features of AUs. In

order to overcome the individual diﬀerence between

static images, the individual sample calibration-based

facial feature with movement diﬀerences is proposed. It

can not only eliminate the diﬀerence between individuals

but also match the AU description in the facial coding

In common calibration-based facial action feature

construction methods, the diﬀerence between eigenvalues of

facial images with and without expressions can be calculated

d i,j � ��������������������������� �

􏼐 􏼑 2+ y i− y j

􏼐 􏼑 2+ z i− z j

△ d i,j � d i,j( expression) − d i,j( neutral),

where d i,j denotes the Euclidean distance between land-

marks i and j and d i,j denotes the diﬀerence between the

distances from i to j with and without facial expressions.

Mathematical Problems in Engineering 3

https://www.researchgate.net/publication/350032444\_Landmark-Based\_Facial\_Feature\_Construction\_and\_Action\_Unit\_Intensity\_Prediction#pfb

https://www.researchgate.net/publication/350032444\_Landmark-Based\_Facial\_Feature\_Construction\_and\_Action\_Unit\_Intensity\_Prediction#pfb

https://www.researchgate.net/publication/350032444\_Landmark-Based\_Facial\_Feature\_Construction\_and\_Action\_Unit\_Intensity\_Prediction#pfb

https://www.researchgate.net/publication/350032444\_Landmark-Based\_Facial\_Feature\_Construction\_and\_Action\_Unit\_Intensity\_Prediction#pfc

https://www.researchgate.net/publication/350032444\_Landmark-Based\_Facial\_Feature\_Construction\_and\_Action\_Unit\_Intensity\_Prediction#pf4

https://www.researchgate.net/publication/350032444\_Landmark-Based\_Facial\_Feature\_Construction\_and\_Action\_Unit\_Intensity\_Prediction#pf4

https://www.researchgate.net/publication/350032444\_Landmark-Based\_Facial\_Feature\_Construction\_and\_Action\_Unit\_Intensity\_Prediction#pf5

https://www.researchgate.net/publication/350032444\_Landmark-Based\_Facial\_Feature\_Construction\_and\_Action\_Unit\_Intensity\_Prediction#pf3

https://www.researchgate.net/publication/350032444\_Landmark-Based\_Facial\_Feature\_Construction\_and\_Action\_Unit\_Intensity\_Prediction#pf5

However, some diﬀerent △ d i,j values, such as △ d 51, 8 and

△ d 51, 57 as shown in Figure 5, are similar due to the char-

acteristics of facial landmark distribution, resulting in a

reduced amount of feature information. For this reason, the

variation rate of the features of facial images with and

without expressions is used for facial feature construction in

this study, and it is expressed as

△ d i,j � d i,j( expression) − d i,j( neutral)

d i,j( neutral).( 3)

## Feature Dimension Reduction. e facial features with

2278 dimensions are constructed from 68 landmarks to

obtain complete facial information. ese features are not

valid for a particular AU from an intuitive perspective; in

other words, some features are invalid for particular AUs.

erefore, feature dimension reduction is necessary for each

AU. Valid features are extracted, which substantially en-

hances the construction eﬃciency.

### Dimension Reduction Methods. T raditional feature

dimension reduction methods mainly depend on the sub-

jective understanding of the existing features. e most

representative features are determined based on the judg-

ment of several authoritative experts on each feature, which

can be a practical method for a lower feature dimension.

However, the workload of experts increases with the feature

dimension, which makes this method impractical. Cur-

rently, there are several methods for feature dimension

reduction, including the genetic algorithm, Fisher's linear

discriminant (FLD), maximum relevance and minimum

redundancy (mRMR), and principal components analysis

As a common optimization algorithm, the genetic al-

gorithm simulates the natural survival of the ﬁttest. is

algorithm can generate and determine the most appropriate

Figure 2: Comparison of diﬀerent basic feature construction

Figure 1: e coordinate system where the center of the camera lens is the origin.

4 Mathematical Problems in Engineering

https://www.researchgate.net/publication/350032444\_Landmark-Based\_Facial\_Feature\_Construction\_and\_Action\_Unit\_Intensity\_Prediction#pf5

feature based on particular rules. However, the parameters

of this method and the method of new feature formation

depend on manual setup, which together with a lack of

theoretical basis for some certain features makes these

methods unsuitable for extensive application.

e FLD represents a widely used dimension reduction

method. In this method, samples are projected to a straight

line, i.e., data are projected to the one-dimensional space. It

divides features into valid and invalid ones, but valid and

linearly correlated features cannot be removed.

e purpose of the mRMR is to minimize the correlation

between selected features and maximize the correlation

between the selected features and mathematical expecta-

tions. is method is the most eﬃcient feature selection

Figure 4: Distribution of 68 landmarks and feature construction.

d 51, 57 (close) d 51, 57 (open)

d 51, 8 (close) d 51, 8 (open)

Δ d 51, 57 = d 51, 57 (open) – d 51, 57 (close)

Δ d 51, 8 = d 51, 8 (open) – d 51, 8 (close)

Figure 5: e process of calculating d i,j.

Figure 3: Diagram of a triangle.

Mathematical Problems in Engineering 5

method, but it does not consider new feature formation by

means of feature combination.

### Principal Component Analysis. e steps of the PCA

are as follows: gather a dataset, select direction with the

greatest change and set it as a new axis, check changes in the

remaining data, and ﬁnd an axis that is perpendicular to the

ﬁrst one and covers as many changes as possible. ese steps

are repeated until all the possible coordinate axes are

identiﬁed. In this way, all the variables denote the axes along

the rectangular coordinate system, while the covariance

matrices denote diagonal matrices. Namely, each new var-

iable is related only to itself rather than any other variable.

Essentially, it rebuilds a new coordinate system without

changing the relationships between data points, which ensures

the original data can be converted without any information loss.

us, dimensions with small data variations in some directions

can be removed directly without aﬀecting data variability. In

Figure 6, XY represents the original coordinate system and X' Y'

represents the coordinate system after PCA conversion.

However, there is no uniform standard for the thresholds on

which the dimension removal procedure relies.

Considering that an eigenvalue threshold needs to be set

in the PCA-based dimension reduction method, dimensions

corresponding to eigenvalues that are smaller than the

threshold are removed for the purpose of dimension re-

duction. Due to diﬀerent data forms used in the PCA al-

gorithm, there is no uniform way to set the eigenvalue

threshold. For the sake of optimal dimension reduction, it is

necessary to analyze the errors and set a reasonable

threshold since there are errors in dynamic video acquisition

and algorithm processing. e speciﬁc method is as follows.

e videos of subjects at complete rest were acquired to

control the statistical error. e subjects were required not to do

any facial expression during data acquisition, including

blinking, so it did not take too much time to conduct the

acquisition. In order to ensure the quality of statistical data, a

one-minute video of each subject in the neutral state was ac-

quired. A total of 18 clips of video data where the subjects did

not blink were acquired. In this study, the videos were acquired

on 30 fps with a resolution of 1280 × 960 using a Microsoft

Kinect sensor. Finally, 18 groups of image data that contained

1800 images each were obtained.

First, the data of each image were processed and converted

into features with 2278 dimensions using the aforementioned

algorithm. For each frame of features, the variance corre-

sponding to each dimension of features from the start frame to

the current frame was calculated. In the end, the variances of all

the dimensions were averaged to obtain the average feature

variance of each frame of data, as shown in Figure 7. By using

100 frames as a step size, the information entropy of the data

within every 100 frames was calculated, and the results are

shown in Figure 8. As presented in Figure 8, the information

entropy started to stabilize after 1500 frames, suggesting that the

number of 1500 frames was the minimum requirement for

error statistics in order to ensure high stability of data error. In

this study, the average feature variance of 1800 frames of data

According to the mathematical derivation of the PCA

algorithm, the eigenvalue is equal to the variance of the

dimension corresponding to the coordinate after data

rotation. If the variance in a certain dimension is smaller

than the average variance without facial expression

changes, this dimension contains less information and

will not impact the overall information content if re-

moved. erefore, the PCA segmentation threshold is set

to 1.16 in this work.

#### Model Construction

## Sample-T ag Relationship. When sample data are pre-

processed, the sample features after dimension reduction are

obtained. Additionally, the sample data also contain the AU

intensity tags of all images. ese tags are calibrated by FACS-

certiﬁed experts after long-time careful image observation. e

FACS is an objective and comprehensive system constructed

based on experimental psychological research. It aims to pro-

vide observers with an objective method for measuring facial

actions. In behavioristics, the FACS is the most widely accepted

measure of facial emotions. us, these AU intensity tags have

been the most recognized result of subtle facial expressions.

Figure 6: e principal components analysis (PCA)-based di-

mension reduction process.

0 200 400 600 800 1000 1200 1400 1600 1800

Frame number of video

Mean of each characteristic variance

Figure 7: e average variance of 18 subjects' features over time.

6 Mathematical Problems in Engineering

https://www.researchgate.net/publication/350032444\_Landmark-Based\_Facial\_Feature\_Construction\_and\_Action\_Unit\_Intensity\_Prediction#pf6

https://www.researchgate.net/publication/350032444\_Landmark-Based\_Facial\_Feature\_Construction\_and\_Action\_Unit\_Intensity\_Prediction#pf6

https://www.researchgate.net/publication/350032444\_Landmark-Based\_Facial\_Feature\_Construction\_and\_Action\_Unit\_Intensity\_Prediction#pf7

https://www.researchgate.net/publication/350032444\_Landmark-Based\_Facial\_Feature\_Construction\_and\_Action\_Unit\_Intensity\_Prediction#pf7

ere are two diﬃculties in constructing an automatic AU

intensity prediction model for sample features and their AU tags

as follows:

(1) e FACS deﬁnitions of various intensities are

shown in Figure 9. Levels A, B, C, D, and E represent

the faint sign of action, slight but inconspicuous

actions, actions that have been obviously taken,

drastic actions, and actions that have reached the

limit, respectively. Each intensity level involves a

series of appearance changes. us, it can be inferred

from the FACS deﬁnitions of AU intensities that

there can be a nonlinear relationship between the

intensity level and the range of facial actions.

(2) Considering that the AU intensity tags, which rep-

resent the annotations of subject facial expressions

made by experts, of the sample database are deter-

mined by the FACS, the results are still generally

acceptable despite the subjectivity. us, the results

denote the true values of the sample data output.

## Radial Basis Function Neural Network. In order to solve

the aforementioned problems, the radial basis function

(RBF) neural network regression is used for AU intensity

prediction.

e RBF is a real-value function whose value depends only

on the distance from a sample to a point ( w) in space, namely,

g( x, w) � g(‖ x− w‖). Any function ( g) that satisﬁes g( x) �

g(‖ x‖) can be called an RBF. Since the Euclidean distance is the

most commonly used distance measure in the RBFs, the RBF is

also known as the Euclidean radial basis function.

In this study, the RBF is a Gaussian kernel function that

can be expressed as g( x, w, σ) � exp((− ‖ x− w‖ 2)/2 σ 2),

where x denotes the sample input, w denotes the center of

the kernel function, and σ denotes the width parameter that

controls the range of the radial action of the function.

e RBF neural network is a three-layer neural network

consisting of the input layer, the hidden layer, and the output

layer. e conversion from the input layer to the hidden

layer is nonlinear, whereas that from the hidden layer to the

output layer is linear. e speciﬁc structure of the RBF

neural network is shown in Figure 10.

e basic idea of the RBF network is to use the RBF function

as the activation function of the hidden-layer neurons so that

the input vector can be mapped directly without requiring

connections via weight. Once the central point of RBF is de-

termined, the mapping relationship is also determined. e

mapping from the hidden layer to the output layer is linear,

which means network output represents a linear weighted sum

of the hidden-layer output. e weight is the adjustable network

parameter. In addition, the mapping from the network input to

the network output is nonlinear, whereas the mapping from the

network output to adjustable parameters is linear. e network

weight can be solved directly by the system of linear equations,

thus speeding up the learning process and avoiding the problem

of the local minimum.

e RBF network's features are ideal for the application

considered in this study. Namely, the relationship between

sample features and sample tags can be properly handled, and

the correspondence between the features of training samples

and their tags can be eﬀectively regressed. erefore, the RBF

neural network regression is performed to ﬁt the AU intensity

prediction model. e mean square error (MSE) is used as the

cost function during the model training and as the ﬁnal

evaluation indicator of model regression.

e regression error is quantized by calculating the MSE

between the true and predicted values based on which model

parameters are optimized to ensure model validity. e MSE

is calculated by

 􏼁 2,( 4)

where y i denotes the AU intensity tag corresponding to the

i th sample and 􏽢

y i denotes the predicted value of the i th

Model Evaluation

e Bosphorus \[30\] and Lucey et al. (CK+) \[31\] databases

were used for regression and evaluation of the proposed AU

strength prediction model. In addition, the model training

was optimized based on the experimental result in order to

ensure model regression could be completed in a shorter

time in the second training under the same experimental

data and condition.

## Database Introduction. e Bosphorus database was

developed by Bosphorus University in Turkey; it included

105 subjects (60 males and 45 females), of whom 29 were

professional actors/actresses, and consisted of 4652 facial

images. e images were marked by FACS-certiﬁed experts

as AU1, AU2, AU4, AU9, AU10, AU12, AU14, AU15, AU16,

AU17, AU18, AU20, AU22, AU23, AU24, AU25, AU26,

AU27, AU28, AU34, AU43, and AU44. is database is one

of the AU-tag databases that contain the largest sample size.

e CK+ database was developed by Jeﬀrey F. Cohn and

T akeo Kanade; it included 210 subjects ( 145 females and 65

males) and consisted of 2105 facial images that were marked by

2468 1 0 1 2 1 4 1 6 1 8

Each 100 frames sequence

Information entro py

Figure 8: Information entropy of every 100 data frames.

Mathematical Problems in Engineering 7

https://www.researchgate.net/publication/350032444\_Landmark-Based\_Facial\_Feature\_Construction\_and\_Action\_Unit\_Intensity\_Prediction#pf8

https://www.researchgate.net/publication/350032444\_Landmark-Based\_Facial\_Feature\_Construction\_and\_Action\_Unit\_Intensity\_Prediction#pf8

https://www.researchgate.net/publication/350032444\_Landmark-Based\_Facial\_Feature\_Construction\_and\_Action\_Unit\_Intensity\_Prediction#pfc

https://www.researchgate.net/publication/350032444\_Landmark-Based\_Facial\_Feature\_Construction\_and\_Action\_Unit\_Intensity\_Prediction#pfc

FACS-certiﬁed experts with AU tags. However, this database

was intended to present six basic emotions of subjects. ere

were a number of diﬀerent AU tags in this database, and the

number of samples that contained a single AU was small.

According to the statistics, the number of tags that were valid for

each AU was smaller than 30. Considering that it would be

diﬃcult to conduct an eﬀective model ﬁtting with so few

samples each AU tag contained, the above two databases were

combined for the purpose of sample size expansion.

## Dataset Construction. A sample library was constructed

for each AU in this study. Take AU1 as an example. e images

with AU1 tags and those of subjects without facial expressions

were extracted from the two databases. Next, the aforemen-

tioned sample feature construction was performed to obtain the

sample features and the corresponding tag data. Lastly, all the

data with AU1 tags were used to form a complete dataset that

contained the features and AU1tags.

## Evaluation Criterion. With the aim to evaluate the model

regression eﬀect more eﬀectively, the ﬁve-fold cross-validation

was introduced and used to measure the regression eﬀect of the

ﬁnal model. By using this method, the dataset was randomly

divided into ﬁve equal parts, of which one was used as the

validation set, while the remaining parts were used as training

sets. e training was repeated ﬁve times, and the MSE values of

the ﬁve validation sets were averaged and taken as the model

evaluation indicator.

In addition, the correlation coeﬃcient (CORR) of sample

tags and predicted values was introduced as another indi-

cator for model regression evaluation, and it was calculated

CORR( y, 􏽢

y) � COV( y, 􏽢

i � 1 y i− y

����������� �

i � 1 y i− y

􏽱 ����������� �

## Fitting Results. In this study, the AU intensities pre-

dicted by the radial basis neural network (RBNN) without

feature dimension reduction, the backpropagation neural

network (BPNN), and the support vector regression (SVR)

algorithm \[25\] were compared, and results are presented in

MSE shows the diﬀerence between the estimated values and

the true values. A lower MSE value represents a more accurate

prediction. In addition, a correlation coeﬃcient closer to 1

represents a better correlation.

As shown in T able 3, the MSE of the proposed method was

smaller than the MSEs of the three other methods for all AUs,

and CORR values were all larger than 0.98. is indicated that

there was a high correlation between predicted and true values.

## T raining Process Analysis. When constructing the radial

basis neural network (RBNN) using the existing algorithms,

the neurons with uniform step sizes were added. In order to

minimize the neural network structure, the neurons were

added at a step size of one. In this way, no more neurons

would be added when the model converged, i.e., when the

MSE stopped decreasing during the model training.

e number of neurons and the MSE of each AU in

the RBNN during the training was counted. In Figure 11,

the abscissa denotes the number of iterations during the

training process and the ordinate denotes the MSE at the

Trace Slight Marked pronounced Severe and extreme Maximum

Figure 9: e ﬁve levels of action unit (AU) intensity scores.

Input layer Hidden layer

Output weight 1

Output lay er

Output weight 2

Output weigh t m

Radial basis function

Radial basis function

Radial basis function

Figure 10: Basic radial basis neural network (RBNN) structure.

8 Mathematical Problems in Engineering

https://www.researchgate.net/publication/350032444\_Landmark-Based\_Facial\_Feature\_Construction\_and\_Action\_Unit\_Intensity\_Prediction#pfb

https://www.researchgate.net/publication/350032444\_Landmark-Based\_Facial\_Feature\_Construction\_and\_Action\_Unit\_Intensity\_Prediction#pf9

https://www.researchgate.net/publication/350032444\_Landmark-Based\_Facial\_Feature\_Construction\_and\_Action\_Unit\_Intensity\_Prediction#pf9

https://www.researchgate.net/publication/350032444\_Landmark-Based\_Facial\_Feature\_Construction\_and\_Action\_Unit\_Intensity\_Prediction#pf9

T able 3: Result for the AU intensity estimation.

AUs MSE CORR

Proposed RBNN BPNN SVR Proposed RBNN BPNN SVR

AU01 0.024 178 0.026 0.047 0.051 0.992 0.991 0.957 0.960

AU02 0.009237 0.012 0.013 0.027 0.997 0.997 0.970 0.978

AU04 0.009893 0.012 0.066 0.059 0.995 0.995 0.893 0.824

AU05 0.027837 0.030 0.134 0.123 0.992 0.99 1 0.881 0.895

AU06 0.022889 0.025 0.119 0.107 0.989 0.989 0.841 0.859

AU07 0.012078 0.013 — — 0.994 0.994 — —

AU09 0.005872 0.010 — — 0.998 0.998 — —

AU10 0.024854 0.024 0.036 0.033 0.996 0.988 0.924 0.939

AU12 0.038977 0.039 0.042 0.039 0.985 0.985 0.939 0.930

AU14 0.016743 0.021 — — 0.994 0.988 — —

AU15 0.038062 0.042 0.056 0.060 0.981 0.979 0.890 0.892

AU16 0.015238 0.017 — — 0.993 0.992 — —

AU17 0.021056 0.023 0.043 0.041 0.990 0.989 0.896 0.923

AU18 0.0186 16 0.019 0.064 0.056 0.992 0.992 0.955 0.947

AU20 0.020243 0.025 0.058 0.046 0.987 0.983 0.878 0.913

AU22 0.009127 0.018 — — 0.997 0.997 — —

AU23 0.025397 0.028 0.092 0.099 0.982 0.980 0.921 0.925

AU24 0.009601 0.012 0.149 0.126 0.996 0.995 0.790 0.863

AU25 0.009886 0.011 — — 0.995 0.994 — —

AU26 0.017 167 0.018 0.025 0.031 0.988 0.988 0.954 0.976

AU27 0.008465 0.008 0.097 0.104 0.996 0.996 0.931 0.969

AU28 0.01648 1 0.024 — — 0.994 0.991 — —

AU, action unit; BPNN, backpropagation neural network; CORR, correlation coeﬃcient; MSE, mean square error; RBNN, radial basis neural network.

–50 150 350

–100 100 300

–100 100 300

0 1000 2000

–50 150 350

–100 400 900

Figure 11: e mean square error (MSE) of each action unit (AU) during the model training.

Mathematical Problems in Engineering 9

corresponding number of iterations in each small image.

As shown in Figure 11, the MSE decreased until it

converged during all AU model training processes. e

MSE showed two diﬀerent local downtrends: downtrend

of the concave function and downtrend of the convex

function. Finally, it converged after the downtrend of the

convex function.

In the proposed RBNN construction method, neurons

were added at dynamic step sizes. Speciﬁcally, the MSE

values of the ﬁve models were calculated during the

network construction, and the concavity and convexity of

the MSE were identiﬁed. If the MSE was concave, the step

size of neuron addition was increased; if the MSE was

convex, the step size of neuron addition was reset to one.

e pseudocode (Algorithm 1) is given as follows.

A comparison of the model training times before and

after algorithm improvement is given in Table 4, where it can

be seen that both the number of model trainings and the

model ﬁtting time decreased after the model was constructed

by means of dynamic neuron addition.

Conclusions

is paper proposed an AU intensity prediction model.

First, the three-dimensional coordinates of 68 landmarks

of human faces in the image set are calculated using the

CE-CLM algorithm. Next, the variation rate between the

Euclidean distances of images with AUs and those

without facial expressions is calculated to obtain varia-

tions of facial features. en, the variations of facial

features without expressions in the videos are used to

obtain the range of feature error using the CE-CLM al-

gorithm. A reasonable threshold is determined using the

PCA algorithm to eliminate the error and retain infor-

mation as much as possible. Lastly, the RBNN is con-

structed to ﬁt the developed model for each AU. e

ﬁtting algorithm is optimized by observing the ﬁtting

process, thereby reducing the number of ﬁttings in the

second model ﬁtting and shortening the model training

In order to decrease the detection error, further optimi-

zation of the CE-CLM algorithm is necessary, which will be part

of our future work. In addition, the arrangement of 68 land-

marks should also be optimized to achieve a more eﬃcient

model detection.

(1) step � 1

(3) While (NN is not convergent)

(5) n � n+ 1

(6) If ( n< 10)

(7) {add cell and training NN}

(9) If \[mse ( n− 9), mse( n− 8),..., mse ( n)\] is concave

(11) step � step + 1

(12) add cell and training NN

(14) Else \[mse ( n− 9), mse ( n− 8),... , mse ( n)\] is convex

(16) step � 1

(17) add cell and training NN

(19) T rain done

e training algorithm of the neutral networks for AU intensity estimation.

T able 4: Comparison of the number of iterations before and after

optimization.

AU no. Before After

AU01 349 322

AU02 288 261

AU04 344 326

AU05 278 251

AU06 230 212

AU07 1129 1102

AU09 143 116

AU10 181 150

AU12 348 321

AU14 174 151

AU15 113 95

AU16 219 192

AU17 307 289

AU18 277 234

AU20 101 92

AU23 128 110

AU24 252 225

AU25 897 870

AU26 448 430

AU27 186 168

AU, action unit.

10 Mathematical Problems in Engineering

https://www.researchgate.net/publication/350032444\_Landmark-Based\_Facial\_Feature\_Construction\_and\_Action\_Unit\_Intensity\_Prediction#pf9

https://www.researchgate.net/publication/350032444\_Landmark-Based\_Facial\_Feature\_Construction\_and\_Action\_Unit\_Intensity\_Prediction#pfa

https://www.researchgate.net/publication/350032444\_Landmark-Based\_Facial\_Feature\_Construction\_and\_Action\_Unit\_Intensity\_Prediction#pfa

Data Availability

All data, models, or code that support the ﬁndings of this

study are available from the corresponding author upon

reasonable request.

Conflicts of Interest

e authors declare that they have no conﬂicts of interest

regarding the publication of this paper.

Acknowledgments

is work was supported by the National Key Research and

Development Project of China under grant 51578262.

\[1\] A. Mehrabian, “Communication without words,” Psychology

T oday, vol. 2, no. 4, pp. 53–55, 1968.

\[2\] P. Ekman and W. V. Friesen, Facial Action Coding System: A

T echnique for the Measurement of Facial Movement, Con-

sulting Psychologists Press, Palo Alto, CA, USA, 1978.

\[3\] P. Ekman and W. V. Friesen, Facial Action Coding System, the

Manual, Research Nexus Division of Network Information

Research Corporation, South Atlanta, GA, USA, 2002.

\[4\] A. Savran, B. Sankur, and M. Taha Bilge, “Regression-based

intensity estimation of facial action units,” Image and Vision

Computing, vol. 30, no. 10, pp. 774–784, 20 12.

\[5\] Martinez and M. F. Valstar, “Advances, challenges, and op-

portunities in automatic facial expression recognition,” in

Advances in Face Detection and Facial Image Analysis,

pp. 63–100, Springer, Cham, Switzerland, 20 16.

\[6\] G. Donato, M. S. Bartlett, J. C. Hager, P. Ekman, and

T. J. Sejnowski, “Classifying facial actions,” IEEE T ransactions

on Pattern Analysis and Machine Intelligence, vol. 21, no. 10,

pp. 974–989, 1999.

\[7\] Z. Zeng, M. Pantic, G. I. Roisman, and T. S. Huang, “A survey

of aﬀect recognition methods: audio, visual, and spontaneous

expressions,” IEEE T rans. Pattern Anal. Mach. Intell, vol. 31,

no. 1, pp. 39–58, 2009.

\[8\] M. Pantie and L. J. M. Rothkrantz, “Automatic analysis of

facial expressions: the state of the art,” IEEE T ransactions on

Pattern Analysis and Machine Intelligence, vol. 22, no. 12,

pp. 1424–1445, 2000.

\[9\] S. Li and W. Deng, “Reliable crowdsourcing and deep locality-

preserving learning for unconstrained facial expression rec-

ognition,” IEEE T ransactions on Image Processing, vol. 28,

no. 1, pp. 356–370, 2019.

\[10\] Y. Tian, T. Kanade, and J. F. Cohn, “Facial expression rec-

ognition,” in Handbook of Face Recognition, pp. 487–519,

Springer, London, UK, 2011.

\[11\] T. F. Cootes, C. J. T aylor, D. H. Cooper, and J. Graham,

“Active shape models-their training and application,” Com-

puter Vision and Image Understanding, vol. 61, no. 1,

pp. 38–59, 1995.

\[12\] T. F. Cootes, G. J. Edwards, and C. J. T aylor, “Active ap-

pearance models,” IEEE T ransactions on Pattern Analysis and

Machine Intelligence, vol. 23, no. 6, pp. 681–685, 2001.

\[13\] D. Cristinacce and T. Cootes, “Automatic feature localisation

with constrained local models,” Pattern Recognition, vol. 41,

no. 10, pp. 3054–3067, 2008.

\[14\] M. H. Mahoor, M. Zhou, K. L. Veon, S. M. Mavadati, and

J. F. Cohn, “Facial action unit recognition with sparse rep-

resentation,,” in Proceedings of the 2011 International Con-

ference Automatic on Face and Gesture Recognition,

pp. 336–342, Santa Barbara, CA, USA, March 2011.

\[15\] T.-H. Wang and J.-J. Lien, “Facial expression recognition

system based on rigid and non-rigid motion separation and

3D pose estimation,” Pattern Recognition, vol. 42, no. 5,

pp. 962–977, 2009.

\[16\] M. F. Valstar and M. Pantic, “Fully automatic recognition of

the temporal phases of facial actions,” IEEE Transactions on

Systems, Man, and Cybernetics, Part B (Cybernetics), vol. 42,

no. 1, pp. 28–43, 2012.

\[17\] S. Kaltwang, S. T odorovic, and M. Pantic, “Doubly sparse

relevance vector machine for continuous facial behavior es-

timation,” IEEE T ransactions on Pattern Analysis and Ma-

chine Intelligence, vol. 38, no. 9, pp. 1748– 176 1, 2016.

\[18\] M. H. Mahoor, S. Cadavid, D. S. Messinger, and J. F. Cohn, “A

framework for automated measurement of the intensity of

non-posed facial action units,” in Proceedings of the IEEE

Computer Society Conference on Computer Vision and Pattern

Recognition, pp. 74–80, Miami, FL, USA, June 2009.

\[19\] M. F. Valstar, T. Almaev, J. M. Girard et al., “FERA

2015–second facial expression recognition and analysis

challenge,” in Proceedings of the 2015 IEEE International

Conference and Workshops on Automatic Face and Gesture

Recognition, pp. 1–8, Ljubljana, Slovenia, May 2015.

\[20\] M. Liu, S. Li, S. Shan, and X. Chen, “AU-aware deep networks

for facial expression recognition,” in Proceedings of the 2013

IEEE International Conference and Workshops on Automatic

Face and Gesture Recognition, pp. 1–6, Shanghai, China, April

\[21\] H. E. T. Gudi, T. M. den Uyl, and A. Maroulis, “Deep learning

based FACS action unit occurrence and intensity estimation,,”

in Proceedings of the 2015 IEEE International Conference and

Workshops on Automatic Face and Gesture Recognition,

pp. 1–5, Ljubljana, Slovenia, May 2015.

\[22\] K. Zhao, W.-S. Chu, and H. Zhang, “Deep region and multi-

label learning for facial action unit detection,,” in Proceedings

of the 2016 IEEE Conference on Computer Vision and Pattern

Recognition, pp. 3391–3399, Las Vegas, NV, USA, June 20 16.

\[23\] Y. Li, B. Wu, B. Ghanem, Y. Zhao, H. Yao, and Q. Ji, “Facial

action unit recognition under incomplete data based on

multi-label learning with missing labels,” Pattern Recognition,

vol. 60, pp. 890–900, 2016.

\[24\] S. Wang, S. Wu, G. Peng, and Q. Ji, “Capturing feature and

label relations simultaneously for multiple facial action unit

recognition,” IEEE T ransactions on Aﬀective Computing,

vol. 10, no. 3, pp. 348–359, 2017.

\[25\] Y. Zhang, L. Zhang, and M. A. Hossain, “Adaptive 3D facial

action intensity estimation and emotion recognition,” Expert

Systems with Applications, vol. 42, no. 3, pp. 1446– 1464, 2015.

\[26\] L. Hao, S. Wang, G. Peng, and Q. Ji, “Facial action unit

recognition augmented by their dependencies,” in Proceedings

of the 2018 13th IEEE International Conference on Automatic

Face & Gesture Recognition, pp. 187–194, Xi'an, China, May

\[27\] O. Rudovic, V. Pavlovic, and M. Pantic, “Context-sensitive

dynamic ordinal regression for intensity estimation of facial

action units,” IEEE Transactions on Pattern Analysis and

Machine Intelligence, vol. 37, no. 5, pp. 944–958, 2015.

\[28\] B. Martinez, M. F. Valstar, B. Jiang, and M. Pantic, “Auto-

matic analysis of facial actions: a survey,” IEEE Transactions

on Aﬀective Computing, vol. 10, no. 3, pp. 325–347, 20 19.

Mathematical Problems in Engineering 11

\[29\] T. B. Zadeh and L.-P. Morency, “Convolutional experts

constrained local model for facial landmark detection,” in

Proceedings of the 2017 IEEE Conference on CVPRW, p. 205 1,

Honolulu, HI, USA, July 2017.

\[30\] A. Savran, N. Aly ¨ uz, H. Dibeklio ˘

glu et al., “Bosphorus da-

tabase for 3D face analysis,” in Lecture Notes in Computer

Science, pp. 47–56, Springer, Berlin, Germany, 2008.

\[31\] P. Lucey, J. F. Cohn, T. Kanade, J. Saragih, Z. Ambadar, and

I. Matthews, “e extended Cohn-Kanade sataset (CK+)\_ a

complete dataset for action unit andemotion-speciﬁed ex-

pression,” in Proceedings of the 2010 IEEE Conference on

CVPRW, pp. 94–10 1, San Francisco, CA, USA, June 2010.

12 Mathematical Problems in Engineering

#### Available via license:

https://www.researchgate.net/deref/https%3A%2F%2Fcreativecommons.org%2Flicenses%2Fby%2F4.0%2F

Content may be subject to copyright.

Citations (21)

References (32)

... Another approach that uses alignment, proposed by J. Ma et al.

, is the use of facial features constructed from facial landmarks. In the cited research, the three-dimensional coordinates of 68 facial landmarks, visualized in Figure 2.11, are obtained based on a convolutional experts-constrained local model (CE-CLM), which enables the construction of dynamic facial features....

... Therefore, constructing the features based on the relationship between the points in space may lead to adequate features for the model prediction. For the model, the distances between points are calculated in a similar way as J. Ma et al.

, but using the specific regions for each AU group proposed by C. Ma, Chen, and Yong \[102\]. Different ways to construct information between points in a coordinate system are shown in Figure 3.4....

... This is done to explore the contribution of each component in the proposed pipeline, and how the performance changes by combining and tuning each part of the model. Finally, to evaluate the overall performance of the AU intensity estimation of the framework, the results presented by Fan et al. \[49\] and the research by J. Ma et al.

are used as a baseline....

A Comprehensive Study into Digital Human Faces. Emphatic Perception using an Improved Machine Vision Model for Facial Tracking using a Facial Action Code System

https://www.researchgate.net/publication/401591972\_A\_Comprehensive\_Study\_into\_Digital\_Human\_Faces\_Emphatic\_Perception\_using\_an\_Improved\_Machine\_Vision\_Model\_for\_Facial\_Tracking\_using\_a\_Facial\_Action\_Code\_System

Full-text available

Carlos L Vilchis

https://www.researchgate.net/profile/Carlos-Vilchis-2

This thesis explores the flourishing field of digital humans, which has gained prominence in recent years as embodied conversational agents with diverse applications. The challenge lies in achieving realism in graphics, empathic responses, and accurate facial expression replication. While computer facial animation has made strides in creating adaptable, real-time systems, democratized solutions for facial motion capture are limited by cost and accessibility. This research presents a framework integrating artificial intelligence techniques for real-time facial tracking. It is hypothesized that by combining the Facial Action Coding System with machine learning, digital human realism and empathic responses can be enhanced. Key questions and objectives address the feasibility of open-source real-time facial tracking, the impact of integration between the Facial Action Coding System and artificial intelligence, and the balance between photo-realistic quality and expressive nuances. Contributions encompass a general facial capture pipeline proposal, an open-source application, an evaluation model for empathic responses, and a comparative analysis of accessible facial performance capture solutions. Parallel research findings include a protocol for genuine expression capture, insights into emotional regulation in virtual environments, and an evaluation of lightweight backbone models for facial reconstruction. Overall, the research carried out during this thesis holds the potential for improving realism and empathy in digital humans, offering valuable insights and setting the stage for future advancements in the field.

https://www.researchgate.net/publication/401591972\_A\_Comprehensive\_Study\_into\_Digital\_Human\_Faces\_Emphatic\_Perception\_using\_an\_Improved\_Machine\_Vision\_Model\_for\_Facial\_Tracking\_using\_a\_Facial\_Action\_Code\_System

Show abstract

... The eigenvectors describing the variance in the models for each face are then extracted using the average template and principal component analysis (PCA). The constraints of ASM

are as follows, the findings struggled to match an image's bounds because of the parametric definition of shapes. It was not very good at processing new photos....

Facial features extraction using active shape model and constrained local model: a comprehensive analysis study

https://www.researchgate.net/publication/396568240\_Facial\_features\_extraction\_using\_active\_shape\_model\_and\_constrained\_local\_model\_a\_comprehensive\_analysis\_study

Full-text available

Musab Iqtait

https://www.researchgate.net/scientific-contributions/Musab-Iqtait-2296524573

Marwan Alqaryouti

https://www.researchgate.net/profile/Marwan-Alqaryouti

Ala Eddin Sadeq

https://www.researchgate.net/scientific-contributions/Ala-Eddin-Sadeq-2226691488

Sattam Almatarneh

https://www.researchgate.net/scientific-contributions/Sattam-Almatarneh-2328054897

span lang="EN-US">Human facial feature extraction plays a critical role in various applications, including biorobotics, polygraph testing, and driver fatigue monitoring. However, many existing algorithms rely on end-to-end models that construct complex classifiers directly from face images, leading to poor interpretability. Additionally, these models often fail to capture dynamic information effectively due to insufficient consideration of respondents' personal characteristics. To address these limitations, this paper evaluates two prominent approaches: the constrained local model (CLM), which accurately extracts facial features depending on patch experts, and the active shape model (ASM), designed to simultaneously extract the appearance and shape of an object. We assess the performance of these models on the MORPH dataset using point to point error as evaluation metrics. Our experimental results demonstrate that the CLM achieves higher accuracy, while the ASM exhibits better efficiency. These findings provide valuable insights for selecting the appropriate model based on specific application requirements.</span

https://www.researchgate.net/publication/396568240\_Facial\_features\_extraction\_using\_active\_shape\_model\_and\_constrained\_local\_model\_a\_comprehensive\_analysis\_study

Show abstract

... Landmark locations have been shown to provide crucial insights in the context of face alignment, feature extraction, facial expression recognition, head pose estimation, eye gaze tracking, and other tasks \[37\]\[38\]\[39\] . They have also been used for automated facial movement recognition systems 40,

. An important advantage of landmark-based approaches is their ease of application to video data, producing time series of multiple coordinates, which can then be analyzed 42 , classified \[43\]\[44\]\[45\] , or processed for different purposes 46,47 ....

Dog facial landmarks detection and its applications for facial analysis

https://www.researchgate.net/publication/393255104\_Dog\_facial\_landmarks\_detection\_and\_its\_applications\_for\_facial\_analysis

Full-text available

George Martvel

https://www.researchgate.net/profile/George-Martvel

Anna Zamansky

https://www.researchgate.net/profile/Anna-Zamansky-2

Giulia Pedretti

https://www.researchgate.net/profile/Giulia-Pedretti

Annika Bremhorst

https://www.researchgate.net/profile/Annika-Bremhorst

Automated analysis of facial expressions is a crucial challenge in the emerging field of animal affective computing. One of the most promising approaches in this context is facial landmarks, which are well-studied for humans and are now being adopted for many non-human species. The scarcity of high-quality, comprehensive datasets is a significant challenge in the field. This paper is the first to present a novel Dog Facial Landmarks in the Wild (DogFLW) dataset containing 3732 images of dogs annotated with facial landmarks and bounding boxes. Our facial landmark scheme has 46 landmarks grounded in canine facial anatomy, the Dog Facial Action Coding System (DogFACS), and informed by existing cross-species landmarking methods. We additionally provide a benchmark for dog facial landmarks detection and demonstrate two case studies for landmark detection models trained on the DogFLW. The first is a pipeline using landmarks for emotion classification from dog facial expressions from video, and the second is the recognition of DogFACS facial action units (variables), which can enhance the DogFACS coding process by reducing the time needed for manual annotation. The DogFLW dataset aims to advance the field of animal affective computing by facilitating the development of more accurate, interpretable, and scalable tools for analysing facial expressions in dogs with broader potential applications in behavioural science, veterinary practice, and animal-human interaction research.

https://www.researchgate.net/publication/393255104\_Dog\_facial\_landmarks\_detection\_and\_its\_applications\_for\_facial\_analysis

Show abstract

... Landmark locations have been shown to provide crucial insights in the context of face alignment, feature extraction, facial expression recognition, head pose estimation, eye gaze tracking, and other tasks \[1,2,21\]. They have also been used for automated facial movement recognition systems

43\]. An important advantage of landmarkbased approaches is their ease of application to video data, producing time series of multiple coordinates, which can then be analyzed \[44\], classified \[8,19,32\], or processed for different purposes \[11,36\]....

Semantic Style Transfer for Enhancing Animal Facial Landmark Detection

https://www.researchgate.net/publication/391658128\_Semantic\_Style\_Transfer\_for\_Enhancing\_Animal\_Facial\_Landmark\_Detection

Full-text available

Anadil Hussein

https://www.researchgate.net/profile/Anadil-Hussein

Anna Zamansky

https://www.researchgate.net/profile/Anna-Zamansky-2

George Martvel

https://www.researchgate.net/profile/George-Martvel

Neural Style Transfer (NST) is a technique for applying the visual characteristics of one image onto another while preserving structural content. Traditionally used for artistic transformations, NST has recently been adapted, e.g., for domain adaptation and data augmentation. This study investigates the use of this technique for enhancing animal facial landmark detectors training. As a case study, we use a recently introduced Ensemble Landmark Detector for 48 anatomical cat facial landmarks and the CatFLW dataset it was trained on, making three main contributions. First, we demonstrate that applying style transfer to cropped facial images rather than full-body images enhances structural consistency, improving the quality of generated images. Secondly, replacing training images with style-transferred versions raised challenges of annotation misalignment, but Supervised Style Transfer (SST) - which selects style sources based on landmark accuracy - retained up to 98% of baseline accuracy. Finally, augmenting the dataset with style-transferred images further improved robustness, outperforming traditional augmentation methods. These findings establish semantic style transfer as an effective augmentation strategy for enhancing the performance of facial landmark detection models for animals and beyond. While this study focuses on cat facial landmarks, the proposed method can be generalized to other species and landmark detection models.

https://www.researchgate.net/publication/391658128\_Semantic\_Style\_Transfer\_for\_Enhancing\_Animal\_Facial\_Landmark\_Detection

Show abstract

... Since manually annotated attention maps are not always available for large-scale datasets, the spatial maps are localized based on facial landmarks \[11,

. In this paper, we utilize an open-source landmark detector \[49\] for automatic landmark detection....

Interpretable Concept-based Deep Learning Framework for Multimodal Human Behavior Modeling

https://www.researchgate.net/publication/389056663\_Interpretable\_Concept-based\_Deep\_Learning\_Framework\_for\_Multimodal\_Human\_Behavior\_Modeling

Full-text available

https://www.researchgate.net/scientific-contributions/Xinyu-Li-2286654667

Marwa Mahmoud

https://www.researchgate.net/scientific-contributions/Marwa-Mahmoud-2305760149

In the contemporary era of intelligent connectivity, Affective Computing (AC), which enables systems to recognize, interpret, and respond to human behavior states, has become an integrated part of many AI systems. As one of the most critical components of responsible AI and trustworthiness in all human-centered systems, explainability has been a major concern in AC. Particularly, the recently released EU General Data Protection Regulation requires any high-risk AI systems to be sufficiently interpretable, including biometric-based systems and emotion recognition systems widely used in the affective computing field. Existing explainable methods often compromise between interpretability and performance. Most of them focus only on highlighting key network parameters without offering meaningful, domain-specific explanations to the stakeholders. Additionally, they also face challenges in effectively co-learning and explaining insights from multimodal data sources. To address these limitations, we propose a novel and generalizable framework, namely the Attention-Guided Concept Model (AGCM), which provides learnable conceptual explanations by identifying what concepts that lead to the predictions and where they are observed. AGCM is extendable to any spatial and temporal signals through multimodal concept alignment and co-learning, empowering stakeholders with deeper insights into the model's decision-making process. We validate the efficiency of AGCM on well-established Facial Expression Recognition benchmark datasets while also demonstrating its generalizability on more complex real-world human behavior understanding applications.

https://www.researchgate.net/publication/389056663\_Interpretable\_Concept-based\_Deep\_Learning\_Framework\_for\_Multimodal\_Human\_Behavior\_Modeling

Show abstract

Multiview of AI-generated Facial Expressions for Entertainment: A Cross-style Analysis

https://www.researchgate.net/publication/397915798\_Multiview\_of\_AI-generated\_Facial\_Expressions\_for\_Entertainment\_A\_Cross-style\_Analysis

Conference Paper

Full-text available

Anthony Kong

https://www.researchgate.net/profile/Anthony-Kong

https://www.researchgate.net/scientific-contributions/Zixin-He-2331885807

The objective of this study is to investigate how artificial intelligence (AI) generated characters' expressions regarding emotions reflect the aspects of emotion in different styles and how this is perceived by an audience. Using the Matrix of Character Styles and Types (MCST) framework, we developed a dataset with multidimensional characters. On the vertical plane it is characters from human to animal and fantasy figures, on the horizontal it is level of art from hyperrealism to abstract. Based on the stable diffusion model, characters in diverse styles exhibited six universal basic emotional expressions: anger, disgust, fear, happiness, sadness, and surprise. The audience's perceptions were then analyzed by a survey on several dimensions, including the expressiveness of the emotions generated, the readability in different AI-generated styles for the target audience groups, and, in general, the acceptance of machine-made imagery. This study contributes to the field of cross-style and cross-character-type AI emotion generation and provides specific guidance on how to generate AI-based 3D content (still image and animation). This study aims to provide designers with a more profound understanding of audience preferences and target groups.

https://www.researchgate.net/publication/397915798\_Multiview\_of\_AI-generated\_Facial\_Expressions\_for\_Entertainment\_A\_Cross-style\_Analysis

Show abstract

A Systematic Review of Mental States and Safety Performance of Construction Workers

https://www.researchgate.net/publication/396064403\_A\_Systematic\_Review\_of\_Mental\_States\_and\_Safety\_Performance\_of\_Construction\_Workers

J CONSTR ENG M ASCE

https://www.researchgate.net/scientific-contributions/Han-Zhou-2326408813

Albert Ping-Chuen Chan

https://www.researchgate.net/scientific-contributions/Albert-Ping-Chuen-Chan-2303548481

https://www.researchgate.net/scientific-contributions/Yang-Yang-2326393544

https://www.researchgate.net/scientific-contributions/Wen-Yi-2326395882

https://www.researchgate.net/publication/396064403\_A\_Systematic\_Review\_of\_Mental\_States\_and\_Safety\_Performance\_of\_Construction\_Workers

Automated landmark-based cat facial analysis and its applications

https://www.researchgate.net/publication/387327364\_Automated\_landmark-based\_cat\_facial\_analysis\_and\_its\_applications

Full-text available

George Martvel

https://www.researchgate.net/profile/George-Martvel

Teddy Lazebnik

https://www.researchgate.net/profile/Teddy-Lazebnik

Marcelo Feighelstein

https://www.researchgate.net/scientific-contributions/Marcelo-Feighelstein-2216960987

Anna Zamansky

https://www.researchgate.net/profile/Anna-Zamansky-2

Facial landmarks, widely studied in human affective computing, are beginning to gain interest in the animal domain. Specifically, landmark-based geometric morphometric methods have been used to objectively assess facial expressions in cats, focusing on pain recognition and the impact of breed-specific morphology on facial signaling. These methods employed a 48-landmark scheme grounded in cat facial anatomy. Manually annotating these landmarks, however, is a labor-intensive process, deeming it impractical for generating sufficiently large amounts of data for machine learning purposes and for use in applied real-time contexts with cats. Our previous work introduced an AI pipeline for automated landmark detection, which showed good performance in standard machine learning metrics. Nonetheless, the effectiveness of fully automated, end-to-end landmark-based systems for practical cat facial analysis tasks remained underexplored. In this paper we develop AI pipelines for three benchmark tasks using two previously collected datasets of cat faces. The tasks include automated cat breed recognition, cephalic type recognition and pain recognition. Our fully automated end-to-end pipelines reached accuracy of 75% and 66% in cephalic type and pain recognition respectively, suggesting that landmark-based approaches hold promise for automated pain assessment and morphological explorations.

https://www.researchgate.net/publication/387327364\_Automated\_landmark-based\_cat\_facial\_analysis\_and\_its\_applications

Show abstract

On the Usability of Structural Similarity for Action Unit Intensity Detection

https://www.researchgate.net/publication/386032018\_On\_the\_Usability\_of\_Structural\_Similarity\_for\_Action\_Unit\_Intensity\_Detection

Conference Paper

Gökhan Güney

https://www.researchgate.net/profile/Goekhan-Gueney-10

Maurice Rohr

https://www.researchgate.net/scientific-contributions/Maurice-Rohr-2212076780

Sebastian Dill

https://www.researchgate.net/profile/Sebastian-Dill-3

Christoph Hoog Antink

https://www.researchgate.net/profile/Christoph-Hoog-Antink

https://www.researchgate.net/publication/386032018\_On\_the\_Usability\_of\_Structural\_Similarity\_for\_Action\_Unit\_Intensity\_Detection

Online learning concentration recognition based on computer vision

https://www.researchgate.net/publication/384570530\_Online\_learning\_concentration\_recognition\_based\_on\_computer\_vision

Conference Paper

https://www.researchgate.net/scientific-contributions/Libo-Qiao-2158577890

https://www.researchgate.net/scientific-contributions/Sheng-Guan-2251117192

https://www.researchgate.net/profile/Wei-Wang-935

https://www.researchgate.net/publication/384570530\_Online\_learning\_concentration\_recognition\_based\_on\_computer\_vision

Reliable Crowdsourcing and Deep Locality-Preserving Learning for Unconstrained Facial Expression Recognition

https://www.researchgate.net/publication/327407041\_Reliable\_Crowdsourcing\_and\_Deep\_Locality-Preserving\_Learning\_for\_Unconstrained\_Facial\_Expression\_Recognition

https://www.researchgate.net/profile/Shan-Li-31

Weihong Deng

https://www.researchgate.net/scientific-contributions/Weihong-Deng-2090693835

Facial expression is central to human experience, but most previous databases and studies are limited to posed facial behavior under controlled conditions. In this paper, we present a novel facial expression database, Real-world Affective Face Database (RAF-DB), which contains approximately 30,000 facial images with uncontrolled poses and illumination from thousands of individuals of diverse ages and races. During the crowdsourcing annotation, each image is independently labeled by approximately 40 annotators. An expectation-maximization (EM) algorithm is developed to reliably estimate the emotion labels, which reveals that real-world faces often express compound or even mixture emotions. A cross-database study between RAF-DB and CK+ database further indicates that the action units (AUs) of real-world emotions are much more diverse than, or even deviate from, those of laboratory-controlled emotions. To address the recognition of multi-modal expressions in the wild, we propose a new deep locality-preserving convolutional neural network (DLP-CNN) method that aims to enhance the discriminative power of deep features by preserving the locality closeness while maximizing the inter-class scatter. Benchmark experiments on 7-class basic expressions and 11-class compound expressions, as well as additional experiments on CK+, MMI and SFEW 2.0 databases, show that the proposed DLP-CNN outperforms the state-of-the-art handcrafted features and deep learning based methods for expression recognition in the wild. To promote further study, we have made the RAF database, benchmarks, and descriptor encodings publicly available to the research community.

https://www.researchgate.net/publication/327407041\_Reliable\_Crowdsourcing\_and\_Deep\_Locality-Preserving\_Learning\_for\_Unconstrained\_Facial\_Expression\_Recognition

Show abstract

Facial Action Unit Recognition Augmented by Their Dependencies

https://www.researchgate.net/publication/325635660\_Facial\_Action\_Unit\_Recognition\_Augmented\_by\_Their\_Dependencies

Conference Paper

Longfei Hao

https://www.researchgate.net/profile/Longfei\_Hao2

Shangfei Wang

https://www.researchgate.net/profile/Shangfei-Wang

Guozhu Peng

https://www.researchgate.net/scientific-contributions/Guozhu-Peng-2162664352

https://www.researchgate.net/profile/Qiang-Ji

https://www.researchgate.net/publication/325635660\_Facial\_Action\_Unit\_Recognition\_Augmented\_by\_Their\_Dependencies

Convolutional Experts Constrained Local Model for Facial Landmark Detection

https://www.researchgate.net/publication/319284817\_Convolutional\_Experts\_Constrained\_Local\_Model\_for\_Facial\_Landmark\_Detection

Conference Paper

https://www.researchgate.net/scientific-contributions/Amir-Zadeh-2111232957

Tadas Baltrusaitis

https://www.researchgate.net/profile/Tadas-Baltrusaitis-2

Louis-Philippe Morency

https://www.researchgate.net/scientific-contributions/Louis-Philippe-Morency-13852141

https://www.researchgate.net/publication/319284817\_Convolutional\_Experts\_Constrained\_Local\_Model\_for\_Facial\_Landmark\_Detection

Capturing Feature and Label Relations Simultaneously for Multiple Facial Action Unit Recognition

https://www.researchgate.net/publication/319022894\_Capturing\_Feature\_and\_Label\_Relations\_Simultaneously\_for\_Multiple\_Facial\_Action\_Unit\_Recognition

Shangfei Wang

https://www.researchgate.net/profile/Shangfei-Wang

https://www.researchgate.net/scientific-contributions/Shan-Wu-2086284206

Guozhu Peng

https://www.researchgate.net/scientific-contributions/Guozhu-Peng-2162664352

https://www.researchgate.net/scientific-contributions/Qiang-Ji-2046151075

Although both feature dependencies and label dependencies are crucial for facial action unit (AU) recognition, little work addresses them simultaneously till now. In this paper, we propose a 4-layer Restricted Boltzmann Machine (RBM) to simultaneously capture feature level and label level dependencies to recognize multiple AUs. The middle hidden layer of the 4-layer RBM model captures dependencies among image features for multiple AUs, while the top latent units capture the high-order semantic dependencies among AU labels. Furthermore, we extend the proposed 4-layer RBM for facial expression-augmented AU recognition, since AU relations are influenced by expressions. By introducing facial expression nodes in the middle visible layer, facial expressions, which are only required during training, facilitate the estimation of both feature dependencies and label dependencies among AUs. Efficient learning and inference algorithms for the extended model are also developed. Experimental results on three benchmark databases, i.e. the CK+ database, the DISFA database and the SEMAINE database, demonstrate that the proposed approaches can successfully capture complex AU relationships from features and labels jointly, and the expression labels available only during training are benefit for AU recognition during testing for both posed and spontaneous facial expressions.

https://www.researchgate.net/publication/319022894\_Capturing\_Feature\_and\_Label\_Relations\_Simultaneously\_for\_Multiple\_Facial\_Action\_Unit\_Recognition

Show abstract

Automatic Analysis of Facial Actions: A Survey

https://www.researchgate.net/publication/318693607\_Automatic\_Analysis\_of\_Facial\_Actions\_A\_Survey

Brais Martinez

https://www.researchgate.net/profile/Brais-Martinez

Michel Valstar

https://www.researchgate.net/profile/Michel-Valstar-2

Bihan Jiang

https://www.researchgate.net/scientific-contributions/Bihan-Jiang-70938792

Maja Pantic

https://www.researchgate.net/scientific-contributions/Maja-Pantic-47824715

As one of the most comprehensive and objective ways to describe facial expressions, the Facial Action Coding System (FACS) has recently received significant attention. Over the past 30 years, extensive research has been conducted by psychologists and neuroscientists on various aspects of facial expression analysis using FACS. Automating FACS coding would make this research faster and more widely applicable, opening up new avenues to understanding how we communicate through facial expressions. Such an automated process can also potentially increase the reliability, precision and temporal resolution of coding. This paper provides a comprehensive survey of research into machine analysis of facial actions. We systematically review all components of such systems: pre-processing, feature extraction and machine coding of facial actions. In addition, existing FACS-coded facial expression databases are summarised. Finally, challenges that have to be addressed to make automatic facial action analysis applicable in real-life situations are extensively discussed. There are two underlying motivations for us to write this survey paper: the first is to provide an up-to-date review of the existing literature, and the second is to offer some insights into the future of machine recognition of facial actions: what are the challenges and opportunities that researchers in the field face.

https://www.researchgate.net/publication/318693607\_Automatic\_Analysis\_of\_Facial\_Actions\_A\_Survey

Show abstract

Deep Region and Multi-label Learning for Facial Action Unit Detection

https://www.researchgate.net/publication/311610736\_Deep\_Region\_and\_Multi-label\_Learning\_for\_Facial\_Action\_Unit\_Detection

Conference Paper

https://www.researchgate.net/profile/Kaili-Zhao

Wen-Sheng Chu

https://www.researchgate.net/profile/Wen-Sheng-Chu

Honggang Zhang

https://www.researchgate.net/scientific-contributions/Honggang-Zhang-2038357532

https://www.researchgate.net/publication/311610736\_Deep\_Region\_and\_Multi-label\_Learning\_for\_Facial\_Action\_Unit\_Detection

Deep learning based FACS Action Unit occurrence and intensity estimation

https://www.researchgate.net/publication/308834639\_Deep\_learning\_based\_FACS\_Action\_Unit\_occurrence\_and\_intensity\_estimation

Conference Paper

https://www.researchgate.net/profile/Amogh-Gudi

H. Emrah Tasli

https://www.researchgate.net/profile/H-Tasli

Tim M. den Uyl

https://www.researchgate.net/scientific-contributions/Tim-M-den-Uyl-2073690517

Andreas Maroulis

https://www.researchgate.net/scientific-contributions/Andreas-Maroulis-2116151773

Ground truth annotation of the occurrence and intensity of FACS Action Unit (AU) activation requires great amount of attention. The efforts towards achieving a common platform for AU evaluation have been addressed in the FG 2015 Facial Expression Recognition and Analysis challenge (FERA 2015). Participants are invited to estimate AU occurrence and intensity on a common benchmark dataset. Conventional approaches towards achieving automated methods are to train multiclass classifiers or to use regression models. In this paper, we propose a novel application of a deep convolutional neural network (CNN) to recognize AUs as part of FERA 2015 challenge. The 7 layer network is composed of 3 convolutional layers and a max-pooling layer. The final fully connected layers provide the classification output. For the selected tasks of the challenge, we have trained two different networks for the two different datasets, where one focuses on the AU occurrences and the other on both occurrences and intensities of the AUs. The occurrence and intensity of AU activation are estimated using specific neuron activations of the output layer. This way, we are able to create a single network architecture that could simultaneously be trained to produce binary and continuous classification output.

https://www.researchgate.net/publication/308834639\_Deep\_learning\_based\_FACS\_Action\_Unit\_occurrence\_and\_intensity\_estimation

Show abstract

Advances, Challenges, and Opportunities in Automatic Facial Expression Recognition

https://www.researchgate.net/publication/305553500\_Advances\_Challenges\_and\_Opportunities\_in\_Automatic\_Facial\_Expression\_Recognition

Brais Martinez

https://www.researchgate.net/scientific-contributions/Brais-Martinez-2113052478

Michel Valstar

https://www.researchgate.net/profile/Michel-Valstar-2

In this chapter we consider the problem of automatic facial expression analysis. Our take on this is that the field has reached a point where it needs to move away from considering experiments and applications under in-the-lab conditions, and move towards so-called in-the-wild scenarios. We assume throughout this chapter that the aim is to develop technology that can be deployed in practical applications under unconstrained conditions. While some first efforts in this direction have been reported very recently, it is still unclear what the right path to achieving accurate, informative, robust, and real-time facial expression analysis will be. To illuminate the journey ahead, we first provide in Sect. 1 an overview of the existing theories and specific problem formulations considered within the computer vision community. Then we describe in Sect. 2 the standard algorithmic pipeline which is common to most facial expression analysis algorithms. We include suggestions as to which of the current algorithms and approaches are most suited to the scenario considered. In Sect. 3 we describe our view of the remaining challenges, and the current opportunities within the field. This chapter is thus not intended as a review of different approaches, but rather a selection of what we believe are the most suitable state-of-the-art algorithms, and a selection of exemplars chosen to characterise a specific approach. We review in Sect. 4 some of the exciting opportunities for the application of automatic facial expression analysis to everyday practical problems and current commercial applications being exploited. Section 5 ends the chapter by summarising the major conclusions drawn.

https://www.researchgate.net/publication/305553500\_Advances\_Challenges\_and\_Opportunities\_in\_Automatic\_Facial\_Expression\_Recognition

Show abstract

Facial Action Unit Recognition under Incomplete Data Based on Multi-label Learning with Missing Labels

https://www.researchgate.net/publication/305078143\_Facial\_Action\_Unit\_Recognition\_under\_Incomplete\_Data\_Based\_on\_Multi-label\_Learning\_with\_Missing\_Labels

PATTERN RECOGN

Yongqiang Li

https://www.researchgate.net/profile/Yongqiang-Li

https://www.researchgate.net/profile/Baoyuan-Wu

Bernard Ghanem

https://www.researchgate.net/profile/Bernard-Ghanem

https://www.researchgate.net/profile/Qiang-Ji

Facial action unit (AU) recognition has been applied in a wild range of fields, and has attracted great attention in the past two decades. Most existing works on AU recognition assumed that the complete label assignment for each training image is available, which is often not the case in practice. Labeling AU is expensive and time consuming process. Moreover, due to the AU ambiguity and subjective difference, some AUs are difficult to label reliably and confidently. Many AU recognition works try to train the classifier for each AU independently, which is of high computation cost and ignores the dependency among different AUs. In this work, we formulate AU recognition under incomplete data as a multi-label learning with missing labels (MLML) problem. Most existing MLML methods usually employ the same features for all classes. However, we find this setting is unreasonable in AU recognition, as the occurrence of different AUs produce changes of skin surface displacement or face appearance in different face regions. If using the shared features for all AUs, much noise will be involved due to the occurrence of other AUs. Consequently, the changes of the specific AUs cannot be clearly highlighted, leading to the performance degradation. Instead, we propose to extract the most discriminative features for each AU individually, which are learned by the supervised learning method. The learned features are further embedded into the instance-level label smoothness term of our model, which also includes the label consistency and the class-level label smoothness. Both a global solution using st-cut and an approximated solution using conjugate gradient (CG) descent are provided. Experiments on both posed and spontaneous facial expression databases demonstrate the superiority of the proposed method in comparison with several state-of-the-art works.

https://www.researchgate.net/publication/305078143\_Facial\_Action\_Unit\_Recognition\_under\_Incomplete\_Data\_Based\_on\_Multi-label\_Learning\_with\_Missing\_Labels

Show abstract

Communication without words

https://www.researchgate.net/publication/303322246\_Communication\_without\_words

Psychol Today

A. Mehrabian

https://www.researchgate.net/scientific-contributions/A-Mehrabian-2109507950

https://www.researchgate.net/publication/303322246\_Communication\_without\_words

Recommended publications

Discover more

https://www.researchgate.net/search

Facial Action Unit Recognition and Intensity Estimation Enhanced Through Label Dependencies

https://www.researchgate.net/publication/328548884\_Facial\_Action\_Unit\_Recognition\_and\_Intensity\_Estimation\_Enhanced\_Through\_Label\_Dependencies

October 2018

· IEEE Transactions on Image Processing

Shangfei Wang

https://www.researchgate.net/profile/Shangfei-Wang

Longfei Hao

https://www.researchgate.net/profile/Longfei\_Hao2

https://www.researchgate.net/profile/Qiang-Ji

The inherent dependencies among facial action units (AU) caused by the underlying anatomic mechanism are essential for the proper recognition of AUs and estimation of intensity levels, but they have not been exploited to their full potential. We are proposing novel methods to recognize AUs and estimate intensity via hybrid Bayesian networks. The upper two layers are latent regression Bayesian

... \[Show full abstract\]

https://www.researchgate.net/

networks (LRBNs), and the lower layers are Bayesian networks (BNs). The visible nodes of the LRBN layers are representations of ground-truth AU occurrences or AU intensities. Through the directed connections from latent layer and visible layer, an LRBN can successfully represent relationships between multiple AUs or AU intensities. The lower layers include Bayesian networks with two nodes for AU recognition, and Bayesian networks with three nodes for AU intensity estimation. The bottom layers incorporate measurements from facial images with AU dependencies for intensity estimation and AU recognition. Efficient learning algorithms of the hybrid Bayesian networks are proposed for AU recognition as well as intensity estimation. Furthermore, the proposed hybrid Bayesian network models are extended for facial expression-assisted AU recognition and intensity estimation, as AU relationships are closely related to facial expressions. We test our methods on three benchmark databases for AU recognition and two benchmark databases for intensity estimation. The results demonstrate that the proposed approaches faithfully model the complex and global inherent AU dependencies, and the expression labels available only during training can boost the estimation of AU dependencies for both AU recognition and intensity estimation.

https://www.researchgate.net/publication/328548884\_Facial\_Action\_Unit\_Recognition\_and\_Intensity\_Estimation\_Enhanced\_Through\_Label\_Dependencies

A Copula Ordinal Regression Framework for Joint Estimation of Facial Action Unit Intensity

https://www.researchgate.net/publication/318514954\_A\_Copula\_Ordinal\_Regression\_Framework\_for\_Joint\_Estimation\_of\_Facial\_Action\_Unit\_Intensity

· IEEE Transactions on Affective Computing

Maja Pantic

https://www.researchgate.net/scientific-contributions/Maja-Pantic-47824715

Ognjen Rudovic

https://www.researchgate.net/profile/Ognjen-Rudovic

Vladimir Pavlovic

https://www.researchgate.net/profile/Vladimir-Pavlovic-2

Robert Walecki

https://www.researchgate.net/scientific-contributions/Robert-Walecki-2082864514

Joint modeling of the intensity of multiple facial action units (AUs) from face images is challenging due to the large number of AUs (30+) and their intensity levels (6). This is in part due to the lack of suitable models that can efficiently handle such a large number of outputs/classes simultaneously, but also due to the lack of suitable data the models on. For this reason, majority of the

... \[Show full abstract\]

https://www.researchgate.net/

methods resort to independent classifiers for the AU intensity. This is suboptimal for at least two reasons: the facial appearance of some AUs changes depending on the intensity of other AUs, and some AUs co-occur more often than others. To this end, we propose the Copula regression approach for modeling multivariate ordinal variables. Our model accounts for ordinal structure in output variables and their non-linear dependencies via copula functions modeled as cliques of a conditional random fields. The copula ordinal regression model achieves the joint learning and inference of intensities of multiple AUs, while being computationally tractable. We demonstrate the effectiveness of our approach on three challenging datasets of naturalistic facial expressions and we show that the estimation of target AU intensities improves especially in the case of (a) noisy image features, (b) head-pose variations and (c) imbalanced training data. Lastly, we show that the proposed approach consistently outperforms (i) independent modeling of AU intensities and (ii) the state-of-the-art approach for the target task and (iii) deep convolutional neural networks.

https://www.researchgate.net/publication/318514954\_A\_Copula\_Ordinal\_Regression\_Framework\_for\_Joint\_Estimation\_of\_Facial\_Action\_Unit\_Intensity

Facial Expression Recognition via Deep Action Units Graph Network Based on Psychological Mechanism

https://www.researchgate.net/publication/336250841\_Facial\_Expression\_Recognition\_via\_Deep\_Action\_Units\_Graph\_Network\_Based\_on\_Psychological\_Mechanism

· IEEE Transactions on Cognitive and Developmental Systems

https://www.researchgate.net/profile/Yang-Liu-1049

Xingming Zhang

https://www.researchgate.net/profile/Xingming-Zhang-7

https://www.researchgate.net/profile/Yubei-Lin

Haoxiang Wang

https://www.researchgate.net/profile/Haoxiang-Wang

Facial expression recognition (FER) is currently a very attractive research field in cognitive psychology and artificial intelligence. In this paper, an innovative FER algorithm called Deep Action Units (AUs) Graph Network (DAUGN) is proposed based on psychological mechanism. First, a segmentation method is designed to divide the face into small key areas, which are then converted into

... \[Show full abstract\]

https://www.researchgate.net/

corresponding AU-related facial expression regions. Second, the local appearance features of these critical regions are extracted for further AUs analysis. Then, an AUs facial graph is constructed to represent expressions by taking the AU-related regions as vertices and the distances between each two landmarks as edges. Finally, the adjacency matrices of facial graph are put into a graph-based convolutional neural network to combine the local-appearance and global-geometry information, which greatly improving the performance of FER. Experiments and comparisons on CK+, MMI and SFEW datasets reveal that the DAUGN achieves more competitive results than several other popular approaches.

https://www.researchgate.net/publication/336250841\_Facial\_Expression\_Recognition\_via\_Deep\_Action\_Units\_Graph\_Network\_Based\_on\_Psychological\_Mechanism

Conference Paper

Full-text available

Multi-output Laplacian dynamic ordinal regression for facial expression recognition and intensity es...

https://www.researchgate.net/publication/261154751\_Multi-output\_Laplacian\_dynamic\_ordinal\_regression\_for\_facial\_expression\_recognition\_and\_intensity\_estimation

· Proceedings / CVPR, IEEE Computer Society Conference on Computer Vision and Pattern Recognition. IEEE Computer Society Conference on Computer Vision and Pattern Recognition

Maja Pantic

https://www.researchgate.net/scientific-contributions/Maja-Pantic-47824715

Ognjen Rudovic

https://www.researchgate.net/profile/Ognjen-Rudovic

Vladimir Pavlovic

https://www.researchgate.net/profile/Vladimir-Pavlovic-2

Automated facial expression recognition has received increased attention over the past two decades. Existing works in the field usually do not encode either the temporal evolution or the intensity of the observed facial displays. They also fail to jointly model multidimensional (multi-class) continuous facial behaviour data; binary classifiers - one for each target basic-emotion class - are used

... \[Show full abstract\]

https://www.researchgate.net/

instead. In this paper, intrinsic topology of multidimensional continuous facial affect data is first modeled by an ordinal manifold. This topology is then incorporated into the Hidden Conditional Ordinal Random Field (H-CORF) framework for dynamic ordinal regression by constraining H-CORF parameters to lie on the ordinal manifold. The resulting model attains simultaneous dynamic recognition and intensity estimation of facial expressions of multiple emotions. To the best of our knowledge, the proposed method is the first one to achieve this on both deliberate as well as spontaneous facial affect data.

View full-text

https://www.researchgate.net/publication/261154751\_Multi-output\_Laplacian\_dynamic\_ordinal\_regression\_for\_facial\_expression\_recognition\_and\_intensity\_estimation

Discover the world's research

Join ResearchGate to find the people and research you need to help your work.

Join for free

https://www.researchgate.net/signup.SignUp.html

ResearchGate iOS App Get it from the App Store now.

https://www.researchgate.net/go.GetApp.html?\_sg=VHrS55hEy\_ylpP1DKxc2Ks9UAkxrYS5wmv-tG97RtMmoZhiBYI6Vd1UxgY4fYjWuD\_aJQ0D5JwlolgH\_tBbJaVZs17FzHFypAW5dk0nvRxA&originCh=bannerStatsCopy&relativePath=publicationLoggedOut&interested=true

https://www.researchgate.net/go.GetApp.html?\_sg=VHrS55hEy\_ylpP1DKxc2Ks9UAkxrYS5wmv-tG97RtMmoZhiBYI6Vd1UxgY4fYjWuD\_aJQ0D5JwlolgH\_tBbJaVZs17FzHFypAW5dk0nvRxA&originCh=bannerStatsCopy&relativePath=publicationLoggedOut&interested=true

Keep up with your stats and more

https://www.researchgate.net/go.GetApp.html?\_sg=VHrS55hEy\_ylpP1DKxc2Ks9UAkxrYS5wmv-tG97RtMmoZhiBYI6Vd1UxgY4fYjWuD\_aJQ0D5JwlolgH\_tBbJaVZs17FzHFypAW5dk0nvRxA&originCh=bannerStatsCopy&relativePath=publicationLoggedOut&interested=true

Access scientific knowledge from anywhere

https://www.researchgate.net/go.GetApp.html?\_sg=VHrS55hEy\_ylpP1DKxc2Ks9UAkxrYS5wmv-tG97RtMmoZhiBYI6Vd1UxgY4fYjWuD\_aJQ0D5JwlolgH\_tBbJaVZs17FzHFypAW5dk0nvRxA&originCh=bannerStatsCopy&relativePath=publicationLoggedOut&interested=true

Discover by subject area

https://www.researchgate.net/topics

Recruit researchers

https://www.researchgate.net/scientific-recruitment/?utm\_source=researchgate&utm\_medium=community-loggedout&utm\_campaign=indextop

Join for free

https://www.researchgate.net/signup.SignUp.html?hdrsu=1&\_sg%5B0%5D=0pbl\_csqGxTJOgP2CJk5TuUROEWIg8c239rDFuzkdifeZDbsqsZ3jPYUUuZUdvHlJa6Hp\_\_e0km-N4VVunewlYXVlc4

https://www.researchgate.net/

Most researchers use their institutional email address as their ResearchGate login Password

Forgot password?

https://www.researchgate.net/application.LostPassword.html

\[x\] yes Keep me logged in Log in or

Continue with Google

https://www.researchgate.net/connector/google

Welcome back! Please log in. Email · Hint

Most researchers use their institutional email address as their ResearchGate login Password

Forgot password?

https://www.researchgate.net/application.LostPassword.html

\[x\] yes Keep me logged in Log in or

Continue with Google

https://www.researchgate.net/connector/google

No account?

https://www.researchgate.net/signup.SignUp.html?hdrsu=1&\_sg%5B0%5D=0pbl\_csqGxTJOgP2CJk5TuUROEWIg8c239rDFuzkdifeZDbsqsZ3jPYUUuZUdvHlJa6Hp\_\_e0km-N4VVunewlYXVlc4

https://www.researchgate.net/about

https://www.researchgate.net/blog

https://www.researchgate.net/careers

Help Center

https://help.researchgate.net/?utm\_source=researchgate&utm\_medium=community-loggedout&utm\_campaign=new-footer&utm\_content=helpcenter

Business solutions

Advertising

https://www.researchgate.net/marketing-solutions?utm\_source=researchgate&utm\_medium=community-loggedout&utm\_campaign=new-footer&utm\_content=advertising

https://www.researchgate.net/scientific-recruitment?utm\_source=researchgate&utm\_medium=community-loggedout&utm\_campaign=new-footer&utm\_content=recruiting

© 2008-2026 ResearchGate GmbH. All rights reserved.

https://www.researchgate.net/terms-of-service

https://www.researchgate.net/privacy-policy

https://www.researchgate.net/ip-policy

https://www.researchgate.net/imprint

Consent preferences

javascript:Didomi.preferences.show()

