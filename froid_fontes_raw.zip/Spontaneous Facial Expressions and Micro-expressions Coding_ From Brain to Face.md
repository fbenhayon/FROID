---
sourceFile: "Spontaneous Facial Expressions and Micro-expressions Coding: From Brain to Face"
exportedBy: "Kortex"
exportDate: "2026-06-29T01:00:28.706Z"
---

# Spontaneous Facial Expressions and Micro-expressions Coding: From Brain to Face

4e81d1c6-1d64-4e5c-a38d-0162af483cb4

Spontaneous Facial Expressions and Micro-expressions Coding: From Brain to Face

a006f515-4feb-42b9-8bb9-eedbbea5c515

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full

Frontiers | Spontaneous Facial Expressions and Micro-expressions Coding: From Brain to Face

https://www.frontiersin.org/

Frontiers in Psychology

https://www.frontiersin.org/journals/psychology

Mission and values

https://www.frontiersin.org/about/mission

https://www.frontiersin.org/about/history

https://www.frontiersin.org/about/leadership

https://www.frontiersin.org/about/awards

Impact and progress

Frontiers' impact

https://www.frontiersin.org/about/impact

Our annual reports

https://www.frontiersin.org/about/annual-reports

Thought leadership

https://www.frontiersin.org/about/thought-leadership

Publishing model

How we publish

https://www.frontiersin.org/about/how-we-publish

Open access

https://www.frontiersin.org/about/open-access

Peer review

https://www.frontiersin.org/about/peer-review

Research integrity

https://www.frontiersin.org/about/research-integrity

Research Topics

https://www.frontiersin.org/about/research-topics

FAIR² Data Management

https://www.frontiersin.org/about/fair-data-management

https://www.frontiersin.org/about/fee-policy

https://publishingpartnerships.frontiersin.org/

National consortia

https://www.frontiersin.org/open-access-agreements/consortia

Institutional partnerships

https://www.frontiersin.org/about/open-access-agreements

Collaborators

https://www.frontiersin.org/about/collaborators

More from Frontiers

Frontiers Forum

https://forum.frontiersin.org/

Frontiers Planet Prize

https://www.frontiersin.org/about/frontiers-planet-prize

Press office

https://pressoffice.frontiersin.org/

Sustainability

https://www.frontiersin.org/about/sustainability

Career opportunities

https://careers.frontiersin.org/

https://www.frontiersin.org/about/contact

All journals

https://www.frontiersin.org/journals

All articles

https://www.frontiersin.org/articles

Submit your research

https://www.frontiersin.org/submission/submit?domainid=1&fieldid=69&specialtyid=0&entitytype=2&entityid=36

https://www.frontiersin.org/search?tab=top-results&origin=https%3A%2F%2Fwww.frontiersin.org%2Fjournals%2Fpsychology%2Farticles%2F10.3389%2Ffpsyg.2021.784834%2Ffull

https://www.frontiersin.org/people/login?returnUrl=https%3A%2F%2Fwww.frontiersin.org%2Fjournals%2Fpsychology%2Farticles%2F10.3389%2Ffpsyg.2021.784834%2Ffull

https://www.frontiersin.org/

Frontiers in Psychology

https://www.frontiersin.org/journals/psychology

Addictive Behaviors

https://www.frontiersin.org/journals/psychology/sections/addictive-behaviors

Auditory Cognitive Neuroscience

https://www.frontiersin.org/journals/psychology/sections/auditory-cognitive-neuroscience

https://www.frontiersin.org/journals/psychology/sections/cognition

Cognitive Science

https://www.frontiersin.org/journals/psychology/sections/cognitive-science

Comparative Psychology

https://www.frontiersin.org/journals/psychology/sections/comparative-psychology

Consciousness Research and Mindfulness

https://www.frontiersin.org/journals/psychology/sections/consciousness-research-and-mindfulness

Cultural Psychology

https://www.frontiersin.org/journals/psychology/sections/cultural-psychology

Decision Neuroscience

https://www.frontiersin.org/journals/psychology/sections/decision-neuroscience

Eating Behavior

https://www.frontiersin.org/journals/psychology/sections/eating-behavior

Educational Psychology

https://www.frontiersin.org/journals/psychology/sections/educational-psychology

Emotion Science

https://www.frontiersin.org/journals/psychology/sections/emotion-science

Environmental Psychology

https://www.frontiersin.org/journals/psychology/sections/environmental-psychology

Evolutionary Psychology

https://www.frontiersin.org/journals/psychology/sections/evolutionary-psychology

Forensic and Legal Psychology

https://www.frontiersin.org/journals/psychology/sections/forensic-and-legal-psychology

Health Psychology

https://www.frontiersin.org/journals/psychology/sections/health-psychology

Human Developmental Psychology

https://www.frontiersin.org/journals/psychology/sections/human-developmental-psychology

Media Psychology

https://www.frontiersin.org/journals/psychology/sections/media-psychology

Movement Science

https://www.frontiersin.org/journals/psychology/sections/movement-science

Neuropsychology

https://www.frontiersin.org/journals/psychology/sections/neuropsychology

Organizational Psychology

https://www.frontiersin.org/journals/psychology/sections/organizational-psychology

Pediatric Psychology

https://www.frontiersin.org/journals/psychology/sections/pediatric-psychology

Perception Science

https://www.frontiersin.org/journals/psychology/sections/perception-science

Performance Science

https://www.frontiersin.org/journals/psychology/sections/performance-science

Personality and Social Psychology

https://www.frontiersin.org/journals/psychology/sections/personality-and-social-psychology

Positive Psychology

https://www.frontiersin.org/journals/psychology/sections/positive-psychology

Psycho-Oncology

https://www.frontiersin.org/journals/psychology/sections/psycho-oncology

Psychology for Clinical Settings

https://www.frontiersin.org/journals/psychology/sections/psychology-for-clinical-settings

Psychology of Aging

https://www.frontiersin.org/journals/psychology/sections/psychology-of-aging

Psychology of Language

https://www.frontiersin.org/journals/psychology/sections/psychology-of-language

Psychopathology

https://www.frontiersin.org/journals/psychology/sections/psychopathology

Quantitative Psychology and Measurement

https://www.frontiersin.org/journals/psychology/sections/quantitative-psychology-and-measurement

Sport Psychology

https://www.frontiersin.org/journals/psychology/sections/sport-psychology

Theoretical and Philosophical Psychology

https://www.frontiersin.org/journals/psychology/sections/theoretical-and-philosophical-psychology

https://www.frontiersin.org/journals/psychology/articles

Research Topics

https://www.frontiersin.org/journals/psychology/research-topics

Editorial board

https://www.frontiersin.org/journals/psychology/editors

About journal

About journal

Field chief editors

https://www.frontiersin.org/journals/psychology/about#about-editors

Mission & scope

https://www.frontiersin.org/journals/psychology/about#about-scope

https://www.frontiersin.org/journals/psychology/about#about-facts

Journal sections

https://www.frontiersin.org/journals/psychology/about#about-submission

Open access statement

https://www.frontiersin.org/journals/psychology/about#about-open

Copyright statement

https://www.frontiersin.org/journals/psychology/about#copyright-statement

https://www.frontiersin.org/journals/psychology/about#about-quality

For authors

Why submit?

https://www.frontiersin.org/journals/psychology/for-authors/why-submit

Article types

https://www.frontiersin.org/journals/psychology/for-authors/article-types

Author guidelines

https://www.frontiersin.org/journals/psychology/for-authors/author-guidelines

Editor guidelines

https://www.frontiersin.org/journals/psychology/for-authors/editor-guidelines

Publishing fees

https://www.frontiersin.org/journals/psychology/for-authors/publishing-fees

Submission checklist

https://www.frontiersin.org/journals/psychology/for-authors/submission-checklist

Contact editorial office

https://www.frontiersin.org/journals/psychology/for-authors/contact-editorial-office

Mission and values

https://www.frontiersin.org/about/mission

https://www.frontiersin.org/about/history

https://www.frontiersin.org/about/leadership

https://www.frontiersin.org/about/awards

Impact and progress

Frontiers' impact

https://www.frontiersin.org/about/impact

Our annual reports

https://www.frontiersin.org/about/annual-reports

Thought leadership

https://www.frontiersin.org/about/thought-leadership

Publishing model

How we publish

https://www.frontiersin.org/about/how-we-publish

Open access

https://www.frontiersin.org/about/open-access

Peer review

https://www.frontiersin.org/about/peer-review

Research integrity

https://www.frontiersin.org/about/research-integrity

Research Topics

https://www.frontiersin.org/about/research-topics

FAIR² Data Management

https://www.frontiersin.org/about/fair-data-management

https://www.frontiersin.org/about/fee-policy

https://publishingpartnerships.frontiersin.org/

National consortia

https://www.frontiersin.org/open-access-agreements/consortia

Institutional partnerships

https://www.frontiersin.org/about/open-access-agreements

Collaborators

https://www.frontiersin.org/about/collaborators

More from Frontiers

Frontiers Forum

https://forum.frontiersin.org/

Frontiers Planet Prize

https://www.frontiersin.org/about/frontiers-planet-prize

Press office

https://pressoffice.frontiersin.org/

Sustainability

https://www.frontiersin.org/about/sustainability

Career opportunities

https://careers.frontiersin.org/

https://www.frontiersin.org/about/contact

All journals

https://www.frontiersin.org/journals

All articles

https://www.frontiersin.org/articles

Submit your research

https://www.frontiersin.org/submission/submit?domainid=1&fieldid=69&specialtyid=0&entitytype=2&entityid=36

Frontiers in Psychology

https://www.frontiersin.org/journals/psychology

Addictive Behaviors

https://www.frontiersin.org/journals/psychology/sections/addictive-behaviors

Auditory Cognitive Neuroscience

https://www.frontiersin.org/journals/psychology/sections/auditory-cognitive-neuroscience

https://www.frontiersin.org/journals/psychology/sections/cognition

Cognitive Science

https://www.frontiersin.org/journals/psychology/sections/cognitive-science

Comparative Psychology

https://www.frontiersin.org/journals/psychology/sections/comparative-psychology

Consciousness Research and Mindfulness

https://www.frontiersin.org/journals/psychology/sections/consciousness-research-and-mindfulness

Cultural Psychology

https://www.frontiersin.org/journals/psychology/sections/cultural-psychology

Decision Neuroscience

https://www.frontiersin.org/journals/psychology/sections/decision-neuroscience

Eating Behavior

https://www.frontiersin.org/journals/psychology/sections/eating-behavior

Educational Psychology

https://www.frontiersin.org/journals/psychology/sections/educational-psychology

Emotion Science

https://www.frontiersin.org/journals/psychology/sections/emotion-science

Environmental Psychology

https://www.frontiersin.org/journals/psychology/sections/environmental-psychology

Evolutionary Psychology

https://www.frontiersin.org/journals/psychology/sections/evolutionary-psychology

Forensic and Legal Psychology

https://www.frontiersin.org/journals/psychology/sections/forensic-and-legal-psychology

Health Psychology

https://www.frontiersin.org/journals/psychology/sections/health-psychology

Human Developmental Psychology

https://www.frontiersin.org/journals/psychology/sections/human-developmental-psychology

Media Psychology

https://www.frontiersin.org/journals/psychology/sections/media-psychology

Movement Science

https://www.frontiersin.org/journals/psychology/sections/movement-science

Neuropsychology

https://www.frontiersin.org/journals/psychology/sections/neuropsychology

Organizational Psychology

https://www.frontiersin.org/journals/psychology/sections/organizational-psychology

Pediatric Psychology

https://www.frontiersin.org/journals/psychology/sections/pediatric-psychology

Perception Science

https://www.frontiersin.org/journals/psychology/sections/perception-science

Performance Science

https://www.frontiersin.org/journals/psychology/sections/performance-science

Personality and Social Psychology

https://www.frontiersin.org/journals/psychology/sections/personality-and-social-psychology

Positive Psychology

https://www.frontiersin.org/journals/psychology/sections/positive-psychology

Psycho-Oncology

https://www.frontiersin.org/journals/psychology/sections/psycho-oncology

Psychology for Clinical Settings

https://www.frontiersin.org/journals/psychology/sections/psychology-for-clinical-settings

Psychology of Aging

https://www.frontiersin.org/journals/psychology/sections/psychology-of-aging

Psychology of Language

https://www.frontiersin.org/journals/psychology/sections/psychology-of-language

Psychopathology

https://www.frontiersin.org/journals/psychology/sections/psychopathology

Quantitative Psychology and Measurement

https://www.frontiersin.org/journals/psychology/sections/quantitative-psychology-and-measurement

Sport Psychology

https://www.frontiersin.org/journals/psychology/sections/sport-psychology

Theoretical and Philosophical Psychology

https://www.frontiersin.org/journals/psychology/sections/theoretical-and-philosophical-psychology

https://www.frontiersin.org/journals/psychology/articles

Research Topics

https://www.frontiersin.org/journals/psychology/research-topics

Editorial board

https://www.frontiersin.org/journals/psychology/editors

About journal

About journal

Field chief editors

https://www.frontiersin.org/journals/psychology/about#about-editors

Mission & scope

https://www.frontiersin.org/journals/psychology/about#about-scope

https://www.frontiersin.org/journals/psychology/about#about-facts

Journal sections

https://www.frontiersin.org/journals/psychology/about#about-submission

Open access statement

https://www.frontiersin.org/journals/psychology/about#about-open

Copyright statement

https://www.frontiersin.org/journals/psychology/about#copyright-statement

https://www.frontiersin.org/journals/psychology/about#about-quality

For authors

Why submit?

https://www.frontiersin.org/journals/psychology/for-authors/why-submit

Article types

https://www.frontiersin.org/journals/psychology/for-authors/article-types

Author guidelines

https://www.frontiersin.org/journals/psychology/for-authors/author-guidelines

Editor guidelines

https://www.frontiersin.org/journals/psychology/for-authors/editor-guidelines

Publishing fees

https://www.frontiersin.org/journals/psychology/for-authors/publishing-fees

Submission checklist

https://www.frontiersin.org/journals/psychology/for-authors/submission-checklist

Contact editorial office

https://www.frontiersin.org/journals/psychology/for-authors/contact-editorial-office

https://www.frontiersin.org/

Frontiers in Psychology

https://www.frontiersin.org/journals/psychology

Addictive Behaviors

https://www.frontiersin.org/journals/psychology/sections/addictive-behaviors

Auditory Cognitive Neuroscience

https://www.frontiersin.org/journals/psychology/sections/auditory-cognitive-neuroscience

https://www.frontiersin.org/journals/psychology/sections/cognition

Cognitive Science

https://www.frontiersin.org/journals/psychology/sections/cognitive-science

Comparative Psychology

https://www.frontiersin.org/journals/psychology/sections/comparative-psychology

Consciousness Research and Mindfulness

https://www.frontiersin.org/journals/psychology/sections/consciousness-research-and-mindfulness

Cultural Psychology

https://www.frontiersin.org/journals/psychology/sections/cultural-psychology

Decision Neuroscience

https://www.frontiersin.org/journals/psychology/sections/decision-neuroscience

Eating Behavior

https://www.frontiersin.org/journals/psychology/sections/eating-behavior

Educational Psychology

https://www.frontiersin.org/journals/psychology/sections/educational-psychology

Emotion Science

https://www.frontiersin.org/journals/psychology/sections/emotion-science

Environmental Psychology

https://www.frontiersin.org/journals/psychology/sections/environmental-psychology

Evolutionary Psychology

https://www.frontiersin.org/journals/psychology/sections/evolutionary-psychology

Forensic and Legal Psychology

https://www.frontiersin.org/journals/psychology/sections/forensic-and-legal-psychology

Health Psychology

https://www.frontiersin.org/journals/psychology/sections/health-psychology

Human Developmental Psychology

https://www.frontiersin.org/journals/psychology/sections/human-developmental-psychology

Media Psychology

https://www.frontiersin.org/journals/psychology/sections/media-psychology

Movement Science

https://www.frontiersin.org/journals/psychology/sections/movement-science

Neuropsychology

https://www.frontiersin.org/journals/psychology/sections/neuropsychology

Organizational Psychology

https://www.frontiersin.org/journals/psychology/sections/organizational-psychology

Pediatric Psychology

https://www.frontiersin.org/journals/psychology/sections/pediatric-psychology

Perception Science

https://www.frontiersin.org/journals/psychology/sections/perception-science

Performance Science

https://www.frontiersin.org/journals/psychology/sections/performance-science

Personality and Social Psychology

https://www.frontiersin.org/journals/psychology/sections/personality-and-social-psychology

Positive Psychology

https://www.frontiersin.org/journals/psychology/sections/positive-psychology

Psycho-Oncology

https://www.frontiersin.org/journals/psychology/sections/psycho-oncology

Psychology for Clinical Settings

https://www.frontiersin.org/journals/psychology/sections/psychology-for-clinical-settings

Psychology of Aging

https://www.frontiersin.org/journals/psychology/sections/psychology-of-aging

Psychology of Language

https://www.frontiersin.org/journals/psychology/sections/psychology-of-language

Psychopathology

https://www.frontiersin.org/journals/psychology/sections/psychopathology

Quantitative Psychology and Measurement

https://www.frontiersin.org/journals/psychology/sections/quantitative-psychology-and-measurement

Sport Psychology

https://www.frontiersin.org/journals/psychology/sections/sport-psychology

Theoretical and Philosophical Psychology

https://www.frontiersin.org/journals/psychology/sections/theoretical-and-philosophical-psychology

https://www.frontiersin.org/journals/psychology/articles

Research Topics

https://www.frontiersin.org/journals/psychology/research-topics

Editorial board

https://www.frontiersin.org/journals/psychology/editors

About journal

About journal

Field chief editors

https://www.frontiersin.org/journals/psychology/about#about-editors

Mission & scope

https://www.frontiersin.org/journals/psychology/about#about-scope

https://www.frontiersin.org/journals/psychology/about#about-facts

Journal sections

https://www.frontiersin.org/journals/psychology/about#about-submission

Open access statement

https://www.frontiersin.org/journals/psychology/about#about-open

Copyright statement

https://www.frontiersin.org/journals/psychology/about#copyright-statement

https://www.frontiersin.org/journals/psychology/about#about-quality

For authors

Why submit?

https://www.frontiersin.org/journals/psychology/for-authors/why-submit

Article types

https://www.frontiersin.org/journals/psychology/for-authors/article-types

Author guidelines

https://www.frontiersin.org/journals/psychology/for-authors/author-guidelines

Editor guidelines

https://www.frontiersin.org/journals/psychology/for-authors/editor-guidelines

Publishing fees

https://www.frontiersin.org/journals/psychology/for-authors/publishing-fees

Submission checklist

https://www.frontiersin.org/journals/psychology/for-authors/submission-checklist

Contact editorial office

https://www.frontiersin.org/journals/psychology/for-authors/contact-editorial-office

Submit your research

https://www.frontiersin.org/submission/submit?domainid=1&fieldid=69&specialtyid=0&entitytype=2&entityid=36

https://www.frontiersin.org/search?tab=top-results&origin=https%3A%2F%2Fwww.frontiersin.org%2Fjournals%2Fpsychology%2Farticles%2F10.3389%2Ffpsyg.2021.784834%2Ffull

https://www.frontiersin.org/people/login?returnUrl=https%3A%2F%2Fwww.frontiersin.org%2Fjournals%2Fpsychology%2Farticles%2F10.3389%2Ffpsyg.2021.784834%2Ffull

ORIGINAL RESEARCH article

Front. Psychol., 03 January 2022

Sec. Human-Media Interaction

Volume 12 - 2021 |

https://doi.org/10.3389/fpsyg.2021.784834

https://doi.org/10.3389/fpsyg.2021.784834

ORIGINAL RESEARCH article

Front. Psychol., 03 January 2022

Sec. Human-Media Interaction

Volume 12 - 2021 |

https://doi.org/10.3389/fpsyg.2021.784834

https://doi.org/10.3389/fpsyg.2021.784834

Spontaneous Facial Expressions and Micro-expressions Coding: From Brain to Face

Z D Zizhao Dong

G W Gang Wang

S L Shaoyuan Lu 1,3

https://loop.frontiersin.org/people/1276313

J L Jingting Li 1

https://loop.frontiersin.org/people/1489358

W Y Wenjing Yan 4

https://loop.frontiersin.org/people/1165489

S W Su-Jing Wang 1,3 \*

https://loop.frontiersin.org/people/1460208

Key Laboratory of Behavioral Science, Institute of Psychology, Chinese Academy of Sciences, Beijing, China

School of Computer Science, Jiangsu University of Science and Technology, Zhenjiang, China

Department of Psychology, University of the Chinese Academy of Sciences, Beijing, China

Department of Applied Psychology, College of Teacher Education, Wenzhou University, Zhejiang, China

Article metrics

View details

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full#metrics

Facial expressions are a vital way for humans to show their perceived emotions. It is convenient for detecting and recognizing expressions or micro-expressions by annotating a lot of data in deep learning. However, the study of video-based expressions or micro-expressions requires that coders have professional knowledge and be familiar with action unit (AU) coding, leading to considerable difficulties. This paper aims to alleviate this situation. We deconstruct facial muscle movements from the motor cortex and systematically sort out the relationship among facial muscles, AU, and emotion to make more people understand coding from the basic principles:

We derived the relationship between AU and emotion based on a data-driven analysis of 5,000 images from the RAF-AU database, along with the experience of professional coders.

We discussed the complex facial motor cortical network system that generates facial movement properties, detailing the facial nucleus and the motor system associated with facial expressions.

The supporting physiological theory for AU labeling of emotions is obtained by adding facial muscle movements patterns.

We present the detailed process of emotion labeling and the detection and recognition of AU.

Based on the above research, the video's coding of spontaneous expressions and micro-expressions is concluded and prospected.

1. Introduction

Emotions are the experience of a person's attitude toward the satisfaction of objective things and are critical to an individual's mental health and social behavior. Emotions consist of three components: subjective experience, external performance, and physiological arousal. The external performance of emotions is often reflected by facial expression, which is an important tool for expressing and recognizing emotions (Ekman,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full#B14

). Expressing and recognizing facial expressions are crucial skills for human social interaction. It has been demonstrated by much research that inferences of emotion fromfacial expressions are based on facial movement cues, i.e., muscle movements of the face (Wehrle et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full#B43

Based on the knowledge of facial muscle movements, researchers usually described facial muscle movement objectively by creating facial coding systems, including Facial Action Coding System (FACS) (Friesen and Ekman,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full#B18

), Face Animation Parameters (Pandzic and Forchheimer,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full#B34

), Maximally Discriminative Facial Movement Coding System (Izard and Weiss,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full#B22

), Monadic Phases Coding System (Izard et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full#B21

), and The Facial Expression Coding System (Kring and Sloan,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full#B25

). Depending upon the instantaneous changes in facial appearance produced by muscle activity, majority of these facial coding systems divide facial expressions into different action units (AUs), which can be used to perform quantitative analysis on facial expressions.

In addition to facial expression research based on psychology and physiology, artificial intelligence plays a vital role in affective computing. Notably, in recent years, with the rapid development of computer science and technology, the deep learning methods begin to be widely adopted to detect and recognize automatically by facial action units and makes automatic expression recognition possible in practical applications, including the field of security (Ji et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full#B24

), clinical (Lucey et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full#B29

), etc. The boom in expression recognition is attributed to many labeled expression datasets. For example, EmotioNet has a sample size of 950,000 (Fabian Benitez-Quiroz et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full#B17

), which is large enough to fit the tens of millions of learned parameters in deep learning networks. The AU and emotion labels are the foundation for training the supervised deep learning networks and evaluating the algorithm performances. In addition, many algorithms are developed based on AU because of its importance (Niu et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full#B33

; Wang et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full#B42

However, the researchers found that ordinary facial expressions, i.e., macro-expressions, can not reflect a person's true emotions all the time. By contrast, the emergence of micro-expression has been considered as a significant clue to reveal the real emotion of humans. Studies have demonstrated that people would show micro-expressions in high-risk situations when they try to hide or suppress their genuine subjective feelings (Ekman and Rosenberg,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full#B16

). Micro-expressions are brief, subtle, and involuntary facial expressions. Unlike macro-expression, micro-expression lasts only 1/25–1/5 s (Yan et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full#B46

Micro-expression spotting and recognition have played a vital role in defense, suicide intervention, and criminal investigation. The AU-based study has also contributed to micro-expressions analysis. For instance, Davison et al. (

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full#B8

) created an objective micro-expression classification system based on AU combinations; Xie et al. (

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full#B44

) proposed an AU-assisted graph attention convolutional network for micro-expression recognition. Micro-expression has the characteristics of short duration and subtle movement amplitude, which causes that the manual annotation of ME videos requires the data processing personnel to view the video sample frame by frame slowly and attentively. Accordingly, long working hours increase the risk of errors. Furthermore, the current sample size of micro-expressions is still relatively small due to the difficulty of elicitation and annotation.

The prevailing annotation method is to annotate the AU according to the FACS proposed by Ekman et al. (Friesen and Ekman,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full#B18

). FACS is the most widely used face coding system, and the manual is over 500 pages long. The manual covers Ekman's detailed explanation of each AU and its meaning, providing schematics and possible combinations of AUs. However, when AU is regarded as one of the criteria for classifying facial expressions (macro-expressions and micro-expressions), a FACS-certified expert is generally required to perform the annotation. The lengthy manual and the certification process have raised the barrier for AU coders.

Therefore, this paper focuses on macro-expression or micro-expression that responds to genuine emotions and analyzes the relationship between the cerebral cortex, which controls facial muscle movements, facial muscles, action units, and expressions. We theoretically deconstruct AU coding based on these analyses, systematically highlight the specific regions for each emotion. Finally, we provide an annotation framework for the annotator to facilitate the AU coding, expression labeling, and emotion classification.

This paper is an extended version of our ACM International Conference on Multimedia(ACM MM) paper (Zizhao et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full#B47

), in which we make a brief guide to coding for spontaneous expressions and micro-expressions in video, and make the beginner to code get started as quickly as possible. In this paper, We discuss in further detail the principles of facial muscle movement from the brain to the face. Specifically, we show the cortical network system of facial muscle movement, introduce the neural pathways of the facial nucleus that control facial muscles, and the influence of other motor systems on the motor properties of the face. Secondly, we explain the relationship between AU and the six basic emotions with a physiological explanation. Finally, the coding of spontaneous expressions and micro-expressions is summarized in emotion label and AU detection and recognition research.

The following of this article is organized as follows: section 2 introduces the relationship between AU and emotions through the analysis of 5,000 images in RAF-AU database; section 3 demonstrates the nervous system of facial muscle movement; section 4 describes the muscles groups targeting the facial expression; section 5 exhibits the process of emotion labeling; section 6 shows detection and recognition research of AU; section 7 presents our conclusion and perspective on coding for spontaneous expressions and micro-expressions in videos.

2. Action Units and Emotions

Human muscle movements are innervated by nerves, and the majority of facial muscle movements are controlled by the seventh nerve in the brain, the facial nerve (Cranial Nerve VII, CN VII). The CN VII is divided into five branches, including the

marginal mandibular

branch (Drake et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full#B12

). These branches are illustrated in the upper part of

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full#F1

An overview of relationships of facial muscle, AU and emotion based on facial nerve (Zizhao et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full#B47

branch of the CN VII is located in the upper and anterior part of the auricle and innervates the

frontalis, corrugator supercilii, depressor supercilii, orbicularis oculi

branch of the CN VII begins at the

zygomatic bone

and ends at the lateral orbital angle, innervates the

orbicularis oculi

zygomaticus

branch of the CN VII is located in the inferior box area and around the mouth and innervates the

Buccinator, orbicularis oris

and other orbicularis muscles. The

marginal mandibular

branch of the CN VII is distributed along the lower edge of the mandible and ends in the descending

depressor anguli oris

, which innervates the lower lip and chin muscles. The

branch of the CN VII is distributed in the cervical region and innervates the

All facial muscles are controlled by one or two terminal motor branches of the CN VII, as shown in

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full#F1

. One or more muscle movements can constitute AUs, and different combinations of AUs show a variety of expressions, which ultimately reflect human emotions. Therefore, it is a complex process from muscle movements to emotions. We conclude the relationship between AU and emotion based on the images in the RAF-AU database (Yan et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full#B45

) and the experience of professional coders.

## The Data-Driven Relationship Between AU and Emotion

All the data, nearly 5,000 images used to analyze, are from RAF-AU (Yan et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full#B45

). The database consists of face images collected from social networks with varying covering, brightness, resolution, and annotated through human crowdsourcing. Six basic emotions and one neutral emotion were used in the samples. Crowdsourced annotation is a method, which may help sag facial expressions in a natural setting by allowing many observers to tag a target heuristically. Finally, the probability score that the picture belongs to a specific emotion is calculated. The database contains about 200,000 facial expressions labeling because that about 40 independent observers tagged each image. It should be noted that although the source image materials are diverse, the judging group of raters is relatively narrow because the taggers are all students.

The corresponding annotation contains both the expert's AU labels and the emotion score obtained from the crowdsourcer's label statistics for each image. We analyzed only the contribution of AUs to the six basic emotions with two methods. One method is to take the highest score as the emotion of the image and then combine it with the labeled AU. In this method, repeated combinations must be removed to avoid the effect on the results due to the predominance of one sample type, i.e., to mitigate the effect of sample imbalance. Another is to count the weighted sum of the contributions of all AUs to the six emotions without removing repetitions. The pseudocode details of these two methods are shown in Algorithms 1 and 2.

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full#T1

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full#T2

list the Top 10 AUs contributing to the six basic emotions, respectively. From

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full#T1

, it can be seen that the contribution of AU25 is very high in the six basic emotions, which makes no sense because the movement of opening the corners of the mouth in AU25 is caused by the relaxation of the lower lip muscles, the relaxation of the genital muscles, and the orbicularis oris muscle. According to our subjective perception, AU25 rarely appears when we have three emotions: happiness, sadness, and anger. The abnormal top statistical data in

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full#T1

may be caused by the shortcomings of crowdsourced annotations, i.e., the subjective tendency or random labeling of some individuals.

Algorithm 1

1: Initialization: AU's contribution array to emotions

: Max AU number,

: Number of samples,

5: Split the AU combination into a single AU set

6: Take the maximum score of the six emotions as the emotion of the sample, defined as

the combination of AU and emotion

first appears

8: Add the emotion score of the sample to the emotion AU

11: Calculate the proportion of AU in each emotion

in descending order

Contribution array

Algorithm 2

1: Initialization: AU's contribution array to emotions

: Max AU number,

: Number of samples,

5: Split the AU combination into a single AU set

6: Add the score of each emotion in the sample to

in descending order

Contribution array

Top 10 of AU's contribution to the six basic emotions (Method 1).

Top 10 of AU's contribution to the six basic emotions (Method 2).

However, there is room for improvement in the results obtained through the above data-driven approaches. The data-driven results can be affected by many aspects. Primarily, by the data source, such as the possible homogeneity of the RAF-AU database (number of subjects, gender, race, age, etc.), the uneven distribution of the samples, and the subjective labels based on human perception resulting from crowdsourcing annotation. Furthermore, the analysis method we used is based on a maximum value and probability weighting. Although straightforward, such analytical approaches represent the contribution of AU to the six basic emotions, are less comprehensive. More analysing methods are also needed in dealing with unbalanced data. In response to the challenges posed by data and analytical methods to data-driven methods, we could combine data-driven and experience-driven research methods. In this way, we could draw on the objectivity of data-driven and the robustness of experience-driven to realize the construction of the AU coding system for macro-expressions/micro-expressions.

## The Experience-Driven Relationship Between AU and Emotion

There usually exists difficulties for the data-driven methods to analyze with theoretic basis. For example, the typical “black box” characteristic brings the problem of poor interpretability. Meanwhile, the results by data-driven are highly dependent on the quality (noiseless) and quantity (wide and massive) of the database. By comparison, the experience-driven method, based on the knowledge of coding and the common sense, is a way to label emotion. Three advantages are listed below: (1) The experience-driven method can help reduce the noise by using coding and common sense knowledge. (2) Experience-driven method has a reliable theory as a support, making the results convincing. (3) Experience-driven can often solve most universal laws with just a few simple formulas. Therefore, we combine experience-driven and data-driven methods to get the final AU and emotional relationship summary table, as shown in

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full#T3

, by using their respective advantages.

, 14, 26, 27,

, 5, 25, 26, 27

4, 5, 9, 10,

, 9, 10, 14, 15, 17,

1, 4, 14, 15, 17,

The relationship between AU and emotion.

The bolded AU in the table indicates that the AU is only associated with the corresponding specific emotion, and not with other emotions

Specifically, firstly, based on the analysis results listed in

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full#T1

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full#T2

(data-driven), the preliminary selection is made by comparing the description and legend of each AU in FACS, and combining with the meaning of emotion. We obtained a preliminary AU system for emotion. Then, with large amounts of facial expression images on search engines such as Google and Baidu, the preliminary AU system for emotion was screened by eliminating non-compliant AU in these images. In this way, the ultimate relationship is shown in

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full#F1

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full#T3

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full#T3

, we assume that the sets of six basic emotions containing AU are

Q i= S i\ ⋂ j S j Q i = S i \ ⋂ j S j

= 1, ..., 6, and

+1, ..., 6}. ⋂ is the intersection operation of the set. \ represents the set of symmetric difference, for example, we assume that

= {3, 9, 14},

= {1, 2, 3}, then

denotes the AU set that is exclusive to the

According to

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full#T3

, we can infer that the bloded AU is only associated with the corresponding specific emotion, and not with other emotions. See

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full#T3

in bold for details. Therefore, we can conclude that the appearance of certain AU represents related emotion. For instance, if AU20 appears, we assume that fearful emotion emerges.

3. Complex Cortical Networks of Facial Movement

The facial motor system is a complex network of specialized cortical areas dependent on multiple parallel systems, voluntary/involuntary motor systems, emotional systems, visual systems, etc., all of which are anatomically and functionally distinct and all of which ultimately reach the facial nucleus to govern facial movements (Cattaneo and Pavesi,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full#B5

). The nerve that emanates from the facial nucleus is the facial nerve. The facial nerve originates in the brainstem, and its pathway is commonly divided into three parts: intra-cranial, intra-temporal, and extra-cranial (see

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full#F2

Motor neurons from the brain to the muscle.

## Facial Nucleus Controls Facial Movements

The human facial motor nucleus is the largest of all motor nuclei in the brainstem. It is divided into two parts: upper and lower. The upper part is innervated by the motor areas of the cerebral cortex bilaterally and sends motor fibers to innervate the muscles of the ipsilateral upper face; the lower part of the nucleus is innervated by the contralateral cerebral cortex only and sends motor fibers to innervate the muscles of the ipsilateral lower face. It contains around 10,000 neurons and consists mainly of the cell bodies of motor neurons (Sherwood,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full#B39

A large number of neurons in the facial nucleus provides the anatomical basis for the various reflex responses of the facial muscles to different sensory modalities. For example, in the classic study by Penfield and Boldrey, it was found that the sensation of facial movement and the urge/desire to move the face was elicited by electrical stimulation of the cerebral cortex, causing movement of different parts of the face, as well as occurring in the absence of movement. Movements of the eyebrows and forehead were less frequent than those of the eyelids, and movements of the lips were the most frequent (Penfield and Boldrey,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full#B36

Another way to assess the mechanism of inhibition within the cerebral cortex is to study the cortical resting period of transcranial magnetic stimulation. The cortical resting period is a period of inactivity called the silent period, when spontaneous muscle contraction is followed by a pause in myoelectric activity after the generation of motor evoked potentials by transcranial magnetic stimulation in the corresponding functional areas of the cerebral cortex. Studies on facial muscle movements have found that the silent period occurs after motor-evoked potentials in the pre-activated lower facial muscles (Curra et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full#B6

), (Paradiso et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full#B35

## Cortical Systems Controls Facial Movement

The earliest studies on facial expressions date back to the nineteenth century. For example, the French neurophysiologist Duchenne de Boulogne (1806–1875) used electrical stimulation to study facial muscle activity (Duchenne,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full#B13

). He used this experimental method to define for the first time expressions in different emotional states, including attention, relaxation, aggression, pain, happiness, sadness, cry, surprise, and fear, showing that each emotional state is expressed with specific facial muscle activity. Also, Duensing observed that there might be different neural structures involved between involuntary and emotional facial movements. Duensing's theory also influenced Charles Darwin's book

The expression of the emotions in man and animals

(1872) (Darwin,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full#B7

Meanwhile, facial movements depend on multiple parallel systems that ultimately all reach the facial nucleus to govern facial movements. We focus on facial movements of expressions or micro-expressions, and two systems related to them have been discussed here: the voluntary/involuntary motor system and the emotional system.

### The Somatic Motor System

According to the form of movement of skeletal muscles, body movements are divided into voluntary and involuntary movements. Voluntary movements are emitted from the cortical centers of the brain and are movements executed according to one's consciousness, characterized by sensation followed by movement; involuntary movements are spontaneous movements that are not controlled by consciousness, such as chills. Meanwhile, the neuroanatomical distinction between voluntary and involuntary expressions has been established in clinical neurology (Matsumoto and Lee,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full#B30

). Voluntary expressions are thought to emanate from the cortical motor tract and enter the facial nucleus through the pyramidal tract; involuntary expressions originate from innervation along the external pyramidal tract. See

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full#F3

The somatic motor system. Voluntary and involuntary expressions are controlled by the pyramidal tract (orange trajectory) and extrapyramidal tract (green trajectory), respectively.

Most facial muscles are overlapping, rarely contracting individually, and usually being brought together in synergy. In particular, these synergistic movements always occur during voluntary movements. For example, the

orbicularis oculi

zygomaticus

have a synergistic effect during the voluntary closure of the eyelid. In contrast, asymmetric movements of the face are usually thought to be the result of facial nerve palsy or involuntary movements (Devoize,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full#B10

), for example, simultaneous contraction of the ipsilateral

orbicularis oculi

, i.e., raising the eyebrows and closing the eyes at the same time. Babinski, a professor of neurology, considers that combined movements such as these cannot be activated by central mechanisms and cannot be replicated by volition. Therefore, facial asymmetry is always considered to be one of the characteristics of micro-expressions.

### The Emotional Motor Systems

Facial expressions are stereotyped physiological responses to specific emotional states, controlled by the voluntary and somatic systems controlled by the emotion-motor system (Holstege,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full#B20

). Expression is only one of the somatic motor components of emotion, which also includes body posture and voice changes. However, in humans, facial expressions are external manifestations of emotions and are an essential part of human non-verbal communication (Müri,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full#B31

), and a significant factor in the cognitive process of emotion. The emotion-motor pathway originates in the gray matter around the amygdaloid nucleus, lateral hypothalamus, and striatum. Most of these gray matter projects, in turn to the reticular formation to control facial premotor neurons, and a few project to facial motor neurons to control facial muscles directly.

In the study of traumatic facial palsy, a separation between the emotional motor system and the voluntary motor system at the brainstem level was found between facial movements (Bouras et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full#B2

). It indicates that these two systems are entirely independent before the facial nucleus. This could be the reason why it is not possible to generate true emotional expression through volition. Therefore, emotion elicitation is required to produce behavioral (expression/micro-expression) responses through stimuli that induce emotion of the subject. It is relatively such expressions that have emotional significance. Moreover, there is also a strong correlation between the different activity patterns among facial muscles and the emotional valence of external stimuli (Dimberg,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full#B11

). Similarly, the emotional motor system and the voluntary motor system interact and confront each other, and the results of this interaction are usually non-motor (e.g., motor dissonance) (Bentsianov and Blitzer,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full#B1

Similar to the involuntary motor system, there is a small degree of asymmetry in the facial movements produced by the emotional motor system. However, the conclusions of this asymmetry are controversial. Many studies in brain-injured, emotionally disturbed, or normal subjects have shown that the majority of emotion expression, recognition, and related behavioral control is in the right hemisphere; that the right hemisphere dominates in the production of basic emotions, i.e., happiness and sadness, and the left hemisphere dominates in the production of socially conforming emotions, i.e., jealousy and complacency; and that the right hemisphere specializes in negative emotions while the left hemisphere specializes in positive emotions (Silberman and Weingartner,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full#B40

4. The Specificity of the Relationship Between Facial Muscle and Emotions

According to

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full#F1

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full#T3

, we make further analysis of facial muscle and emotions to guarantee that each emotion can be targeted at a specific AU.

## The Muscle That Classifies Positive and Negative Emotions

The basic dimensions for emotions are the two main categories, positive and negative emotions. Positive emotions are associated with the satisfaction of demand and are usually accompanied by a pleasurable subjective experience, which can enhance motivation and activity. By comparison, negative emotions represent a negative or aversive emotion such as sadness, disgust, etc., by an individual. The

zygomaticus

is controlled by the

branch of the CN VII. The

branch of the CN VII begins at the

zygomatic bone

and ends at the lateral orbital angle, innervates the

orbicularis oculi

zygomaticus

zygomaticus

includes the

zygomaticus major

zygomaticus minor

zygomaticus major

begins in the

zygomatic bone

, and ends at the

angulus oris

. The responsibility of

zygomaticus

is to pull the corners of the mouth back or up to smile. The

zygomaticus minor

begins in the lateral profile of

zygomatic bone

, and ends at the

angulus oris

. The function is to raise the upper lip, such as grinning.

corrugator supercilii

begins in the medial end of the arch of the eyebrow and ends at the skin of the eyebrow, which is located at the

orbicularis oculi

muscles back. It is innervated by the

branch of the CN VII. The contraction of

corrugator supercilii

depresses the brow and generates a vertical frown.

It has been found that the

corrugator supercilii

induced by unpleasant stimuli is more intense than that induced by pleasant stimuli, and the

zygomaticus

is more intense by pleasant stimuli (Brown and Schwartz,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full#B3

). In a word, pleasant stimuli usually lead to greater electromyography(EMG) activity in the

zygomaticus

, whereas unpleasant stimuli lead to greater EMG activity in the frowning muscle (Larsen et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full#B27

In the AU encoding process,

zygomaticus

activity and

corrugator supercilii

activity can reliably recognize positive emotion and negative emotion respectively. This conclusion also supports the discrete emotion theory (Cacioppo et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full#B4

). For example, oblique lip-corner contraction (AU12), together with cheek raising (AU6) can reliably signals enjoyment (Ekman et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full#B15

), while brow furrowing (AU4) tends to signal negative emotion (Brown and Schwartz,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full#B3

). The correlation between emotion and facial muscle activity can be summarized as follows: (1) The main muscle area of the zygomatic is a reliable discriminating area for positive emotion; (2) The corrugator muscle area is a reliable identification area for negative emotion.

As shown in

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full#F1

, AU4, which is controlled by contraction of the depressor supercilii and corrugator supercilii, is present in all negative emotions. Most of the AU associated with happiness is controlled by the zygomatic branch, which mainly innervates the zygomatic muscle. Therefore, the coder should focus more on the cheekbones, i.e., the middle of the face and the mouth if they want to catch the expressions or micro-expressions elicited by positive stimuli. For those elicited by negative stimuli, the coder should focus more on the forehead, i.e., the eyebrows and the upper part of the face.

## Further Specific Classification of the Muscles of Negative Emotions

In the six basic emotions, the negative emotions usually manifested as sadness, disgust, anger and fear, which are all highly associated with the

corrugator supercilii

, the brow and upper region. Therefore, in combination with the lower face, launching a further distinguishing of these four emotions from facial muscles is crucial for emotional classification.

### Muscle Group Specific for Sadness

depressor anguli oris

begins at the genital tubercle and the oblique line of the mandible, ends at the

angulus oris

. It is innervated by the

branch of the CN VII and the

marginal mandibular

branch. It serves to depress the

angulus oris

. The study found that when the participants produced happy or sad emotions by recalling, the facial EMG of the frowning muscle in the sadness was significantly higher than that in the happiness (Schwartz et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full#B38

). This suggests that the combination of

corrugator supercilii

and textitdepressor anguli oris may be effective in classifying sad emotions.

### Muscle Group Specific for Fear

begins in the

epicranial aponeurosis

, and extends to terminates in the skin of the brow and nasal root, and into the

orbicularis oculi

corrugator supercilii

. It is innervated by the

auricular posterior

nerve and the

branch of the CN VII. The

is a vertical movement that serves to raise the eyebrows and increase the wrinkles at the level of the forehead, often seen in expressions of surprise. In expression coding, the action of raising the inner brow is coded as AU1. The

orbicularis oculi

begin in the pars nasalis ossis frontalis, the frontal eminence of the upper skeleton and the medial palpebral ligament, surrounds the orbit and ends at the adjacent muscles. Anatomically it is divided into the orbital and palpebral portions. It is innervated by the

branches of the CN VII. The function is to close the eyelid. In the study of the positive intersection of facial expressions and emotional stimuli, the researchers asked the subjects to maintain the fear feature of facial muscles, involving

corrugator supercilii, frontalis, orbicularis oculi

depressor anguli oris

(Tourangeau and Ellsworth,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full#B41

## Distinguish the Special Muscle of Surprise

Surprise is an emotion that is independent of positive and negative emotions. For example, pleasant surprise, shock, etc., fall within the category of surprise. The study of people's surprise emotion has been started since Darwin (Darwin,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full#B7

), and it is ubiquitous in social life and belongs to one of the basic emotions. Moreover, surprise can be easily induced in the laboratory.

Landis conducted the earliest study of surprising expressions (Landis,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full#B26

). About 30% of people raised their eyebrows, and about 20% of people's eyes widened when a firecracker landed on the back of the subject's chair. Moreover, in discussing the evidence for a strong dissociation between emotion and facial expression, the research measured facial movements associated with surprise twice (see experiments 7 and 8). When subjects experienced surprise, the facial movements were described as frowning, eye-widening, and eyebrow raising (Reisenzein et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full#B37

). Also, in exploring the distinction in dynamics between genuine and deliberate expressions of surprise, it was found that all expressions of surprise consisted mainly of raised eyebrows and eyelid movements (Namba et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full#B32

). The facial muscles involved in these movements were:

corrugator supercilii, orbicularis oculi

. Details are described in section 4.2. The AUs associated with these facial muscles and movements include AU2, AU4, and AU5. As shown in

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full#F1

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full#T3

5. Emotion Label

Expressions are generally divided into six basic emotions, happiness, disgust, sadness, fear, anger and surprise. Micro-expressions are usually useful when there is a small negative micro-expression in a positive expression, such as “nasty-nice.” For micro-expressions, therefore, they are usually divided into four types, positive, negative, surprise and other. To be specific, positive expression includes happy expressions, which is relatively easy to be induced because of some obvious characteristics. Negative expressions like disgust, sadness, fear, anger, etc., are relatively difficult to distinguish, but they are significantly different from positive expressions. Meanwhile, surprise, which expresses unexpected emotions that can only be interpreted according to the context, has no direct relationship with positive or negative expressions. The additional category, “Others,” indicates expressions or micro-expressions that have ambiguous emotional meanings can be classified into the six basic emotions.

Emotion labeling requires the consideration of the components of emotions. Generally speaking, we need to take three conditions into account for the emotional facial action: AU label, elicitation material, and the subject's self-report of this video. Meanwhile, the influence of some habitual behaviors should be eliminated, such as frown when blinking or sniffing.

## AU Label

For AU annotation, the annotator needs to be skilled in the facial coding system and watches the videos containing facial expression frame by frame. The three crucial frames for AU are the start frame (onset), peak frame (apex), and end frame (offset). Then we can get the expression time period for labeling AU. The start frame represents the time where the face changes from neutral expression. The peak frame is the time with the greatest extent of that facial expression. The end frame is the time where the expression ends and returns to neutral expression.

## Elicitation Material

Spontaneous expressions have high ecological validity compared to posed expressions and are usually elicited with elicitation material. In psychology, researchers usually use different emotional stimuli to induce emotions with different properties and intensities. A stimulus is an important tool for inducing experimental emotions. We use stimuli materials, usually from existing emotional materials databases, to elicit different types of emotions of the subject.

## Subject's Self-Report of This Video

After watching the video, the subjects need to evaluate the video according to their subjective feelings. This self-report is an effective means of testing whether emotions have been successfully elicited.

## Reliability of Label

In order to ensure the validity or reliability of data annotation, the process of emotion labeling usually requires the participation of two coders and the calculation of inter-coders confidence must exist in a proper range. The formula is as follows 2:

R= N × ∣ ∣ ⋂ N i= 1 C i ∣ ∣ ∣ ∣ ⋃ N i= 1 C i ∣ ∣ R = N × | ⋂ i = 1 N C i | | ⋃ i = 1 N C i |

represents the set of labeled emotions in the facial expression images by coder i(2 ≤ i ≤ N), respectively, and ∣· ∣ represents the number of labeled emotion in the set after the intersection or merge operations.

The reason is that in the process of annotation, the coders must make subjective judgments based on their expertise. In order to make these subjective judgments as similar as possible to the perceptions of the majority of people, inter-rater reliability is of paramount importance. Inter-rater reliability is a necessary step for the validity of content analysis (emotion labeling) research. The conclusions of data annotation are questionable or even meaningless without this step.

It is mentioned above show that emotion labeling is a complex process, which needs coders to have the expertise with both psychology and statistics, increasing the threshold for being a coder. So we tried to find a direct relationship between emotions and facial movements to identify specific regions of emotions, as shown in

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full#F1

6. Detection and Recognition of AU

Facial muscles possess complex muscle patterns. Researchers have developed facial motion coding systems, video recordings, electromyography, and other methods to study and analyze facial muscle contractions.

The FACS coding system developed by Friesen and Ekman (

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full#B18

) is based on the anatomical structure of facial muscles and is composed of all visible facial motion units AU under different intensities. So far, more than 7,000 AU combinations have been found in a large number of expressions. However, even for FACS coders, such labeling is time-consuming and labor-intensive.

Since then, the researchers have made some automatic coding attempts. For example, by analyzing the images in the video, it can automatically detect, track and classify the AU or AU combination that causes facial expressions (Lien et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full#B28

). Nevertheless, unfortunately, image quality is especially susceptible to illumination, which, to some extent, limits such visible spectrum imaging technology.

To surmount such problem, researchers used facial electromyography, which is widely used in clinical research, to record AU muscle electrical activity (even visually imperceptible). This technique is susceptible to measuring the dynamics and strength of muscle contractions (Delplanque et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full#B9

). However, there still exist some shortcomings: objective factors such as electrode size and position, epidermal cleanliness, and muscle movement methods, may interfere with the accuracy of the final experimental results and cause deviations in experimental conclusions. What's more, the number of muscles related to AU should theoretically be as much as that of electrodes, which also makes EMG a severe limitation as a non-invasive method.

Additionally, thermal imaging technology has also been applied to the study of facial muscle contraction and AU. Research has demonstrated that muscle contraction can cause skin temperature to increase (González-Alonso et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full#B19

). For this reason, Jarlier et al. took thermal imaging as a tool to investigate specific facial heat patterns associated with the production of facial AUs (Jarlier et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full#B23

). Therefore, thermal images can be used to detect and evaluate specific facial muscle thermal patterns (the speed and intensity of muscle contraction). Furthermore, this method avoids the lighting problems encountered when using traditional cameras and the influence of electrodes when using EMG.

7. Conclusion

In this article, with the help of statistical analysis, a data-driven approach is used to obtain a quantifiable system between AU and emotion. And then, we further obtain a robust correspondence system between AU and emotion by combining with an empirically driven comparison to actual data (from the web). In the next part, we introduce the cortical system that controls facial movements. Moreover, the physiological theoretical support for AU labeling of emotions was obtained by adding facial muscle movements. Finally, we sort out the process of emotion label and the research of AU recognition and detection. The main manifestations are listed below:

Based on the

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full#F1

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full#T3

, the theories of sections 3 and 4, we sum up the main points of coding in the article:

When corners of lips pulled up (AU12) appears, it can be coded as a positive emotion, i.e., happy; In addition, cheek rise (AU6), lip suck (AU28) are both happy specific action units and can also be coded as positive emotions;

When brow rise (AU2) is present, it can be coded as surprise;

When frown (AU4) is present, it can be coded as a negative emotion;

It can be coded as anger when gnashing (AU16, AU22 or AU23), which only occur in the specific action units, appear;

When movements of the eyebrows (AU1 and AU4), eyes (AU5) and mouth (AU25) are present simultaneously, they can be coded as fear;

It can be coded as disgusted when the specific action unit of disgust, lower eyelid rise (AU7), mouth tightly closed (AU24), is present;

It can be coded as sad when frown (AU4) and eyes wide open (AU5) are present at the same time; eyes closed (AU43) is the specific action unit for sadness and can also be coded as sadness.

This work was supported by grants from National Natural Science Foundation of China (61772511, U19B2032), National Key Research and Development Program (2017YFC0822502), and China Postdoctoral Science Foundation (2020M680738).

Publisher's Note

All claims expressed in this article are solely those of the authors and do not necessarily represent those of their affiliated organizations, or those of the publisher, the editors and the reviewers. Any product that may be evaluated in this article, or claim that may be made by its manufacturer, is not guaranteed or endorsed by the publisher.

Data availability statement

Publicly available datasets were analyzed in this study. This data can be found here:

http://whdeng.cn/RAF/model3.html#:$~$:text=a%20Real-world%20Affective%20Faces%20Action%20Unit%20%28RAF-AU%29database%20that,to%20annotating%20blended%20facial%20expressions%20in%20the%20wild

http://whdeng.cn/RAF/model3.html#:$~$:text=a%20Real-world%20Affective%20Faces%20Action%20Unit%20%28RAF-AU%29database%20that,to%20annotating%20blended%20facial%20expressions%20in%20the%20wild

Author contributions

ZD has contributed the main body of text and the main ideas. GW was responsible for empirical data analysis. SL was responsible for constructing the partial research framework. JL has contributed to the construction of the text and refinement of ideas and provided extensive feedback and commentary. S-JW led the project and acquired the funding support. All authors contributed to the article and approved the submitted version.

Acknowledgments

The authors would like to thank Xudong Lei for linguistic assistance during preparation of this manuscript.

Conflict of interest

The authors declare that the research was conducted in the absence of any commercial or financial relationships that could be construed as a potential conflict of interest.

1 Bentsianov B. Blitzer A. ( 2004). Facial anatomy.

Clin. Dermatol

. 22, 3– 13. 10.1016/j.clindermatol.2003.11.011

Pubmed Abstract

https://pubmed.ncbi.nlm.nih.gov/15158538

https://doi.org/10.1016/j.clindermatol.2003.11.011

Google Scholar

http://scholar.google.com/scholar\_lookup?author=B..%2BBentsianov&author=A..%2BBlitzer&publication\_year=2004&title=Facial%2Banatomy&journal=Clin.+Dermatol&volume=22&pages=3-13

2 Bouras T. Stranjalis G. Sakas D. E. ( 2007). Traumatic midbrain hematoma in a patient presenting with an isolated palsy of voluntary facial movements: case report.

J. Neurosurg

. 107, 158– 160. 10.3171/JNS-07/07/0158

Pubmed Abstract

https://pubmed.ncbi.nlm.nih.gov/17639886

https://doi.org/10.3171/JNS-07/07/0158

Google Scholar

http://scholar.google.com/scholar\_lookup?author=T..%2BBouras&author=G..%2BStranjalis&author=D.%2BE..%2BSakas&publication\_year=2007&title=Traumatic%2Bmidbrain%2Bhematoma%2Bin%2Ba%2Bpatient%2Bpresenting%2Bwith%2Ban%2Bisolated%2Bpalsy%2Bof%2Bvoluntary%2Bfacial%2Bmovements%3A%2Bcase%2Breport&journal=J.+Neurosurg&volume=107&pages=158-160

3 Brown S.-L. Schwartz G. E. ( 1980). Relationships between facial electromyography and subjective experience during affective imagery.

Biol. Psychol

. 11, 49– 62. 10.1016/0301-0511(80)90026-5

Pubmed Abstract

https://pubmed.ncbi.nlm.nih.gov/7248403

https://doi.org/10.1016/0301-0511(80)90026-5

Google Scholar

http://scholar.google.com/scholar\_lookup?author=S.-L..%2BBrown&author=G.%2BE..%2BSchwartz&publication\_year=1980&title=Relationships%2Bbetween%2Bfacial%2Belectromyography%2Band%2Bsubjective%2Bexperience%2Bduring%2Baffective%2Bimagery&journal=Biol.+Psychol&volume=11&pages=49-62

4 Cacioppo J. Berntson G. Larsen J. Poehlmann K. Ito T. Lewis M. et al. ( 2000).

Handbook of Emotions

. New York, NY: The Guilford Press.

Google Scholar

http://scholar.google.com/scholar\_lookup?author=J..%2BCacioppo&author=G..%2BBerntson&author=J..%2BLarsen&author=K..%2BPoehlmann&author=T..%2BIto&author=M..%2BLewis&publication\_year=2000&journal=Handbook+of+Emotions

5 Cattaneo L. Pavesi G. ( 2014). The facial motor system.

Neurosci. Biobehav. Rev

. 38, 135– 159. 10.1016/j.neubiorev.2013.11.002

Pubmed Abstract

https://pubmed.ncbi.nlm.nih.gov/24239732

https://doi.org/10.1016/j.neubiorev.2013.11.002

Google Scholar

http://scholar.google.com/scholar\_lookup?author=L..%2BCattaneo&author=G..%2BPavesi&publication\_year=2014&title=The%2Bfacial%2Bmotor%2Bsystem&journal=Neurosci.+Biobehav.+Rev&volume=38&pages=135-159

6 Curra A. Romaniello A. Berardelli A. Cruccu G. Manfredi M. ( 2000). Shortened cortical silent period in facial muscles of patients with cranial dystonia.

Neurology54

, 130– 130. 10.1212/WNL.54.1.130

Pubmed Abstract

https://pubmed.ncbi.nlm.nih.gov/10636138

https://doi.org/10.1212/WNL.54.1.130

Google Scholar

http://scholar.google.com/scholar\_lookup?author=A..%2BCurra&author=A..%2BRomaniello&author=A..%2BBerardelli&author=G..%2BCruccu&author=M..%2BManfredi&publication\_year=2000&title=Shortened%2Bcortical%2Bsilent%2Bperiod%2Bin%2Bfacial%2Bmuscles%2Bof%2Bpatients%2Bwith%2Bcranial%2Bdystonia&journal=Neurology&volume=54&pages=130-130

7 Darwin C.. ( 1872).

The Expression of the Emotions in Man and Animals by Charles Darwin

. London: John Murray. 10.1037/10001-000

https://doi.org/10.1037/10001-000

Google Scholar

http://scholar.google.com/scholar\_lookup?author=C...%2BDarwin&publication\_year=1872&journal=The+Expression+of+the+Emotions+in+Man+and+Animals+by+Charles+Darwin

8 Davison A. K. Merghani W. Yap M. H. ( 2018). Objective classes for micro-facial expression recognition.

J. Imaging4

: 119. 10.3390/jimaging4100119

https://doi.org/10.3390/jimaging4100119

Google Scholar

http://scholar.google.com/scholar\_lookup?author=A.%2BK..%2BDavison&author=W..%2BMerghani&author=M.%2BH..%2BYap&publication\_year=2018&title=Objective%2Bclasses%2Bfor%2Bmicro-facial%2Bexpression%2Brecognition&journal=J.+Imaging&volume=4

9 Delplanque S. Grandjean D. Chrea C. Coppin G. Aymard L. Cayeux I. et al. ( 2009). Sequential unfolding of novelty and pleasantness appraisals of odors: evidence from facial electromyography and autonomic reactions.

: 316. 10.1037/a0015369

Pubmed Abstract

https://pubmed.ncbi.nlm.nih.gov/19485609

https://doi.org/10.1037/a0015369

Google Scholar

http://scholar.google.com/scholar\_lookup?author=S..%2BDelplanque&author=D..%2BGrandjean&author=C..%2BChrea&author=G..%2BCoppin&author=L..%2BAymard&author=I..%2BCayeux&publication\_year=2009&title=Sequential%2Bunfolding%2Bof%2Bnovelty%2Band%2Bpleasantness%2Bappraisals%2Bof%2Bodors%3A%2Bevidence%2Bfrom%2Bfacial%2Belectromyography%2Band%2Bautonomic%2Breactions&journal=Emotion&volume=9

10 Devoize J.-L.. ( 2011). Hemifacial spasm in antique sculpture: interest in the “other babinski sign”.

J. Neurol. Neurosurg. Psychiatry82

, 26– 26. 10.1136/jnnp.2010.208363

Pubmed Abstract

https://pubmed.ncbi.nlm.nih.gov/20601668

https://doi.org/10.1136/jnnp.2010.208363

Google Scholar

http://scholar.google.com/scholar\_lookup?author=J.-L...%2BDevoize&publication\_year=2011&title=Hemifacial%2Bspasm%2Bin%2Bantique%2Bsculpture%3A%2Binterest%2Bin%2Bthe%2B%E2%80%9Cother%2Bbabinski%2Bsign%E2%80%9D&journal=J.+Neurol.+Neurosurg.+Psychiatry&volume=82&pages=26-26

11 Dimberg U.. ( 1982). Facial reactions to facial expressions.

Psychophysiology19

, 643– 647. 10.1111/j.1469-8986.1982.tb02516.x

Pubmed Abstract

https://pubmed.ncbi.nlm.nih.gov/7178381

https://doi.org/10.1111/j.1469-8986.1982.tb02516.x

Google Scholar

http://scholar.google.com/scholar\_lookup?author=U...%2BDimberg&publication\_year=1982&title=Facial%2Breactions%2Bto%2Bfacial%2Bexpressions&journal=Psychophysiology&volume=19&pages=643-647

12 Drake R. Vogl A. W. Mitchell A. W. ( 2009).

Gray's Anatomy for Students E-book

. London: Churchill Livingstone; Elsevier Health Sciences.

Google Scholar

http://scholar.google.com/scholar\_lookup?author=R..%2BDrake&author=A.%2BW..%2BVogl&author=A.%2BW..%2BMitchell&publication\_year=2009&journal=Gray%27s+Anatomy+for+Students+E-book

13 Duchenne G.-B.. ( 1876).

Mécanisme de la physionomie humaine ou analyse électro-physiologique de l'expression des passions

. Paris: J.-B. Bailliére et fils.

Google Scholar

http://scholar.google.com/scholar\_lookup?author=G.-B...%2BDuchenne&publication\_year=1876&journal=M%C3%A9canisme+de+la+physionomie+humaine+ou+analyse+%C3%A9lectro-physiologique+de+l%27expression+des+passions

14 Ekman P.. ( 1993). Facial expression and emotion.

Am. Psychol

. 48: 384. 10.1037/0003-066X.48.4.384

https://doi.org/10.1037/0003-066X.48.4.384

Google Scholar

http://scholar.google.com/scholar\_lookup?author=P...%2BEkman&publication\_year=1993&title=Facial%2Bexpression%2Band%2Bemotion&journal=Am.+Psychol&volume=48

15 Ekman P. Davidson R. J. Friesen W. V. ( 1990). The duchenne smile: emotional expression and brain physiology: II.

J. Pers. Soc. Psychol

. 58: 342. 10.1037/0022-3514.58.2.342

Pubmed Abstract

https://pubmed.ncbi.nlm.nih.gov/2319446

https://doi.org/10.1037/0022-3514.58.2.342

Google Scholar

http://scholar.google.com/scholar\_lookup?author=P..%2BEkman&author=R.%2BJ..%2BDavidson&author=W.%2BV..%2BFriesen&publication\_year=1990&title=The%2Bduchenne%2Bsmile%3A%2Bemotional%2Bexpression%2Band%2Bbrain%2Bphysiology%3A%2BII&journal=J.+Pers.+Soc.+Psychol&volume=58

16 Ekman P. Rosenberg E. L. ( 1997).

What the Face Reveals: Basic and Applied Studies of Spontaneous Expression Using the Facial Action Coding System (FACS)

. New York, NY: Oxford University Press.

Google Scholar

http://scholar.google.com/scholar\_lookup?author=P..%2BEkman&author=E.%2BL..%2BRosenberg&publication\_year=1997&journal=What+the+Face+Reveals%3A+Basic+and+Applied+Studies+of+Spontaneous+Expression+Using+the+Facial+Action+Coding+System+%28FACS%29

17 Fabian Benitez-Quiroz C. Srinivasan R. Martinez A. M. ( 2016). “Emotionet: an accurate, real-time algorithm for the automatic annotation of a million facial expressions in the wild,” in

Proceedings of the IEEE Conference on Computer Vision and Pattern Recognition

( Las Vegas, NV), 5562– 5570. 10.1109/CVPR.2016.600

Pubmed Abstract

https://pubmed.ncbi.nlm.nih.gov/27295638

https://doi.org/10.1109/CVPR.2016.600

Google Scholar

http://scholar.google.com/scholar\_lookup?author=C..%2BFabian%2BBenitez-Quiroz&author=R..%2BSrinivasan&author=A.%2BM..%2BMartinez&publication\_year=2016&title=%E2%80%9CEmotionet%3A%2Ban%2Baccurate%2C%2Breal-time%2Balgorithm%2Bfor%2Bthe%2Bautomatic%2Bannotation%2Bof%2Ba%2Bmillion%2Bfacial%2Bexpressions%2Bin%2Bthe%2Bwild%2C%E2%80%9D&journal=Proceedings+of+the+IEEE+Conference+on+Computer+Vision+and+Pattern+Recognition&pages=5562-5570

18 Friesen E. Ekman P. ( 1978). Facial action coding system: a technique for the measurement of facial movement.

Google Scholar

http://scholar.google.com/scholar\_lookup?author=E..%2BFriesen&author=P..%2BEkman&publication\_year=1978&title=Facial%2Baction%2Bcoding%2Bsystem%3A%2Ba%2Btechnique%2Bfor%2Bthe%2Bmeasurement%2Bof%2Bfacial%2Bmovement&journal=Palo+Alto&volume=3

19 González-Alonso J. Quistorff B. Krustrup P. Bangsbo J. Saltin B. ( 2000). Heat production in human skeletal muscle at the onset of intense dynamic exercise.

. 524, 603– 615. 10.1111/j.1469-7793.2000.00603.x

Pubmed Abstract

https://pubmed.ncbi.nlm.nih.gov/10766936

https://doi.org/10.1111/j.1469-7793.2000.00603.x

Google Scholar

http://scholar.google.com/scholar\_lookup?author=J..%2BGonz%C3%A1lez-Alonso&author=B..%2BQuistorff&author=P..%2BKrustrup&author=J..%2BBangsbo&author=B..%2BSaltin&publication\_year=2000&title=Heat%2Bproduction%2Bin%2Bhuman%2Bskeletal%2Bmuscle%2Bat%2Bthe%2Bonset%2Bof%2Bintense%2Bdynamic%2Bexercise&journal=J.+Physiol&volume=524&pages=603-615

20 Holstege G.. ( 2002). Emotional innervation of facial musculature.

Movement Disord

. 17, S12– S16. 10.1002/mds.10050

Pubmed Abstract

https://pubmed.ncbi.nlm.nih.gov/11836745

https://doi.org/10.1002/mds.10050

Google Scholar

http://scholar.google.com/scholar\_lookup?author=G...%2BHolstege&publication\_year=2002&title=Emotional%2Binnervation%2Bof%2Bfacial%2Bmusculature&journal=Movement+Disord&volume=17&pages=S12-S16

21 Izard C. E. Huebner R. R. Risser D. Dougherty L. ( 1980). The young infant's ability to produce discrete emotion expressions.

Dev. Psychol

. 16: 132. 10.1037/0012-1649.16.2.132

https://doi.org/10.1037/0012-1649.16.2.132

Google Scholar

http://scholar.google.com/scholar\_lookup?author=C.%2BE..%2BIzard&author=R.%2BR..%2BHuebner&author=D..%2BRisser&author=L..%2BDougherty&publication\_year=1980&title=The%2Byoung%2Binfant%27s%2Bability%2Bto%2Bproduce%2Bdiscrete%2Bemotion%2Bexpressions&journal=Dev.+Psychol&volume=16

22 Izard C. E. Weiss M. ( 1979).

Maximally Discriminative Facial Movement Coding System

. University of Delaware, Instructional Resources Center.

Google Scholar

http://scholar.google.com/scholar\_lookup?author=C.%2BE..%2BIzard&author=M..%2BWeiss&publication\_year=1979&journal=Maximally+Discriminative+Facial+Movement+Coding+System

23 Jarlier S. Grandjean D. Delplanque S. N'diaye K. Cayeux I. Velazco M. I. et al. ( 2011). Thermal analysis of facial muscles contractions.

IEEE Trans. Affect. Comput

. 2, 2– 9. 10.1109/T-AFFC.2011.3

Pubmed Abstract

https://pubmed.ncbi.nlm.nih.gov/27295638

https://doi.org/10.1109/T-AFFC.2011.3

Google Scholar

http://scholar.google.com/scholar\_lookup?author=S..%2BJarlier&author=D..%2BGrandjean&author=S..%2BDelplanque&author=K..%2BN%27diaye&author=I..%2BCayeux&author=M.%2BI..%2BVelazco&publication\_year=2011&title=Thermal%2Banalysis%2Bof%2Bfacial%2Bmuscles%2Bcontractions&journal=IEEE+Trans.+Affect.+Comput&volume=2&pages=2-9

24 Ji Q. Lan P. Looney C. ( 2006). A probabilistic framework for modeling and real-time monitoring human fatigue.

IEEE Trans. Syst. Man Cybernet. A Syst. Hum

. 36, 862– 875. 10.1109/TSMCA.2005.855922

Pubmed Abstract

https://pubmed.ncbi.nlm.nih.gov/27295638

https://doi.org/10.1109/TSMCA.2005.855922

Google Scholar

http://scholar.google.com/scholar\_lookup?author=Q..%2BJi&author=P..%2BLan&author=C..%2BLooney&publication\_year=2006&title=A%2Bprobabilistic%2Bframework%2Bfor%2Bmodeling%2Band%2Breal-time%2Bmonitoring%2Bhuman%2Bfatigue&journal=IEEE+Trans.+Syst.+Man+Cybernet.+A+Syst.+Hum&volume=36&pages=862-875

25 Kring A. M. Sloan D. ( 1991). The facial expression coding system (FACES): a users guide. Unpublished manuscript. 10.1037/t03675-000

https://doi.org/10.1037/t03675-000

Google Scholar

http://scholar.google.com/scholar\_lookup?author=A.%2BM..%2BKring&author=D..%2BSloan&publication\_year=1991&title=The%2Bfacial%2Bexpression%2Bcoding%2Bsystem%2B%28FACES%29%3A%2Ba%2Busers%2Bguide

26 Landis C.. ( 1924). Studies of emotional reactions. II. General behavior and facial expression.

J. Comp. Psychol

. 4, 447– 510. 10.1037/h0073039

Pubmed Abstract

https://pubmed.ncbi.nlm.nih.gov/9802236

https://doi.org/10.1037/h0073039

Google Scholar

http://scholar.google.com/scholar\_lookup?author=C...%2BLandis&publication\_year=1924&title=Studies%2Bof%2Bemotional%2Breactions.%2BII.%2BGeneral%2Bbehavior%2Band%2Bfacial%2Bexpression&journal=J.+Comp.+Psychol&volume=4&pages=447-510

27 Larsen J. T. Norris C. J. Cacioppo J. T. ( 2003). Effects of positive and negative affect on electromyographic activity over zygomaticus major and

corrugator supercilii

Psychophysiology40

, 776– 785. 10.1111/1469-8986.00078

Pubmed Abstract

https://pubmed.ncbi.nlm.nih.gov/14696731

https://doi.org/10.1111/1469-8986.00078

Google Scholar

http://scholar.google.com/scholar\_lookup?author=J.%2BT..%2BLarsen&author=C.%2BJ..%2BNorris&author=J.%2BT..%2BCacioppo&publication\_year=2003&title=Effects%2Bof%2Bpositive%2Band%2Bnegative%2Baffect%2Bon%2Belectromyographic%2Bactivity%2Bover%2Bzygomaticus%2Bmajor%2Band%2Bcorrugator%2Bsupercilii&journal=Psychophysiology&volume=40&pages=776-785

28 Lien J. J.-J. Kanade T. Cohn J. F. Li C.-C. ( 2000). Detection, tracking, and classification of action units in facial expression.

Robot. Auton. Syst

. 31, 131– 146. 10.1016/S0921-8890(99)00103-7

https://doi.org/10.1016/S0921-8890(99)00103-7

Google Scholar

http://scholar.google.com/scholar\_lookup?author=J.%2BJ.-J..%2BLien&author=T..%2BKanade&author=J.%2BF..%2BCohn&author=C.-C..%2BLi&publication\_year=2000&title=Detection%2C%2Btracking%2C%2Band%2Bclassification%2Bof%2Baction%2Bunits%2Bin%2Bfacial%2Bexpression&journal=Robot.+Auton.+Syst&volume=31&pages=131-146

29 Lucey P. Cohn J. F. Matthews I. Lucey S. Sridharan S. Howlett J. et al. ( 2010). Automatically detecting pain in video through facial action units.

IEEE Trans. Syst. Man Cybernet. B41

, 664– 674. 10.1109/TSMCB.2010.2082525

Pubmed Abstract

https://pubmed.ncbi.nlm.nih.gov/21097382

https://doi.org/10.1109/TSMCB.2010.2082525

Google Scholar

http://scholar.google.com/scholar\_lookup?author=P..%2BLucey&author=J.%2BF..%2BCohn&author=I..%2BMatthews&author=S..%2BLucey&author=S..%2BSridharan&author=J..%2BHowlett&publication\_year=2010&title=Automatically%2Bdetecting%2Bpain%2Bin%2Bvideo%2Bthrough%2Bfacial%2Baction%2Bunits&journal=IEEE+Trans.+Syst.+Man+Cybernet.+B&volume=41&pages=664-674

30 Matsumoto D. Lee M. ( 1993). Consciousness, volition, and the neuropsychology of facial expressions of emotion.

Conscious. Cogn

. 2, 237– 254. 10.1006/ccog.1993.1022

https://doi.org/10.1006/ccog.1993.1022

Google Scholar

http://scholar.google.com/scholar\_lookup?author=D..%2BMatsumoto&author=M..%2BLee&publication\_year=1993&title=Consciousness%2C%2Bvolition%2C%2Band%2Bthe%2Bneuropsychology%2Bof%2Bfacial%2Bexpressions%2Bof%2Bemotion&journal=Conscious.+Cogn&volume=2&pages=237-254

31 Müri R. M.. ( 2016). Cortical control of facial expression.

J. Comp. Neurol

. 524, 1578– 1585. 10.1002/cne.23908

Pubmed Abstract

https://pubmed.ncbi.nlm.nih.gov/26418049

https://doi.org/10.1002/cne.23908

Google Scholar

http://scholar.google.com/scholar\_lookup?author=R.%2BM...%2BM%C3%BCri&publication\_year=2016&title=Cortical%2Bcontrol%2Bof%2Bfacial%2Bexpression&journal=J.+Comp.+Neurol&volume=524&pages=1578-1585

32 Namba S. Matsui H. Zloteanu M. ( 2021). Distinct temporal features of genuine and deliberate facial expressions of surprise.

. 11: 3362. 10.1038/s41598-021-83077-4

Pubmed Abstract

https://pubmed.ncbi.nlm.nih.gov/33564091

https://doi.org/10.1038/s41598-021-83077-4

Google Scholar

http://scholar.google.com/scholar\_lookup?author=S..%2BNamba&author=H..%2BMatsui&author=M..%2BZloteanu&publication\_year=2021&title=Distinct%2Btemporal%2Bfeatures%2Bof%2Bgenuine%2Band%2Bdeliberate%2Bfacial%2Bexpressions%2Bof%2Bsurprise&journal=Sci.+Rep&volume=11

33 Niu X. Han H. Shan S. Chen X. ( 2019). “Multi-label co-regularization for semi-supervised facial action unit recognition,” in

Advances in Neural Information Processing Systems 32

, eds H. Wallach, H. Larochelle, A. Beygelzimer, F. d' Alché-Buc, E. Fox, and R. Garnett ( Vancouver, BC: Vancouver Convention Center; Curran Associates, Inc.).

Google Scholar

http://scholar.google.com/scholar\_lookup?author=X..%2BNiu&author=H..%2BHan&author=S..%2BShan&author=X..%2BChen&publication\_year=2019&title=%E2%80%9CMulti-label%2Bco-regularization%2Bfor%2Bsemi-supervised%2Bfacial%2Baction%2Bunit%2Brecognition%2C%E2%80%9D&journal=Advances+in+Neural+Information+Processing+Systems+32

34 Pandzic I. S. Forchheimer R. ( 2003).

MPEG-4 Facial Animation: The Standard, Implementation and Applications

. Chennai: John Wiley & Sons. 10.1002/0470854626

Pubmed Abstract

https://pubmed.ncbi.nlm.nih.gov/25855820

https://doi.org/10.1002/0470854626

Google Scholar

http://scholar.google.com/scholar\_lookup?author=I.%2BS..%2BPandzic&author=R..%2BForchheimer&publication\_year=2003&journal=MPEG-4+Facial+Animation%3A+The+Standard%2C+Implementation+and+Applications

35 Paradiso G. O. Cunic D. I. Gunraj C. A. Chen R. ( 2005). Representation of facial muscles in human motor cortex.

. 567, 323– 336. 10.1113/jphysiol.2005.088542

Pubmed Abstract

https://pubmed.ncbi.nlm.nih.gov/15946959

https://doi.org/10.1113/jphysiol.2005.088542

Google Scholar

http://scholar.google.com/scholar\_lookup?author=G.%2BO..%2BParadiso&author=D.%2BI..%2BCunic&author=C.%2BA..%2BGunraj&author=R..%2BChen&publication\_year=2005&title=Representation%2Bof%2Bfacial%2Bmuscles%2Bin%2Bhuman%2Bmotor%2Bcortex&journal=J.+Physiol&volume=567&pages=323-336

36 Penfield W. Boldrey E. ( 1937). Somatic motor and sensory representation in the cerebral cortex of man as studied by electrical stimulation.

, 389– 443. 10.1093/brain/60.4.389

https://doi.org/10.1093/brain/60.4.389

Google Scholar

http://scholar.google.com/scholar\_lookup?author=W..%2BPenfield&author=E..%2BBoldrey&publication\_year=1937&title=Somatic%2Bmotor%2Band%2Bsensory%2Brepresentation%2Bin%2Bthe%2Bcerebral%2Bcortex%2Bof%2Bman%2Bas%2Bstudied%2Bby%2Belectrical%2Bstimulation&journal=Brain&volume=60&pages=389-443

37 Reisenzein R. Bordgen S. Holtbernd T. Matz D. ( 2006). Evidence for strong dissociation between emotion and facial displays: the case of surprise.

J. Pers. Soc. Psychol

. 91, 295– 315. 10.1037/0022-3514.91.2.295

Pubmed Abstract

https://pubmed.ncbi.nlm.nih.gov/16881766

https://doi.org/10.1037/0022-3514.91.2.295

Google Scholar

http://scholar.google.com/scholar\_lookup?author=R..%2BReisenzein&author=S..%2BBordgen&author=T..%2BHoltbernd&author=D..%2BMatz&publication\_year=2006&title=Evidence%2Bfor%2Bstrong%2Bdissociation%2Bbetween%2Bemotion%2Band%2Bfacial%2Bdisplays%3A%2Bthe%2Bcase%2Bof%2Bsurprise&journal=J.+Pers.+Soc.+Psychol&volume=91&pages=295-315

38 Schwartz G. E. Fair P. L. Salt P. Mandel M. R. Klerman G. L. ( 1976). Facial expression and imagery in depression: an electromyographic study.

Psychosom. Med

. 38, 337– 347. 10.1097/00006842-197609000-00006

Pubmed Abstract

https://pubmed.ncbi.nlm.nih.gov/981492

https://doi.org/10.1097/00006842-197609000-00006

Google Scholar

http://scholar.google.com/scholar\_lookup?author=G.%2BE..%2BSchwartz&author=P.%2BL..%2BFair&author=P..%2BSalt&author=M.%2BR..%2BMandel&author=G.%2BL..%2BKlerman&publication\_year=1976&title=Facial%2Bexpression%2Band%2Bimagery%2Bin%2Bdepression%3A%2Ban%2Belectromyographic%2Bstudy&journal=Psychosom.+Med&volume=38&pages=337-347

39 Sherwood C. C.. ( 2005). Comparative anatomy of the facial motor nucleus in mammals, with an analysis of neuron numbers in primates.

Anat. Rec. A287

, 1067– 1079. 10.1002/ar.a.20259

Pubmed Abstract

https://pubmed.ncbi.nlm.nih.gov/16200649

https://doi.org/10.1002/ar.a.20259

Google Scholar

http://scholar.google.com/scholar\_lookup?author=C.%2BC...%2BSherwood&publication\_year=2005&title=Comparative%2Banatomy%2Bof%2Bthe%2Bfacial%2Bmotor%2Bnucleus%2Bin%2Bmammals%2C%2Bwith%2Ban%2Banalysis%2Bof%2Bneuron%2Bnumbers%2Bin%2Bprimates&journal=Anat.+Rec.+A&volume=287&pages=1067-1079

40 Silberman E. K. Weingartner H. ( 1986). Hemispheric lateralization of functions related to emotion.

. 5, 322– 353. 10.1016/0278-2626(86)90035-7

Pubmed Abstract

https://pubmed.ncbi.nlm.nih.gov/3530287

https://doi.org/10.1016/0278-2626(86)90035-7

Google Scholar

http://scholar.google.com/scholar\_lookup?author=E.%2BK..%2BSilberman&author=H..%2BWeingartner&publication\_year=1986&title=Hemispheric%2Blateralization%2Bof%2Bfunctions%2Brelated%2Bto%2Bemotion&journal=Brain+Cogn&volume=5&pages=322-353

41 Tourangeau R. Ellsworth P. C. ( 1979). The role of facial response in the experience of emotion.

J. Pers. Soc. Psychol

. 37: 1519. 10.1037/0022-3514.37.9.1519

Pubmed Abstract

https://pubmed.ncbi.nlm.nih.gov/3572738

https://doi.org/10.1037/0022-3514.37.9.1519

Google Scholar

http://scholar.google.com/scholar\_lookup?author=R..%2BTourangeau&author=P.%2BC..%2BEllsworth&publication\_year=1979&title=The%2Brole%2Bof%2Bfacial%2Bresponse%2Bin%2Bthe%2Bexperience%2Bof%2Bemotion&journal=J.+Pers.+Soc.+Psychol&volume=37

42 Wang S. Peng G. Ji Q. ( 2020). Exploring domain knowledge for facial expression-assisted action unit activation recognition.

IEEE Trans. Affect. Comput

. 11, 640– 652. 10.1109/TAFFC.2018.2822303

Pubmed Abstract

https://pubmed.ncbi.nlm.nih.gov/27295638

https://doi.org/10.1109/TAFFC.2018.2822303

Google Scholar

http://scholar.google.com/scholar\_lookup?author=S..%2BWang&author=G..%2BPeng&author=Q..%2BJi&publication\_year=2020&title=Exploring%2Bdomain%2Bknowledge%2Bfor%2Bfacial%2Bexpression-assisted%2Baction%2Bunit%2Bactivation%2Brecognition&journal=IEEE+Trans.+Affect.+Comput&volume=11&pages=640-652

43 Wehrle T. Kaiser S. Schmidt S. Scherer K. R. ( 2000). Studying the dynamics of emotional expression using synthesized facial muscle movements.

J. Pers. Soc. Psychol

. 78: 105. 10.1037/0022-3514.78.1.105

Pubmed Abstract

https://pubmed.ncbi.nlm.nih.gov/10653509

https://doi.org/10.1037/0022-3514.78.1.105

Google Scholar

http://scholar.google.com/scholar\_lookup?author=T..%2BWehrle&author=S..%2BKaiser&author=S..%2BSchmidt&author=K.%2BR..%2BScherer&publication\_year=2000&title=Studying%2Bthe%2Bdynamics%2Bof%2Bemotional%2Bexpression%2Busing%2Bsynthesized%2Bfacial%2Bmuscle%2Bmovements&journal=J.+Pers.+Soc.+Psychol&volume=78

44 Xie H.-X. Lo L. Shuai H.-H. Cheng W.-H. ( 2020). “AU-assisted graph attention convolutional network for micro-expression recognition,” in

Proceedings of the 28th ACM International Conference on Multimedia

( Seattle, WA), 2871– 2880. 10.1145/3394171.3414012

https://doi.org/10.1145/3394171.3414012

Google Scholar

http://scholar.google.com/scholar\_lookup?author=H.-X..%2BXie&author=L..%2BLo&author=H.-H..%2BShuai&author=W.-H..%2BCheng&publication\_year=2020&title=%E2%80%9CAU-assisted%2Bgraph%2Battention%2Bconvolutional%2Bnetwork%2Bfor%2Bmicro-expression%2Brecognition%2C%E2%80%9D&journal=Proceedings+of+the+28th+ACM+International+Conference+on+Multimedia&pages=2871-2880

45 Yan W.-J. Li S. Que C. Pei J. Deng W. ( 2020). “RAF-AU database: in-the-wild facial expressions with subjective emotion judgement and objective au annotations,” in

Proceedings of the Asian Conference on Computer Vision

Google Scholar

http://scholar.google.com/scholar\_lookup?author=W.-J..%2BYan&author=S..%2BLi&author=C..%2BQue&author=J..%2BPei&author=W..%2BDeng&publication\_year=2020&title=%E2%80%9CRAF-AU%2Bdatabase%3A%2Bin-the-wild%2Bfacial%2Bexpressions%2Bwith%2Bsubjective%2Bemotion%2Bjudgement%2Band%2Bobjective%2Bau%2Bannotations%2C%E2%80%9D&journal=Proceedings+of+the+Asian+Conference+on+Computer+Vision

46 Yan W.-J. Wu Q. Liang J. Chen Y.-H. Fu X. ( 2013). How fast are the leaked facial expressions: the duration of micro-expressions.

J. Nonverb. Behav

. 37, 217– 230. 10.1007/s10919-013-0159-8

https://doi.org/10.1007/s10919-013-0159-8

Google Scholar

http://scholar.google.com/scholar\_lookup?author=W.-J..%2BYan&author=Q..%2BWu&author=J..%2BLiang&author=Y.-H..%2BChen&author=X..%2BFu&publication\_year=2013&title=How%2Bfast%2Bare%2Bthe%2Bleaked%2Bfacial%2Bexpressions%3A%2Bthe%2Bduration%2Bof%2Bmicro-expressions&journal=J.+Nonverb.+Behav&volume=37&pages=217-230

47 Zizhao D. Gang W. Shaoyuan L. Wen-Jing Y. Wang S.-J. ( 2021). “A brief guide: code for spontaneous expressions and micro-expressions in videos,” in

ACM International Conference on Multimedia

( Chengdu).

Google Scholar

http://scholar.google.com/scholar\_lookup?author=D..%2BZizhao&author=W..%2BGang&author=L..%2BShaoyuan&author=Y..%2BWen-Jing&author=S.-J..%2BWang&publication\_year=2021&title=%E2%80%9CA%2Bbrief%2Bguide%3A%2Bcode%2Bfor%2Bspontaneous%2Bexpressions%2Band%2Bmicro-expressions%2Bin%2Bvideos%2C%E2%80%9D&journal=ACM+International+Conference+on+Multimedia

expressions, micro-expressions, action unit, coding, cerebral cortex, facial muscle

Dong Z, Wang G, Lu S, Li J, Yan W and Wang S-J (2022) Spontaneous Facial Expressions and Micro-expressions Coding: From Brain to Face.

Front. Psychol.

12:784834. doi:

10.3389/fpsyg.2021.784834

http://dx.doi.org/10.3389/fpsyg.2021.784834

28 September 2021

17 November 2021

04 January 2022

Yong Li, Nanjing University of Science and Technology, China

Reviewed by

Ming Yin, Jiangsu Police Officer College, China; Xunbing Shen, Jiangxi University of Chinese Medicine, China

Check for updates

© 2022 Dong, Wang, Lu, Li, Yan and Wang.

This is an open-access article distributed under the terms of the

Creative Commons Attribution License (CC BY)

http://creativecommons.org/licenses/by/4.0/

. The use, distribution or reproduction in other forums is permitted, provided the original author(s) and the copyright owner(s) are credited and that the original publication in this journal is cited, in accordance with accepted academic practice. No use, distribution or reproduction is permitted which does not comply with these terms.

Correspondence: Su-Jing Wang

wangsujing@psych.ac.cn

mailto:wangsujing@psych.ac.cn

This article was submitted to Human-Media Interaction, a section of the journal Frontiers in Psychology

All claims expressed in this article are solely those of the authors and do not necessarily represent those of their affiliated organizations, or those of the publisher, the editors and the reviewers. Any product that may be evaluated in this article or claim that may be made by its manufacturer is not guaranteed or endorsed by the publisher.

Editor & Reviewers

Y L Yong Li Nanjing University of Science and Technology, China

https://loop.frontiersin.org/people/1161503

Reviewed by

X S Xunbing Shen Key Laboratory of Psychology of TCM and Brain Science, Jiangxi Administration of Traditional Chinese Medicine, Jiangxi University of Chinese Medicine, China

https://loop.frontiersin.org/people/326205

M Y Ming Yin Jiangsu Police Officer College, China

https://loop.frontiersin.org/people/584588

Frontiers' quality

How do we build trust in science?

Behind each Frontiers journal is an editorial board committed to upholding research integrity and scientific quality

https://www.frontiersin.org/about/quality

\[Published in Frontiers in Psychology

Human-Media Interaction

impact factor

citescore\](https://www.frontiersin.org/journals/psychology)

\[Part of a Research Topic Bridging the Gap between Machine Learning and Affective Computing

articles\](https://www.frontiersin.org/research-topics/19201/bridging-the-gap-between-machine-learning-and-affective-computing)

Article metrics

View details

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full#metrics

Download PDF

https://public-pages-files-2025.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/pdf

Download other formats

http://www.readcube.com/articles/10.3389/fpsyg.2021.784834

https://public-pages-files-2025.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/epub

https://public-pages-files-2025.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/xml

Cite article Share article

https://public-pages-files-2025.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/pdf

Download other format

http://www.readcube.com/articles/10.3389/fpsyg.2021.784834

https://public-pages-files-2025.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/epub

https://public-pages-files-2025.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/xml

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full#outline

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full#figures

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full#cite

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full#share

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full#metrics

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full#h1

1. Introduction

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full#s1

2. Action Units and Emotions

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full#s2

3. Complex Cortical Networks of Facial Movement

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full#s3

4. The Specificity of the Relationship Between Facial Muscle and Emotions

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full#s4

5. Emotion Label

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full#s5

6. Detection and Recognition of AU

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full#s6

7. Conclusion

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full#s7

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full#s10

Publisher's Note

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full#s11

Data availability statement

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full#h11

Author contributions

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full#h12

Acknowledgments

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full#h13

Conflict of interest

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full#h14

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full#h15

Figures and Tables

View in article

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full#F1

View in article

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full#F2

View in article

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full#F3

Algorithm 1

View in article

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full#tbl-no-id-79542624

Algorithm 2

View in article

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full#tbl-no-id-79542623

Table 1 Top 10 of AU's contribution to the six basic emotions (Method 1).

View in article

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full#T1

Table 2 Top 10 of AU's contribution to the six basic emotions (Method 2).

View in article

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full#T2

Table 3 The relationship between AU and emotion.

View in article

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full#T3

Copy to clipboard

Dong Z, Wang G, Lu S, Li J, Yan W and Wang S-J (2022) Spontaneous Facial Expressions and Micro-expressions Coding: From Brain to Face. Front. Psychol. 12:784834. doi: 10.3389/fpsyg.2021.784834

Copy citation

Export citation file

https://public-pages-files-2025.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/bibTex

https://public-pages-files-2025.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/endNote

Reference Manager

https://public-pages-files-2025.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/reference

Simple Text file

https://public-pages-files-2025.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/text

https://www.facebook.com/sharer/sharer.php?u=https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full

https://www.facebook.com/sharer/sharer.php?u=https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full

https://www.twitter.com/share?url=https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full

https://www.twitter.com/share?url=https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full

https://www.linkedin.com/share?url=https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full

https://www.linkedin.com/share?url=https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full

\[\](mailto:?subject=Interesting science article: Spontaneous Facial Expressions and Micro-expressions Coding: From Brain to Face&body=Hi!!%0D%0A%0D%0AI think you might find interesting the article "Spontaneous Facial Expressions and Micro-expressions Coding: From Brain to Face".%0D%0A%0D%0AYou can read more about it here: https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full)\[Email\](mailto:?subject=Interesting science article: Spontaneous Facial Expressions and Micro-expressions Coding: From Brain to Face&body=Hi!!%0D%0A%0D%0AI think you might find interesting the article "Spontaneous Facial Expressions and Micro-expressions Coding: From Brain to Face".%0D%0A%0D%0AYou can read more about it here: https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full)

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.784834/full

Author guidelines

https://www.frontiersin.org/guidelines/author-guidelines

Services for authors

https://www.frontiersin.org/for-authors/author-services

Policies and publication ethics

https://www.frontiersin.org/guidelines/policies-and-publication-ethics

Editor guidelines

https://www.frontiersin.org/guidelines/editor-guidelines

https://www.frontiersin.org/about/fee-policy

https://www.frontiersin.org/articles

Research Topics

https://www.frontiersin.org/research-topics

https://www.frontiersin.org/journals

How we publish

https://www.frontiersin.org/about/how-we-publish

Frontiers Forum

https://forum.frontiersin.org/

Frontiers Policy Labs

https://policylabs.frontiersin.org/

Frontiers for Young Minds

https://kids.frontiersin.org/

Frontiers Planet Prize

https://www.frontiersin.org/about/frontiers-planet-prize

Help center

https://helpcenter.frontiersin.org/

Emails and alerts

https://subscription-management.frontiersin.org/emails/preferences#block0

https://www.frontiersin.org/about/contact

https://www.frontiersin.org/submission/submit

Career opportunities

https://careers.frontiersin.org/

https://www.facebook.com/Frontiersin

https://twitter.com/frontiersin

https://www.linkedin.com/company/frontiers

https://www.instagram.com/frontiersin\_

© 2026 Frontiers Media SA. All rights reserved.

Privacy policy

https://www.frontiersin.org/legal/privacy-policy

Terms and conditions

https://www.frontiersin.org/legal/terms-and-conditions

Accessibility statement

https://www.frontiersin.org/about/accessibility-statement

Share on WeChat

Scan with WeChat to share this article

We use cookies

Our website uses cookies that are essential for its operation and additional cookies to track performance, or to improve and personalize our services. To manage your cookie preferences, please click Cookie Settings. For more information on how we use cookies, please see our

Cookie Policy

https://www.frontiersin.org/legal/privacy-policy

Cookies Settings Reject non-essential cookies Accept cookies

Privacy Preference Center

Our website uses cookies that are necessary for its operation. Additional cookies are only used with your consent. These cookies are used to store and access information such as the characteristics of your device as well as certain personal data (IP address, navigation usage, geolocation data) and we process them to analyse the traffic on our website in order to provide you a better user experience, evaluate the efficiency of our communications and to personalise content to your interests. Some cookies are placed by third-party companies with which we work to deliver relevant ads on social media and the internet. Click on the different categories' headings to change your cookie preferences. If you wish to learn more about how we use cookies, please see our cookie policy below.

Cookie Policy

https://www.frontiersin.org/legal/list-of-cookies

Manage Consent Preferences

Strictly Necessary Cookies

Always Active

These cookies are necessary for our websites to function as they enable you to navigate around the sites and use our features. They cannot be switched off in our systems. They are activated set in response to your actions such as setting your privacy preferences, logging-in or filling in forms. You can set your browser to block or alert you about these cookies, but some parts of the site will not then work.

Performance/Analytics Cookies

Performance/Analytics Cookies

These cookies allow us to collect information about how visitors use our website, including the number of visitors, the websites that referred them to our website, and the pages that they visited. We use them to compile reports, to measure and improve the performance of our website, analyze which pages are the most viewed, see how visitors move around the site and fix bugs. If you do not allow these cookies, your experience will not be altered but we will not be able to improve the performance and content of our website.

Targeting/Advertising Cookies

Targeting/Advertising Cookies

These cookies may be set by us to offer your personalized content and opportunities to cooperate. They may also be used by social media companies we work with to build a profile of your interests and show you relevant adverts on their services. They do not store directly personal information but are based on unique identifiers related to your browser and internet device. If you do not allow these cookies, you will experience less targeted advertising.

Cookie List

checkbox label label

Apply Cancel

Consent Leg.Interest

checkbox label label

checkbox label label

checkbox label label

Confirm My Choices

