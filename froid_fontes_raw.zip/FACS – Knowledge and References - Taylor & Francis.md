---
sourceFile: "FACS – Knowledge and References - Taylor & Francis"
exportedBy: "Kortex"
exportDate: "2026-06-29T01:00:27.853Z"
---

# FACS – Knowledge and References - Taylor & Francis

2fba9aca-890a-4fde-9976-8117eb74ce94

FACS – Knowledge and References - Taylor & Francis

07fdfaef-3ae7-48ae-be27-4d45ee1f0940

https://taylorandfrancis.com/knowledge/Engineering\_and\_technology/Biomedical\_engineering/FACS/

FACS – Knowledge and References – Taylor & Francis

Skip to content

https://taylorandfrancis.com/knowledge/Engineering\_and\_technology/Biomedical\_engineering/FACS/#content\_start

https://taylorandfrancis.com/contact/global-offices/

https://taylorandfrancis.com/africa/

https://china.taylorandfrancis.com/

https://taylorandfrancis.com/japan/

https://taylorandfrancis.com/mena/

https://taylorandfrancis.com/help/

https://taylorandfrancis.com/about/careers

https://taylorandfrancis.com/

Who we serve

https://taylorandfrancis.com/who-we-serve/

Expand submenu

https://taylorandfrancis.com/who-we-serve/academia/authors

Journal authors

https://taylorandfrancis.com/who-we-serve/academia/authors/journal-authors

Book authors

https://taylorandfrancis.com/who-we-serve/academia/authors/book-authors

Faculty/instructors

https://taylorandfrancis.com/who-we-serve/academia/lecturers

https://taylorandfrancis.com/who-we-serve/academia/librarians/

Journal editors

https://taylorandfrancis.com/who-we-serve/academia/journal-editors/

Industry & government

Practitioners

https://taylorandfrancis.com/who-we-serve/industry-government/practitioners

R&D professionals

https://taylorandfrancis.com/who-we-serve/industry-government/business

https://taylorandfrancis.com/partnership/commercial/publishing-services/

https://taylorandfrancis.com/who-we-serve/industry-government/government

Healthcare professionals

https://taylorandfrancis.com/who-we-serve/industry-government/healthcare

Marketing & brand managers

https://taylorandfrancis.com/who-we-serve/industry-government/marketing

https://taylorandfrancis.com/who-we-serve/partners/societies

Booksellers

https://taylorandfrancis.com/who-we-serve/partners/booksellers

https://taylorandfrancis.com/who-we-serve/partners/funders

https://taylorandfrancis.com/who-we-serve/partners/publishers/

https://taylorandfrancis.com/knowledge/

Expand submenu

Medicine & healthcare

https://taylorandfrancis.com/knowledge/medicine-healthcare/

https://taylorandfrancis.com/knowledge/humanities-and-social-sciences/education/

Business & management

https://taylorandfrancis.com/knowledge/humanities-and-social-sciences/business-management/

https://taylorandfrancis.com/knowledge/humanities-and-social-sciences/psychology/

Environmental sciences

https://taylorandfrancis.com/knowledge/science-technology/environmental-sciences/

https://taylorandfrancis.com/knowledge/science-technology/bioscience/

Computer & information sciences

https://taylorandfrancis.com/knowledge/science-technology/computer-information-sciences/

Mathematics

https://taylorandfrancis.com/knowledge/science-technology/mathematics/

Engineering

https://taylorandfrancis.com/knowledge/engineering/

https://taylorandfrancis.com/knowledge/engineering/civil-engineering/

https://taylorandfrancis.com/knowledge/engineering/electrical-engineering/

Industrial & manufacturing

https://taylorandfrancis.com/knowledge/engineering/industrial-manufacturing-engineering

https://taylorandfrancis.com/knowledge/engineering/mechanical-engineering/

Chemical engineering

https://taylorandfrancis.com/knowledge/engineering/chemical-engineering/

Automotive engineering

https://taylorandfrancis.com/knowledge/engineering/automotive-engineering/

Energy and oil

https://taylorandfrancis.com/knowledge/engineering/energy-oil/

Materials science research

https://taylorandfrancis.com/knowledge/engineering/material-science-engineering/

Explore our research portfolio

https://taylorandfrancis.com/knowledge/

Corporate solutions

https://taylorandfrancis.com/corporate-solutions/

Expand submenu

Pharmaceutical

https://taylorandfrancis.com/medical-publication-professionals/

https://taylorandfrancis.com/partnership/commercial/research-access/finance/

Materials sciences

https://taylorandfrancis.com/corporate-solutions/materials-science-research/

https://taylorandfrancis.com/partnership/commercial/research-access/technology/

https://taylorandfrancis.com/partnership/commercial/research-access/law/

Automotive engineering

https://taylorandfrancis.com/partnership/commercial/research-access/automotive-industry/

Chemical engineering

https://taylorandfrancis.com/partnership/commercial/research-access/chemical-engineering/

Energy and oil

https://taylorandfrancis.com/partnership/commercial/research-access/energy/

https://taylorandfrancis.com/partnership/commercial/research-access/defense/

Food science

https://taylorandfrancis.com/partnership/commercial/research-access/food-science/

https://newsroom.taylorandfrancisgroup.com/

Expand submenu

https://newsroom.taylorandfrancisgroup.com/

Insights, analysis, and blogs

https://insights.taylorandfrancis.com/

https://taylorandfrancis.com/events/

https://taylorandfrancis.com/about/

Expand submenu

https://taylorandfrancis.com/about/

https://taylorandfrancis.com/about/our-brands/

Executive leadership team

https://taylorandfrancis.com/about/executive-leadership-team/

Our history

https://taylorandfrancis.com/about/history/

https://taylorandfrancis.com/about/careers/

Our policies

https://taylorandfrancis.com/our-policies/

Open research

https://taylorandfrancis.com/openresearch/

Corporate responsibility

https://taylorandfrancis.com/about/corporate-responsibility/

Artificial intelligence (AI)

https://taylorandfrancis.com/about/ai/

https://taylorandfrancis.com/contact/global-offices/

https://taylorandfrancis.com/africa/

https://china.taylorandfrancis.com/

https://taylorandfrancis.com/japan/

https://taylorandfrancis.com/mena/

https://taylorandfrancis.com/help/

https://taylorandfrancis.com/about/careers

Publish with us

I want to publish

https://taylorandfrancis.com/knowledge/Engineering\_and\_technology/Biomedical\_engineering/FACS/

in a journal

https://taylorandfrancis.com/knowledge/Engineering\_and\_technology/Biomedical\_engineering/FACS/

#### To find out how to publish or submit your book proposal:

Go to Author Services >

#### To find a journal or submit your article to a journal:

Go to our journal suggester >

Facial Action Coding System (FACS) is a comprehensive and automatic anatomical system that encodes various facial movements by combining distinct basic Action Units (AUs) to measure changes in facial expressions during emotions. FACS widens the categories of emotions by providing a more detailed and nuanced understanding of facial expressions. From:

Artificial Intelligence and Global Society

https://www.routledge.com/Artificial-Intelligence-and-Global-Society-Impact-and-Practices/Kumar-Jain-Kumar/p/book/9781003006602

Micro Expression Recognition Using Delaunay Triangulation and Voronoi Tessellation

https://www.tandfonline.com/doi/10.1080/03772063.2022.2068680

Related Topics

https://taylorandfrancis.com/knowledge/Engineering\_and\_technology/Biomedical\_engineering/Anatomy

Emotion recognition

https://taylorandfrancis.com/knowledge/Engineering\_and\_technology/Artificial\_intelligence/Emotion\_recognition

Facial expression

https://taylorandfrancis.com/knowledge/Engineering\_and\_technology/Biomedical\_engineering/Facial\_expression

Facial muscles

https://taylorandfrancis.com/knowledge/Engineering\_and\_technology/Biomedical\_engineering/Facial\_muscles

Orbicularis oculi muscle

https://taylorandfrancis.com/knowledge/Engineering\_and\_technology/Biomedical\_engineering/Orbicularis\_oculi\_muscle

https://taylorandfrancis.com/knowledge/Engineering\_and\_technology/Biomedical\_engineering/Taxonomy

Zygomaticus major muscle

About this page

The research on this page is brought to you by Taylor & Francis Knowledge Centers. This collection is automatically generated from our most recent books and journals on this topic.

https://taylorandfrancis.com/

https://taylorandfrancis.com/knowledge/

Engineering and technology

https://taylorandfrancis.com/knowledge/Engineering\_and\_technology

Biomedical engineering

https://taylorandfrancis.com/knowledge/Engineering\_and\_technology/Biomedical\_engineering

Explore chapters and articles related to this topic

Emotion Recognition for Human Machine Interaction

View Chapter

https://doi.org/10.1201/9781003006602

Purchase Book

https://www.routledge.com/Artificial-Intelligence-and-Global-Society-Impact-and-Practices/Kumar-Jain-Kumar/p/book/9781003006602

Published in \[Puneet Kumar\](https://www.routledge.com/search?author=Puneet Kumar), \[Vinod Kumar Jain\](https://www.routledge.com/search?author=Vinod Kumar Jain), \[Dharminder Kumar\](https://www.routledge.com/search?author=Dharminder Kumar), Artificial Intelligence and Global Society, 2021

\[Maya Ingle\](https://www.routledge.com/search?author=Maya Ingle), \[Leena Bhole\](https://www.routledge.com/search?author=Leena Bhole)

The face is the most capable of expressing human emotion, and it plays a significant role in human emotion reflection and prediction. Facial Action Coding System (FACS) is the most comprehensive and automatic system for measuring the changes in facial expressions during emotions. These changes are tracked through automatic facial actions called as Action Units (AUs). These AUs help identify higher decision-making processes, including recognition of basic emotions \[17\]. This system has a 3D camera and Kinect device that capture facial images and form feature vectors with special coordinates of the face. Multilayer Perceptron neural network supports this system to recognize six basic emotions, achieving a 96% success rate \[1\]. The Viola Jones face detection method assists in building efficient emotion recognition system using k-NN classifier, gaining a 97% accuracy. Ada boost algorithm contributes to building an efficient classifier for facial expression to recognize emotion \[16\].

Face Expression Recognition using Side Length Features Induced by Landmark Triangulation

View Chapter

https://doi.org/10.1201/9780429061486

Purchase Book

https://www.routledge.com/Computational-Intelligence-for-Human-Action-Recognition/De-Dutta/p/book/9780429061486

Published in \[Sourav De\](https://www.routledge.com/search?author=Sourav De), \[Paramartha Dutta\](https://www.routledge.com/search?author=Paramartha Dutta), Computational Intelligence for Human Action Recognition, 2020

\[Nandi Avishek\](https://www.routledge.com/search?author=Nandi Avishek), \[Dutta Paramartha\](https://www.routledge.com/search?author=Dutta Paramartha), \[Nasir Md\](https://www.routledge.com/search?author=Nasir Md)

Affective analysis is one of the important aspects of Human-Computer Interaction(HCI) in the field of emotion analysis \[1\]. Automatic analysis of human emotions has many real-life applications in medical, computational and security and surveillance, monitoring systems, companion robotics, and mood-based suggestion systems. Some studies have found that among many different forms of human emotions the one emanating from the face has the highest power to differentiate one emotion from another. Thus, expression of the face contributes a significant amount of characteristic information for automated recognition of human emotions. To classify the different types of emotions, some sort of grouping of emotions in distinct classes is necessary. For this purpose, Ekman et al. proposed six classes of atomic emotions with a substantial difference in appearance and emotional quality: Anger(AN), Fear(FE), Disgust(DI), Sadness(SA), Happiness(HA), and Surprise(SU) \[2\]. Later they found that these six expression classes have almost the same arousal and variance characteristics among different sets of people from different geographical locations \[3\]. These six basic expressions are uniquely identifiable because a single class of emotion emulates a unique combination of muscular movement hence generating classifiable feature cues corresponding to that particular class of emotion. Another important consideration towards automatic facial expression recognition is that the quality of the detected feature plays an important role in the segregation of facial expression in different classes. The quality of facial feature descriptors is mainly hindered due to variation in camera angle, lighting conditions, low image resolution, low visibility conditions, head rotation, face occultation, etc. The primary challenge of the affective computing community is to design an efficient and effective affect descriptor that is independent of such conditions mentioned earlier. The design of an effective facial feature descriptor is an essential criterion for affect classification in a dynamically changing environment. Facial Action Coding System (FACS) is one of such systems which describes movement of facial muscles to classify each facial expression and effectively associate it to its respective expression class \[4\]. FACS is a powerful feature descriptor but Action Unit (AU) detectors of FACS suffer from misclassification in the case of occultation and pose variation. In contrast to FACS system, the geometric based methods directly use location and shape information of relevant facial components such as eyes, eyebrows, nose, and mouth to extract the emotion-related features from the face induced by location points which are fed into a classifier without any intermediate stage of Action Unit (AU) detection.

The frequency of facial muscles engaged in expressing emotions in people with visual disabilities via cloud-based video communication

View Article

https://www.tandfonline.com/doi/10.1080/1463922X.2022.2081374

Journal Information

https://www.tandfonline.com/journals/TTIE

Published in Theoretical Issues in Ergonomics Science, 2023

Hyung Nam Kim

The facial expressions were coded by using the Facial Action Coding System (FACS), that is, a comprehensive system to distinguish all possible visible anatomically based facial actions (Ekman and Friesen 1978; Ekman and Friesen 1976). The FACS helped to break down all visually discernible facial expressions into individual components of muscle movements, called Action Units. The Action Units cover various facial components (e.g., brows, eyelids, lips, head, nose, and cheeks). Statistical analyses were performed using the IBM SPSS Statistics for Macintosh, version 24 (IBM Corp 2016). The coding was accomplished by FACS coders who were trained based on the instructions of Cohn, Ambadar, and Ekman (2007) and competent with coding facial expressions using the FACS as shown in previous research (Kim and Sutharson 2022). The interrater reliability was also assessed using a subset (10%) of the total data (Geisler and Swarts 2019; Leclerc and Dassa 2009), e.g., a coder watched the sample of the facial expression videos and coded them for the presence of the FACS' Action Units. The interrater reliability for the coders was found to be k = 0.66 (95% CI: 0.32 to 1.00), p < .05, which is a substantial agreement according to Landis and Koch (1977).

Micro Expression Recognition Using Delaunay Triangulation and Voronoi Tessellation

View Article

https://www.tandfonline.com/doi/10.1080/03772063.2022.2068680

Journal Information

https://www.tandfonline.com/journals/TIJR

Published in IETE Journal of Research, 2022

Rashmi Adyapady R., B. Annappa

The FACS system designed by Paul Ekman helps to describe facial expressions by defining a set of atomic facial muscle actions known as AUs \[39\]. AUs play an essential role in finding the minute changes in facial movements and extracting meaningful feature information \[14\]. The presence of AUs and their combination together help discover the differences in muscle movements and further help to map into respective emotion classes. The facial actions describe the local variations on the face \[10\]. Each AU is coded based on the contraction of a single or group of muscles. Under distinct facial expressions, certain AUs show strong relationships \[14\]. FACS is an anatomical system that encodes various facial movements by combining distinct basic AUs, thus making the categories of emotions much wider. Since more attention needs to be paid to the research addressing the relationship between facial actions and emotion labels \[8\]. This work aims to examine the subtle facial feature difference that exists amongst the facial AUs, which could aid in classifying the expressions efficiently. Each AU contributes differently to the classification of facial expressions. Since it is tedious and challenging to generate facial representations for vast quantities of AUs \[8\], this work focuses on analyzing the AUs and finding the representations for AUs of only important facial regions that would strongly help for classification.

A survey on computer vision techniques for detecting facial features towards the early diagnosis of mild cognitive impairment in the elderly

View Article

https://www.tandfonline.com/doi/10.1080/21642583.2019.1647577

Journal Information

https://www.tandfonline.com/journals/TSSC

Published in Systems Science & Control Engineering, 2019

Zixiang Fei, Erfu Yang, David Day-Uei Li, Stephen Butler, Winifred Ijomah, Huiyu Zhou

Careful selection and extraction of facial features is extremely important, if inadequate features are selected, then even the best classifier cannot provide satisfying recognition results (Shan, Gong, & McOwan, 2009). Facial features selection is related to facial muscle action units (AU). Combination of a set of action units can make up different emotions. Although it could be argued that there are potentially thousands of facial expressions, most of them differ only slightly. In terms of categorization, Ekman and Friesen proposed the Facial Action Coding System (FACS), which is the most widely used system for facial expressions analysis (Ekman & Rosenberg, 2005). Within the Facial Action Coding System, facial expressions are made up of 46 action units (AU), with action units related to specific sets of facial muscles.

Scroll to Top

https://taylorandfrancis.com/knowledge/Engineering\_and\_technology/Biomedical\_engineering/FACS/#newtfg

Our company

https://taylorandfrancis.com/about/

Our leadership team

https://taylorandfrancis.com/about/executive-leadership-team/

https://taylorandfrancis.com/careers/

https://taylorandfrancis.com/contact/

Taylor & Francis Online

https://www.tandfonline.com/

Routledge.com

https://www.routledge.com/

Our policies

Privacy policy

https://www.informa.com/privacy-policy/

https://taylorandfrancis.com/cookies/

Terms and conditions

https://taylorandfrancis.com/terms-and-conditions/

Accessibility

https://taylorandfrancis.com/about/corporate-responsibility/accessibility-at-taylor-francis/

Modern slavery

https://www.informa.com/globalassets/documents/corporate-responsibility/informa-modern-slavery-statement-2019.pdf

Anti-bribery and corruption

https://www.informa.com/globalassets/documents/policies/inf\_anti-bribery-global-policy.pdf

Corporate responsibility

https://taylorandfrancis.com/about/corporate-responsibility/

Gender pay gap report

https://www.informa.com/uk-colleagues-and-pay-report-2020/

Code of conduct for conference proceedings

https://authorservices.taylorandfrancis.com/editorial-policies/code-of-conduct-for-conference-proceedings-organizers/

Information for

Book Authors

https://taylorandfrancis.com/who-we-serve/academia/authors/book-authors/

Journal Authors

https://taylorandfrancis.com/who-we-serve/academia/authors/journal-authors/

https://taylorandfrancis.com/who-we-serve/academia/librarians/

https://taylorandfrancis.com/who-we-serve/academia/journal-editors/

https://taylorandfrancis.com/who-we-serve/partners/societies/

Booksellers

https://taylorandfrancis.com/who-we-serve/partners/booksellers/

Press and media

https://newsroom.taylorandfrancisgroup.com/

Customer support

https://taylorandfrancis.com/help/

Rights and permissions

https://taylorandfrancis.com/corporate-solutions/solutions/

Royalty recipients

https://www.routledge.com/faqs/author-faqs/royalties

Taylor & Francis

https://www.linkedin.com/company/taylor-&-francis-group/

https://x.com/tandfonline

https://www.youtube.com/user/TaylorandFrancis

https://www.facebook.com/TaylorandFrancisGroup

https://www.linkedin.com/company/informa

https://x.com/informaplc

https://x.com/routledgebooks/

https://www.youtube.com/channel/UCmG1AOBM5fskgWhCG3i8bhA

© 2026 Informa plc.

Taylor & Francis is a division of Informa plc

Registered in England & Wales No. 3099067

5 Howick Place | London | SW1P 1WG

Insert/edit link

Enter the destination URL

Open link in a new tab

Or link to existing content

No search term specified. Showing recent items.

Search or use up and down arrow keys to select an item.

Notifications

This website processes personal data

https://transcend.io/

Do Not Sell My Personal Information

See our privacy policy

https://privacy.informa.com/trackers/en/

Switch language

