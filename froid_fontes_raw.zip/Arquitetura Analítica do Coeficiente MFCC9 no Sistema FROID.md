# Arquitetura Analítica do Coeficiente MFCC9 no Sistema FROID

Para dotar o FROID dos recursos analíticos mais modernos e garantir que sua arquitetura seja programada pela nossa elite de desenvolvedores com matemática física transparente, a extração do MFCC9 foge de qualquer padrão de "caixa-preta". Trata-se de um biomarcador acústico vital que captura microalterações fonéticas imperceptíveis na dinâmica neuromuscular do paciente \[1\], revelando de forma radiográfica o nível de ansiedade somática e tensão retida, especialmente quando isolado em discursos de valência neutra \[2\].

O cálculo matemático para a extração do Coeficiente Cepstral de Frequência Mel 9 (MFCC9) processa a voz através de uma análise homomórfica no domínio da "quefrequência" \[3, 4\]. Esse processo desmembra o som entre a excitação glótica (cordas vocais) e a ressonância do trato vocal (filtro anatômico), seguindo estas etapas e fórmulas:

\*\*1. Separação Fonte-Filtro (Domínio da Frequência):\*\*
O sinal de voz janelado é convertido para o domínio da frequência utilizando a Transformada Discreta de Fourier (DFT) \[5\]. A magnitude do espectro divide o sinal acústico total $S(j\omega)$ em seus dois componentes estruturais: a excitação de origem $E(j\omega)$ e as propriedades do filtro do trato vocal $V(j\omega)$ \[6\]:
$$|S(j\omega)| = |E(j\omega)| \cdot |V(j\omega)|$$ \[6\].

\*\*2. Mapeamento para a Escala Mel:\*\*
A magnitude do espectro resultante passa por um banco de filtros triangulares, mapeando as frequências lineares (Hz) para um formato não-linear que espelha as propriedades de resposta fisiológica auditiva humana \[7, 8\]. A equação de conversão de Hertz ($f\_l$) para a escala Mel é \[8\]:
$$mel = 1127.01048 \ln\left( \frac{f\_l}{700} + 1 \right)$$ \[8\].

\*\*3. Separação Homomórfica (Aplicação do Logaritmo):\*\*
Para separar linearmente as características de ressonância do trato vocal da excitação glótica (cujos valores se multiplicavam no espectro de potência original), aplica-se o logaritmo nas saídas do banco de filtros Mel \[6, 8\]. Esta etapa transforma a multiplicação em uma soma:
$$\log |S(j\omega)| = \log |E(j\omega)| + \log |V(j\omega)|$$ \[3\].

\*\*4. Extração Final com a Transformada Cosseno Discreta (DCT):\*\*
Finalmente, as saídas logarítmicas são descorrelacionadas aplicando-se a Transformada Cosseno Discreta (DCT), em substituição à Transformada Inversa de Fourier (IFT) que era utilizada tradicionalmente para o Cepstrum \[8\]. 

\*\*A Extração Numérica do MFCC9:\*\*
Desta matriz transformada (DCT), o algoritmo retém tipicamente apenas do 1º ao 13º componente, pois coeficientes de ordem mais alta perdem a informação rápida do trato vocal e representam mais a fonte do sinal bruto \[8\]. 

O \*\*MFCC9\*\* é matematicamente o \*\*9º coeficiente obtido após a aplicação da DCT\*\* sobre o espectro de escala Mel logarítmico \[1, 8\]. 

Dentro do motor algorítmico do FROID, esse resultado passa a ser um indicador direto da exaustão humana e disfunção do sistema nervoso. O sistema rastreia o MFCC9 sabendo que ele possui uma correlação matemática inversa (negativa) de $r = -0.34$ em relação à ansiedade somática \[2\]. Em termos práticos preditivos, na regressão linear da nossa IA, este 9º coeficiente atua como variável independente ($\beta = -0.45$, $p = 0.049$) para extrair objetivamente a subescala de ansiedade/somatização clínica de um paciente (escala HAMD) \[9\]. 

Para cruzar essas informações nas timelines interativas de 500ms do dashboard FROID, os programadores também podem aplicar equações da primeira e segunda derivada (MFCC delta), extraindo a aceleração dessa tensão neuromuscular no tempo:
$$\Delta MFCC\_9(n) = MFCC\_9(n) - MFCC\_9(n-1)$$ \[10, 11\].