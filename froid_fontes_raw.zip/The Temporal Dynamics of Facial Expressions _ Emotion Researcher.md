---
sourceFile: "The Temporal Dynamics of Facial Expressions | Emotion Researcher"
exportedBy: "Kortex"
exportDate: "2026-06-29T01:00:28.772Z"
---

# The Temporal Dynamics of Facial Expressions | Emotion Researcher

60c665d9-7519-42af-a7a8-da64f9b24298

The Temporal Dynamics of Facial Expressions | Emotion Researcher

2e3b2487-94fc-4846-9efe-b4ba60013f1b

https://emotionresearcher.com/the-temporal-dynamics-of-facial-expressions/

The Temporal Dynamics of Facial Expressions | Emotion Researcher

Skip to content

https://emotionresearcher.com/the-temporal-dynamics-of-facial-expressions/#content

#### Search for:

Emotion Researcher

https://emotionresearcher.com/

ISRE's Sourcebook for Research on Emotion and Affect

http://emotionresearcher.com/

https://emotionresearcher.com/the-temporal-dynamics-of-facial-expressions/

Stephen Fineman

https://emotionresearcher.com/getting-critical-about-emotion/

Michael Brady

https://emotionresearcher.com/emotional-insight-and-the-virtues-of-suffering/

Carolyn Zahn-Waxler

https://emotionresearcher.com/a-researcher-who-found-herself/

Ronald de Sousa

https://emotionresearcher.com/the-rationality-of-emotion-biology-ideology-and-emotional-truth/

Joseph Campos

https://emotionresearcher.com/from-goats-to-aardvarks-the-journey-of-a-functionalist-researcher-of-emotion/

James Averill

https://emotionresearcher.com/the-social-construction-of-emotion-myths-and-realities/

Martha Nussbaum

https://emotionresearcher.com/on-anger-disgust-love/

Jim Russell

https://emotionresearcher.com/the-circumplex-and-the-psychological-construction-of-emotions/

Jennifer Lerner

https://emotionresearcher.com/how-cognition-became-hot-emotions-decisions-and-policy-making/

Justin D'Arms

https://emotionresearcher.com/on-how-emotions-ground-sentimental-values-with-implications-for-affective-science/

Phoebe Ellsworth

https://emotionresearcher.com/phoebe-ellsworth-on-appraisal-theory-and-the-use-of-social-psychology-in-the-law/

Klaus Scherer

https://emotionresearcher.com/the-component-process-model-of-emotion-and-the-power-of-coincidences/

Lisa Feldman Barrett

https://emotionresearcher.com/lisa-feldman-barrett-why-emotions-are-situated-conceptualizations/

Nico Frijda

https://emotionresearcher.com/interview-with-nico-frijda/

https://emotionresearcher.com/an-audio-interview-with-paul-ekman/

https://emotionresearcher.com/interview-with-joe-ledoux/

https://emotionresearcher.com/the-temporal-dynamics-of-facial-expressions/

https://emotionresearcher.com/the-temporal-dynamics-of-facial-expressions/

Grief and the Significance of Loss

https://emotionresearcher.com/grief-and-the-significance-of-loss/

PDF of Grief Issue (December 2024)

http://emotionresearcher.com/wp-content/uploads/2024/12/Emotion-Researcher\_Grief\_Issue\_December\_2024.pdf

2022 ISRE Dissertation Awards

https://emotionresearcher.com/the-temporal-dynamics-of-facial-expressions/

Identity Sentiments and Emotion Signals in Contemporary Relationships

https://emotionresearcher.com/identity-sentiments-and-emotion-signals-in-contemporary-relationships-modeling-relational-change-through-affective-expectation/

Linguistic Distancing and Emotion Regulation

https://emotionresearcher.com/linguistic-distancing-and-emotion-regulation-theoretical-developmental-and-translational-perspectives/

“No fair!”: An investigation of children's development of fairness

https://emotionresearcher.com/no-fair-an-investigation-of-childrens-development-of-fairness/

PDF of 2022 ISRE Dissertation Award Finalists Issue (June 2023)

http://emotionresearcher.com/wp-content/uploads/2023/06/Emotion-Researcher-June-2023.pdf

Emotions and Feeling

https://emotionresearcher.com/the-temporal-dynamics-of-facial-expressions/

A Science of Emotion without Feelings

https://emotionresearcher.com/a-science-of-emotion-without-feelings/

Emotion Recognition ≠ Emotion Understanding: Challenges Confronting the Field of Affective Computing

https://emotionresearcher.com/emotion-recognition-emotion-understanding-challenges-confronting-the-field-of-affective-computing/

Feelings, and the Multicomponential Approach to Emotions

https://emotionresearcher.com/feelings-and-the-multicomponential-approach-to-emotions/

PDFs of Emotion and Feeling Issue (February 2022)

http://emotionresearcher.com/wp-content/uploads/2022/02/Emotion-Researcher-February-2022.pdf

Emotion and Memory

https://emotionresearcher.com/the-temporal-dynamics-of-facial-expressions/

Emotions and Memory

https://emotionresearcher.com/emotions-and-memory/

The Development of an Emotional Self-concept through Narrative Reminiscing

https://emotionresearcher.com/the-development-of-an-emotional-self-concept-through-narrative-reminiscing/

Multiple Routes to Emotional Memories in the Brain

https://emotionresearcher.com/multiple-routes-to-emotional-memories-in-the-brain/

PDFs of Emotion and Memory Issue (February 2021)

http://emotionresearcher.com/wp-content/uploads/2021/02/Emotion-Researcher-February-2021.pdf

https://emotionresearcher.com/the-temporal-dynamics-of-facial-expressions/

Tacit Creationism in Emotion Research

https://emotionresearcher.com/tacit-creationism-in-emotion-research/

Sexual Disgust: An Evolutionary Perspective

https://emotionresearcher.com/sexual-disgust-an-evolutionary-perspective/

Internalized Norms and Intrinsic Motivations: Are Normative Motivations Psychologically Primitive?

https://emotionresearcher.com/internalized-norms-and-intrinsic-motivations-are-normative-motivations-psychologically-primitive/

PDFs of Evolution Issue (June 2020)

http://emotionresearcher.com/wp-content/uploads/2020/06/Emotion-Researcher-June-2020.pdf

https://emotionresearcher.com/the-temporal-dynamics-of-facial-expressions/

Anger and Politics

https://emotionresearcher.com/anger-and-politics/

Anger is a Positive Emotion – At Least for Those who Show it

https://emotionresearcher.com/anger-is-a-positive-emotion-at-least-for-those-who-show-it/

On the Ethics of Anger

https://emotionresearcher.com/on-the-ethics-of-anger/

Anger and Anthropology

https://emotionresearcher.com/anger-and-anthropology/

PDFs of Anger Issue (August 2019)

http://emotionresearcher.com/wp-content/uploads/2019/09/Emotion-Researcher-August-2019.pdf

Emotions and Health

https://emotionresearcher.com/the-temporal-dynamics-of-facial-expressions/

Assessing and Understanding the Role of Everyday Emotion and Affect in Relation to Stress and Health

https://emotionresearcher.com/assessing-and-understanding-the-role-of-everyday-emotion-and-affect-in-relation-to-stress-and-health/

The Politics of Well-being and Ecstasy

https://emotionresearcher.com/the-politics-of-well-being-and-ecstasy/

PDFs of Emotion and Health Issue (November 2018)

http://emotionresearcher.com/wp-content/uploads/2018/11/Emotion-Researcher-November-2018.pdf

Emotions in History

https://emotionresearcher.com/the-temporal-dynamics-of-facial-expressions/

Historicizing Emotions

https://emotionresearcher.com/historicizing-emotions/

Old and New in the History of Emotions

https://emotionresearcher.com/old-and-new-in-the-history-of-emotions/

Emotions in History: The Beginnings

https://emotionresearcher.com/emotions-in-history-the-beginnings/

On the Emotional Turn in the History of Early Modern Philosophy

https://emotionresearcher.com/on-the-emotional-turn-in-the-history-of-early-modern-philosophy/

PDFs of Emotions in History Issue (March 2018)

http://emotionresearcher.com/wp-content/uploads/2018/03/Emotion-Researcher-March-2018.pdf

Understanding Empathy

https://emotionresearcher.com/the-temporal-dynamics-of-facial-expressions/

Derek Matravers

https://emotionresearcher.com/recent-work-in-the-philosophy-of-empathy/

Alexandra Main

https://emotionresearcher.com/empathy-and-its-development-what-is-missing/

Jodi Halpern

https://emotionresearcher.com/the-therapeutic-effects-of-empathy-in-healthcare/

PDFs of Understanding Empathy Issue (July 2017)

http://emotionresearcher.com/wp-content/uploads/2017/07/Emotion-Researcher-July-2017.pdf

Emotions and Politics

https://emotionresearcher.com/the-temporal-dynamics-of-facial-expressions/

George Marcus

https://emotionresearcher.com/how-affective-intelligence-theory-can-help-us-understand-politics/

Jason Brennan

https://emotionresearcher.com/politics-makes-us-mean-and-dumb/

Kathleen Searles & Travis Ridout

https://emotionresearcher.com/the-use-and-consequences-of-emotions-in-politics/

Samuel Justin Sinclair et al.

https://emotionresearcher.com/3162-2/

PDFs of Emotions and Politics Issue (February 2017)

http://emotionresearcher.com/wp-content/uploads/2017/02/Final-PDFs-of-Emotions-and-Politics-Issue-February-2017.pdf

Emotions and Law

https://emotionresearcher.com/the-temporal-dynamics-of-facial-expressions/

Susan Bandes

https://emotionresearcher.com/what-roles-do-emotions-play-in-the-law/

Terry Maroney

https://emotionresearcher.com/emotion-in-the-behavior-and-decision-making-of-jurors-and-judges/

Sam Pillsbury

https://emotionresearcher.com/emotion-and-criminal-punishment-in-principle-and-in-practice/

Eyal Aharoni & Nicole Vincent

https://emotionresearcher.com/psychopathic-brains-on-trial/

PDFs of Emotions and Law Issue (Oct 2016)

http://emotionresearcher.com/wp-content/uploads/2016/10/Final-PDFs-of-Emotions-and-Law-Issue-October-2016.pdf

Understanding Guilt

https://emotionresearcher.com/the-temporal-dynamics-of-facial-expressions/

Michael Lewis

https://emotionresearcher.com/the-development-of-guilt-as-repair-in-childhood/

Michael Ent & Roy Baumeister

https://emotionresearcher.com/the-functions-of-guilt/

Cailin O'Connor

https://emotionresearcher.com/guilt-games-and-evolution/

Michael Deem & Grant Ramsey

https://emotionresearcher.com/the-evolutionary-puzzle-of-guilt-individual-or-group-selection/

PDFs of Guilt Issue (May 2016)

http://emotionresearcher.com/wp-content/uploads/2016/05/Final-PDFs-of-Guilt-Issue-May-2016.pdf

Understanding Love

https://emotionresearcher.com/the-temporal-dynamics-of-facial-expressions/

Elaine Hatfield & Richard Rapson

https://emotionresearcher.com/passionate-love-the-forgotten-emotion/

Stephanie Cacioppo

https://emotionresearcher.com/neural-markers-of-interpersonal-attraction-a-possible-new-direction-for-couples-therapy/

Michael Numan

https://emotionresearcher.com/brain-circuits-for-parental-behavior-and-love-with-implications-for-other-social-bonds/

Berit Brogaard

https://emotionresearcher.com/does-true-love-need-to-be-unconditional/

PDFs of Love Issue (January 2016)

http://emotionresearcher.com/wp-content/uploads/2016/01/Final-PDFs-Love-Issue-january-2016.pdf

Facial Expressions

https://emotionresearcher.com/the-temporal-dynamics-of-facial-expressions/

Dacher Keltner and Daniel Cordaro

https://emotionresearcher.com/understanding-multimodal-emotional-expressions-recent-advances-in-basic-emotion-theory/

Alan Fridlund

https://emotionresearcher.com/the-behavioral-ecology-view-of-facial-displays-25-years-later/

Jim Russell

https://emotionresearcher.com/moving-on-from-the-basic-emotion-theory-of-facial-expressions/

Debate: Keltner and Cordaro vs. Fridlund vs. Russell

https://emotionresearcher.com/the-great-expressions-debate/

PDFs of Facial Expressions Issue (August 2015)

http://emotionresearcher.com/wp-content/uploads/2015/08/Final-PDFs-of-Facial-Expressions-Issue-August-2015.pdf

Emotional Intelligence

https://emotionresearcher.com/the-temporal-dynamics-of-facial-expressions/

Neal Ashkanasy & Marie Dasborough

https://emotionresearcher.com/reintroducing-emotional-intelligence-what-it-is-and-where-we-stand-now/

John Antonakis

https://emotionresearcher.com/emotional-intelligence-the-hype-the-hope-the-evidence/

Dana Joseph and Daniel Newman

https://emotionresearcher.com/emotional-intelligence-some-research-findings-and-remaining-questions/

Moïra Mikolajczak & Ainize Peña-Sarrionandia

https://emotionresearcher.com/on-the-efficiency-of-emotional-intelligence-training-in-adulthood/

Q & A On Emotional Intelligence With John (Jack) D. Mayer

https://emotionresearcher.com/q-a-on-emotional-intelligence-with-john-jack-d-mayer/

PDFs of Emotional Intelligence Issue (March 2015)

http://emotionresearcher.com/wp-content/uploads/2015/03/Final-PDFs-of-Emotional-Intelligence-Issue-March-2015-.pdf

Musical Emotions

https://emotionresearcher.com/the-temporal-dynamics-of-facial-expressions/

Patrik Juslin

https://emotionresearcher.com/music-and-emotion-there-is-more-to-music-than-meets-the-ear/

Jenefer Robinson

https://emotionresearcher.com/how-music-grabs-the-emotions/

Judith Becker

https://emotionresearcher.com/musical-emotions-across-cultures/

Patrik Vuilleumier

https://emotionresearcher.com/musical-emotions-in-the-brain/

PDFs of Musical Emotions Issue (Nov 2014)

http://emotionresearcher.com/wp-content/uploads/2014/11/PDFs-of-Musical-Emotions-Issue-Nov-2014.pdf

Emotions and Social Engagement

https://emotionresearcher.com/the-temporal-dynamics-of-facial-expressions/

https://emotionresearcher.com/open-to-culture-emotions-in-development/

Brian Parkinson

https://emotionresearcher.com/how-emotions-affect-other-people/

Kathryn Lively

https://emotionresearcher.com/the-sociology-of-emotion-emotion-as-both-social-object-and-social-force/

Achim Stephan & Sven Walter

https://emotionresearcher.com/the-situated-perspective-on-emotions-a-philosophical-roadmap/

PDFs of Emotions and Social Engagement Issue (August 2014)

http://emotionresearcher.com/wp-content/uploads/2014/03/Emotions-and-Social-Engagement-Issue-August-2014-Unformatted-PDFs.pdf

Understanding Disgust

https://emotionresearcher.com/the-temporal-dynamics-of-facial-expressions/

https://emotionresearcher.com/on-the-origin-of-disgust/

Paul Rozin & Jonathan Haidt

https://emotionresearcher.com/on-the-expansion-of-disgust/

Joshua Tybur & Debra Lieberman

https://emotionresearcher.com/evaluating-distinct-evolutionary-theories-of-disgust/

Roger Giner-Sorolla & Lasana Harris

https://emotionresearcher.com/the-negative-side-of-disgust/

Jason Clark & Philip Powell

https://emotionresearcher.com/why-disgust-is-morally-beneficial/

PDFs of Disgust Issue (March 2014)

http://emotionresearcher.com/wp-content/uploads/2014/04/Understanding-Disgust-Issue-March-2014-Unformatted-PDFs.pdf

The Emotional Brain

https://emotionresearcher.com/the-temporal-dynamics-of-facial-expressions/

Jaak Panksepp

https://emotionresearcher.com/the-emotional-brain/panksepp/

Kristen Lindquist

https://emotionresearcher.com/the-emotional-brain/lindquist/

Luiz Pessoa

https://emotionresearcher.com/the-emotional-brain/pessoa/

Stephan Hamann

https://emotionresearcher.com/the-emotional-brain/hamann/

PDFs of Emotional Brain Issue (Dec 2013)

http://emotionresearcher.com/wp-content/uploads/2014/04/Emotional-Brain-Issue-Dec-2013-Unformatted-PDFs.pdf

https://emotionresearcher.com/the-temporal-dynamics-of-facial-expressions/

https://emotionresearcher.com/semantic-spaces-big-data-and-ai-in-emotion-science/

Luca Barlassina

https://emotionresearcher.com/valence-a-reflection/

Jozefien De Leersnyder

https://emotionresearcher.com/a-socio-cultural-fit-perspective-on-emotions/

Jessica Lougheed

https://emotionresearcher.com/a-dynamic-systems-perspective-of-emotion-in-the-parent-adolescent-relationship/

Amrisha Vaish

https://emotionresearcher.com/social-emotions-and-their-prosocial-functions-in-early-childhood/

Alfred Archer

https://emotionresearcher.com/admiring-the-immoral/

Nina Strohminger

https://emotionresearcher.com/four-unwarranted-assumptions-about-the-role-of-emotion-in-moral-judgment/

Michael Kraus

https://emotionresearcher.com/the-roles-of-emotions-in-social-hierarchies/

Eva Krumhuber

https://emotionresearcher.com/the-temporal-dynamics-of-facial-expressions/

June Gruber

https://emotionresearcher.com/are-positive-emotions-always-good-for-you/

Piercarlo Valdesolo

https://emotionresearcher.com/on-emotions-and-their-role-in-morality/

Rachael Jack

https://emotionresearcher.com/face-as-dynamic-communication-tool/

https://emotionresearcher.com/disgust-racism-and-the-moral-conventional-distinction/

Maïa Ponsonnet

https://emotionresearcher.com/maia-ponsonnet-aboriginal-languages-emotional-experience-and-the-linguistic-representation-of-emotions/

Gerben A. Van Kleef

https://emotionresearcher.com/gerben-a-van-kleef-exploring-the-social-nature-of-emotion/

Giovanna Colombetti

https://emotionresearcher.com/get-to-know-giovanna-colombetti/

https://emotionresearcher.com/spotlight/mauss/

https://emotionresearcher.com/the-temporal-dynamics-of-facial-expressions/

https://emotionresearcher.com/about-isre/

https://emotionresearcher.com/contact-the-editor/

How To Cite ER

https://emotionresearcher.com/how-to-cite-er/

https://emotionresearcher.com/emotion-researcher-privacy-policy/

Table of Contents

https://emotionresearcher.com/table-of-contents/

The Temporal Dynamics of Facial Expressions

https://emotionresearcher.com/#facebook

https://emotionresearcher.com/#twitter

https://emotionresearcher.com/#tumblr

https://emotionresearcher.com/#email

Eva Krumhuber, Division of Psychology and Language Sciences, University College London

https://www.ucl.ac.uk/pals/research/experimental-psychology/person/eva-krumhuber/

Or Why Martin Scorsese Didn't Look Happy During the 2003 Oscars Ceremony

October 2016 – Join me in exploring one of the most extraordinary aspects of human life: the ability to express emotions. As a social species, we have developed rich capacities to interact with each other. From our earliest age, social relationships dominate our lives and contribute to making us who we are. Ingrained with the need for social connection (Baumeister & Leary, 1995), emotions help us to communicate with others, judge their intentions and negotiate our behavioral responses. What seems like an effortless skill involves a range of complex and relational processes (Kappas & Descóteaux, 2003). A particularly intricate aspect of human communication is its dynamic nature: rather than being like a single snapshot, emotional expressions change over time in response to information dynamically gleaned from the environment. As we cannot press a 'Pause' button to capture another's emotional expression in a vacuum, we need to learn how to interpret expressions in their changing context.

Unfortunately, this temporal quality of facial displays has been frequently overlooked in emotion research, most of which has relied on the use of still images or photographs. Such stimuli often consist of actors portraying high-intensity emotions based on pre-defined and stereotypical patterns of facial actions (i.e.,

Pictures of Facial Affect

http://www.paulekman.com/product/pictures-of-facial-affect-pofa/

by Ekman & Friesen, 1976;

NimStim Set of Facial Expressions

http://www.macbrain.org/resources.htm

by Tottenham et al., 2009;

Karolinska Directed Emotional Faces

http://www.emotionlab.se/resources/kdef

by Goeleven, de Raedt, Leyman, & Verschuere, 2008). These commonly include the basic six emotions of happiness, anger, fear, sadness, disgust and surprise. Whilst static prototypes are well recognized due to their simplified and amplified nature, they hardly ever occur in real life. In addition, they impose a standard where correct emotion classification consists of the assignment of emotion category labels as intended by the researcher. This approach targets mainly questions about what the facial expression is

to portray, rather than what we

think that the person felt at the moment of the expression.

The latter aspect is particularly intriguing. Is it possible to 'recognize' an expression as the prototypical exemplar of a particular emotion, and yet have the impression that the person is feeling something different? Take the smile which is undoubtedly classified universally as a happy expression (Russell, 1994). Yet we all know that not all smiles are happy; they can be put on in the absence of any such positive emotion (i.e., politeness, appeasement) or to conceal negative feelings/motives (i.e., embarrassment, contempt, dominance; Ambadar, Cohn, & Reed, 2009; Niedenthal, Mermillod, Maringer, & & Hess, 2010).

In order to distinguish between so-called 'genuinely felt' and 'unfelt/false' smiles (see Fridlund, 1994, for a different conceptualisation), Ekman and Friesen (1982) suggested several behavioral indicators. The most well-known of these is the Duchenne marker, which is indicated by a crinkling of the skin around the eyes and is said to accompany or constitute a genuine, happiness-expressing smile (Ekman, Davidson, & Friesen, 1990). Much previous work has shown that we tend to perceive such a smile as expressing a felt positive emotion (e.g., Frank, Ekman, & Friesen, 1993; Krumhuber, Likowski, & Weyers, for a meta-analysis see Gunnery & Ruben, 2016).

In my own research, I wanted to find out whether this impression could change when dynamic information is added. To illustrate this idea, an example from Hollywood might prove valuable. At the Oscars ceremony in 2003, one of the favorites for the award of best director was Martin Scorsese for his epic drama 'Gangs of New York'. The film was nominated in 10 categories, making it likely that Scorsese would walk home with several golden statues. When Roman Polanski was announced as the winner of the award for best director, Scorsese's response was that of fierce disappointment, up until the moment when he realized that he was on camera. If you watch the video, you can see his expression change within milliseconds of the announcement to that of a happy smile (see 1m 06s).

Tap to unmute

Your browser can't play this video.

https://www.youtube.com/supported\_browsers

https://www.youtube.com/

An error occurred.

Try watching this video on www.youtube.com

https://www.youtube.com/watch?v=PXnNOBj26lk

, or enable JavaScript if it is disabled in your browser.

One could debate whether his smile is a Duchenne smile (see Gunnery & Hall, 2014; Krumhuber & Manstead, 2009, for evidence questioning the reliability of the Duchenne marker as a true indicator of happiness). Martin Scorsese's motivations here are obviously complex. Based on the speed with which his smile unfolds, however, it seems improbable that happiness would have been high on his list of priorities! It simply looks too quick to reflect genuinely felt enjoyment of his rival's success.

In an attempt to test whether the perception of Martin's dynamic smile relates to a more general phenomenon, I created video-clips of smile expressions that systematically differed in the duration with which they unfolded (onset), peaked at their apex, or returned from peak to neutral (offset; based on Ekman & Friesen, 1982). When I showed them to people and asked them to rate how genuine they thought the smiles were, their ratings systematically varied with the dynamic trajectory of the smiles. Specifically, smiles that unfolded quickly (that is, those with a short onset) and disappeared abruptly (those with a short offset) made the target's smile appear less authentic and less believable (Krumhuber & Kappas, 2005). These 'dynamic fake' smiles also led people to assign lower ratings of trustworthiness, attractiveness, and flirtatiousness to the smiling person (Krumhuber, Manstead, & Kappas, 2007).

In subsequent work, I found that dynamic information affects people's decisions and behavioral intentions. For example, using a simulated job interview scenario, interviewees displaying smiles with long onset and offset durations were evaluated higher on job-related traits such as competence and motivation, and judged to be more likely to be short-listed and selected for a job (Krumhuber, Manstead, Cosker, Marshall, & Rosin, 2009). Furthermore, people were more likely to trust and cooperate with others in economic games when they displayed such dynamic authentic smiles rather than neutral expressions or dynamic fake smiles (Krumhuber, Manstead, Cosker, Marshall, Rosin, & Kappas, 2007).

From these findings two conclusions can be drawn: First, people go beyond what is stereotypically recognized or thought of as an emotion. This suggests that the perception of visual properties of an expression (e.g. smiling mouth, Duchenne marker) is distinct from the perception of affect-specific information about what the sender really feels. Hence, emotion recognition (i.e. accurate classification) does not equal emotion interpretation; a crucial distinction that is missing in Basic Emotion Theory which assumes a direct link between expressive physical features and affective states (Calvo & Nummenmaa, 2016). Second, the dynamic quality of facial displays is used in the course of their display to discern the affective meaning of expressions (i.e. internal states of the expresser).

In line with work from other research labs over the past few years, there is much evidence to suggest that facial motion provides information over and above that contained in static emotional displays (for a review on the effects of dynamic aspects of facial expressions, see Krumhuber, Kappas, & Manstead, 2013; Krumhuber & Skora, in press). In addition to the speed with which parts of the face move, the temporal sequence of facial expressions is a critical factor in the expression of emotion. This aspect is particularly acknowledged by componential theories of emotions (Smith & Scott, 1997) which regard individual elements of expressions as emerging dynamic properties. Studies that have applied a fine-grained behavioral analysis to the time course of expressions (using the Facial Action Coding System, Ekman, Friesen, & Hager, 2002) suggest that facial actions indeed unfold sequentially and converge toward the apex in an asynchronous manner (Fiorentini, Schmidt, & Viviani, 2012; Krumhuber & Scherer, 2011; With & Kaiser, 2011). Furthermore, such sequential temporal patterns shape emotion judgements made by observers (Jack, Garrod, & Schyns, 2014; Krumhuber & Scherer, 2016). There is more work to be done in this area, much of which will be achieved using machine recognition to extract the dynamic structure of facial expressions (Pantic, 2009).

For the foreseeable future, facial motion promises to remain a topic of scientific interest. With computing entering the social domain, it is possible to communicate not only with other human beings, but increasingly artificial entities. These can be computer-animated characters (e.g. Lara Croft, Shodan, Master Chief), robots (e.g. Ishiguro's

http://www.geminoid.jp/en/index.html

http://www.hansonrobotics.com/robot/albert-einstein-hubo/

, Breazeal's

https://en.wikipedia.org/wiki/Kismet\_(robot)

) or even virtual agents (e.g. Pelachaud's

http://perso.telecom-paristech.fr/~pelachau/Greta/

http://ict.usc.edu/prototypes/simcoach/

). Whether embodied or digital, their appearance and life-like demeanor is becoming more and more realistic (Küster, Krumhuber, & Kappas, 2014). To gain users' acceptance, our responses are likely to be guided by the relevant social cues they produce. Facial expressions are an essential ingredient in revealing a character's personality, thoughts, and feelings. However, only if they appear convincing and authentic will we feel comfortable in interaction.

From previous research, we know that people's affinity to artificial entities may not linearly increase with the degree of human-likeness (MacDorman, Green, Ho, & Koch, 2009). That is, more humanlike appearance does not always lead to more favorable evaluations. In fact, such characters can be subject to the so-called 'Uncanny Valley' effect (Mori, 2012) when their appearance falls short of emulating those of actual human beings. As a result, imperfections of human appearance can become 'uncanny' and repulsive. Classic examples of this can be found in CGI-heavy animated films such as

The Polar Express

http://www.imdb.com/title/tt0338348/

The Final Fantasy: The Spirits Within

http://www.imdb.com/title/tt0173840/

, which many viewers find disturbing and off-putting due to their 'creepy' characters (e.g., Geller, 2008). This mismatch between appearance and behavior is particularly evident when movement is involved, which can violate perceptual expectations (Saygin, Chaminade, Ishiguro, Driver, & Frith, 2012). To avoid potential pitfalls, it will be important to establish how emotions should be expressed if we are to create emotionally-appealing and usable systems. The temporal features of facial expressions can provide crucial insight into this process by allowing us to infer not only the presence of an emotional signal but also its meaning.

Are you interested in dynamic facial expression research?

Would you like to use dynamic expressions in your own research? Not sure where to find the appropriate stimuli? In a forthcoming article to be published in

Emotion Review

, we (Krumhuber, Skora, Küster, & Fou) provide a systematic overview of 22 publically-available databases of dynamic facial expressions and compare their conceptual and practical features, which can provide guidance as to which database to use.

If you want to create your own dynamic stimuli using easy-to-use facial animation software, you can use FACSGen 2.0 (Krumhuber, Tamarit, Roesch, & Scherer, 2012), which allows the production of static and dynamic facial expressions based on the Facial Action Coding System (FACS, Ekman, Friesen, & Hager, 2002). Unfortunately, due to ongoing licensing issues, the software is currently not publicly available. For updates on the software's availability, please contact David Sander (

david.sander@unige.ch

mailto:david.sander@unige.ch

) or Didier Grandjean (

Didier.grandjean@unige.ch

mailto:Didier.grandjean@unige.ch

For readers with more advanced technical skills (e.g. computer scientists or engineers), the D3DFACS dataset (Cosker, Krumhuber, & Hilton, 2011) might be of interest: it is composed of 3D scans of real human faces, contains over 500 dynamic facial action sequences, and is fully FACS coded. The dataset can be used to build realistic facial animation models and is also currently used in the commercial sector by visual effects companies. For more information and in order to obtain access, please contact

http://www.cs.bath.ac.uk/~dpc/D3DFACS/

http://www.cs.bath.ac.uk/~dpc/D3DFACS/

Baumeister, R. F., & Leary, M. R. (1995). The need to belong: Desire for interpersonal attachments as a fundamental human motivation.

Psychological Bulletin, 117

Calvo, M. G., & Nummenmaa, L. (2016). Perceptual and affective mechanisms in facial expression recognition: An integrative review.

Cognition and Emotion, 30

, 1081-1106.

Cosker, D., Krumhuber, E., & Hilton, A. (2011). A FACS valid 3D dynamic action unit database with applications to 3D dynamic morphable facial modeling. In D. Metaxas, L. Quan, A. Sanfeliu, & L. Van Gool (Eds.),

Proceedings of the 13 th IEEE International Conference on Computer Vision (ICCV)

(p. 2296-2303), Barcelona, Spain: IEEE Conference Publication

Ekman, P., Davidson, R., & Friesen, W. V. (1990). The Duchenne smile: Emotional expression and brain physiology

II. Journal of Personality and Social Psychology, 58,

Ekman, P., & Friesen, W. V. (1976).

Pictures of facial affect.

Palo Alto, CA: Consulting Psychologists Press.

Ekman, P., & Friesen, W.V. (1982). Felt, false and miserable smiles.

Journal of Nonverbal Behavior, 6

Ekman, P., Friesen, W. V., & Hager, J. C. (2002).

The Facial Action Coding System

(2nd ed.). Salt Lake City, UT: Research Nexus eBook.

Fiorentini, C., Schmidt, S., & Viviani, P. (2012). The identification of unfolding facial expressions.

Perception, 41

Frank, M. G., Ekman, P., & Friesen, W. V. (1993). Behavioral markers and recognizability of the smile of enjoyment.

Journal of Personality and

Social Psychology, 64,

Fridlund, A.J. (1994).

Human facial expression: An evolutionary view.

New York: Academic Press

Geller, T. (2008). Overcoming the uncanny valley.

IEEE Computer Graphics and Applications, 28,

Goeleven, E., de Raedt, R., Leyman, L., & Verschuere, B. (2008). The Karolinska Directed Emotional Faces: A validation study.

Cognition and

Emotion, 22,

Gunnery, S. D., & Hall, J. A. (2014). The Duchenne smile and persuasion.

Journal of Nonverbal Behavior, 38

Gunnery, S. D., & Ruben, M. A. (2016). Perceptions of Duchenne and non-Duchenne smiles: A meta-analysis.

Cognition and Emotion, 30

Jack, R. E., Garrod, O. G. B., & Schyns, P.G. (2014). Dynamic facial expressions of emotions transmit an evolving hierarchy of signals over time.

Current Biology, 24

Kappas, A., & Descóteaux, J. (2003). Of butterflies and roaring thunder: Nonverbal communication in interaction and regulation of emotion. In P. Philippot, E.J. Coats, & R,S. Feldman (Eds.),

Nonverbal behavior in clinical settings

. New York: Oxford University Press.

Krumhuber, E., & Kappas, A. (2005). Moving smiles: The role of dynamic components for the perception of the genuineness of smiles

. Journal of Nonverbal Behavior, 29,

Krumhuber, E. G., Likowski, K. U., & Weyers, P. (2014). Facial mimicry of spontaneous and deliberate Duchenne and Non-Duchenne smiles.

Journal of Nonverbal Behavior, 38, 1-11.

Krumhuber, E., Manstead, A. S. R, & Kappas, A. (2007)

Temporal aspects of facial displays in person and expression perception. The effects of smile dynamics, head-tilt and gender.

Journal of Nonverbal Behavior, 31,

Krumhuber, E., Manstead, A. S. R, Cosker, D., Marshall, D., & Rosin, P. L. (2009). Effects of dynamic attributes of smiles in human and synthetic faces: A simulated job interview setting.

Journal of Nonverbal Behavior, 33,

Krumhuber, E., Manstead, A. S. R, Cosker, D., Marshall, D., Rosin, P. L., & Kappas, A. (2007). Facial dynamics as indicators of trustworthiness and cooperative behavior.

Emotion, 7,

Krumhuber, E, & Manstead, A. S. R. (2009). Can Duchenne smiles be feigned? New evidence on felt and false smiles.

Emotion, 9,

Krumhuber, E. G., Kappas, A., & Manstead, A. S. R. (2013). Effects of dynamic aspects of facial expressions: A review.

Emotion Review, 5

Krumhuber, E., Tamarit, L., Roesch, E. B., & Scherer, K. R. (2012). FACSGen 2.0 animation software: Generating 3D FACS-valid facial expressions for emotion research.

Emotion, 12,

Krumhuber, E., & Scherer, K. R. (2011). Affect bursts: Dynamic patterns of facial expression.

Emotion, 11,

Krumhuber, E., & Scherer, K. R. (2016). The look of fear from the eyes varies with the dynamic sequence of facial actions.

Swiss Journal of Psychology, 75,

Krumhuber, E., Skora, L., Küster, D., & Fou, L. (in press). A review of dynamic datasets for facial expression research.

Emotion Review.

Krumhuber, E., & Skora, L. (in press). Perceptual study on facial expressions. In B. Müller & S. Wolf (Eds.),

Handbook of Human Motion

. Heidelberg, Germany: Springer-Verlag

Küster, D., Krumhuber, E., & Kappas, A. (2014). Nonverbal behavior online: A focus on interactions with and via artificial agents and avatars. In A. Kostic & D. Chadee (Eds.),

Social Psychology of Nonverbal Communications

(pp. 272-302). New York, NY: Palgrave Macmillan.

MacDorman, K. F., Green, R. D., Ho, C.-C., & Koch, C. T. (2009). Too real for comfort? Uncanny responses to computer generated faces.

Computers in Human Behavior, 25,

Mori, M. (2012). The Uncanny Valley. (K. F. MacDorman & N. Kageki, Trans.).

IEEE Robotics and Automation Magazine, 19,

Niedenthal, P. M., Mermillod, M., Maringer, M., & Hess, U. (2010). The simulation of the smiles (SIMS) model: Embodied simulation and the meaning of facial expression.

Behavioral and Brain Sciences, 33,

Pantic, M. (2009). Machine analysis of facial behaviour: Naturalistic and dynamic behaviour.

Philosophical Transactions of the Royal Society B, 364,

Russell, J. A. (1994). Is there universal recognition of emotion from facial expression? A review of the cross-cultural studies.

Psychological Bulletin, 115,

Saygin, A. P., Chaminade, T., Ishiguro, H., Driver, J., & Frith, C. (2012). The thing that should not be: predictive coding and the uncanny valley in perceiving human and humanoid actions.

Social Cognitive and Affective Neuroscience, 7

Smith, C. A., & Scott, H. S. (1997). A componential approach to the meaning of facial

expressions. In J. A. Russell & J. M. Fernandez-Dols (Eds.),

The psychology of facial expression

(pp. 229–254). Cambridge, UK: Cambridge University Press.

Tottenham, N

http://www.ncbi.nlm.nih.gov/pubmed/?term=Tottenham%20N%5BAuthor%5D&cauthor=true&cauthor\_uid=19564050

Tanaka, J. W

http://www.ncbi.nlm.nih.gov/pubmed/?term=Tanaka%20JW%5BAuthor%5D&cauthor=true&cauthor\_uid=19564050

http://www.ncbi.nlm.nih.gov/pubmed/?term=Leon%20AC%5BAuthor%5D&cauthor=true&cauthor\_uid=19564050

http://www.ncbi.nlm.nih.gov/pubmed/?term=McCarry%20T%5BAuthor%5D&cauthor=true&cauthor\_uid=19564050

http://www.ncbi.nlm.nih.gov/pubmed/?term=Nurse%20M%5BAuthor%5D&cauthor=true&cauthor\_uid=19564050

http://www.ncbi.nlm.nih.gov/pubmed/?term=Hare%20TA%5BAuthor%5D&cauthor=true&cauthor\_uid=19564050

Marcus, D. J

http://www.ncbi.nlm.nih.gov/pubmed/?term=Marcus%20DJ%5BAuthor%5D&cauthor=true&cauthor\_uid=19564050

Westerlund, A

http://www.ncbi.nlm.nih.gov/pubmed/?term=Westerlund%20A%5BAuthor%5D&cauthor=true&cauthor\_uid=19564050

Casey, B. J

http://www.ncbi.nlm.nih.gov/pubmed/?term=Casey%20BJ%5BAuthor%5D&cauthor=true&cauthor\_uid=19564050

http://www.ncbi.nlm.nih.gov/pubmed/?term=Nelson%20C%5BAuthor%5D&cauthor=true&cauthor\_uid=19564050

(2009). The NimStim set of facial expressions: judgments from untrained research participants.

Psychiatry Research,168

With, S., & Kaiser, S. (2011). Sequential patterning of facial actions in the production and perception of emotional expressions.

Swiss Journal of Psychology, 70

https://emotionresearcher.com/#facebook

https://emotionresearcher.com/#twitter

https://emotionresearcher.com/#tumblr

https://emotionresearcher.com/#email

Traffic Count

1400232 Total reads:

96 Reads today:

1078849 Total visitors:

86 Visitors today:

#### Search for:

http://wordpress.org/

WP Travel Magazine by WP Mag Plus

https://wpmagplus.com/

This website uses cookies to improve your experience. We'll assume you're ok with this, but you can opt-out if you wish.

https://emotionresearcher.com/the-temporal-dynamics-of-facial-expressions/

http://emotionresearcher.com/?page\_id=3784&preview=true

Privacy & Cookies Policy

Privacy Overview

This website uses cookies to improve your experience while you navigate through the website. Out of these, the cookies that are categorized as necessary are stored on your browser as they are essential for the working of basic functionalities of the ...

https://emotionresearcher.com/the-temporal-dynamics-of-facial-expressions/

Always Enabled

Necessary cookies are absolutely essential for the website to function properly. This category only includes cookies that ensures basic functionalities and security features of the website. These cookies do not store any personal information.

Non-necessary

https://emotionresearcher.com/the-temporal-dynamics-of-facial-expressions/

Non-necessary

Any cookies that may not be particularly necessary for the website to function and is used specifically to collect user personal data via analytics, ads, other embedded contents are termed as non-necessary cookies. It is mandatory to procure user consent prior to running these cookies on your website.

SAVE & ACCEPT

https://emotionresearcher.com/the-temporal-dynamics-of-facial-expressions/

Thanks for sharing!

https://www.addtoany.com/

https://emotionresearcher.com/the-temporal-dynamics-of-facial-expressions/#addtoany

