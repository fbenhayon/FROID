---
sourceFile: "Demystifying Mental Health by Decoding Facial Action Unit Sequences - MDPI"
exportedBy: "Kortex"
exportDate: "2026-06-29T01:00:27.722Z"
---

# Demystifying Mental Health by Decoding Facial Action Unit Sequences - MDPI

3b4076fc-14e7-49c9-95e4-60f9304106e9

Demystifying Mental Health by Decoding Facial Action Unit Sequences - MDPI

5faea653-e669-4b27-940b-154e09e0050b

https://www.mdpi.com/2504-2289/8/7/78

Demystifying Mental Health by Decoding Facial Action Unit Sequences

Loading web-font Gyre-Pagella/Main/Regular

Next Article in Journal

Trends and Challenges towards Effective Data-Driven Decision Making in UK Small and Medium-Sized Enterprises: Case Studies and Lessons Learnt from the Analysis of 85 Small and Medium-Sized Enterprises

https://www.mdpi.com/2504-2289/8/7/79

Previous Article in Journal

AMIKOMNET: Novel Structure for a Deep Learning Model to Enhance COVID-19 Classification Task Performance

https://www.mdpi.com/2504-2289/8/7/77

Active Journals

https://www.mdpi.com/about/journals

Find a Journal

https://www.mdpi.com/about/journalfinder

Journal Proposal

https://www.mdpi.com/about/journals/proposal

Proceedings Series

https://www.mdpi.com/about/proceedings

\](https://www.mdpi.com/topics)

Information

For Authors

https://www.mdpi.com/authors

For Reviewers

https://www.mdpi.com/reviewers

For Editors

https://www.mdpi.com/editors

For Librarians

https://www.mdpi.com/librarians

For Publishers

https://www.mdpi.com/publishing\_services

For Societies

https://www.mdpi.com/societies

For Conference Organizers

https://www.mdpi.com/conference\_organizers

Open Access Policy

https://www.mdpi.com/openaccess

Institutional Open Access Program

https://www.mdpi.com/ioap

Special Issues Guidelines

https://www.mdpi.com/special\_issues\_guidelines

Editorial Process

https://www.mdpi.com/editorial\_process

Research and Publication Ethics

https://www.mdpi.com/ethics

Article Processing Charges

https://www.mdpi.com/apc

https://www.mdpi.com/awards

Testimonials

https://www.mdpi.com/testimonials

Author Services

\](https://www.mdpi.com/authors/english)

Initiatives

https://sciforum.net/

https://www.mdpi.com/books

Preprints.org

https://www.preprints.org/

https://www.scilit.com/

SciProfiles

https://sciprofiles.com/

Encyclopedia

https://encyclopedia.pub/

https://jams.pub/

Proceedings Series

https://www.mdpi.com/about/proceedings

https://www.mdpi.com/about

https://www.mdpi.com/about/contact

https://careers.mdpi.com/

https://www.mdpi.com/about/announcements

https://www.mdpi.com/about/press

http://blog.mdpi.com/

Sign In / Sign Up

https://www.mdpi.com/user/login

You can make submissions to other journals

https://susy.mdpi.com/user/manuscripts/upload

https://www.mdpi.com/2504-2289/8/7/78

You are accessing a machine-readable page. In order to be human-readable, please install an RSS reader.

https://www.mdpi.com/2504-2289/8/7/78

https://www.mdpi.com/2504-2289/8/7/78

https://www.mdpi.com/2504-2289/8/7/78

All articles published by MDPI are made immediately available worldwide under an open access license. No special permission is required to reuse all or part of the article published by MDPI, including figures and tables. For articles published under an open access Creative Common CC BY license, any part of the article may be reused without permission provided that the original article is clearly cited. For more information, please refer to

https://www.mdpi.com/openaccess

https://www.mdpi.com/openaccess

Feature papers represent the most advanced research with significant potential for high impact in the field. A Feature Paper should be a substantial original Article that involves several techniques or approaches, provides an outlook for future research directions and describes possible research applications.

Feature papers are submitted upon individual invitation or recommendation by the scientific editors and must receive positive feedback from the reviewers.

Editor's Choice articles are based on recommendations by the scientific editors of MDPI journals from around the world. Editors select a small number of articles recently published in the journal that they believe will be particularly interesting to readers, or important in the respective research area. The aim is to provide a snapshot of some of the most exciting work published in the various research areas of the journal.

Original Submission Date Received: .

You seem to have javascript disabled. Please note that many of the page functionalities won't work as expected without javascript enabled.

https://www.mdpi.com/2504-2289/8/7/78

zoom\_out\_map

https://www.mdpi.com/toggle\_desktop\_layout\_cookie

https://www.mdpi.com/2504-2289/8/7/78

https://www.mdpi.com/2504-2289/8/7/78

https://www.mdpi.com/about/journals

Active Journals

https://www.mdpi.com/about/journals

Find a Journal

https://www.mdpi.com/about/journalfinder

Journal Proposal

https://www.mdpi.com/about/journals/proposal

Proceedings Series

https://www.mdpi.com/about/proceedings

https://www.mdpi.com/topics

Information

https://www.mdpi.com/authors

For Authors

https://www.mdpi.com/authors

For Reviewers

https://www.mdpi.com/reviewers

For Editors

https://www.mdpi.com/editors

For Librarians

https://www.mdpi.com/librarians

For Publishers

https://www.mdpi.com/publishing\_services

For Societies

https://www.mdpi.com/societies

For Conference Organizers

https://www.mdpi.com/conference\_organizers

Open Access Policy

https://www.mdpi.com/openaccess

Institutional Open Access Program

https://www.mdpi.com/ioap

Special Issues Guidelines

https://www.mdpi.com/special\_issues\_guidelines

Editorial Process

https://www.mdpi.com/editorial\_process

Research and Publication Ethics

https://www.mdpi.com/ethics

Article Processing Charges

https://www.mdpi.com/apc

https://www.mdpi.com/awards

Testimonials

https://www.mdpi.com/testimonials

Author Services

https://www.mdpi.com/authors/english

Initiatives

https://www.mdpi.com/about/initiatives

https://sciforum.net/

https://www.mdpi.com/books

Preprints.org

https://www.preprints.org/

https://www.scilit.com/

SciProfiles

https://sciprofiles.com/

Encyclopedia

https://encyclopedia.pub/

https://jams.pub/

Proceedings Series

https://www.mdpi.com/about/proceedings

https://www.mdpi.com/about

https://www.mdpi.com/about

https://www.mdpi.com/about/contact

https://careers.mdpi.com/

https://www.mdpi.com/about/announcements

https://www.mdpi.com/about/press

http://blog.mdpi.com/

Sign In / Sign Up

https://www.mdpi.com/user/login

https://susy.mdpi.com/user/manuscripts/upload?journal=BDCC

#### Search for Articles:

Title / Keyword

Author / Affiliation / Email

All Journals

Accounting and Auditing

Acta Microbiologica Hellenica (AMH)

Administrative Sciences

Adolescents

Advances in Respiratory Medicine (ARM)

Aerobiology

Agriculture

AgriEngineering

Agrochemicals

AI Chemistry

AI for Engineering

AI in Education

AI in Medicine

AI Materials

Anesthesia Research

Antibiotics

Antioxidants

Applied Biosciences

Applied Mechanics

Applied Microbiology

Applied Nano

Applied Sciences

Applied System Innovation (ASI)

AppliedChem

AppliedMath

AppliedPhys

Aquaculture Journal

Architecture

Astronautics

Audiology Research

Behavioral Sciences

Big Data and Cognitive Computing (BDCC)

Bioengineering

Biology and Life Sciences Forum

Biomechanics

Biomedicines

BioMedInformatics

Biomimetics

Biomolecules

Bioresources and Bioproducts

Blockchains

Brain Sciences

C (Journal of Carbon Research)

Cardiogenetics

Cardiovascular Medicine

ChemEngineering

Chemistry Proceedings

Chemosensors

Clean Technologies (Clean Technol.)

Clinical and Translational Neuroscience (CTN)

Clinical Bioenergetics

Clinics and Practice

Clocks & Sleep

Colloids and Interfaces

Commodities

Complexities

Complications

Computation

Computer Sciences & Mathematics Forum

Condensed Matter

Conservation

Construction Materials

Corrosion and Materials Degradation (CMD)

Craniomaxillofacial Trauma & Reconstruction (CMTR)

Cryptography

Current Issues in Molecular Biology (CIMB)

Current Oncology

Dentistry Journal

Dermatopathology

Diabetology

Diagnostics

Disabilities

Drugs and Drug Candidates (DDC)

Econometrics

Education Sciences

Electricity

Electrochem

Electronic Materials

Electronics

Emergency Care and Medicine

Encyclopedia

Energy Storage and Applications (ESA)

Engineering Proceedings

Entropic and Disordered Matter (EDM)

Environmental and Earth Sciences Proceedings

Environmental Remediation

Environments

Epidemiologia

European Burn Journal (EBJ)

European Journal of Investigation in Health, Psychology and Education (EJIHPE)

Family Sciences

Fermentation

Forecasting

Forensic Sciences

Fossil Studies

Foundations

Fractal and Fractional (Fractal Fract)

Future Internet

Future Pharmacology

Future Transportation

Gastroenterology Insights

Gastrointestinal Disorders

Geographies

Geosciences

Geotechnics

Gout, Urate, and Crystal Deposition Disease (GUCDD)

Green Health

Hematology Reports

Horticulturae

Hydrobiology

Infectious Disease Reports

Informatics

Information

Infrastructures

Instruments

Intelligent Infrastructure and Construction

International Journal of Cognitive Sciences (IJCS)

International Journal of Environmental Medicine (IJEM)

International Journal of Environmental Research and Public Health (IJERPH)

International Journal of Financial Studies (IJFS)

International Journal of Molecular Sciences (IJMS)

International Journal of Neonatal Screening (IJNS)

International Journal of Orofacial Myology and Myofunctional Therapy (IJOM)

International Journal of Plant Biology (IJPB)

International Journal of Topology

International Journal of Translational Medicine (IJTM)

International Journal of Turbomachinery, Propulsion and Power (IJTPP)

International Medical Education (IME)

ISPRS International Journal of Geo-Information (IJGI)

Journal of Aesthetic Medicine (J. Aesthetic Med.)

Journal of Ageing and Longevity (JAL)

Journal of CardioRenal Medicine (JCRM)

Journal of Cardiovascular Development and Disease (JCDD)

Journal of Clinical & Translational Ophthalmology (JCTO)

Journal of Clinical Medicine (JCM)

Journal of Composites Science (J. Compos. Sci.)

Journal of Cybersecurity and Privacy (JCP)

Journal of Dementia and Alzheimer's Disease (JDAD)

Journal of Developmental Biology (JDB)

Journal of Experimental and Theoretical Analyses (JETA)

Journal of Eye Movement Research (JEMR)

Journal of Functional Biomaterials (JFB)

Journal of Functional Morphology and Kinesiology (JFMK)

Journal of Fungi (JoF)

Journal of Genome Biotechnology and Genetics (JGBG)

Journal of Gerontology and Geriatrics (JGG)

Journal of Imaging (J. Imaging)

Journal of Innovation

Journal of Intelligence (J. Intell.)

Journal of Interdisciplinary Research Applied to Medicine (JDReAM)

Journal of Low Power Electronics and Applications (JLPEA)

Journal of Manufacturing and Materials Processing (JMMP)

Journal of Marine Science and Engineering (JMSE)

Journal of Market Access & Health Policy (JMAHP)

Journal of Mind and Medical Sciences (JMMS)

Journal of Molecular Pathology (JMP)

Journal of Nanotheranostics (JNT)

Journal of Nuclear Engineering (JNE)

Journal of Otorhinolaryngology, Hearing and Balance Medicine (JOHBM)

Journal of Parks

Journal of Personalized Medicine (JPM)

Journal of Pharmaceutical and BioTech Industry (JPBI)

Journal of Phytomedicine

Journal of Respiration (JoR)

Journal of Risk and Financial Management (JRFM)

Journal of Sensor and Actuator Networks (JSAN)

Journal of Superintelligence

Journal of the American Podiatric Medical Association (JAPMA)

Journal of the Oman Medical Association (JOMA)

Journal of Theoretical and Applied Electronic Commerce Research (JTAER)

Journal of Vascular Diseases (JVD)

Journal of Xenobiotics (JoX)

Journal of Zoological and Botanical Gardens (JZBG)

Journalism and Media

Kidney and Dialysis

Kinases and Phosphatases

Laboratories

Limnological Review

Low-Altitude Economy

Machine Learning and Knowledge Extraction (MAKE)

Magnetochemistry

Marine Drugs

Materials Proceedings

Mathematical and Computational Applications (MCA)

Mathematics

Medical Sciences

Medical Sciences Forum

Metabolites

Meteorology

Methods and Protocols (MPs)

Microbiology Research

Microelectronics

Micromachines

Microorganisms

Microplastics

Modern Mathematical Physics

Multimodal Technologies and Interaction (MTI)

Nanoenergy Advances

Nanomanufacturing

Nanomaterials

Neuroimaging

Neurology International

Non-Coding RNA (ncRNA)

Nursing Reports

Nutraceuticals

Occupational Health

Parasitologia

Pathophysiology

Peace Studies

Pediatric Reports

Pharmaceuticals

Pharmaceutics

Pharmacoepidemiology

Philosophies

Physical Sciences Forum

Physiologia

Polysaccharides

Populations

Precision Oncology

Primary and Hospital Care (PHC)

Proceedings

Psychiatry International

Psychoactives

Psychology International

Publications

Purification

Quantum Beam Science (QuBS)

Quantum Reports

Real Estate

Regional Science and Environmental Economics (RSEE)

Remote Sensing

Reproductive Medicine (Reprod. Med.)

Romanian Journal of Preventive Medicine (RJPM)

Scientia Pharmaceutica (Sci. Pharm.)

Semiconductors and Heterogeneous Integration

Separations

Smart Cities

Social Sciences

Société Internationale d'Urologie Journal (SIUJ)

Soil Systems

Spectroscopy Journal

Stratigraphy and Sedimentology

Surgical Techniques Development

Sustainability

Sustainable Chemistry

Swiss Archives of Neurology, Psychiatry and Psychotherapy (SANPP)

Technologies

Thalassemia Reports

Theoretical and Applied Ergonomics

Therapeutics

Time and Space

Tourism and Hospitality

Transplantology

Trauma Care

Trends in Higher Education

Trends in Public Health

Tropical Medicine and Infectious Disease (TropicalMed)

Urban Science

Venereology

Veterinary Sciences

Virtual Worlds

World Electric Vehicle Journal (WEVJ)

Zoonotic Diseases

Big Data and Cognitive Computing (BDCC)

https://www.mdpi.com/2504-2289/8/7/78

Article Type

All Article Types

Communication

Book Review

Brief Communication

Brief Report

Case Report

Clinicopathological Challenge

Concept Paper

Conference Report

Data Descriptor

Expression of Concern

Extended Abstract

Field Guide

Giants in Urology

Interesting Images

New Book Received

Patent Summary

Perspective

Proceeding Paper

Project Report

Registered Report

Study Protocol

Systematic Review

Technical Note

Urology around the World

All Article Types

https://www.mdpi.com/2504-2289/8/7/78

Advanced Search

https://www.mdpi.com/2504-2289/8/7/78

All Sections

Artificial Intelligence and Multi-Agent Systems

Cognitive System

Data Mining and Machine Learning

Large Language Models and Embodied Intelligence

All Sections

https://www.mdpi.com/2504-2289/8/7/78

Special Issue

All Special Issues

Big Data and Cognitive Computing in 2023

Advanced Data Mining Techniques for IoT and Big Data

Advanced Machine Learning and Data Mining: A New Frontier in Artificial Intelligence Research

Advancements in Deep Learning and Deep Federated Learning Models

Advances and Applications of Deep Learning Methods and Image Processing

Advances in Complex Networks

Advances in Intelligent Defense Systems for the Internet of Things

Advances in Natural Language Processing and Text Mining

Advances in System Design and IoT Based Smart City

AI-Driven Pattern Recognition for Next-Generation Biometrics

AI, Computer Vision and Human–Robot Interaction

Application of Artificial Intelligence in Traffic Management

Application of Cloud Computing in Industrial Internet of Things

Application of Cloud Computing in Industrial Internet of Things—2nd Edition

Application of Deep Learning and Convolution Neural Networks for Social Healthcare

Application of Deep Neural Networks

Application of Semantic Technologies in Intelligent Environment

Applied Artificial Intelligence for Sustainability

Applied Data Science for Social Good

Applied Data Science for Social Good: 2nd Edition

Applied Deep Learning: Business and Industrial Applications

Artificial Cognition for Human-Robot Interaction

Artificial Cognitive Systems for Computer Vision

Artificial Intelligence (AI) and Natural Language Processing (NLP)

Artificial Intelligence and Multi-Agent Systems for Big Data

Artificial Intelligence and Natural Language Processing

Artificial Intelligence for Online Safety

Artificial Intelligence for Sustainability Development

Artificial Intelligence for Trustworthy Industrial Internet of Things

Artificial Intelligence in Digital Humanities

Artificial Intelligence in Sustainable Reconfigurable Manufacturing Systems and Operations Management

Artificial Superintelligence: Coordination & Strategy

Augmented Reality, Virtual Reality, and Computer Graphics

Big Data Analytic: From Accuracy to Interpretability

Big Data Analytics and Cloud Data Management

Big Data Analytics and Edge Computing: Recent Trends and Future

Big Data Analytics and Forecasting in Fashion

Big Data Analytics for Cultural Heritage

Big Data Analytics for Cultural Heritage 2nd Edition

Big Data Analytics for Social Services

Big Data Analytics with Machine Learning for Cyber Security

Big Data and Cognitive Computing in 2026

Big Data and Cognitive Computing: 5th Anniversary Feature Papers

Big Data and Cognitive Computing: Feature Papers 2018

Big Data and Cognitive Computing: Feature Papers 2020

Big Data and Data Science in Educational Research

Big Data and Information Science Technology

Big Data and Internet of Things

Big Data and Internet of Things in Smart Cities

Big Data and Machine Learning Applications for Material Removal, Additive and Hybrid Manufacturing Processes

Big Data and UN Sustainable Development Goals (SDGs)

Big Data in Computer-Aided Design

Big Data in Health Care Information Systems

Big Data in Omics Science: Challenges and Opportunities

Big Data System for Global Health

Big Music Data

Big-Data Driven Multi-Criteria Decision-Making

Bioinformatics Dry Laboratories for Research and Education: Computational Systems and Infrastructures

Blockchain and Cloud Computing in Big Data and Generative AI Era

Blockchain Meets IoT for Big Data

Brain-Inspired Hyperdimensional Computing: Theoretical Perspectives and Real-World Applications

Business Intelligence and Big Data in E-commerce

Challenges and Perspectives of Social Networks within Social Computing

Cognitive and Physiological Assessments in Human-Computer Interaction

Cognitive Services Integrating with Big Data, Clouds and IoT

Computational Collective Intelligence with Big Data–AI Society

Computational Finance and Big Data Analytics

Computational Intelligence: Spiking Neural Networks

Computational Models of Cognition and Learning

COVID-19: Medical Internet of Things and Big Data Analytics

Cross Modality Deep Learning and Knowledge Representation

Cyber Security in Big Data Era

Cybersecurity, Threat Analysis and the Management of Risk

Data Mining and the Future of Cybersecurity

Data Science in Health Care

Data Security and Privacy in Blockchain-Based Decentralized Applications

Data-Based Bioinformatics and Applications

Data, Structure, and Information in Artificial Intelligence

Deep Learning for Advanced Visual Representation and Analysis

Deep Learning Technology and Big Data Method for Business and Environmental Management

Deep Learning-Based Pose Estimation: Applications in Vision, Robotics, and Beyond

Deep Network Learning and Its Applications

Digital Health and Data Analytics in Public Health

Digital Twins for Complex Systems

Distributed Applications and Services for Future Internet

Edge Computing and Fog Computing on the Internet of Things

Educational Data Mining and Technology

Emerging Trends and Applications of Big Data in Robotic Systems

Energy-Efficient IoT (Internet of Things) and Big Data Challenges for Connected Intelligence

Fault Diagnosis and Detection Based on Deep Learning

Feature-Rich Artificial Intelligence Models and Applications of Cognition

Generative AI and Large Language Models

Graph-Based Data Mining and Social Network Analysis

Health Assessment in the Big Data Era

Human Factor in Information Systems Development and Management

Industrial Applications of IoT and Blockchain for Sustainable Environment

Industrial Data Mining and Machine Learning Applications

Information Security and Cyber Intelligence

Interactive Visual Analytics and Explainable AI for Big Data

Internet of Things (IoT) and Ambient Intelligence

Knowledge Modelling and Learning through Cognitive Networks

Knowledge Representation Formalisms for AI Applications

Learning with Big Data: Scalable Algorithms and Novel Applications

Low-Power Data Processing on the Edge: Solutions for Artificial Intelligence Hardware Acceleration

Machine and Deep Learning in Computer Vision Applications

Machine Learning and AI Technology for Sustainable Development

Machine Learning and Artificial Intelligence for Health Applications on Social Networks

Machine Learning and Data Analysis for Image Processing

Machine Learning and Data Analytics for Communication Networks in the 5G Era

Machine Learning Applications and Big Data Challenges

Machine Learning for Dependable Edge Computing Systems and Services

Machine Learning for Social Media Analysis

Machine Learning in Data Mining for Knowledge Discovery

Machine Learning Techniques on Biometrics and IoT Applications

Managing Cybersecurity Threats and Increasing Organizational Resilience

ML-Based Cognitive Network Management: For Better 6G Applications

Multimedia Systems for Multimedia Big Data

Natural Language Processing and Event Extraction for Big Data

Natural Language Processing Applications in Big Data

Perception and Detection of Intelligent Vision

Predictive Performance-Explainability Duality for Big Data Analytics-Powered Healthcare

Privacy-Enhancing Technologies of Data for Sustainable and Secure Cooperation

Quality and Security of Critical Infrastructure Systems

Real-Time Data Services for the Internet of Things

Recent Advances and Applications of Big Data and Distributed Computing Systems

Recent Advances in Big Data-Driven Prescriptive Analytics

Recent Advances in Deep Transfer Learning Applications for Image Processing Problems and Big Data

Recent Advances in Machine Learning Methods for Imperfect Large-Scale Data

Recommendation, Information Retrieval, and Exploratory Search

Research on Privacy and Data Security

Research Progress in Artificial Intelligence and Social Network Analysis

Resilient and Reliable Artificial Intelligence (AI) Systems

Review Papers in Big Data, Cloud-Based Data Analysis and Learning Systems

Revolutionizing Healthcare: Exploring the Latest Advances in Digital Health Technology

Security, Privacy, and Trust in Artificial Intelligence Applications

Semantic Web Technology and Recommender Systems

Semantic Web Technology and Recommender Systems 2nd Edition

Smart Communication Systems and Networks for Big Data

Smarter Healthcare via Big Data and Machine Learning

Speech Recognition and Machine Learning: Current Trends and Future

Sustainable Big Data Analytics and Machine Learning Technologies

Transforming Cyber Security Provision Through Utilizing Artificial Intelligence

Unlocking Minds and Machines: Advances in Cognitive Computing and Big Data Analytics

Virtual Reality, Augmented Reality, and Human-Computer Interaction

All Special Issues

https://www.mdpi.com/2504-2289/8/7/78

Logical Operator Operator

Search Text

Search Type

Affiliations

add\_circle\_outline

remove\_circle\_outline

https://www.mdpi.com/about/journals

https://www.mdpi.com/journal/BDCC

https://www.mdpi.com/2504-2289/8

https://www.mdpi.com/2504-2289/8/7

10.3390/bdcc8070078

https://www.mdpi.com/2504-2289/8/7/78

Submit to this Journal

https://susy.mdpi.com/user/manuscripts/upload?form%5Bjournal\_id%5D%3D245

Review for this Journal

https://susy.mdpi.com/volunteer/journals/review

Propose a Special Issue

https://www.mdpi.com/journalproposal/sendproposalspecialissue/BDCC

► ▼ Article Menu

https://www.mdpi.com/2504-2289/8/7/78

Article Menu

Academic Editor

https://www.mdpi.com/2504-2289/8/7/78#academic\_editors

Moulay A. Akhloufi

https://sciprofiles.com/profile/309135?utm\_source=mdpi.com&utm\_medium=website&utm\_campaign=avatar\_name

Recommended Articles

https://www.mdpi.com/2504-2289/8/7/78

Related Info Link

https://www.mdpi.com/2504-2289/8/7/78#related

Google Scholar

http://scholar.google.com/scholar?q=Demystifying%20Mental%20Health%20by%20Decoding%20Facial%20Action%20Unit%20Sequences

More by Authors Links

https://www.mdpi.com/2504-2289/8/7/78#authors

https://www.mdpi.com/2504-2289/8/7/78

http://doaj.org/search/articles?source=%7B%22query%22%3A%7B%22query\_string%22%3A%7B%22query%22%3A%22%5C%22Deepika%20Sharma%5C%22%22%2C%22default\_operator%22%3A%22AND%22%2C%22default\_field%22%3A%22bibjson.author.name%22%7D%7D%7D

http://doaj.org/search/articles?source=%7B%22query%22%3A%7B%22query\_string%22%3A%7B%22query%22%3A%22%5C%22Jaiteg%20Singh%5C%22%22%2C%22default\_operator%22%3A%22AND%22%2C%22default\_field%22%3A%22bibjson.author.name%22%7D%7D%7D

Sehra, S. Singh

http://doaj.org/search/articles?source=%7B%22query%22%3A%7B%22query\_string%22%3A%7B%22query%22%3A%22%5C%22Sukhjit%20Singh%20Sehra%5C%22%22%2C%22default\_operator%22%3A%22AND%22%2C%22default\_field%22%3A%22bibjson.author.name%22%7D%7D%7D

Sehra, S. Kaur

http://doaj.org/search/articles?source=%7B%22query%22%3A%7B%22query\_string%22%3A%7B%22query%22%3A%22%5C%22Sumeet%20Kaur%20Sehra%5C%22%22%2C%22default\_operator%22%3A%22AND%22%2C%22default\_field%22%3A%22bibjson.author.name%22%7D%7D%7D

on Google Scholar

https://www.mdpi.com/2504-2289/8/7/78

http://scholar.google.com/scholar?q=Deepika%20Sharma

http://scholar.google.com/scholar?q=Jaiteg%20Singh

Sehra, S. Singh

http://scholar.google.com/scholar?q=Sukhjit%20Singh%20Sehra

Sehra, S. Kaur

http://scholar.google.com/scholar?q=Sumeet%20Kaur%20Sehra

https://www.mdpi.com/2504-2289/8/7/78

http://www.pubmed.gov/?cmd=Search&term=Deepika%20Sharma

http://www.pubmed.gov/?cmd=Search&term=Jaiteg%20Singh

Sehra, S. Singh

http://www.pubmed.gov/?cmd=Search&term=Sukhjit%20Singh%20Sehra

Sehra, S. Kaur

http://www.pubmed.gov/?cmd=Search&term=Sumeet%20Kaur%20Sehra

Article Views 8611

https://www.mdpi.com/2504-2289/8/7/78#metrics

Citations 6

https://www.mdpi.com/2504-2289/8/7/78#metrics

Table of Contents

https://www.mdpi.com/2504-2289/8/7/78#table\_of\_contents

https://www.mdpi.com/2504-2289/8/7/78#html-abstract

Introduction

https://www.mdpi.com/2504-2289/8/7/78#sec1-BDCC-08-00078

Related Work

https://www.mdpi.com/2504-2289/8/7/78#sec2-BDCC-08-00078

Materials and Methods

https://www.mdpi.com/2504-2289/8/7/78#sec3-BDCC-08-00078

Result and Discussion

https://www.mdpi.com/2504-2289/8/7/78#sec4-BDCC-08-00078

Conclusions

https://www.mdpi.com/2504-2289/8/7/78#sec5-BDCC-08-00078

Author Contributions

https://www.mdpi.com/2504-2289/8/7/78

https://www.mdpi.com/2504-2289/8/7/78

Data Availability Statement

https://www.mdpi.com/2504-2289/8/7/78

Conflicts of Interest

https://www.mdpi.com/2504-2289/8/7/78

https://www.mdpi.com/2504-2289/8/7/78#html-references\_list

share Share

https://www.mdpi.com/2504-2289/8/7/78

announcement Help

https://www.mdpi.com/2504-2289/8/7/78

format\_quote Cite

javascript:void(0);

question\_answer Discuss in SciProfiles

https://sciprofiles.com/discussion-groups/public/10.3390/bdcc8070078?utm\_source=mpdi.com&utm\_medium=publication&utm\_campaign=discuss\_in\_sciprofiles

Find support for a specific problem in the support section of our website.

Get Support

https://www.mdpi.com/about/contactform

Please let us know what you think of our products and services.

Give Feedback

https://www.mdpi.com/feedback/send

Information

Visit our dedicated information section to learn more about MDPI.

Get Information

https://www.mdpi.com/authors

https://www.mdpi.com/2504-2289/8/7/78

JSmol Viewer

https://www.mdpi.com/2504-2289/8/7/78

Download PDF

https://www.mdpi.com/2504-2289/8/7/78/pdf?version=1720537284

Order Article Reprints

https://www.mdpi.com/2504-2289/8/7/78/reprints

#### Line Spacing:

#### Column Width:

#### Background:

Open Access Article

Demystifying Mental Health by Decoding Facial Action Unit Sequences

Deepika Sharma

Deepika Sharma

SciProfiles

https://sciprofiles.com/profile/author/SXFkczErN3Z6ajQ3SVUvdjJCQnFYdXNrTksxLzFhU2M4Mm5qVXU2UmFoZz0=?utm\_source=mdpi.com&utm\_medium=website&utm\_campaign=avatar\_name

https://scilit.com/scholars?q=Deepika%20Sharma

Preprints.org

https://www.preprints.org/search?condition\_blocks=\[{%22value%22:%22Deepika+Sharma%22,%22type%22:%22author%22,%22operator%22:null}\]&sort\_field=relevance&sort\_dir=desc&page=1&exact\_match=true

Google Scholar

https://scholar.google.com/scholar?q=Deepika+Sharma

Jaiteg Singh

Jaiteg Singh

SciProfiles

https://sciprofiles.com/profile/1958539?utm\_source=mdpi.com&utm\_medium=website&utm\_campaign=avatar\_name

https://scilit.com/scholars?q=Jaiteg%20Singh

Preprints.org

https://www.preprints.org/search?condition\_blocks=\[{%22value%22:%22Jaiteg+Singh%22,%22type%22:%22author%22,%22operator%22:null}\]&sort\_field=relevance&sort\_dir=desc&page=1&exact\_match=true

Google Scholar

https://scholar.google.com/scholar?q=Jaiteg+Singh

mailto:jaiteg.singh@chitkara.edu.in

Sukhjit Singh Sehra

Sukhjit Singh Sehra

SciProfiles

https://sciprofiles.com/profile/40079?utm\_source=mdpi.com&utm\_medium=website&utm\_campaign=avatar\_name

https://scilit.com/scholars?q=Sukhjit%20Singh%20Sehra

Preprints.org

https://www.preprints.org/search?condition\_blocks=\[{%22value%22:%22Sukhjit+Singh+Sehra%22,%22type%22:%22author%22,%22operator%22:null}\]&sort\_field=relevance&sort\_dir=desc&page=1&exact\_match=true

Google Scholar

https://scholar.google.com/scholar?q=Sukhjit+Singh+Sehra

mailto:ssehra@wlu.ca

Sumeet Kaur Sehra

Sumeet Kaur Sehra

SciProfiles

https://sciprofiles.com/profile/3367257?utm\_source=mdpi.com&utm\_medium=website&utm\_campaign=avatar\_name

https://scilit.com/scholars?q=Sumeet%20Kaur%20Sehra

Preprints.org

https://www.preprints.org/search?condition\_blocks=\[{%22value%22:%22Sumeet+Kaur+Sehra%22,%22type%22:%22author%22,%22operator%22:null}\]&sort\_field=relevance&sort\_dir=desc&page=1&exact\_match=true

Google Scholar

https://scholar.google.com/scholar?q=Sumeet+Kaur+Sehra

Chitkara University Institute of Engineering & Technology, Chitkara University, Rajpura 140401, Punjab, India

Physics and Computer Science, Wilfrid Laurier University, Waterloo, ON N2L 3C5, Canada

Authors to whom correspondence should be addressed.

Big Data Cogn. Comput.

https://doi.org/10.3390/bdcc8070078

https://doi.org/10.3390/bdcc8070078

Submission received: 20 April 2024 / Revised: 1 July 2024 / Accepted: 3 July 2024 / Published: 9 July 2024

Download keyboard\_arrow\_down

https://www.mdpi.com/2504-2289/8/7/78

Download PDF

https://www.mdpi.com/2504-2289/8/7/78/pdf?version=1720537284

Download PDF with Cover

https://www.mdpi.com/2504-2289/8/7/78

Download XML

https://www.mdpi.com/2504-2289/8/7/78

Download Epub

https://www.mdpi.com/2504-2289/8/7/78/epub

Browse Figures

https://www.mdpi.com/2504-2289/8/7/78

https://pub.mdpi-res.com/BDCC/BDCC-08-00078/article\_deploy/html/images/BDCC-08-00078-g001.png?1720537367

https://pub.mdpi-res.com/BDCC/BDCC-08-00078/article\_deploy/html/images/BDCC-08-00078-g002.png?1720537368

https://pub.mdpi-res.com/BDCC/BDCC-08-00078/article\_deploy/html/images/BDCC-08-00078-g003.png?1720537369

https://pub.mdpi-res.com/BDCC/BDCC-08-00078/article\_deploy/html/images/BDCC-08-00078-g004.png?1720537371

https://pub.mdpi-res.com/BDCC/BDCC-08-00078/article\_deploy/html/images/BDCC-08-00078-g005a.png?1720537372

https://pub.mdpi-res.com/BDCC/BDCC-08-00078/article\_deploy/html/images/BDCC-08-00078-g005b.png?1720537374

https://pub.mdpi-res.com/BDCC/BDCC-08-00078/article\_deploy/html/images/BDCC-08-00078-g006.png?1720537375

Review Reports

https://www.mdpi.com/2504-2289/8/7/78/review\_report

Versions Notes

https://www.mdpi.com/2504-2289/8/7/78/notes

Article Views

https://www.mdpi.com/2504-2289/8/7/78#metrics

Citations -

https://www.mdpi.com/2504-2289/8/7/78#metrics

Mental health is indispensable for effective daily functioning and stress management. Facial expressions may provide vital clues about the mental state of a person as they are universally consistent across cultures. This study intends to detect the emotional variances through facial micro-expressions using facial action units (AUs) to identify probable mental health issues. In addition, convolutional neural networks (CNN) were used to detect and classify the micro-expressions. Further, combinations of AUs were identified for the segmentation of micro-expressions classes using K-means square. Two benchmarked datasets CASME II and SAMM were employed for the training and evaluation of the model. The model achieved an accuracy of 95.62% on CASME II and 93.21% on the SAMM dataset, respectively. Subsequently, a case analysis was done to identify depressive patients using the proposed framework and it attained an accuracy of 92.99%. This experiment revealed the fact that emotions like disgust, sadness, anger, and surprise are the prominent emotions experienced by depressive patients during communication. The findings suggest that leveraging facial action units for micro-expression detection offers a promising approach to mental health diagnostics.

micro-expressions

https://www.mdpi.com/search?q=micro-expressions

https://www.mdpi.com/search?q=CNN

https://www.mdpi.com/search?q=K-means

emotion recognition

https://www.mdpi.com/search?q=emotion+recognition

action units

https://www.mdpi.com/search?q=action+units

1. Introduction

Mental health could be understood as a condition of optimal wellness where individuals are able to adeptly handle their daily stressors, meet their emotional needs, and make valuable contributions to their professional and societal spheres (World Health Organization (WHO)). The mental well-being of an individual may be influenced by a variety of elements, encompassing environmental factors, socioeconomic circumstances, personal attributes, and genetic predisposition. Symptoms such as stress, anxiety, and melancholy stand out as key signs of declining mental health \[

https://www.mdpi.com/2504-2289/8/7/78#B1-BDCC-08-00078

\]. The growing awareness about mental health underscores the urgent need for efficient and reliable methods of identification of mental problems and timely intervention. Conventional self-reporting techniques and clinical interviews for estimating mental health could be expensive, time-consuming, subjective, and biased \[

https://www.mdpi.com/2504-2289/8/7/78#B2-BDCC-08-00078

\]. There is potential for early identification and better diagnosis of mental issues. Subsequently, effective therapies to support mental well-being by investigating alternative strategies could be explored. Understanding facial expressions and the use of machine learning for emotion identification are potential alternatives for estimating mental health. Communication is indispensable for every aspect of humanness. In addition, spoken words, facial expressions, body language, eye movements, and other nonverbal cues do convey a lot of information about an individual's behavior, emotional state, and temperament \[

https://www.mdpi.com/2504-2289/8/7/78#B3-BDCC-08-00078

\]. The relationship between facial expressions and mental health has been very complex. Individual differences, cultural differences, social contexts, and experiences can influence the interpretation of emotions. The human capacity for emotional concealment makes this analysis even more complex. An individual experiencing depression, for example, may adopt a facade of happiness to mask internal turmoil. It is imperative to utilize objective methods to decipher the often-enigmatic language of facial expressions to understand mental health. A wide spectrum of thoughts, emotions, and intentions are communicated through facial expressions. Despite cultural and linguistic differences among individuals, most emotions are conveyed through similar facial expressions. These facial expressions are triggered by coordinated contractions of various facial muscles, either in dynamic movement or static postures. Psychological researchers have identified six basic emotions consistently associated with distinct facial expressions: happiness, surprise, fear, anger, sadness, and disgust \[

https://www.mdpi.com/2504-2289/8/7/78#B4-BDCC-08-00078

\]. Broadly, facial expressions can be categorized into two categories, viz. macro and micro-expressions. Macro-expressions are prominently visible because they involve entire facial muscles and last for two to three seconds. Micro-expressions involve the same facial muscles as macro-expressions but with subtler movements. Micro-expressions last for merely 1/50th to 1/200th of a second and are difficult to identify. This transience makes micro-expressions challenging to detect in real-time conversations with the naked eye, requiring skilled and attentive observers. The significance of micro-expressions lies in their potential to reveal underlying emotions masked by deliberate expressions. However, a major obstacle to developing accurate automated detection tools is the possibility of micro-expressions being confined to a single, localized area of the face \[

https://www.mdpi.com/2504-2289/8/7/78#B5-BDCC-08-00078

Facial action units (AUs) play a crucial role in providing a reliable and unbiased method of observing facial features. AUs offer a systematic and quantified approach to evaluating facial expressions by dissecting facial motions. Facial AUs refer to minuscule movements of specific facial muscles that contribute to a more detailed comprehension of emotions. These subtle distinctions separate authentic emotions from contrived ones \[

https://www.mdpi.com/2504-2289/8/7/78#B6-BDCC-08-00078

\]. Facial AUs offer a distinct perspective for evaluating mental well-being, as different combinations of AUs are linked to different mental health disorders. For instance, anxiety is associated with heightened activity in AU12 and AU17, whereas depression is characterized by reduced activity in AU6 and AU12 \[

https://www.mdpi.com/2504-2289/8/7/78#B7-BDCC-08-00078

https://www.mdpi.com/2504-2289/8/7/78#B8-BDCC-08-00078

\]. Examining the interaction between AUs might yield significant observations regarding an individual's psychological condition, facilitating prompt identification, tracking of treatment progress, and tailored healthcare.

https://www.mdpi.com/2504-2289/8/7/78#table\_body\_display\_BDCC-08-00078-t001

shows the significantly used action units for emotion recognition with their related muscle movement area on the face \[

https://www.mdpi.com/2504-2289/8/7/78#B9-BDCC-08-00078

Facial action units with their description.

By deciphering facial expressions, one can transcend subjective interpretations and get profound insight into the connection between the internal state and external manifestations of an individual \[

https://www.mdpi.com/2504-2289/8/7/78#B10-BDCC-08-00078

\]. The identification of micro-expressions (MEs) may contribute across a wide range of domains, including mental health, lie detection, law enforcement, political psychology, medical care, and human–computer interaction \[

https://www.mdpi.com/2504-2289/8/7/78#B11-BDCC-08-00078

\]. In contrast to conventional methods that rely on the extraction of hand-crafted features and the implementation of custom methods to analyze these features, this paper introduces a deep-learning approach to identify micro-expressions (MEs) based on facial action units (AUs).

Enabling mental health professionals to detect potential mental disorders at an earlier stage may help in designing effective custom treatment plans. Machine learning has revolutionized the mental health domain by employing facial AUs to comprehend and forecast emotions and mental states. Such integration of AUs and the computational capabilities of machine learning can revolutionize clinical diagnosis of mental health issues and timely intervention. The intricate facial expressions contain vital information regarding the emotions and cognitive conditions of an individual. Machine-learning algorithms, which have been trained on extensive datasets containing labeled facial expressions, can identify intricate patterns in the activation of AUs.

The rest of this paper is organized as follows.

https://www.mdpi.com/2504-2289/8/7/78#sec2-BDCC-08-00078

reviews the existing research on action unit recognition and emotion classification using machine-learning algorithms.

https://www.mdpi.com/2504-2289/8/7/78#sec3-BDCC-08-00078

elaborates on the materials and methodologies employed during the experimentation.

https://www.mdpi.com/2504-2289/8/7/78#sec4-BDCC-08-00078

presents the findings and discusses their significance. Finally,

https://www.mdpi.com/2504-2289/8/7/78#sec5-BDCC-08-00078

concludes the findings and summarizes the key takeaways of this research.

2. Related Work

Ensuring accurate diagnosis of mental health issues remains a critical concern. As stated earlier, conventional approaches, while helpful, can suffer from drawbacks, such as subjectivity in self-reporting, cost constraints, social biases, time-consuming procedures, or scheduling conflicts in clinical interviews. Recent studies have explored the possibility of using facial expressions, particularly brief micro-expressions, as bio-markers to identify the emotional states to overcome these constraints. This related work explores the recent research in automated mental health detection using facial expressions, facial action units, and machine learning. Additionally, the various methodologies employed for the identification of action units were also reviewed.

An automatic facial AU recognition and stress detection model was proposed using the support vector regression algorithm (SVR). The model was trained on BOSPHORUS and UNBC datasets and tested on experimental dataset SRD'15, having stressed and normal states. According to the study, the AUs that are under investigation when stress conditions arise are AU17, AU25, AU1, AU7, and AU26, which are the most modified and can distinguish between different emotional states \[

https://www.mdpi.com/2504-2289/8/7/78#B8-BDCC-08-00078

To identify the Depression Anxiety Stress Scale (DASS) levels, a support vector machine (SVM) machine-learning-based model was proposed to analyze facial expressions using action units. It was observed that the depressed emotional state has two sadness and happiness emotions with AU6, AU12, AU15, and AU26. Anxiety has surprise and disgust emotions with AU2, AU9, AU25, and AU45. Stress was measured with sadness and disgust emotions with AU1, AU6, AU12, and AU15. The model achieved 87.2%, 77.9%, and 90.2% accuracy on depression, anxiety, and stress, respectively \[

https://www.mdpi.com/2504-2289/8/7/78#B7-BDCC-08-00078

Facial expressions were used to identify depression and anxiety through a CNN-based approach VGG network. The FER+ dataset was used for the experiment. HAAR cascade was used for feature extraction from the facial images. The VGG model was used for normal and abnormal states as positive and negative emotion classification. Further, the negative emotions predict whether a person is depressed or has anxiety. The overall framework has achieved 95% accuracy \[

https://www.mdpi.com/2504-2289/8/7/78#B12-BDCC-08-00078

SVM and random forest (RF) machine-learning techniques were employed to develop an algorithm to validate the identified facial expressions with seven emotions. A web application was used as stimuli to show the 70 images randomly to the participants. At a time, a single participant was shown the 35 images' subset for ten minutes with the option buttons having happy, sad, and other emotions. The facial expressions of a total of 31 participants were captured as they observed the displayed images. The participants were then instructed to select the options that best described their emotions. Furthermore, the FeelPix labeled dataset was developed from these participants' recorded facial expressions based on left meningeal, right meningeal, nasal center, and subnasal center positions. The experiment shows promising results in the form of accuracy, precision, F1-score, and G mean for different emotions. Overall, 74% accuracy has been achieved while testing the algorithm \[

https://www.mdpi.com/2504-2289/8/7/78#B13-BDCC-08-00078

A long-short term memory (LSTM) algorithm-based depression detection framework was proposed, using facial expressions and action units. The video dataset of depressed and non-depressed samples was used for the experiment. An accuracy of 91.67% was achieved for depression detection. The key findings of this framework are that depressed subjects have shown movements in AU26, AU20, and AU07. Non-depressed facial movements were captured by AU06, AU25, AU14, and AU12 \[

https://www.mdpi.com/2504-2289/8/7/78#B14-BDCC-08-00078

Micro-expression recognition based on action units is divided into two parts i.e., feature extraction and emotion classification. The goal of ME recognition, such as video ME sequence “s”, which consists of “n” frames with fixed classes set “k”, is to determine which class each frame belongs to. The main emphasis is on classes that have a high probability of p(c

|s) among the classes with a probability of “k”. The overall structure of this process is shown in the

https://www.mdpi.com/2504-2289/8/7/78#fig\_body\_display\_BDCC-08-00078-f001

Basic architecture of ME classification.

Based on problem formulation to find the probability, techniques are divided into four categories.

## Conventional Techniques

In conventional techniques, hand-crafted features are employed, and the variance between the features is evaluated to identify expression segments from non-expression segments. Temporal and spatial dimensions are included in the model. The appearance of facial details, which represents the variance in pixel intensity like texture, or the geometric facial information, which includes the forms and placements of facial landmarks, are the two bases on which the features are extracted. These traditional approaches include local binary pattern on three orthogonal planes (LBP-TOP) \[

https://www.mdpi.com/2504-2289/8/7/78#B15-BDCC-08-00078

\], histogram of oriented optical flow (HOOF) \[

https://www.mdpi.com/2504-2289/8/7/78#B16-BDCC-08-00078

\], main directional mean optical flow (MDMO) \[

https://www.mdpi.com/2504-2289/8/7/78#B17-BDCC-08-00078

\], and bi-weighted oriented optical flow (Bi-WOOF) \[

https://www.mdpi.com/2504-2289/8/7/78#B18-BDCC-08-00078

\]. Feature extraction through LBP-TOP is a combination of LBP histograms of three orthogonal planes named XY, YT, and XT. Histogram concatenation results in duplicate information when neighboring pixels are utilized multiple times in the LBP-TOP computation. Through the extraction of some AUs' substantial optical flow direction, MDMO is employed to characterize localized facial dynamics.

Despite these methods, the mean oriented Riesz features (MORF) technique uses the Riesz pyramid to describe the MEs' evolution in two frames, named MOR image sets, which is then utilized to create a histogram \[

https://www.mdpi.com/2504-2289/8/7/78#B19-BDCC-08-00078

\]. A 3D histogram of oriented gradient (HOG) is used to recognize the MEs by applying it to twelve facial areas. A fusion of motion boundary histogram (FMBH) is created by combining motion boundary histograms constructed using norms with angles calculated from the optical flow's horizontal and vertical components \[

https://www.mdpi.com/2504-2289/8/7/78#B20-BDCC-08-00078

## Deep-Learning Techniques

Deep-learning approaches are commonly used to solve tasks related to computer vision, such as detecting objects, as well as tracking and video labeling, including image classification. Numerous researchers have evaluated and used the deep-learning framework for ME analysis because of the deep-learning models' outstanding results on these types of assignments. Most innovative deep-learning systems are built using convolutional neural network (CNN) variants or the combination of CNN and recurrent neural network (RNN). A CNN framework was proposed for ME recognition by employing pre-trained weights for feature extraction trained on ImageNet CK+ and SPOS datasets \[

https://www.mdpi.com/2504-2289/8/7/78#B21-BDCC-08-00078

https://www.mdpi.com/2504-2289/8/7/78#B22-BDCC-08-00078

\]. A lateral accretive hybrid network (LEAR-Net) was proposed; this was a CNN-based system that used an accretion layer to enhance the network's learning capacity, hence improving the salient expression aspects \[

https://www.mdpi.com/2504-2289/8/7/78#B23-BDCC-08-00078

\]. In another proposed framework, long-short term memory (LSTM) and CNN were employed for temporal and spatial feature extraction. Although accuracy advancements have been considerable for most computer vision applications, advancements in ME evaluation have been relatively moderate \[

https://www.mdpi.com/2504-2289/8/7/78#B24-BDCC-08-00078

## Hybrid Techniques

Hybrid techniques utilize the conventional and deep-learning approaches to produce better outcomes. Different optical flow methods are used for feature extraction using CNN. Off-ApexNet was proposed for ME recognition by using only onset and apex frames through optical flow for feature extraction. Subsequently, a shallow triple stream 3D CNN was proposed to show the improvements in Off-ApexNet by adding the vertical and horizontal optical flow \[

https://www.mdpi.com/2504-2289/8/7/78#B24-BDCC-08-00078

\]. An enriched long-term recurrent convolutional network (EL-RCN) was proposed for the computation of optical flow and strain for training the spatial features. In this framework, two approaches were used, namely spatial dimension enrichment and temporal dimension enrichment using the VGG-16 model. For classification, the LSTM algorithm was employed. A spatiotemporal recurrent convolutional network was proposed with two variations. First, based on appearance connectivity in one-dimensional vectors and second, with geometrical connectivity of optical flow \[

https://www.mdpi.com/2504-2289/8/7/78#B25-BDCC-08-00078

\]. The implementation of conventional approaches to streamline the extraction of spatiotemporal features and the process of classification using deep-learning architecture is an advantage of the techniques in this area.

## Region of Interest-Based Techniques

The previously mentioned techniques focus on the improvement of feature extraction, but region-based strategies target the locality segment in data preprocessing. Instead of analyzing the entire face of MEs, region-of-interest approaches are employed to retrieve reliable and pertinent information \[

https://www.mdpi.com/2504-2289/8/7/78#B26-BDCC-08-00078

https://www.mdpi.com/2504-2289/8/7/78#B27-BDCC-08-00078

\], six distinct regions were originally identified including right and left cheeks, eyes and eyebrows, the nose, and the mouth. In another investigation, a manual selection of active patches was captured through eighteen regions of interest (ROIs). To identify the necessary morphological patches (NMPs), a weight was assigned to every active patch. Based on the characteristics that LBP-TOP has extracted, the weights were calculated using the entropy-weight approach \[

https://www.mdpi.com/2504-2289/8/7/78#B28-BDCC-08-00078

\]. In subsequent research, rather than selecting the eighteen action patches manually, the six regions were split into smaller blocks to obtain 106 active patches. The random forest (RF) technique was applied to features extracted from action patches using LBP-TOP and optical flow for NMPs \[

https://www.mdpi.com/2504-2289/8/7/78#B29-BDCC-08-00078

3. Materials and Methods

## Datasets

This study used two datasets—Spontaneous Actions and Micro-Movements (SAMM) and Chinese Academy of Sciences Micro-expression II (CASME II), which are the two most prominent datasets used in micro-expression based studies.

The SAMM dataset is the most recent high-resolution collection of 159 spontaneously produced micro-movements with the greatest demographic heterogeneity. The dataset was designed to be as varied as practicable to capture a wide range of emotional reactions. A total of 32 participants, with an average age of 33.24 years, were recruited for the experiment, representing an equal number of male and female participants. Based on the seven fundamental emotions, the induction process was captured at 200 frames per second (fps). The resolution of the facial region is around 400 × 400 pixels, while the overall resolution is 2040 × 1088 pixels. The SAMM dataset has seven classes including anger, happiness, surprise, contempt, fear, disgust, and others \[

https://www.mdpi.com/2504-2289/8/7/78#B30-BDCC-08-00078

The CASME II dataset is an improved version of CASME. Every sample in this dataset has spontaneous and dynamic micro-expressions. The CASME II dataset is a collection of 249 samples at 200 frames per second. The total number of participants was 35 (male + female). The resolution of the facial region is around 280 × 340 pixels, while the overall resolution is 640 × 480 pixels. The CASME II dataset is divided into five categories, such as happiness, surprise, repression, disgust, and others \[

https://www.mdpi.com/2504-2289/8/7/78#B31-BDCC-08-00078

https://www.mdpi.com/2504-2289/8/7/78#table\_body\_display\_BDCC-08-00078-t002

provides information about the purpose, methodology employed, outcomes, accuracy, and the exploration area for both datasets. The CASME II and SAMM datasets were utilized to identify micro-expression and emotion recognition based on facial muscle movements, action units, facial skin deformations, elasticity, and landmark feature maps.

Analysis of the CASME II and SAMM datasets.

## Proposed Framework

The following procedures are part of the suggested framework for the recognition and classification of micro-expressions utilizing action units: pre-processing of the data, recognition of action units, classification of emotions, and micro-expression subdivision, shown in

https://www.mdpi.com/2504-2289/8/7/78#fig\_body\_display\_BDCC-08-00078-f002

Proposed framework architecture (adapted with permission from ©Xiaolan Fu \[

https://www.mdpi.com/2504-2289/8/7/78#B31-BDCC-08-00078

### Data Pre-Processing

https://www.mdpi.com/2504-2289/8/7/78#fig\_body\_display\_BDCC-08-00078-f002

illustrates the proposed framework. Initially, it invokes a two-step data preparation process to pre-process input images for further evaluation. Data pre-processing primarily includes face detection and detected facial image enhancement.

The initial step involves the identification of faces within the given video sequence by employing a pre-trained Haar cascade classifier. Further, the Haar cascade classifier provides bounding boxes and pinpoints the detected faces within an image. This, in turn, facilitates the creation of a uniform data format for subsequent analysis. This uniformity is achieved by enabling the extraction of facial regions with consistent proportions and alignment, as described in \[

https://www.mdpi.com/2504-2289/8/7/78#B35-BDCC-08-00078

\]. Subsequently, the contrast limited adaptive histogram equalization (CLAHE) model is invoked for image enhancement. This method augments the contrast within specific facial areas, particularly in images characterized by uneven lighting and low contrast levels. CLAHE operates by dividing the image into smaller sub-regions (tiles) and applying localized histogram equalization to each tile. This approach enhances contrast within each region while minimizing the overall contrast change, thereby mitigating the formation of visual artifacts \[

https://www.mdpi.com/2504-2289/8/7/78#B36-BDCC-08-00078

### Action Unit Detection

A pre-trained model that has been trained on the facial action coding system (FACS) is used to detect the action units from pre-processed images. During evaluation, the model collects expressions, such as lip configurations, eyebrow movements, and wrinkle patterns that are suggestive of activation of AUs. Embedded computer vision algorithms in the pre-trained model automatically detect the intensity and presence of AUs \[

https://www.mdpi.com/2504-2289/8/7/78#B26-BDCC-08-00078

### Emotion Classification

Comprehensive representations of encountered emotions are provided by the identified AUs. The purpose of this model is to transform the combination of activated AUs into recognizable emotions, such as surprise, happiness, sadness, anger, etc. We use the identified AUs as an abundant collection of characteristics for an independent deep-learning model intended for the categorization of emotions. This model is specially trained to map combinations of AUs to discrete emotion categories. The model intakes a large dataset of annotated facial images during training. Each image has a related active AU (such as happiness, sadness, or anger) that corresponds to that emotion. The program learns the complex links between different AUs and how they are associated with different emotions by analyzing this data. For example, the model may detect that displays of happiness often co-occur with a combination of AU 6 (raised cheeks) and AU 12 (lip corners pushed up). On the other hand, AU 7 (lid tightener) and AU 4 (brow furrow) might represent sadness. During this phase of learning, the model creates a strong association between emotional states and AU pairings.

### Action Units Combinations

K-means clustering of the action units is performed by implementing the specific emotion and the associated activated action unit information from the previous step as shown in

https://www.mdpi.com/2504-2289/8/7/78#fig\_body\_display\_BDCC-08-00078-f002

. This will provide the clustering of different combinations of action units as ME1, ME2, to ME

based on silhouette analysis. It assesses an object's similarity to its cluster concerning other clusters. The silhouette score varies between −1 to 1, which indicates a low value for inadequate match to nearby clusters and a high value for appropriate grouping of its own cluster. The formula used for the calculation of silhouette score at a particulate point is:

s ( k ) = b k − a k max  { a k , b k }

where s(k) ≥ silhouette score for a single data point k

a(k) ≥ average distance between K to other points (within the same cluster)

b(k) ≥ smallest average distance of K (to different clusters)

#### To calculate the average score for the dataset, calculated by:

A v e r a g e S i l h o u e t t e S c o r e = 1 N ∑ k = 1 N = s ( k )

where N ≥ total number of points in the dataset.

## Model Architecture

The proposed framework used a customized CNN architecture that emerged especially to detect action units (AUs) in facial images. This model maintains superior results while giving priority to lightweight design.

The input layer that the model receives has a predetermined form, such as 8 × 8 × 512, where 8 stands for the width and height of resized frames in pixels. The images are pre-processed to generate a high-dimensional feature vector having 512 channels \[

https://www.mdpi.com/2504-2289/8/7/78#B37-BDCC-08-00078

\]. The benefit of a high-dimensional feature vector is that it captures the essential information from the video frames. A zero-padding layer adds padding pixels around the borders of the input image. This helps prevent information loss during the convolution operation. To extract initial features from the padded picture, a 7 × 7 convolutional layer with 16 filters and a stride of 2 pixels is used. Stride 2 reduces the dimensionality of the image by having the filter move by 2 pixels in both the horizontal and vertical directions following each convolution process.

By stabilizing the neuronal activations, batch normalization contributes to the stabilization of the learning process. By introducing non-linearity into the network using a ReLU (rectified linear unit) activation function, the model can learn more intricate correlations between features. The most important characteristics are retained while the picture dimensionality is further reduced by a subsequent 3 × 3 max pooling layer with a stride of 2 pixels. Max pooling takes the maximum value from a defined window (here, 3 × 3) and moves the window across the image with a stride of 2.

The RepeatLayers function uses multiple convolutional layers, which enhances the feature extraction at each layer. The main motive for adding multiple layers is that the usage of features extracted at the initial layer will be added to subsequent layers with high-dimensional features. Using this approach, the network will gradually learn more intricate visualizations of the input \[

https://www.mdpi.com/2504-2289/8/7/78#B38-BDCC-08-00078

https://www.mdpi.com/2504-2289/8/7/78#B39-BDCC-08-00078

\]. This function stacks two convolutional layers with the same number of output filters but different filter sizes (e.g., 3 × 3). After every convolutional layer, batch normalization, and ReLU activation are used. Including a shortcut connection is an important feature. Because of this link, the model will immediately add the first convolutional layer's output to the second convolutional layer's output inside the RepeatLayers block. Particularly in deeper networks, this aids in gradient flow and learning. To gradually capture increasingly complicated characteristics, the design uses the RepeatLayers function twice, with progressively more filters, such as 16 to 16, then 32 to 32. In addition, this function projects the shortcut connection that ensures the dimensions are accurately aligned. In case the number of filters in the shortcut connection differs from the number of filters in the output of the convolutional layers, a 1 × 1 convolutional layer is applied to the shortcut to bring the number of filters in line.

The collected features are combined over the feature maps' whole spatial dimension using a global average pooling layer. In other words, it creates a single feature vector for each image by averaging the values from each channel throughout the feature map's width and height. Finally, a dense layer that is completely linked and has as many neurons as the number of AUs being targeted is applied. The output layer generates the final output probabilities for each AU using a softmax activation function. The output values of the softmax function are guaranteed to total up to 1 and reflect probabilities between 0 and 1.

https://www.mdpi.com/2504-2289/8/7/78#table\_body\_display\_BDCC-08-00078-t003

presents the network configuration of the proposed model.

Proposed model's network configuration.

Performance Metrics

The accuracy (ACC) measure shows the proportion of test dataset emotions that were properly identified overall. It provides a general understanding of the model's ability to map detected AUs to pre-defined emotional categories. The mathematical expression for this is:

ACC = (TP + TN)/(TP + TN + FP + FN)

where TP is true positive, the total number of emotions that are accurately identified, TN is true negatives, the total number of accurately categorized non-emotions, FP is false positives, the number of emotions that are misclassified (e.g., disgust when contempt), and FN is false negatives, the number of emotions that the model failed to recognize (missing a fear expression).

Precision (P) quantifies the proportion of true positives, or emotions that are accurately categorized, to all positive predictions, or images that the model recognized as corresponding to a certain emotion. The model's ability to prevent false positives—the inaccurate classification of emotions—is shown by a high accuracy. One way to calculate it is:

P = TP/(TP + FP)

Recall (R) is the percentage of accurately identified emotions, or true positives, among all true positive examples (images that are in the test set containing the intended emotion). Most of the pertinent emotions found in the data can be identified by the model with a high recall. It is comprehensible as:

R = TP/(TP + FN)

F1-score (F1) offers a balanced perspective on recall and precision by taking the harmonic mean of both variables. It considers the model's capability to detect true positives as well as its ability to prevent false positives. It is computed as follows:

F1 = 2 × (P × R)/(P + R)

## Micro-Expression Sub-Division

To make clusters (sub-divisions) of the different micro-expressions, such as happiness, sadness, anger, etc., the K-means clustering algorithm is employed. The K-means clustering technique is widely used to categorize unlabeled data elements into discrete groups. The data elements are progressively assigned to the cluster corresponding to the closest mean as a centroid in an iterative manner. The objective of this method is to form clusters that are both well-separated from one another as well as internally homogenous.

4. Result and Discussion

## Results

### Emotion Classification

A customized CNN model architecture is used for emotion classification, employing the datasets CASME II, with 5 classes, and SAMM, with 7 classes. To evaluate the model's performance to classify emotions, a confusion matrix is employed, which provides a detailed breakdown of true positives, true negatives, false positives, and false negatives. Further, the model is assessed using standard metrics like accuracy, precision, recall, and F1-score to determine emotions based on the observed AUs.

https://www.mdpi.com/2504-2289/8/7/78#fig\_body\_display\_BDCC-08-00078-f003

https://www.mdpi.com/2504-2289/8/7/78#fig\_body\_display\_BDCC-08-00078-f004

show the confusion matrix for CASME and SAMM datasets:

Confusion matrix for CASME dataset.

Confusion matrix for SAMM dataset.

The model achieved an accuracy of 95.62% on the CASME II dataset and 93.21% on the SAMM dataset. The CASME II dataset achieved a precision of 93.56, recall of 95.62, and F1-score of 91.78, and for the SAMM dataset these values are 91.45, 93.21, and 89.31. The attained precision signifies the model's ability to categorize well-known emotions according to the identified AUs. Due to its high accuracy value, the model is thought to identify emotions effectively and prevent misclassifications with a minimal number of false positives. The recall number indicates how well the model can represent most of the real emotions seen in the test data. Ultimately, the F1-score supports the model's balanced performance by taking both recall and accuracy into account.

### Micro-Expression Sub-Division Based on Action Units

To make clusters (sub-divisions) of the different micro-expressions, such as happiness, sadness, anger, etc., the K-means clustering algorithm is employed. The K-means clustering technique is widely used to categorize unlabeled data elements into discrete groups. The data elements are progressively assigned to the cluster corresponding to the closest mean as a centroid in an iterative manner. The objective of this method is to form clusters that are both well-separated from one another as well as internally homogenous. The effectiveness of data points' clustering inside their designated groupings in comparison to points in other clusters is evaluated by silhouette score. As mentioned above in

Section 3.4

https://www.mdpi.com/2504-2289/8/7/78#sec3dot4-BDCC-08-00078

, scores nearest to 1 indicate well-formed clusters, 0 for overlapping, and −1 for weak cluster formation. The results of this experiment have obtained significant information on the ideal number of clusters and the overall efficacy of the K-means clustering for the SAMM dataset by examining the silhouette score for various K combinations for distinct emotions, as shown in

https://www.mdpi.com/2504-2289/8/7/78#fig\_body\_display\_BDCC-08-00078-f005

Silhouette score for combination of AUs for distinct micro-expressions.

### Ablation Study

This ablation study aims to analyze the impact of the proposed framework to measure its performance among other machine-learning algorithms. The comparison between the proposed model and other algorithms, such as SVM, DT, ANN, and conventional CNN, is presented in

https://www.mdpi.com/2504-2289/8/7/78#table\_body\_display\_BDCC-08-00078-t004

. The decision tree has achieved a very low accuracy of 18.54% in micro-expression recognition. A decision tree works on clear decision boundaries and micro-expressions change with complex patterns. This might be the reason that the decision tree failed to capture these subtle changes with complex patterns. The results show that the proposed model has achieved remarkable accuracy among others.

Evaluation of the proposed model among other ML classifiers.

To assess the performance of the proposed model through varying the numbers of convolutional layers, epochs, batch size, optimizer, batch normalization, etc., these are presented in

https://www.mdpi.com/2504-2289/8/7/78#table\_body\_display\_BDCC-08-00078-t005

https://www.mdpi.com/2504-2289/8/7/78#table\_body\_display\_BDCC-08-00078-t006

https://www.mdpi.com/2504-2289/8/7/78#table\_body\_display\_BDCC-08-00078-t007

https://www.mdpi.com/2504-2289/8/7/78#table\_body\_display\_BDCC-08-00078-t008

Evaluation of the proposed model depending on a variable number of parameters.

Evaluation of the proposed model depending on epochs and batch size.

Evaluation of the proposed model with and without batch normalization layers.

Evaluation of the proposed model depending on the activation function.

The results shown in

https://www.mdpi.com/2504-2289/8/7/78#table\_body\_display\_BDCC-08-00078-t005

indicate that both the number of layers and the optimizer play a significant role in neural networks. The increment in the number of layers led to improved accuracy irrespective of the optimizer used. The Adam optimizer consistently achieved higher accuracy compared to SGD. In our case, the best combination was found with a 5-layer structure with the Adam optimizer.

https://www.mdpi.com/2504-2289/8/7/78#table\_body\_display\_BDCC-08-00078-t006

suggests that the model benefits from both more training time to learn the intricate patterns and more data points per update to improve gradient estimation. If we increase the epochs or batch size, it can lead to overfitting. In that case, the model can learn from training data but performs poorly on unseen examples.

https://www.mdpi.com/2504-2289/8/7/78#table\_body\_display\_BDCC-08-00078-t007

shows that batch normalization plays an important function in stabilizing the training process, which makes the model learn effectively. The selection of the activation function has a significant influence on the correctness of the proposed model. The activation functions explored during the study in

https://www.mdpi.com/2504-2289/8/7/78#table\_body\_display\_BDCC-08-00078-t008

indicate that the elu and sigmoid functions result in low performance. The activation function tanh performed better. Due to the high computational efficiency, as well as to prevent the vanishing gradients, the relu function outperformed the other functions. It enables the model to learn effectively from variations throughout the whole network.

## Discussion

The earlier sections examined the possibilities of computational learning and action units in identifying mental health conditions. This section explores the significance and ramifications of the results through a comparison between state-of-the-art techniques. Further, micro-expression sub-division is discussed based on different combinations of action units related to specific emotions. Subsequently, a case study is performed to evaluate the performance of the model by analyzing interview videos of depressed patients. Furthermore, this section explores the promising possibilities of ME utilization in applied, experimental, clinical, and assistive scenarios.

### Comparison with State-of-the-Art Techniques

Micro-expressions—brief facial movements that convey real emotions—have enormous possibilities for use in automated emotion evaluation. However, it is still difficult to discern emotions through such nuanced visuals. This section compares the outcomes of the proposed approach to existing state-of-the-art methods in terms of datasets, methods, and accuracy percentage in

https://www.mdpi.com/2504-2289/8/7/78#table\_body\_display\_BDCC-08-00078-t009

Comparison of state-of-the-art techniques with the proposed technique.

### Micro-Expression Sub-Division

https://www.mdpi.com/2504-2289/8/7/78#table\_body\_display\_BDCC-08-00078-t010

lists the grouping of action units according to emotions. This demonstrates that an emotion and the action units that go along with it can have one or many combinations. Some combinations of AUs with 12A or 12B AUs represent the eye blinking and left or right eye movements. The AUs with L or R represent the activation on the left side or right side of the face.

Micro-expressions of different emotions.

### Mental Health Assessment

Depression, stress, and anxiety are common mental health conditions that are frequently characterized by an all-encompassing sense of melancholy, disinterest, or adjustments to sleep and eating patterns. One of the major obstacles to treating these kinds of mental health issues is that they can appear subtly, especially in those who are good at hiding their emotions. Considering such conditions, facial micro-expressions present a promising way to identify depression, stress, anxiety, or other mental health issues because they are brief, spontaneous expressions that might disclose underlying emotions. These unnoticed, millisecond-long micro-expressions can reveal a lot about an individual's genuine emotional state and can be evaded consciously. However, these fast and nuanced emotions are difficult for the human eye to pick up on.

The proposed model is implemented on a video dataset of clinical interactions with patients suffering from mental health issues, which is publicly available on YouTube. These videos are the psychiatric interviews uploaded by the University of Nottingham with 480 × 360 resolution. There was no predetermined structure for these clinical interviews, so participants conversed freely and answered standard questions on mental health without being prompted. Initially, the pre-processing of these videos was done for face detection. After that, the pre-processed data were passed to the trained model.

https://www.mdpi.com/2504-2289/8/7/78#fig\_body\_display\_BDCC-08-00078-f006

shows the resultant confusion matrix of the experiment, which has achieved an accuracy of 92.99% for emotion recognition.

Confusion matrix for the case study.

This confusion matrix reveals that most depressed individuals experience disgust, anger, sadness, fear, and surprise emotions. The clustering model gives the predicted action units to determine under which emotion group they will be classified. The results show that most of these images have the following emotions: disgust, anger, and sadness with activated AU10 (upper lip raiser), AU4 (brow lowerer), AU1(inner brow raiser), AU17 (chin raiser), AU15 (lip corner depressed), and AU7 (lid tightener) with AU4, AU6 and AU9 combination. Therefore, the predicted cluster values fall under Disgust\_ME1, Disgust\_ME2, Sadness\_ME1, Sadness\_ME2, Anger\_ME1, Anger\_ME2, Anger\_ME5, Surprise\_ME4, and Disgust\_ME8.

The proposed emotion recognition technique based on facial micro-expressions has the potential as a beneficial tool in numerous healthcare settings. It can facilitate the diagnoses of mental health conditions, such as stress, anxiety, depression, autism spectrum disorder, etc., while interacting with the patients \[

https://www.mdpi.com/2504-2289/8/7/78#B44-BDCC-08-00078

\]. Also, it can be used to enhance the accuracy of pain analysis in individuals with impaired communication abilities. Emotion recognition remains an area for improvement in human–computer interaction (HCI) applications. Therefore, it can enhance the HCI in medical settings by enabling machines to have a deeper knowledge of user emotions \[

https://www.mdpi.com/2504-2289/8/7/78#B45-BDCC-08-00078

\]. Though these applications indicate the potential, additional investigations are required to validate the proposed model's accuracy in real-world settings. Moreover, ethical considerations are the major challenge related to the confidentiality and information security of the patients.

### Application Scenarios

Emotion recognition through micro-expressions has the potential to provide substantial contributions to various real-world applications. This technology can be employed in assistive environments as well as in controlled clinical research. ME-based emotion recognition can be used in numerous areas, such as healthcare, neuromarketing, marketing, gaming, UI and UX Design, human–computer interaction (HCI), computer vision (CV) simulation, entertainment, and education. In healthcare monitoring systems, facial expression recognition is used for behavior analysis \[

https://www.mdpi.com/2504-2289/8/7/78#B46-BDCC-08-00078

\], pain detection \[

https://www.mdpi.com/2504-2289/8/7/78#B47-BDCC-08-00078

\], patient monitoring \[

https://www.mdpi.com/2504-2289/8/7/78#B48-BDCC-08-00078

\], and developing assistive technologies \[

https://www.mdpi.com/2504-2289/8/7/78#B49-BDCC-08-00078

\]. In HCI, assistive techniques for emotion recognition can provide a better understanding of users' emotional reactions to content moderation and sentiment analysis \[

https://www.mdpi.com/2504-2289/8/7/78#B45-BDCC-08-00078

https://www.mdpi.com/2504-2289/8/7/78#B50-BDCC-08-00078

### Experimental Scenarios

The experimental scenarios of this work could be in mental health assessment, healthcare monitoring, driver drowsiness detection, flight simulation, user interface designing, education, human resource management, and game design. The effectiveness of the method can be measured by using different stimuli, such as video clips, images, and audio. The subtle facial muscle movements vary, correlated to physiological changes, giving a better understanding of emotions comprehensively. Also, the experiment could be employed for developing a cross-cultural facial expression recognition model \[

https://www.mdpi.com/2504-2289/8/7/78#B51-BDCC-08-00078

https://www.mdpi.com/2504-2289/8/7/78#B52-BDCC-08-00078

https://www.mdpi.com/2504-2289/8/7/78#B53-BDCC-08-00078

Emotions are strongly influenced by cultural differences and indirectly affect the recognition and production of MEs. Cultural influence on micro-expressions can be divided into people from Eastern cultures, with low-arousal, and people from Western cultures, with high-arousal emotional expressions. The neural indication, such as functional magnetic resonance imaging (fMRI), has shown that Chinese people value a state of calmness and European/American people value excitement more than calmness. people from Eastern cultures express more around the eye regions and people from Western cultures express their emotions through the full-face \[

https://www.mdpi.com/2504-2289/8/7/78#B54-BDCC-08-00078

https://www.mdpi.com/2504-2289/8/7/78#B55-BDCC-08-00078

https://www.mdpi.com/2504-2289/8/7/78#B56-BDCC-08-00078

\]. The considerate intensity of an identified emotion is the most important determinant for ME-based emotion recognition. Previous research has shown that MEs appear with very low intensity and macro facial expressions appear with high intensity. Pronounced intensities of macro-expressions can be captured through facial texture deformations and facial movements due to their presence on a large facial region \[

https://www.mdpi.com/2504-2289/8/7/78#B29-BDCC-08-00078

### Clinical Scenarios

As mentioned in

Section 4.2.3

https://www.mdpi.com/2504-2289/8/7/78#sec4dot2dot3-BDCC-08-00078

, this technique can be used for mental health assessment and pain management. Early identification of different mental illness signs, such as depression, anxiety, or stress might be helpful to the clinician as well as patients for proper diagnosis and treatment. It can also be used to monitor the emotional states and improvement during rehabilitation, which enables the therapists to manage the treatment approach. Patients having impaired communication skills or difficulty in verbal communication during pain management can be monitored and helped with critical situations \[

https://www.mdpi.com/2504-2289/8/7/78#B53-BDCC-08-00078

https://www.mdpi.com/2504-2289/8/7/78#B57-BDCC-08-00078

https://www.mdpi.com/2504-2289/8/7/78#B58-BDCC-08-00078

https://www.mdpi.com/2504-2289/8/7/78#B59-BDCC-08-00078

\]. Facial MEs have the potential for utilization in mental health analysis, despite the existence of substantial challenges. Some of the prominent areas for mental health detection are discussed below:

#### Depression detection:

Non-verbal clues, such as facial expressions, might serve as symptoms of depressive conditions in mental health analysis. As in clinical settings, depression diagnosis can be time-consuming and highly dependent upon expert observation. Automated detection of depressive disorders must be taken into consideration for early and effective treatment. It can be used as a screening tool for depression detection and treatment progress monitoring \[

https://www.mdpi.com/2504-2289/8/7/78#B60-BDCC-08-00078

https://www.mdpi.com/2504-2289/8/7/78#B61-BDCC-08-00078

https://www.mdpi.com/2504-2289/8/7/78#B62-BDCC-08-00078

https://www.mdpi.com/2504-2289/8/7/78#B63-BDCC-08-00078

#### Anxiety and stress detection:

ME-based stress or anxiety detection methods have great potential in mental health interventions. Their goal is to identify the subtle symptoms of repression, discomfort, or worry, which could reveal the hidden stress. This technique has potential for applications in healthcare monitoring, workplace stress assessment, and in psychology, due to its effective and non-invasive methodology. Anxiety levels can also be measured through monitoring the subtle changes in facial muscles, like twitching under the eye and lip corner areas \[

https://www.mdpi.com/2504-2289/8/7/78#B7-BDCC-08-00078

https://www.mdpi.com/2504-2289/8/7/78#B8-BDCC-08-00078

https://www.mdpi.com/2504-2289/8/7/78#B64-BDCC-08-00078

#### Autism spectrum disorder (ASD):

ASD is a neurodevelopmental disorder that affects the social engagement, communication skills, and behavior of an individual. People with ASD cannot express their emotions and face difficulty in managing their anxiety or stress. ME analysis of the ASD-affected persons could offer a direction to understand their emotional states and behavior that can be used to diagnose and their communication training \[

https://www.mdpi.com/2504-2289/8/7/78#B65-BDCC-08-00078

https://www.mdpi.com/2504-2289/8/7/78#B66-BDCC-08-00078

#### Mood disorder:

ME-based applications can be explored to monitor the individual's overall mood variations with mental health conditions like bipolar disorder. This could be helpful for tracking the treatment progress throughout the time period where the continuous monitoring of mood variations is required \[

https://www.mdpi.com/2504-2289/8/7/78#B67-BDCC-08-00078

#### Post-traumatic stress disorder (PTSD):

People with mental health conditions such as PTSD are prone to experiencing emotional trauma and flashbacks related to a horrifying event they experienced before. Micro-expression-based emotion analysis could potentially be used to identify the PTSD triggers and help to diagnose and treatment \[

https://www.mdpi.com/2504-2289/8/7/78#B14-BDCC-08-00078

https://www.mdpi.com/2504-2289/8/7/78#B68-BDCC-08-00078

### Assistive Scenarios

To enhance communication for individuals who have difficulty speaking, augmentative and alternative communication (AAC) technology might be upgraded by incorporating this technique \[

https://www.mdpi.com/2504-2289/8/7/78#B69-BDCC-08-00078

\]. Also, in educational scenarios, it could help the educator to change their teaching techniques by reviewing the student's emotional involvement during class activities from real-time captured emotional information \[

https://www.mdpi.com/2504-2289/8/7/78#B70-BDCC-08-00078

\]. The proposed technique can be explored in a virtual reality (VR)-based therapy system for mental health assessment by adapting the individual's emotional state \[

https://www.mdpi.com/2504-2289/8/7/78#B71-BDCC-08-00078

https://www.mdpi.com/2504-2289/8/7/78#B72-BDCC-08-00078

https://www.mdpi.com/2504-2289/8/7/78#B73-BDCC-08-00078

\]. This could also be beneficial for robots utilized in marketing, companionship, or in healthcare \[

https://www.mdpi.com/2504-2289/8/7/78#B49-BDCC-08-00078

5. Conclusions

This study intended to determine the feasibility of assigning micro-expression labels to indicate possible emotional variances seen in facial expressions using facial action units. The proposed method incorporates the CASME II and SAMM datasets, which provide information regarding the emotion, action units related to the facial muscle movements, objective classes, and significant parameters. The model trained on these datasets achieved 95.62% and 93.21% accuracy and was trialed for the assessment of depressive disorder from annotated video data. The findings show that majority of the depressed individuals exhibit disgust, sadness, and anger emotions. This has great potential in the discipline of mental health, as early intervention and therapy can greatly benefit from an accurate assessment of emotional states. In the future, other significant feature extraction techniques will be used to attain higher accuracy for mental health assessment and to assign the labels for this clinical interview data as ground truth. The suggested framework provides an intriguing approach for emotion recognition using micro-expressions, through action units with CNN and K-means clustering algorithms for ME label assignment. Future avenues for investigation also include finding the intensity level of low, medium, or high for micro-expression sub-division.

Author Contributions

Conceptualization, D.S. and J.S.; Formal analysis, S.S.S. and S.K.S.; Methodology, D.S., J.S. and S.S.S.; Project administration, D.S. and J.S.; Writing – original draft, D.S. and J.S.; Writing—review & editing, S.S.S. and S.K.S. All authors have read and agreed to the published version of the manuscript.

This research received no specific grant from any funding agency in the public, commercial, or not-for-profit sectors.

Data Availability Statement

The dataset used in this study is fully available as an open-source resource.

Conflicts of Interest

The authors declare no conflict of interest.

Galderisi, S.; Heinz, A.; Kastrup, M.; Beezhold, J.; Sartorius, N. Toward a new definition of mental health. World Psychiatry

, 14, 231–233. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Toward+a+new+definition+of+mental+health&author=Galderisi,+S.&author=Heinz,+A.&author=Kastrup,+M.&author=Beezhold,+J.&author=Sartorius,+N.&publication\_year=2015&journal=World+Psychiatry&volume=14&pages=231%E2%80%93233&doi=10.1002/wps.20231&pmid=26043341

https://doi.org/10.1002/wps.20231

https://www.ncbi.nlm.nih.gov/pubmed/26043341

Rayan, A.; Alanazi, S. A novel approach to forecasting the mental well-being using machine learning. Alex. Eng. J.

, 84, 175–183. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=A+novel+approach+to+forecasting+the+mental+well-being+using+machine+learning&author=Rayan,+A.&author=Alanazi,+S.&publication\_year=2023&journal=Alex.+Eng.+J.&volume=84&pages=175%E2%80%93183&doi=10.1016/j.aej.2023.10.060

https://doi.org/10.1016/j.aej.2023.10.060

Pise, A.A.; Alqahtani, M.A.; Verma, P. K, P.; Karras, D.A.; Halifa, A. Methods for Facial Expression Recognition with Applications in Challenging Situations. Comput. Intell. Neurosci.

, 2022, 9261438. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=K,+P.;+Karras,+D.A.;+Halifa,+A.+Methods+for+Facial+Expression+Recognition+with+Applications+in+Challenging+Situations&author=Pise,+A.A.&author=Alqahtani,+M.A.&author=Verma,+P.&publication\_year=2022&journal=Comput.+Intell.+Neurosci.&volume=2022&pages=9261438&doi=10.1155/2022/9261438&pmid=35665283

https://doi.org/10.1155/2022/9261438

https://www.ncbi.nlm.nih.gov/pubmed/35665283

Feng, Y.; Zhou, Y.; Zeng, S.; Pan, B. Facial expression recognition based on convolutional neural network. In Proceedings of the 2019 IEEE 10th International Conference on Software Engineering and Service Science (ICSESS), Beijing, China, 18–20 October 2019; pp. 410–413. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Facial+expression+recognition+based+on+convolutional+neural+network&conference=Proceedings+of+the+2019+IEEE+10th+International+Conference+on+Software+Engineering+and+Service+Science+(ICSESS)&author=Feng,+Y.&author=Zhou,+Y.&author=Zeng,+S.&author=Pan,+B.&publication\_year=2019&pages=410%E2%80%93413&doi=10.1109/ICSESS47205.2019.9040730

https://doi.org/10.1109/ICSESS47205.2019.9040730

Shen, X.B.; Wu, Q.; Fu, X.L. Effects of the duration of expressions on the recognition of microexpressions. J. Zhejiang Univ. Sci. B

, 13, 221–230. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Effects+of+the+duration+of+expressions+on+the+recognition+of+microexpressions&author=Shen,+X.B.&author=Wu,+Q.&author=Fu,+X.L.&publication\_year=2012&journal=J.+Zhejiang+Univ.+Sci.+B&volume=13&pages=221%E2%80%93230&doi=10.1631/jzus.B1100063&pmid=22374615

https://doi.org/10.1631/jzus.B1100063

https://www.ncbi.nlm.nih.gov/pubmed/22374615

Farnsworth, B. Facial Action Coding System (FACS)—A Visual Guidebook—iMotions. Web

, 1–26. Available online:

https://imotions.com/blog/learning/research-fundamentals/facial-action-coding-system/

https://imotions.com/blog/learning/research-fundamentals/facial-action-coding-system/

(accessed on 2 July 2024).

Gavrilescu, M.; Vizireanu, N. Predicting depression, anxiety, and stress levels from videos using the facial action coding system. Sensors

, 19, 3693. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Predicting+depression,+anxiety,+and+stress+levels+from+videos+using+the+facial+action+coding+system&author=Gavrilescu,+M.&author=Vizireanu,+N.&publication\_year=2019&journal=Sensors&volume=19&pages=3693&doi=10.3390/s19173693

https://doi.org/10.3390/s19173693

Giannakakis, G.; Koujan, M.R.; Roussos, A. Automatic stress detection evaluating models of facial action units. In Proceedings of the 2020 15th IEEE International Conference on Automatic Face and Gesture Recognition (FG 2020), Buenos Aires, Argentina, 16–20 November 2020; pp. 728–733. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Automatic+stress+detection+evaluating+models+of+facial+action+units&conference=Proceedings+of+the+2020+15th+IEEE+International+Conference+on+Automatic+Face+and+Gesture+Recognition+(FG+2020)&author=Giannakakis,+G.&author=Koujan,+M.R.&author=Roussos,+A.&publication\_year=2020&pages=728%E2%80%93733

Martinez, B.; Valstar, M.F.; Jiang, B.; Pantic, M. Automatic analysis of facial actions: A survey. IEEE Trans. Affect. Comput.

, 10, 325–347. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Automatic+analysis+of+facial+actions:+A+survey&author=Martinez,+B.&author=Valstar,+M.F.&author=Jiang,+B.&author=Pantic,+M.&publication\_year=2019&journal=IEEE+Trans.+Affect.+Comput.&volume=10&pages=325%E2%80%93347&doi=10.1109/TAFFC.2017.2731763

https://doi.org/10.1109/TAFFC.2017.2731763

Friesen, W.V. Nonverbal Leakage and Clues to Deception. Psychiatry

, 32, 88–106. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Nonverbal+Leakage+and+Clues+to+Deception&author=Friesen,+W.V.&publication\_year=1969&journal=Psychiatry&volume=32&pages=88%E2%80%93106&doi=10.1080/00332747.1969.11023575

https://doi.org/10.1080/00332747.1969.11023575

O'Sullivan, M.; Frank, M.G.; Hurley, C.M.; Tiwana, J. Police Lie Detection Accuracy: The Effect of Lie Scenario. Law Hum. Behav.

, 33, 530–538. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Police+Lie+Detection+Accuracy:+The+Effect+of+Lie+Scenario&author=O%E2%80%99Sullivan,+M.&author=Frank,+M.G.&author=Hurley,+C.M.&author=Tiwana,+J.&publication\_year=2009&journal=Law+Hum.+Behav.&volume=33&pages=530%E2%80%93538&doi=10.1007/s10979-008-9166-4

https://doi.org/10.1007/s10979-008-9166-4

Hussein, S.A.; Bayoumi, A.E.R.S.; Soliman, A.M. Automated detection of human mental disorder. J. Electr. Syst. Inf. Technol.

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Automated+detection+of+human+mental+disorder&author=Hussein,+S.A.&author=Bayoumi,+A.E.R.S.&author=Soliman,+A.M.&publication\_year=2023&journal=J.+Electr.+Syst.+Inf.+Technol.&volume=10&pages=9&doi=10.1186/s43067-023-00076-3

https://doi.org/10.1186/s43067-023-00076-3

La Monica, L.; Cenerini, C.; Vollero, L.; Pennazza, G.; Santonico, M.; Keller, F. Development of a Universal Validation Protocol and an Open-Source Database for Multi-Contextual Facial Expression Recognition. Sensors

, 23, 8376. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Development+of+a+Universal+Validation+Protocol+and+an+Open-Source+Database+for+Multi-Contextual+Facial+Expression+Recognition&author=La+Monica,+L.&author=Cenerini,+C.&author=Vollero,+L.&author=Pennazza,+G.&author=Santonico,+M.&author=Keller,+F.&publication\_year=2023&journal=Sensors&volume=23&pages=8376&doi=10.3390/s23208376

https://doi.org/10.3390/s23208376

Mahayossanunt, Y.; Nupairoj, N.; Hemrungrojn, S.; Vateekul, P. Explainable Depression Detection Based on Facial Expression Using LSTM on Attentional Intermediate Feature Fusion with Label Smoothing. Sensors

, 23, 9402. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Explainable+Depression+Detection+Based+on+Facial+Expression+Using+LSTM+on+Attentional+Intermediate+Feature+Fusion+with+Label+Smoothing&author=Mahayossanunt,+Y.&author=Nupairoj,+N.&author=Hemrungrojn,+S.&author=Vateekul,+P.&publication\_year=2023&journal=Sensors&volume=23&pages=9402&doi=10.3390/s23239402&pmid=38067773

https://doi.org/10.3390/s23239402

https://www.ncbi.nlm.nih.gov/pubmed/38067773

Zhao, G.; Pietik, M. Dynamic Texture Recognition Using Local Binary Patterns with an Application to Facial Expressions. IEEE Trans. Pattern Anal. Mach. Intell.

, 29, 915–928. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Dynamic+Texture+Recognition+Using+Local+Binary+Patterns+with+an+Application+to+Facial+Expressions&author=Zhao,+G.&author=Pietik,+M.&publication\_year=2007&journal=IEEE+Trans.+Pattern+Anal.+Mach.+Intell.&volume=29&pages=915%E2%80%93928&doi=10.1109/TPAMI.2007.1110&pmid=17431293

https://doi.org/10.1109/TPAMI.2007.1110

https://www.ncbi.nlm.nih.gov/pubmed/17431293

Davison, A.K.; Merghani, W.; Yap, M.H. Objective classes for micro-facial expression recognition. J. Imaging

, 4, 119. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Objective+classes+for+micro-facial+expression+recognition&author=Davison,+A.K.&author=Merghani,+W.&author=Yap,+M.H.&publication\_year=2018&journal=J.+Imaging&volume=4&pages=119&doi=10.3390/jimaging4100119

https://doi.org/10.3390/jimaging4100119

Liu, Y.J.; Zhang, J.K.; Yan, W.J.; Wang, S.J.; Zhao, G.; Fu, X. A Main Directional Mean Optical Flow Feature for Spontaneous Micro-Expression Recognition. IEEE Trans. Affect. Comput.

, 7, 299–310. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=A+Main+Directional+Mean+Optical+Flow+Feature+for+Spontaneous+Micro-Expression+Recognition&author=Liu,+Y.J.&author=Zhang,+J.K.&author=Yan,+W.J.&author=Wang,+S.J.&author=Zhao,+G.&author=Fu,+X.&publication\_year=2016&journal=IEEE+Trans.+Affect.+Comput.&volume=7&pages=299%E2%80%93310&doi=10.1109/TAFFC.2015.2485205

https://doi.org/10.1109/TAFFC.2015.2485205

Liong, S.T.; See, J.; Wong, K.S.; Phan, R.C.W. Less is more: Micro-expression recognition from video using apex frame. Signal Process. Image Commun.

, 62, 82–92. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Less+is+more:+Micro-expression+recognition+from+video+using+apex+frame&author=Liong,+S.T.&author=See,+J.&author=Wong,+K.S.&author=Phan,+R.C.W.&publication\_year=2018&journal=Signal+Process.+Image+Commun.&volume=62&pages=82%E2%80%9392&doi=10.1016/j.image.2017.11.006

https://doi.org/10.1016/j.image.2017.11.006

Duque, C.A.; Alata, O.; Emonet, R.; Konik, H.; Legrand, A.C. Mean oriented Riesz features for micro expression classification. Pattern Recognit. Lett.

, 135, 382–389. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Mean+oriented+Riesz+features+for+micro+expression+classification&author=Duque,+C.A.&author=Alata,+O.&author=Emonet,+R.&author=Konik,+H.&author=Legrand,+A.C.&publication\_year=2020&journal=Pattern+Recognit.+Lett.&volume=135&pages=382%E2%80%93389&doi=10.1016/j.patrec.2020.05.008

https://doi.org/10.1016/j.patrec.2020.05.008

Polikovsky, S.; Kameda, Y.; Ohta, Y. Facial micro-expressions recognition using high speed camera and 3D-Gradient descriptor. In Proceedings of the IET Seminar Digest, London, UK, 3 December 2009; Volume 2009. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Facial+micro-expressions+recognition+using+high+speed+camera+and+3D-Gradient+descriptor&conference=Proceedings+of+the+IET+Seminar+Digest&author=Polikovsky,+S.&author=Kameda,+Y.&author=Ohta,+Y.&publication\_year=2009

Patel, D.; Hong, X.; Zhao, G. Selective deep features for micro-expression recognition. In Proceedings of the International Conference on Pattern Recognition, Cancun, Mexico, 4–8 December 2016; pp. 2258–2263. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Selective+deep+features+for+micro-expression+recognition&conference=Proceedings+of+the+International+Conference+on+Pattern+Recognition&author=Patel,+D.&author=Hong,+X.&author=Zhao,+G.&publication\_year=2016&pages=2258%E2%80%932263

Lucey, P.; Cohn, J.F.; Kanade, T.; Saragih, J.; Ambadar, Z.; Matthews, I. The extended Cohn-Kanade dataset (CK+): A complete dataset for action unit and emotion-specified expression. In Proceedings of the 2010 IEEE Computer Society Conference on Computer Vision and Pattern Recognition—Workshops, CVPRW 2010, San Francisco, CA, USA, 13–18 June 2010; pp. 94–101. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=The+extended+Cohn-Kanade+dataset+(CK+):+A+complete+dataset+for+action+unit+and+emotion-specified+expression&conference=Proceedings+of+the+2010+IEEE+Computer+Society+Conference+on+Computer+Vision+and+Pattern+Recognition%E2%80%94Workshops,+CVPRW+2010&author=Lucey,+P.&author=Cohn,+J.F.&author=Kanade,+T.&author=Saragih,+J.&author=Ambadar,+Z.&author=Matthews,+I.&publication\_year=2010&pages=94%E2%80%93101

Verma, M.; Vipparthi, S.K.; Singh, G.; Murala, S. LEARNet: Dynamic Imaging Network for Micro Expression Recognition. IEEE Trans. Image Process.

, 29, 1618–1627. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=LEARNet:+Dynamic+Imaging+Network+for+Micro+Expression+Recognition&author=Verma,+M.&author=Vipparthi,+S.K.&author=Singh,+G.&author=Murala,+S.&publication\_year=2020&journal=IEEE+Trans.+Image+Process.&volume=29&pages=1618%E2%80%931627&doi=10.1109/TIP.2019.2912358&pmid=31545721

https://doi.org/10.1109/TIP.2019.2912358

https://www.ncbi.nlm.nih.gov/pubmed/31545721

Kim, D.H.; Baddar, W.J.; Ro, Y.M. Micro-expression recognition with expression-state constrained spatio-temporal feature representations. In Proceedings of the MM 2016—Proceedings of the 2016 ACM Multimedia Conference, Amsterdam, The Netherlands, 15–19 October 2016; Association for Computing Machinery, Inc.: New York, NY, USA, 2016; pp. 382–386. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Micro-expression+recognition+with+expression-state+constrained+spatio-temporal+feature+representations&author=Kim,+D.H.&author=Baddar,+W.J.&author=Ro,+Y.M.&publication\_year=2016&pages=382%E2%80%93386

Khor, H.Q.; See, J.; Phan, R.C.W.; Lin, W. Enriched long-term recurrent convolutional network for facial micro-expression recognition. In Proceedings of the 2018 13th IEEE International Conference on Automatic Face & Gesture Recognition (FG 2018), Xi'an, China, 15–19 May 2018; pp. 667–674. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Enriched+long-term+recurrent+convolutional+network+for+facial+micro-expression+recognition&conference=Proceedings+of+the+2018+13th+IEEE+International+Conference+on+Automatic+Face+&+Gesture+Recognition+(FG+2018)&author=Khor,+H.Q.&author=See,+J.&author=Phan,+R.C.W.&author=Lin,+W.&publication\_year=2018&pages=667%E2%80%93674&doi=10.1109/FG.2018.00105

https://doi.org/10.1109/FG.2018.00105

Lewinski, P.; Den Uyl, T.M.; Butler, C. Automated facial coding: Validation of basic emotions and FACS AUs in facereader. J. Neurosci. Psychol. Econ.

, 7, 227–236. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Automated+facial+coding:+Validation+of+basic+emotions+and+FACS+AUs+in+facereader&author=Lewinski,+P.&author=Den+Uyl,+T.M.&author=Butler,+C.&publication\_year=2014&journal=J.+Neurosci.+Psychol.+Econ.&volume=7&pages=227%E2%80%93236&doi=10.1037/npe0000028

https://doi.org/10.1037/npe0000028

Ekman, P.; Friesen, W.V. Facial Action Coding System. In Facial Action Coding System (FACS); APA PsycTests: Washington, DC, USA, 1978. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Facial+Action+Coding+System&author=Ekman,+P.&author=Friesen,+W.V.&publication\_year=1978

Zhao, Y.; Xu, J. Necessary morphological patches extraction for automatic micro-expression recognition. Appl. Sci.

, 8, 1811. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Necessary+morphological+patches+extraction+for+automatic+micro-expression+recognition&author=Zhao,+Y.&author=Xu,+J.&publication\_year=2018&journal=Appl.+Sci.&volume=8&pages=1811&doi=10.3390/app8101811

https://doi.org/10.3390/app8101811

Zhao, Y.; Xu, J. An improved micro-expression recognition method based on necessary morphological patches. Symmetry

, 11, 497. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=An+improved+micro-expression+recognition+method+based+on+necessary+morphological+patches&author=Zhao,+Y.&author=Xu,+J.&publication\_year=2019&journal=Symmetry&volume=11&pages=497&doi=10.3390/sym11040497

https://doi.org/10.3390/sym11040497

Davison, A.K.; Lansley, C.; Costen, N.; Tan, K.; Yap, M.H. SAMM: A Spontaneous Micro-Facial Movement Dataset. IEEE Trans. Affect. Comput.

, 9, 116–129. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=SAMM:+A+Spontaneous+Micro-Facial+Movement+Dataset&author=Davison,+A.K.&author=Lansley,+C.&author=Costen,+N.&author=Tan,+K.&author=Yap,+M.H.&publication\_year=2018&journal=IEEE+Trans.+Affect.+Comput.&volume=9&pages=116%E2%80%93129&doi=10.1109/TAFFC.2016.2573832

https://doi.org/10.1109/TAFFC.2016.2573832

Yan, W.J.; Li, X.; Wang, S.J.; Zhao, G.; Liu, Y.J.; Chen, Y.H.; Fu, X. CASME II: An improved spontaneous micro-expression database and the baseline evaluation. PLoS ONE

, 9, e86041. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=CASME+II:+An+improved+spontaneous+micro-expression+database+and+the+baseline+evaluation&author=Yan,+W.J.&author=Li,+X.&author=Wang,+S.J.&author=Zhao,+G.&author=Liu,+Y.J.&author=Chen,+Y.H.&author=Fu,+X.&publication\_year=2014&journal=PLoS+ONE&volume=9&pages=e86041&doi=10.1371/journal.pone.0086041

https://doi.org/10.1371/journal.pone.0086041

Ruan, B.K.; Lo, L.; Shuai, H.H.; Cheng, W.H. Mimicking the Annotation Process for Recognizing the Micro Expressions. In Proceedings of the MM 22: The 30th ACM International Conference on Multimedia, Lisbon, Portugal, 10–14 October 2022; Association for Computing Machinery: New York, NY, USA, 2022; Volume 1, ISBN 9781450392037. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Mimicking+the+Annotation+Process+for+Recognizing+the+Micro+Expressions&author=Ruan,+B.K.&author=Lo,+L.&author=Shuai,+H.H.&author=Cheng,+W.H.&publication\_year=2022

Allaert, B.; Bilasco, I.M.; Djeraba, C. Micro and Macro Facial Expression Recognition Using Advanced Local Motion Patterns. IEEE Trans. Affect. Comput.

, 13, 147–158. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Micro+and+Macro+Facial+Expression+Recognition+Using+Advanced+Local+Motion+Patterns&author=Allaert,+B.&author=Bilasco,+I.M.&author=Djeraba,+C.&publication\_year=2022&journal=IEEE+Trans.+Affect.+Comput.&volume=13&pages=147%E2%80%93158&doi=10.1109/TAFFC.2019.2949559

https://doi.org/10.1109/TAFFC.2019.2949559

Choi, D.Y.; Song, B.C. Facial Micro-Expression Recognition Using Two-Dimensional Landmark Feature Maps. IEEE Access

, 8, 121549–121563. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Facial+Micro-Expression+Recognition+Using+Two-Dimensional+Landmark+Feature+Maps&author=Choi,+D.Y.&author=Song,+B.C.&publication\_year=2020&journal=IEEE+Access&volume=8&pages=121549%E2%80%93121563&doi=10.1109/ACCESS.2020.3006958

https://doi.org/10.1109/ACCESS.2020.3006958

Li, C.; Qi, Z.; Jia, N.; Wu, J. Human face detection algorithm via Haar cascade classifier combined with three additional classifiers. In Proceedings of the ICEMI 2017—Proceedings of IEEE 13th International Conference on Electronic Measurement and Instruments, Yangzhou, China, 20–22 October 2017; pp. 483–487. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Human+face+detection+algorithm+via+Haar+cascade+classifier+combined+with+three+additional+classifiers&conference=Proceedings+of+the+ICEMI+2017%E2%80%94Proceedings+of+IEEE+13th+International+Conference+on+Electronic+Measurement+and+Instruments&author=Li,+C.&author=Qi,+Z.&author=Jia,+N.&author=Wu,+J.&publication\_year=2017&pages=483%E2%80%93487

Benitez-Garcia, G.; Olivares-Mercado, J.; Aguilar-Torres, G.; Sanchez-Perez, G.; Perez-Meana, H. Face identification based on Contrast Limited Adaptive Histogram Equalization (CLAHE). In Proceedings of the 2011 International Conference on Image Processing, Computer Vision, and Pattern Recognition, IPCV 2011, Washington, DC, USA, 20–25 June 2011; Volume 1, pp. 363–369. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Face+identification+based+on+Contrast+Limited+Adaptive+Histogram+Equalization+(CLAHE)&conference=Proceedings+of+the+2011+International+Conference+on+Image+Processing,+Computer+Vision,+and+Pattern+Recognition,+IPCV+2011&author=Benitez-Garcia,+G.&author=Olivares-Mercado,+J.&author=Aguilar-Torres,+G.&author=Sanchez-Perez,+G.&author=Perez-Meana,+H.&publication\_year=2011&pages=363%E2%80%93369

Irawan, B.; Utama, N.P.; Munir, R.; Purwarianti, A. Spontaneous Micro-Expression Recognition Using 3DCNN on Long Videos for Emotion Analysis. In Proceedings of the 2023 10th International Conference on Advanced Informatics: Concept, Theory and Application (ICAICTA), Lombok, Indonesia, 7–9 October 2023; pp. 1–6. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Spontaneous+Micro-Expression+Recognition+Using+3DCNN+on+Long+Videos+for+Emotion+Analysis&conference=Proceedings+of+the+2023+10th+International+Conference+on+Advanced+Informatics:+Concept,+Theory+and+Application+(ICAICTA)&author=Irawan,+B.&author=Utama,+N.P.&author=Munir,+R.&author=Purwarianti,+A.&publication\_year=2023&pages=1%E2%80%936&doi=10.1109/ICAICTA59291.2023.10390247

https://doi.org/10.1109/ICAICTA59291.2023.10390247

Chowanda, A. Separable convolutional neural networks for facial expressions recognition. J. Big Data

, 8, 132. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Separable+convolutional+neural+networks+for+facial+expressions+recognition&author=Chowanda,+A.&publication\_year=2021&journal=J.+Big+Data&volume=8&pages=132&doi=10.1186/s40537-021-00522-x

https://doi.org/10.1186/s40537-021-00522-x

Hashmi, M.F.; Kiran Kumar Ashish, B.; Sharma, V.; Keskar, A.G.; Bokde, N.D.; Yoon, J.H.; Geem, Z.W. Larnet: Real-time detection of facial micro expression using lossless attention residual network. Sensors

, 21, 1098. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Larnet:+Real-time+detection+of+facial+micro+expression+using+lossless+attention+residual+network&author=Hashmi,+M.F.&author=Kiran+Kumar+Ashish,+B.&author=Sharma,+V.&author=Keskar,+A.G.&author=Bokde,+N.D.&author=Yoon,+J.H.&author=Geem,+Z.W.&publication\_year=2021&journal=Sensors&volume=21&pages=1098&doi=10.3390/s21041098&pmid=33562767

https://doi.org/10.3390/s21041098

https://www.ncbi.nlm.nih.gov/pubmed/33562767

Zhou, G.; Yuan, S.; Xing, H.; Jiang, Y.; Geng, P.; Cao, Y.; Ben, X. Micro-expression action unit recognition based on dynamic image and spatial pyramid. J. Supercomput.

, 79, 19879–19902. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Micro-expression+action+unit+recognition+based+on+dynamic+image+and+spatial+pyramid&author=Zhou,+G.&author=Yuan,+S.&author=Xing,+H.&author=Jiang,+Y.&author=Geng,+P.&author=Cao,+Y.&author=Ben,+X.&publication\_year=2023&journal=J.+Supercomput.&volume=79&pages=19879%E2%80%9319902&doi=10.1007/s11227-023-05409-7

https://doi.org/10.1007/s11227-023-05409-7

Wang, L.; Cai, W. Micro-expression recognition by fusing action unit detection and spatio-temporal features. In Proceedings of the ICASSP 2024—2024 IEEE International Conference on Acoustics, Speech and Signal Processing (ICASSP), Seoul, Republic of Korea, 14–19 April 2024; pp. 5595–5599. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Micro-expression+recognition+by+fusing+action+unit+detection+and+spatio-temporal+features&conference=Proceedings+of+the+ICASSP+2024%E2%80%942024+IEEE+International+Conference+on+Acoustics,+Speech+and+Signal+Processing+(ICASSP)&author=Wang,+L.&author=Cai,+W.&publication\_year=2024&pages=5595%E2%80%935599&doi=10.1109/ICASSP48485.2024.10446702

https://doi.org/10.1109/ICASSP48485.2024.10446702

Lei, L.; Chen, T.; Li, S.; Li, J. Micro-expression recognition based on facial graph representation learning and facial action unit fusion. In Proceedings of the 2021 IEEE/CVF Conference on Computer Vision and Pattern Recognition Workshops (CVPRW), Nashville, TN, USA, 19–25 June 2021; pp. 1571–1580. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Micro-expression+recognition+based+on+facial+graph+representation+learning+and+facial+action+unit+fusion&conference=Proceedings+of+the+2021+IEEE/CVF+Conference+on+Computer+Vision+and+Pattern+Recognition+Workshops+(CVPRW)&author=Lei,+L.&author=Chen,+T.&author=Li,+S.&author=Li,+J.&publication\_year=2021&pages=1571%E2%80%931580&doi=10.1109/CVPRW53098.2021.00173

https://doi.org/10.1109/CVPRW53098.2021.00173

Chowdary, M.K.; Nguyen, T.N.; Hemanth, D.J. Deep learning-based facial emotion recognition for human–computer interaction applications. Neural Comput. Appl.

, 35, 23311–23328. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Deep+learning-based+facial+emotion+recognition+for+human%E2%80%93computer+interaction+applications&author=Chowdary,+M.K.&author=Nguyen,+T.N.&author=Hemanth,+D.J.&publication\_year=2023&journal=Neural+Comput.+Appl.&volume=35&pages=23311%E2%80%9323328&doi=10.1007/s00521-021-06012-8

https://doi.org/10.1007/s00521-021-06012-8

Banskota, N.; Alsadoon, A.; Prasad, P.W.C.; Dawoud, A.; Rashid, T.A.; Alsadoon, O.H. A novel enhanced convolution neural network with extreme learning machine: Facial emotional recognition in psychology practices. Multimed. Tools Appl.

, 82, 6479–6503. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=A+novel+enhanced+convolution+neural+network+with+extreme+learning+machine:+Facial+emotional+recognition+in+psychology+practices&author=Banskota,+N.&author=Alsadoon,+A.&author=Prasad,+P.W.C.&author=Dawoud,+A.&author=Rashid,+T.A.&author=Alsadoon,+O.H.&publication\_year=2022&journal=Multimed.+Tools+Appl.&volume=82&pages=6479%E2%80%936503&doi=10.1007/s11042-022-13567-8

https://doi.org/10.1007/s11042-022-13567-8

Wang, H.H.; Gu, J.W. The applications of facial expression recognition in human-computer interaction. In Proceedings of the 2018 IEEE International Conference on Advanced Manufacturing (ICAM), Yunlin, Taiwan, 16–18 November 2018; pp. 288–291. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=The+applications+of+facial+expression+recognition+in+human-computer+interaction&conference=Proceedings+of+the+2018+IEEE+International+Conference+on+Advanced+Manufacturing+(ICAM)&author=Wang,+H.H.&author=Gu,+J.W.&publication\_year=2018&pages=288%E2%80%93291&doi=10.1109/AMCON.2018.8614755

https://doi.org/10.1109/AMCON.2018.8614755

Healy, M.; Walsh, P. Detecting demeanor for healthcare with machine learning. In Proceedings of the 2017 IEEE International Conference on Bioinformatics and Biomedicine (BIBM), Kansas City, MO, USA, 13–16 November 2017; pp. 2015–2019. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Detecting+demeanor+for+healthcare+with+machine+learning&conference=Proceedings+of+the+2017+IEEE+International+Conference+on+Bioinformatics+and+Biomedicine+(BIBM)&author=Healy,+M.&author=Walsh,+P.&publication\_year=2017&pages=2015%E2%80%932019&doi=10.1109/BIBM.2017.8217970

https://doi.org/10.1109/BIBM.2017.8217970

Bargshady, G.; Zhou, X.; Deo, R.C.; Soar, J.; Whittaker, F.; Wang, H. Enhanced deep learning algorithm development to detect pain intensity from facial expression images. Expert Syst. Appl.

, 149, 113305. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Enhanced+deep+learning+algorithm+development+to+detect+pain+intensity+from+facial+expression+images&author=Bargshady,+G.&author=Zhou,+X.&author=Deo,+R.C.&author=Soar,+J.&author=Whittaker,+F.&author=Wang,+H.&publication\_year=2020&journal=Expert+Syst.+Appl.&volume=149&pages=113305&doi=10.1016/j.eswa.2020.113305

https://doi.org/10.1016/j.eswa.2020.113305

Onyema, E.M.; Shukla, P.K.; Dalal, S.; Mathur, M.N.; Zakariah, M.; Tiwari, B. Enhancement of Patient Facial Recognition through Deep Learning Algorithm: ConvNet. J. Healthc. Eng.

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Enhancement+of+Patient+Facial+Recognition+through+Deep+Learning+Algorithm:+ConvNet&author=Onyema,+E.M.&author=Shukla,+P.K.&author=Dalal,+S.&author=Mathur,+M.N.&author=Zakariah,+M.&author=Tiwari,+B.&publication\_year=2021&journal=J.+Healthc.+Eng.&pages=2021&doi=10.1155/2021/5196000&pmid=34912534

https://doi.org/10.1155/2021/5196000

https://www.ncbi.nlm.nih.gov/pubmed/34912534

Bisogni, C.; Castiglione, A.; Hossain, S.; Narducci, F.; Umer, S. Impact of Deep Learning Approaches on Facial Expression Recognition in Healthcare Industries. IEEE Trans. Ind. Inform.

, 18, 5619–5627. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Impact+of+Deep+Learning+Approaches+on+Facial+Expression+Recognition+in+Healthcare+Industries&author=Bisogni,+C.&author=Castiglione,+A.&author=Hossain,+S.&author=Narducci,+F.&author=Umer,+S.&publication\_year=2022&journal=IEEE+Trans.+Ind.+Inform.&volume=18&pages=5619%E2%80%935627&doi=10.1109/TII.2022.3141400

https://doi.org/10.1109/TII.2022.3141400

Wei, H.; Zhang, Z. A survey of facial expression recognition based on deep learning. In Proceedings of the 2020 15th IEEE Conference on Industrial Electronics and Applications (ICIEA), Kristiansand, Norway, 9–13 November 2020; pp. 90–94. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=A+survey+of+facial+expression+recognition+based+on+deep+learning&conference=Proceedings+of+the+2020+15th+IEEE+Conference+on+Industrial+Electronics+and+Applications+(ICIEA)&author=Wei,+H.&author=Zhang,+Z.&publication\_year=2020&pages=90%E2%80%9394&doi=10.1109/ICIEA48937.2020.9248180

https://doi.org/10.1109/ICIEA48937.2020.9248180

Saffaryazdi, N.; Wasim, S.T.; Dileep, K.; Nia, A.F.; Nanayakkara, S.; Broadbent, E.; Billinghurst, M. Using Facial Micro-Expressions in Combination With EEG and Physiological Signals for Emotion Recognition. Front. Psychol.

, 13, 1–23. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Using+Facial+Micro-Expressions+in+Combination+With+EEG+and+Physiological+Signals+for+Emotion+Recognition&author=Saffaryazdi,+N.&author=Wasim,+S.T.&author=Dileep,+K.&author=Nia,+A.F.&author=Nanayakkara,+S.&author=Broadbent,+E.&author=Billinghurst,+M.&publication\_year=2022&journal=Front.+Psychol.&volume=13&pages=1%E2%80%9323&doi=10.3389/fpsyg.2022.864047

https://doi.org/10.3389/fpsyg.2022.864047

Huang, Y.; Yang, J.; Liu, S.; Pan, J. Combining facial expressions and electroencephalography to enhance emotion recognition. Futur. Internet

, 11, 105. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Combining+facial+expressions+and+electroencephalography+to+enhance+emotion+recognition&author=Huang,+Y.&author=Yang,+J.&author=Liu,+S.&author=Pan,+J.&publication\_year=2019&journal=Futur.+Internet&volume=11&pages=105&doi=10.3390/fi11050105

https://doi.org/10.3390/fi11050105

Lu, S.; Li, J.; Wang, Y.; Dong, Z.; Wang, S.J.; Fu, X. A More Objective Quantification of Micro-Expression Intensity through Facial Electromyography. In Proceedings of the 2nd Workshop on Facial Micro-Expression: Advanced Techniques for Multi-Modal Facial Expression Analysis, Lisbon, Portugal, 14 October 2022; pp. 11–17. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=A+More+Objective+Quantification+of+Micro-Expression+Intensity+through+Facial+Electromyography&conference=Proceedings+of+the+2nd+Workshop+on+Facial+Micro-Expression:+Advanced+Techniques+for+Multi-Modal+Facial+Expression+Analysis&author=Lu,+S.&author=Li,+J.&author=Wang,+Y.&author=Dong,+Z.&author=Wang,+S.J.&author=Fu,+X.&publication\_year=2022&pages=11%E2%80%9317&doi=10.1145/3552465.3555038

https://doi.org/10.1145/3552465.3555038

Park, B.K.; Tsai, J.L.; Chim, L.; Blevins, E.; Knutson, B. Neural evidence for cultural differences in the valuation of positive facial expressions. Soc. Cogn. Affect. Neurosci.

, 11, 243–252. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Neural+evidence+for+cultural+differences+in+the+valuation+of+positive+facial+expressions&author=Park,+B.K.&author=Tsai,+J.L.&author=Chim,+L.&author=Blevins,+E.&author=Knutson,+B.&publication\_year=2015&journal=Soc.+Cogn.+Affect.+Neurosci.&volume=11&pages=243%E2%80%93252&doi=10.1093/scan/nsv113&pmid=26342220

https://doi.org/10.1093/scan/nsv113

https://www.ncbi.nlm.nih.gov/pubmed/26342220

Lim, N. Cultural differences in emotion: Differences in emotional arousal level between the East and the West. Integr. Med. Res.

, 5, 105–109. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Cultural+differences+in+emotion:+Differences+in+emotional+arousal+level+between+the+East+and+the+West&author=Lim,+N.&publication\_year=2016&journal=Integr.+Med.+Res.&volume=5&pages=105%E2%80%93109&doi=10.1016/j.imr.2016.03.004&pmid=28462104

https://doi.org/10.1016/j.imr.2016.03.004

https://www.ncbi.nlm.nih.gov/pubmed/28462104

Yang, Y. Micro-expressions: A Study of Basic Reading and The Influencing Factors on Production and Recognition. J. Educ. Humanit. Soc. Sci.

, 26, 1048–1053. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Micro-expressions:+A+Study+of+Basic+Reading+and+The+Influencing+Factors+on+Production+and+Recognition&author=Yang,+Y.&publication\_year=2024&journal=J.+Educ.+Humanit.+Soc.+Sci.&volume=26&pages=1048%E2%80%931053&doi=10.54097/y71ea179

https://doi.org/10.54097/y71ea179

Carneiro de Melo, W.; Granger, E.; Hadid, A. A Deep Multiscale Spatiotemporal Network for Assessing Depression from Facial Dynamics. IEEE Trans. Affect. Comput.

, 13, 1581–1592. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=A+Deep+Multiscale+Spatiotemporal+Network+for+Assessing+Depression+from+Facial+Dynamics&author=Carneiro+de+Melo,+W.&author=Granger,+E.&author=Hadid,+A.&publication\_year=2020&journal=IEEE+Trans.+Affect.+Comput.&volume=13&pages=1581%E2%80%931592&doi=10.1109/TAFFC.2020.3021755

https://doi.org/10.1109/TAFFC.2020.3021755

Fei, Z.; Yang, E.; Li, D.D.U.; Butler, S.; Ijomah, W.; Li, X.; Zhou, H. Deep convolution network based emotion analysis towards mental health care. Neurocomputing

, 388, 212–227. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Deep+convolution+network+based+emotion+analysis+towards+mental+health+care&author=Fei,+Z.&author=Yang,+E.&author=Li,+D.D.U.&author=Butler,+S.&author=Ijomah,+W.&author=Li,+X.&author=Zhou,+H.&publication\_year=2020&journal=Neurocomputing&volume=388&pages=212%E2%80%93227&doi=10.1016/j.neucom.2020.01.034

https://doi.org/10.1016/j.neucom.2020.01.034

De Sario, G.D.; Haider, C.R.; Maita, K.C.; Torres-Guzman, R.A.; Emam, O.S.; Avila, F.R.; Garcia, J.P.; Borna, S.; McLeod, C.J.; Bruce, C.J.; et al. Using AI to Detect Pain through Facial Expressions: A Review. Bioengineering

, 10, 548. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Using+AI+to+Detect+Pain+through+Facial+Expressions:+A+Review&author=De+Sario,+G.D.&author=Haider,+C.R.&author=Maita,+K.C.&author=Torres-Guzman,+R.A.&author=Emam,+O.S.&author=Avila,+F.R.&author=Garcia,+J.P.&author=Borna,+S.&author=McLeod,+C.J.&author=Bruce,+C.J.&author=et+al.&publication\_year=2023&journal=Bioengineering&volume=10&pages=548&doi=10.3390/bioengineering10050548

https://doi.org/10.3390/bioengineering10050548

Gorbova, J.; Colovic, M.; Marjanovic, M.; Njegus, A.; Anbarjafari, G. Going deeper in hidden sadness recognition using spontaneous micro expressions database. Multimed. Tools Appl.

, 78, 23161–23178. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Going+deeper+in+hidden+sadness+recognition+using+spontaneous+micro+expressions+database&author=Gorbova,+J.&author=Colovic,+M.&author=Marjanovic,+M.&author=Njegus,+A.&author=Anbarjafari,+G.&publication\_year=2019&journal=Multimed.+Tools+Appl.&volume=78&pages=23161%E2%80%9323178&doi=10.1007/s11042-019-7658-5

https://doi.org/10.1007/s11042-019-7658-5

Chahar, R.; Dubey, A.K.; Narang, S.K. A review and meta-analysis of machine intelligence approaches for mental health issues and depression detection. Int. J. Adv. Technol. Eng. Explor.

, 8, 1279–1314. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=A+review+and+meta-analysis+of+machine+intelligence+approaches+for+mental+health+issues+and+depression+detection&author=Chahar,+R.&author=Dubey,+A.K.&author=Narang,+S.K.&publication\_year=2021&journal=Int.+J.+Adv.+Technol.+Eng.+Explor.&volume=8&pages=1279%E2%80%931314&doi=10.19101/IJATEE.2021.874198

https://doi.org/10.19101/IJATEE.2021.874198

Huang, W. Elderly depression recognition based on facial micro-expression extraction. Trait. Signal

, 38, 1123–1130. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Elderly+depression+recognition+based+on+facial+micro-expression+extraction&author=Huang,+W.&publication\_year=2021&journal=Trait.+Signal&volume=38&pages=1123%E2%80%931130&doi=10.18280/ts.380423

https://doi.org/10.18280/ts.380423

He, L.; Jiang, D.; Sahli, H. Automatic Depression Analysis Using Dynamic Facial Appearance Descriptor and Dirichlet Process Fisher Encoding. IEEE Trans. Multimed.

, 21, 1476–1486. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Automatic+Depression+Analysis+Using+Dynamic+Facial+Appearance+Descriptor+and+Dirichlet+Process+Fisher+Encoding&author=He,+L.&author=Jiang,+D.&author=Sahli,+H.&publication\_year=2019&journal=IEEE+Trans.+Multimed.&volume=21&pages=1476%E2%80%931486&doi=10.1109/TMM.2018.2877129

https://doi.org/10.1109/TMM.2018.2877129

Zhang, J.; Yin, H.; Zhang, J.; Yang, G.; Qin, J.; He, L. Real-time mental stress detection using multimodality expressions with a deep learning framework. Front. Neurosci.

, 16, 947168. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Real-time+mental+stress+detection+using+multimodality+expressions+with+a+deep+learning+framework&author=Zhang,+J.&author=Yin,+H.&author=Zhang,+J.&author=Yang,+G.&author=Qin,+J.&author=He,+L.&publication\_year=2022&journal=Front.+Neurosci.&volume=16&pages=947168&doi=10.3389/fnins.2022.947168&pmid=35992909

https://doi.org/10.3389/fnins.2022.947168

https://www.ncbi.nlm.nih.gov/pubmed/35992909

Munsif, M.; Ullah, M.; Ahmad, B.; Sajjad, M.; Cheikh, F.A. Monitoring Neurological Disorder Patients via Deep Learning Based Facial Expressions Analysis; Springer International Publishing: Berlin/Heidelberg, Germany, 2022; Volume 652, ISBN 9783031083402. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Monitoring+Neurological+Disorder+Patients+via+Deep+Learning+Based+Facial+Expressions+Analysis&author=Munsif,+M.&author=Ullah,+M.&author=Ahmad,+B.&author=Sajjad,+M.&author=Cheikh,+F.A.&publication\_year=2022

Beibin, L.; Mehta, S.; Aneja, D.; Foster, C.; Ventola, P.; Shic, F. A facial affect analysis system for autism spectrum disorder. In Proceedings of the 2019 IEEE International Conference on Image Processing (ICIP), Taipei, Taiwan, 22–25 September 2019; pp. 4549–4553. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=A+facial+affect+analysis+system+for+autism+spectrum+disorder&conference=Proceedings+of+the+2019+IEEE+International+Conference+on+Image+Processing+(ICIP)&author=Beibin,+L.&author=Mehta,+S.&author=Aneja,+D.&author=Foster,+C.&author=Ventola,+P.&author=Shic,+F.&publication\_year=2019&pages=4549%E2%80%934553

Gilanie, G.; Ul Hassan, M.; Asghar, M.; Qamar, A.M.; Ullah, H.; Khan, R.U.; Aslam, N.; Khan, I.U. An Automated and Real-time Approach of Depression Detection from Facial Micro-expressions. Comput. Mater. Contin.

, 73, 2513–2528. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=An+Automated+and+Real-time+Approach+of+Depression+Detection+from+Facial+Micro-expressions&author=Gilanie,+G.&author=Ul+Hassan,+M.&author=Asghar,+M.&author=Qamar,+A.M.&author=Ullah,+H.&author=Khan,+R.U.&author=Aslam,+N.&author=Khan,+I.U.&publication\_year=2022&journal=Comput.+Mater.+Contin.&volume=73&pages=2513%E2%80%932528&doi=10.32604/cmc.2022.028229

https://doi.org/10.32604/cmc.2022.028229

Wu, Y.; Mao, K.; Dennett, L.; Zhang, Y.; Chen, J. Systematic review of machine learning in PTSD studies for automated diagnosis evaluation. npj Ment. Health Res.

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Systematic+review+of+machine+learning+in+PTSD+studies+for+automated+diagnosis+evaluation&author=Wu,+Y.&author=Mao,+K.&author=Dennett,+L.&author=Zhang,+Y.&author=Chen,+J.&publication\_year=2023&journal=npj+Ment.+Health+Res.&volume=2&pages=16&doi=10.1038/s44184-023-00035-w

https://doi.org/10.1038/s44184-023-00035-w

Elsahar, Y.; Hu, S.; Bouazza-Marouf, K.; Kerr, D.; Mansor, A. Augmentative and Alternative Communication (AAC) Advances: A Review of Configurations for Individuals with a Speech Disability. Sensors

, 19, 1911. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Augmentative+and+Alternative+Communication+(AAC)+Advances:+A+Review+of+Configurations+for+Individuals+with+a+Speech+Disability&author=Elsahar,+Y.&author=Hu,+S.&author=Bouazza-Marouf,+K.&author=Kerr,+D.&author=Mansor,+A.&publication\_year=2019&journal=Sensors&volume=19&pages=1911&doi=10.3390/s19081911

https://doi.org/10.3390/s19081911

Tonguç, G.; Ozaydın Ozkara, B. Automatic recognition of student emotions from facial expressions during a lecture. Comput. Educ.

, 148, 103797. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Automatic+recognition+of+student+emotions+from+facial+expressions+during+a+lecture&author=Tongu%C3%A7,+G.&author=Ozayd%C4%B1n+Ozkara,+B.&publication\_year=2020&journal=Comput.+Educ.&volume=148&pages=103797&doi=10.1016/j.compedu.2019.103797

https://doi.org/10.1016/j.compedu.2019.103797

Papoutsi, C.; Drigas, A.; Skianis, C. Virtual and Augmented Reality for Developing Emotional Intelligence Skills. Int. J. Recent Contrib. Eng. Sci. IT

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Virtual+and+Augmented+Reality+for+Developing+Emotional+Intelligence+Skills&author=Papoutsi,+C.&author=Drigas,+A.&author=Skianis,+C.&publication\_year=2021&journal=Int.+J.+Recent+Contrib.+Eng.+Sci.+IT&volume=9&pages=35&doi=10.3991/ijes.v9i3.23939

https://doi.org/10.3991/ijes.v9i3.23939

Sharma, B.; Mantri, A. Augmented reality underpinned instructional design (ARUIDS) for cogno-orchestrative load. J. Comput. Theor. Nanosci.

, 16, 4379–4388. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Augmented+reality+underpinned+instructional+design+(ARUIDS)+for+cogno-orchestrative+load&author=Sharma,+B.&author=Mantri,+A.&publication\_year=2019&journal=J.+Comput.+Theor.+Nanosci.&volume=16&pages=4379%E2%80%934388&doi=10.1166/jctn.2019.8529

https://doi.org/10.1166/jctn.2019.8529

Dawn, S. Virtual reality and augmented reality based affective computing applications in healthcare, challenges, and its future direction. In Affective Computing in Healthcare: Applications Based on Biosignals and Artificial Intelligence; IOP Publishing Ltd.: Bristol, UK, 2023. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Virtual+reality+and+augmented+reality+based+affective+computing+applications+in+healthcare,+challenges,+and+its+future+direction&author=Dawn,+S.&publication\_year=2023

https://doi.org/10.1088/978-0-7503-5182-9CH10

Basic architecture of ME classification.

Proposed framework architecture (adapted with permission from ©Xiaolan Fu \[

https://www.mdpi.com/2504-2289/8/7/78#B31-BDCC-08-00078

Confusion matrix for CASME dataset.

Confusion matrix for SAMM dataset.

Silhouette score for combination of AUs for distinct micro-expressions.

Confusion matrix for the case study.

Facial action units with their description.

Action Units

Facial Muscle Description

Action Units

Facial Muscle Description

Inner brow raiser

Outer brow raiser

Lip Corner depressor

Brow lowerer

Lower lip depressor

Upper lid raiser

Chin raiser

Cheek raiser

Lip stretcher

Lid tightener

Lip pressor

Nose wrinkler

Lip tightener

Upper lip raiser

Nasolabial deepener

Lip corner puller

Eyes closed

Cheek puffer

Analysis of the CASME II and SAMM datasets.

Accuracy (%)

Methodology Used

Exploration Areas

https://www.mdpi.com/2504-2289/8/7/78#B31-BDCC-08-00078

Micro-expression recognition

LBP-TOP, SVM, LOSO–cross validation technique

ME dataset has been created with 5 class emotions labeled, including action units for 3000 facial muscle movements.

ME variations can be explored in different environments

https://www.mdpi.com/2504-2289/8/7/78#B32-BDCC-08-00078

Micro-expression recognition

CASME II SAMM

5-class, 3-class 83.3, 93.2 79.4, 86.5

AU-class activation map (CAM), area weighted module (AWM)

ME recognition with 5 classes (disgust, happiness, repression, surprise, others) and 3 class categories (negative, positive, surprise).

Graph structure can be used to extract features using facial landmarks, instead of the whole face area.

https://www.mdpi.com/2504-2289/8/7/78#B30-BDCC-08-00078

Micro-facial movements for objective class AUs

Recall 0.91

LBP-TOP, 3D HOG, deformable part models, LOSO

The proposed dataset can be used to train a model for deception detection, emotion recognition, lie detection.

Optical flow and unsupervised clustering techniques can be incorporated to capture micro-movements.

https://www.mdpi.com/2504-2289/8/7/78#B33-BDCC-08-00078

Micro facial expression recognition

Local motion patterns (LMP)

LMP features were extracted to measure the facial skin elasticity and deformations.

Head movements, non-frontal poses and occlusion can enhance the model accuracy.

https://www.mdpi.com/2504-2289/8/7/78#B34-BDCC-08-00078

Micro-expressions and emotion recognition

CNN, LSTM, landmark feature map (LFM)

LFM predicted MEs in positive, negative and surprised categories. LFM calculates the proportional distances between landmarks.

Including facial expression intensity, texture features could be employed to achieve high accuracy.

Proposed model's network configuration.

Output Shape

# of Parameters

Conv2D (7 × 7, 16 filters)

(64, 64, 16)

BatchNormalization

(64, 64, 16)

MaxPooling2D

(31, 31, 16)

Conv2D (3 × 3, 16 filters)

(31, 31, 16)

BatchNormalization

(31, 31, 16)

Conv2D (3 × 3, 16 filters)

(31, 31, 16)

BatchNormalization

(31, 31, 16)

(31, 31, 16)

Conv2D (3 × 3, 32 filters)

(31, 31, 16)

BatchNormalization

(31, 31, 32)

Conv2D (3 × 3, 32 filters)

(31, 31, 32)

BatchNormalization

(31, 31, 32)

Con2d (1 × 1, 32 filters)

(31, 31, 32)

BatchNormalization

(31, 31, 32)

(31, 31, 32)

GlobalAveragePooling2D

Dense (output layer)

Evaluation of the proposed model among other ML classifiers.

Decision Tree

Proposed Model

Accuracy-CASME II

Accuracy-SAMM

Evaluation of the proposed model depending on a variable number of parameters.

Number of Layers

Evaluation of the proposed model depending on epochs and batch size.

Evaluation of the proposed model with and without batch normalization layers.

Batch Normalization

Evaluation of the proposed model depending on the activation function.

Activation Function

Comparison of state-of-the-art techniques with the proposed technique.

https://www.mdpi.com/2504-2289/8/7/78#B40-BDCC-08-00078

CASME, CAS(ME)2

Regional feature module (Reg), 3DCNN

F1-score (0.786)

https://www.mdpi.com/2504-2289/8/7/78#B41-BDCC-08-00078

CASME-II SAMM

3DCNN AU graph convolutional networks (GCN)

81.85% F1-score (0.7760)

https://www.mdpi.com/2504-2289/8/7/78#B42-BDCC-08-00078

CASME-II SAMM

Depth-wise conv AU GCN

https://www.mdpi.com/2504-2289/8/7/78#B43-BDCC-08-00078

Transfer learning ResNet50, VGG16 Inception V3, Mobile Net

https://www.mdpi.com/2504-2289/8/7/78#B34-BDCC-08-00078

CNN, LSTM (LFM, CLFM)

71.34% 73.98%

https://www.mdpi.com/2504-2289/8/7/78#B23-BDCC-08-00078

CASME-I CASME-II CAS(ME)2 SMIC

Proposed Method

CASME-II SAMM

CNN K-means

95.62% 93.56%

: Spontaneous Micro-expression Database, CK+

: Extended Cohn–Kanade.

Micro-expressions of different emotions.

Action Units

MEs Sub-Division

{AU7, AU12}

Happiness\_ME1

Happiness\_ME2

Happiness\_ME3

{AU6, AU12, AU15}

Happiness\_ME4

{AU6, AU12}

Happiness\_ME5

{AU12A, AU24}

Happiness\_ME6

Happiness\_ME7

{AUL12A, AU25}

Happiness\_ME8

Surprise\_ME1

{AU5B, AU24}

Surprise\_ME2

{AU25, AU26}

Surprise\_ME3

Surprise\_ME4

Surprise\_ME5

{AU1A, AU2B, AU14C}

Surprise\_ME6

{AU4, AU7, AU43}

{AU7B, AU43E}

{AU4, AU6, AU7, AU43}

{AU15, AU17}

Sadness\_ME1

Sadness\_ME2

Sadness\_ME3

{AU12, AU15}

Sadness\_ME4

Disgust\_ME1

Disgust\_ME2

Disgust\_ME3

{AU9, AU12}

Disgust\_ME4

{AU9, AU10}

Disgust\_ME5

{AU10, AU25, AU26}

Disgust\_ME6

{AU7, AU20, AU26}

{AUL20, AU21}

{AU20C, AU25, AU26}

Contempt\_ME1

Contempt\_ME2

{AUR14, AUR17}

Contempt\_ME3

{AUL12, AUL14}

Contempt\_ME4

{AU14, AU25, AU26}

Contempt\_ME5

{AUR12, AUR14}

Contempt\_ME6

#### Disclaimer/Publisher's Note:

The statements, opinions and data contained in all publications are solely those of the individual author(s) and contributor(s) and not of MDPI and/or the editor(s). MDPI and/or the editor(s) disclaim responsibility for any injury to people or property resulting from any ideas, methods, instructions or products referred to in the content.

© 2024 by the authors. Licensee MDPI, Basel, Switzerland. This article is an open access article distributed under the terms and conditions of the Creative Commons Attribution (CC BY) license (

https://creativecommons.org/licenses/by/4.0/

https://creativecommons.org/licenses/by/4.0/

Share and Cite

mailto:?&subject=From%20MDPI%3A%20%22Demystifying%20Mental%20Health%20by%20Decoding%20Facial%20Action%20Unit%20Sequences"&body=https://www.mdpi.com/2863870%3A%0A%0ADemystifying%20Mental%20Health%20by%20Decoding%20Facial%20Action%20Unit%20Sequences%0A%0AAbstract%3A%20Mental%20health%20is%20indispensable%20for%20effective%20daily%20functioning%20and%20stress%20management.%20Facial%20expressions%20may%20provide%20vital%20clues%20about%20the%20mental%20state%20of%20a%20person%20as%20they%20are%20universally%20consistent%20across%20cultures.%20This%20study%20intends%20to%20detect%20the%20emotional%20variances%20through%20facial%20micro-expressions%20using%20facial%20action%20units%20%28AUs%29%20to%20identify%20probable%20mental%20health%20issues.%20In%20addition%2C%20convolutional%20neural%20networks%20%28CNN%29%20were%20used%20to%20detect%20and%20classify%20the%20micro-expressions.%20Further%2C%20combinations%20of%20AUs%20were%20identified%20for%20the%20segmentation%20of%20micro-expressions%20classes%20using%20K-means%20square.%20Two%20benchmarked%20datasets%20CASME%20II%20and%20SAMM%20were%20employed%20for%20the%20training%20and%20evaluation%20of%20the%20model.%20The%20model%20achieved%20an%20accuracy%20of%2095.62%25%20on%20CASME%20II%20and%2093.21%25%20on%20the%20SAMM%20dataset%2C%20respectively.%20Subsequently%2C%20a%20case%20analysis%20was%20done%20to%20identify%20depressive%20patients%20using%20the%20proposed%20framework%20and%20it%20attained%20an%20accuracy%20of%2092.99%25.%20This%20experiment%20revealed%20the%20fact%20that%20emotions%20like%20disgust%2C%20sadness%2C%20anger%2C%20and%20surprise%20are%20the%20prominent%20emotions%20experienced%20by%20depressive%20patients%20during%20communication.%20The%20findings%20suggest%20that%20leveraging%20facial%20action%20units%20for%20micro-expression%20detection%20offers%20a%20promising%20approach%20to%20mental%20health%20diagnostics.

https://x.com/intent/tweet?text=Demystifying+Mental+Health+by+Decoding+Facial+Action+Unit+Sequences&hashtags=mdpiBDCC&url=https%3A%2F%2Fwww.mdpi.com%2F2863870&via=BDCC\_MDPI

http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fwww.mdpi.com%2F2863870&title=Demystifying%20Mental%20Health%20by%20Decoding%20Facial%20Action%20Unit%20Sequences%26source%3Dhttps%3A%2F%2Fwww.mdpi.com%26summary%3DMental%20health%20is%20indispensable%20for%20effective%20daily%20functioning%20and%20stress%20management.%20Facial%20expressions%20may%20provide%20vital%20clues%20about%20the%20mental%20state%20of%20a%20person%20as%20they%20are%20universally%20consistent%20across%20cultures.%20This%20study%20intends%20to%20detect%20the%20%5B...%5D

http://www.facebook.com/sharer.php?u=https://www.mdpi.com/2863870

javascript:void(0);

http://www.reddit.com/submit?url=https://www.mdpi.com/2863870

http://www.mendeley.com/import/?url=https://www.mdpi.com/2863870

MDPI and ACS Style

Sharma, D.; Singh, J.; Sehra, S.S.; Sehra, S.K. Demystifying Mental Health by Decoding Facial Action Unit Sequences.

Big Data Cogn. Comput.

, 78. https://doi.org/10.3390/bdcc8070078

Sharma D, Singh J, Sehra SS, Sehra SK. Demystifying Mental Health by Decoding Facial Action Unit Sequences.

Big Data and Cognitive Computing

. 2024; 8(7):78. https://doi.org/10.3390/bdcc8070078

Chicago/Turabian Style

Sharma, Deepika, Jaiteg Singh, Sukhjit Singh Sehra, and Sumeet Kaur Sehra. 2024. "Demystifying Mental Health by Decoding Facial Action Unit Sequences"

Big Data and Cognitive Computing

8, no. 7: 78. https://doi.org/10.3390/bdcc8070078

Sharma, D., Singh, J., Sehra, S. S., & Sehra, S. K. (2024). Demystifying Mental Health by Decoding Facial Action Unit Sequences.

Big Data and Cognitive Computing

(7), 78. https://doi.org/10.3390/bdcc8070078

Article Metrics

https://www.mdpi.com/2504-2289/8/7/78

https://www.scopus.com/inward/citedby.uri?partnerID=HzOxMe3b&scp=85199543227&origin=inward

Web of Science

https://www.webofscience.com/api/gateway?GWVersion=2&SrcApp=PARTNER\_APP&SrcAuth=LinksAMR&KeyUT=WOS:001276549900001&DestLinkType=FullRecord&DestApp=ALL\_WOS&UsrCustomerID=7e717b028bc90856e7c55c7029afc773

Google Scholar

\[click to view\]

https://scholar.google.com/scholar\_lookup?title=Demystifying+Mental+Health+by+Decoding+Facial+Action+Unit+Sequences&volume=8&doi=10.3390%2Fbdcc8070078&journal=Big+Data+and+Cognitive+Computing&publication\_year=2024&author=Deepika+Sharma&author=Jaiteg+Singh&author=Sukhjit+Singh+Sehra&author=Sumeet+Kaur+Sehra

Article Access Statistics

Created with Highcharts 4.0.4 Article access statistics Article Views 7. Jan 8. Jan 9. Jan 10. Jan 11. Jan 12. Jan 13. Jan 14. Jan 15. Jan 16. Jan 17. Jan 18. Jan 19. Jan 20. Jan 21. Jan 22. Jan 23. Jan 24. Jan 25. Jan 26. Jan 27. Jan 28. Jan 29. Jan 30. Jan 31. Jan 1. Feb 2. Feb 3. Feb 4. Feb 5. Feb 6. Feb 7. Feb 8. Feb 9. Feb 10. Feb 11. Feb 12. Feb 13. Feb 14. Feb 15. Feb 16. Feb 17. Feb 18. Feb 19. Feb 20. Feb 21. Feb 22. Feb 23. Feb 24. Feb 25. Feb 26. Feb 27. Feb 28. Feb 1. Mar 2. Mar 3. Mar 4. Mar 5. Mar 6. Mar 7. Mar 8. Mar 9. Mar 10. Mar 11. Mar 12. Mar 13. Mar 14. Mar 15. Mar 16. Mar 17. Mar 18. Mar 19. Mar 20. Mar 21. Mar 22. Mar 23. Mar 24. Mar 25. Mar 26. Mar 27. Mar 28. Mar 29. Mar 30. Mar 31. Mar 1. Apr 2. Apr 3. Apr 4. Apr 5. Apr 6. Apr 0k 10k 2.5k 5k 7.5k

For more information on the journal statistics, click

https://www.mdpi.com/journal/BDCC/stats

Multiple requests from the same IP address are counted as one view.

https://www.mdpi.com/2504-2289/8/7/78

https://www.mdpi.com/2504-2289/8/7/78

https://www.mdpi.com/2504-2289/8/7/78

https://www.mdpi.com/2504-2289/8/7/78

https://www.mdpi.com/2504-2289/8/7/78

https://www.mdpi.com/2504-2289/8/7/78

Previous Scene

https://www.mdpi.com/2504-2289/8/7/78

https://www.mdpi.com/2504-2289/8/7/78

#### Export citation file:

javascript:window.document.forms\['export-bibtex'\].submit()

javascript:window.document.forms\['export-endnote'\].submit()

javascript:window.document.forms\['export-ris'\].submit()

MDPI and ACS Style

Sharma, D.; Singh, J.; Sehra, S.S.; Sehra, S.K. Demystifying Mental Health by Decoding Facial Action Unit Sequences.

Big Data Cogn. Comput.

, 78. https://doi.org/10.3390/bdcc8070078

Sharma D, Singh J, Sehra SS, Sehra SK. Demystifying Mental Health by Decoding Facial Action Unit Sequences.

Big Data and Cognitive Computing

. 2024; 8(7):78. https://doi.org/10.3390/bdcc8070078

Chicago/Turabian Style

Sharma, Deepika, Jaiteg Singh, Sukhjit Singh Sehra, and Sumeet Kaur Sehra. 2024. "Demystifying Mental Health by Decoding Facial Action Unit Sequences"

Big Data and Cognitive Computing

8, no. 7: 78. https://doi.org/10.3390/bdcc8070078

Sharma, D., Singh, J., Sehra, S. S., & Sehra, S. K. (2024). Demystifying Mental Health by Decoding Facial Action Unit Sequences.

Big Data and Cognitive Computing

(7), 78. https://doi.org/10.3390/bdcc8070078

https://www.mdpi.com/2504-2289/8/7/78

Big Data Cogn. Comput.

, EISSN 2504-2289, Published by MDPI

https://www.mdpi.com/rss/journal/BDCC

Content Alert

https://www.mdpi.com/journal/BDCC/toc-alert

Further Information

Article Processing Charges

https://www.mdpi.com/apc

Pay an Invoice

https://www.mdpi.com/about/payment

Open Access Policy

https://www.mdpi.com/openaccess

Contact MDPI

https://www.mdpi.com/about/contact

Jobs at MDPI

https://careers.mdpi.com/

For Authors

https://www.mdpi.com/authors

For Reviewers

https://www.mdpi.com/reviewers

For Editors

https://www.mdpi.com/editors

For Librarians

https://www.mdpi.com/librarians

For Publishers

https://www.mdpi.com/publishing\_services

For Societies

https://www.mdpi.com/societies

For Conference Organizers

https://www.mdpi.com/conference\_organizers

MDPI Initiatives

https://sciforum.net/

https://www.mdpi.com/books

Preprints.org

https://www.preprints.org/

https://www.scilit.com/

SciProfiles

https://sciprofiles.com?utm\_source=mpdi.com&utm\_medium=bottom\_menu&utm\_campaign=initiative

Encyclopedia

https://encyclopedia.pub/

https://jams.pub/

Proceedings Series

https://www.mdpi.com/about/proceedings

Follow MDPI

https://www.linkedin.com/company/mdpi

https://www.facebook.com/MDPIOpenAccessPublishing

https://x.com/MDPIOpenAccess

Subscribe to receive issue release notifications and newsletters from MDPI journals

Accounting and Auditing

Acta Microbiologica Hellenica

Administrative Sciences

Adolescents

Advances in Respiratory Medicine

Aerobiology

Agriculture

AgriEngineering

Agrochemicals

AI Chemistry

AI for Engineering

AI in Education

AI in Medicine

AI Materials

Anesthesia Research

Antibiotics

Antioxidants

Applied Biosciences

Applied Mechanics

Applied Microbiology

Applied Nano

Applied Sciences

Applied System Innovation

AppliedChem

AppliedMath

AppliedPhys

Aquaculture Journal

Architecture

Astronautics

Audiology Research

Behavioral Sciences

Big Data and Cognitive Computing

Bioengineering

Biology and Life Sciences Forum

Biomechanics

Biomedicines

BioMedInformatics

Biomimetics

Biomolecules

Bioresources and Bioproducts

Blockchains

Brain Sciences

Cardiogenetics

Cardiovascular Medicine

ChemEngineering

Chemistry Proceedings

Chemosensors

Clean Technologies

Clinical and Translational Neuroscience

Clinical Bioenergetics

Clinics and Practice

Clocks & Sleep

Colloids and Interfaces

Commodities

Complexities

Complications

Computation

Computer Sciences & Mathematics Forum

Condensed Matter

Conservation

Construction Materials

Corrosion and Materials Degradation

Craniomaxillofacial Trauma & Reconstruction

Cryptography

Current Issues in Molecular Biology

Current Oncology

Dentistry Journal

Dermatopathology

Diabetology

Diagnostics

Disabilities

Drugs and Drug Candidates

Econometrics

Education Sciences

Electricity

Electrochem

Electronic Materials

Electronics

Emergency Care and Medicine

Encyclopedia

Energy Storage and Applications

Engineering Proceedings

Entropic and Disordered Matter

Environmental and Earth Sciences Proceedings

Environmental Remediation

Environments

Epidemiologia

European Burn Journal

European Journal of Investigation in Health, Psychology and Education

Family Sciences

Fermentation

Forecasting

Forensic Sciences

Fossil Studies

Foundations

Fractal and Fractional

Future Internet

Future Pharmacology

Future Transportation

Gastroenterology Insights

Gastrointestinal Disorders

Geographies

Geosciences

Geotechnics

Gout, Urate, and Crystal Deposition Disease

Green Health

Hematology Reports

Horticulturae

Hydrobiology

Infectious Disease Reports

Informatics

Information

Infrastructures

Instruments

Intelligent Infrastructure and Construction

International Journal of Cognitive Sciences

International Journal of Environmental Medicine

International Journal of Environmental Research and Public Health

International Journal of Financial Studies

International Journal of Molecular Sciences

International Journal of Neonatal Screening

International Journal of Orofacial Myology and Myofunctional Therapy

International Journal of Plant Biology

International Journal of Topology

International Journal of Translational Medicine

International Journal of Turbomachinery, Propulsion and Power

International Medical Education

ISPRS International Journal of Geo-Information

Journal of Aesthetic Medicine

Journal of Ageing and Longevity

Journal of CardioRenal Medicine

Journal of Cardiovascular Development and Disease

Journal of Clinical & Translational Ophthalmology

Journal of Clinical Medicine

Journal of Composites Science

Journal of Cybersecurity and Privacy

Journal of Dementia and Alzheimer's Disease

Journal of Developmental Biology

Journal of Experimental and Theoretical Analyses

Journal of Eye Movement Research

Journal of Functional Biomaterials

Journal of Functional Morphology and Kinesiology

Journal of Fungi

Journal of Genome Biotechnology and Genetics

Journal of Gerontology and Geriatrics

Journal of Imaging

Journal of Innovation

Journal of Intelligence

Journal of Interdisciplinary Research Applied to Medicine

Journal of Low Power Electronics and Applications

Journal of Manufacturing and Materials Processing

Journal of Marine Science and Engineering

Journal of Market Access & Health Policy

Journal of Mind and Medical Sciences

Journal of Molecular Pathology

Journal of Nanotheranostics

Journal of Nuclear Engineering

Journal of Otorhinolaryngology, Hearing and Balance Medicine

Journal of Parks

Journal of Personalized Medicine

Journal of Pharmaceutical and BioTech Industry

Journal of Phytomedicine

Journal of Respiration

Journal of Risk and Financial Management

Journal of Sensor and Actuator Networks

Journal of Superintelligence

Journal of the American Podiatric Medical Association

Journal of the Oman Medical Association

Journal of Theoretical and Applied Electronic Commerce Research

Journal of Vascular Diseases

Journal of Xenobiotics

Journal of Zoological and Botanical Gardens

Journalism and Media

Kidney and Dialysis

Kinases and Phosphatases

Laboratories

Limnological Review

Low-Altitude Economy

Machine Learning and Knowledge Extraction

Magnetochemistry

Marine Drugs

Materials Proceedings

Mathematical and Computational Applications

Mathematics

Medical Sciences

Medical Sciences Forum

Metabolites

Meteorology

Methods and Protocols

Microbiology Research

Microelectronics

Micromachines

Microorganisms

Microplastics

Modern Mathematical Physics

Multimodal Technologies and Interaction

Nanoenergy Advances

Nanomanufacturing

Nanomaterials

Neuroimaging

Neurology International

Non-Coding RNA

Nursing Reports

Nutraceuticals

Occupational Health

Parasitologia

Pathophysiology

Peace Studies

Pediatric Reports

Pharmaceuticals

Pharmaceutics

Pharmacoepidemiology

Philosophies

Physical Sciences Forum

Physiologia

Polysaccharides

Populations

Precision Oncology

Primary and Hospital Care

Proceedings

Psychiatry International

Psychoactives

Psychology International

Publications

Purification

Quantum Beam Science

Quantum Reports

Real Estate

Regional Science and Environmental Economics

Remote Sensing

Reproductive Medicine

Romanian Journal of Preventive Medicine

Scientia Pharmaceutica

Semiconductors and Heterogeneous Integration

Separations

Smart Cities

Social Sciences

Société Internationale d'Urologie Journal

Soil Systems

Spectroscopy Journal

Stratigraphy and Sedimentology

Surgical Techniques Development

Sustainability

Sustainable Chemistry

Swiss Archives of Neurology, Psychiatry and Psychotherapy

Technologies

Thalassemia Reports

Theoretical and Applied Ergonomics

Therapeutics

Time and Space

Tourism and Hospitality

Transplantology

Trauma Care

Trends in Higher Education

Trends in Public Health

Tropical Medicine and Infectious Disease

Urban Science

Venereology

Veterinary Sciences

Virtual Worlds

World Electric Vehicle Journal

Zoonotic Diseases

Select options

\[-\] accountaudit

Accounting and Auditing

\[-\] acoustics

Acta Microbiologica Hellenica

\[-\] actuators

\[-\] adhesives

Administrative Sciences

\[-\] adolescents

Adolescents

Advances in Respiratory Medicine

\[-\] aerobiology

Aerobiology

\[-\] aerospace

\[-\] agriculture

Agriculture

\[-\] agriengineering

AgriEngineering

\[-\] agrochemicals

Agrochemicals

\[-\] agronomy

AI Chemistry

AI for Engineering

AI in Education

AI in Medicine

\[-\] aimater

AI Materials

\[-\] algorithms

\[-\] allergies

\[-\] analytica

\[-\] analytics

\[-\] anatomia

\[-\] anesthres

Anesthesia Research

\[-\] animals

\[-\] antibiotics

Antibiotics

\[-\] antibodies

\[-\] antioxidants

Antioxidants

\[-\] applbiosci

Applied Biosciences

\[-\] applmech

Applied Mechanics

\[-\] applmicrobiol

Applied Microbiology

\[-\] applnano

Applied Nano

\[-\] applsci

Applied Sciences

Applied System Innovation

\[-\] appliedchem

AppliedChem

\[-\] appliedmath

AppliedMath

\[-\] appliedphys

AppliedPhys

Aquaculture Journal

\[-\] architecture

Architecture

\[-\] arthropoda

\[-\] astronautics

Astronautics

\[-\] astronomy

\[-\] atmosphere

\[-\] audiolres

Audiology Research

\[-\] automation

\[-\] bacteria

\[-\] batteries

\[-\] behavsci

Behavioral Sciences

\[-\] beverages

Big Data and Cognitive Computing

\[-\] biochem

\[-\] bioengineering

Bioengineering

\[-\] biologics

\[-\] biology

Biology and Life Sciences Forum

\[-\] biomass

\[-\] biomechanics

Biomechanics

\[-\] biomedicines

Biomedicines

\[-\] biomedinformatics

BioMedInformatics

\[-\] biomimetics

Biomimetics

\[-\] biomolecules

Biomolecules

\[-\] biophysica

\[-\] bioresourbioprod

Bioresources and Bioproducts

\[-\] biosensors

\[-\] biosphere

\[-\] biotech

\[-\] blockchains

Blockchains

\[-\] brainsci

Brain Sciences

\[-\] buildings

\[-\] businesses

\[-\] cancers

\[-\] cardiogenetics

Cardiogenetics

\[-\] cardiovascmed

Cardiovascular Medicine

\[-\] catalysts

\[-\] ceramics

\[-\] challenges

\[-\] ChemEngineering

ChemEngineering

\[-\] chemistry

\[-\] chemproc

Chemistry Proceedings

\[-\] chemosensors

Chemosensors

\[-\] children

\[-\] civileng

\[-\] cleantechnol

Clean Technologies

\[-\] climate

Clinical and Translational Neuroscience

\[-\] clinbioenerg

Clinical Bioenergetics

\[-\] clinpract

Clinics and Practice

\[-\] clockssleep

Clocks & Sleep

\[-\] coatings

\[-\] colloids

Colloids and Interfaces

\[-\] colorants

\[-\] commodities

Commodities

\[-\] complexities

Complexities

\[-\] complications

Complications

\[-\] compounds

\[-\] computation

Computation

Computer Sciences & Mathematics Forum

\[-\] computers

\[-\] condensedmatter

Condensed Matter

\[-\] conservation

Conservation

\[-\] constrmater

Construction Materials

Corrosion and Materials Degradation

\[-\] cosmetics

Craniomaxillofacial Trauma & Reconstruction

\[-\] cryptography

Cryptography

\[-\] crystals

\[-\] culture

Current Issues in Molecular Biology

\[-\] curroncol

Current Oncology

\[-\] dentistry

Dentistry Journal

\[-\] dermato

\[-\] dermatopathology

Dermatopathology

\[-\] designs

\[-\] diabetology

Diabetology

\[-\] diagnostics

Diagnostics

\[-\] dietetics

\[-\] digital

\[-\] disabilities

Disabilities

\[-\] diseases

\[-\] diversity

Drugs and Drug Candidates

\[-\] dynamics

\[-\] ecologies

\[-\] econometrics

Econometrics

\[-\] economies

\[-\] education

Education Sciences

\[-\] electricity

Electricity

\[-\] electrochem

Electrochem

\[-\] electronicmat

Electronic Materials

\[-\] electronics

Electronics

Emergency Care and Medicine

\[-\] encyclopedia

Encyclopedia

\[-\] endocrines

\[-\] energies

Energy Storage and Applications

\[-\] engproc

Engineering Proceedings

Entropic and Disordered Matter

\[-\] entropy

Environmental and Earth Sciences Proceedings

\[-\] environremediat

Environmental Remediation

\[-\] environments

Environments

\[-\] epidemiologia

Epidemiologia

\[-\] epigenomes

European Burn Journal

European Journal of Investigation in Health, Psychology and Education

Family Sciences

\[-\] fermentation

Fermentation

\[-\] fintech

\[-\] forecasting

Forecasting

\[-\] forensicsci

Forensic Sciences

\[-\] forests

\[-\] fossstud

Fossil Studies

\[-\] foundations

Foundations

\[-\] fractalfract

Fractal and Fractional

\[-\] futureinternet

Future Internet

\[-\] futurepharmacol

Future Pharmacology

\[-\] futuretransp

Future Transportation

\[-\] galaxies

\[-\] gastroent

Gastroenterology Insights

\[-\] gastrointestdisord

Gastrointestinal Disorders

\[-\] gastronomy

\[-\] genealogy

\[-\] geographies

Geographies

\[-\] geohazards

\[-\] geomatics

\[-\] geometry

\[-\] geosciences

Geosciences

\[-\] geotechnics

Geotechnics

\[-\] geriatrics

\[-\] glacies

Gout, Urate, and Crystal Deposition Disease

\[-\] grasses

\[-\] greenhealth

Green Health

\[-\] hardware

\[-\] healthcare

\[-\] hematolrep

Hematology Reports

\[-\] heritage

\[-\] histories

\[-\] horticulturae

Horticulturae

\[-\] hospitals

\[-\] humanities

\[-\] hydrobiology

Hydrobiology

\[-\] hydrogen

\[-\] hydrology

\[-\] hydropower

\[-\] hygiene

\[-\] industries

Infectious Disease Reports

\[-\] informatics

Informatics

\[-\] information

Information

\[-\] infrastructures

Infrastructures

\[-\] inorganics

\[-\] insects

\[-\] instruments

Instruments

Intelligent Infrastructure and Construction

International Journal of Cognitive Sciences

International Journal of Environmental Medicine

International Journal of Environmental Research and Public Health

International Journal of Financial Studies

International Journal of Molecular Sciences

International Journal of Neonatal Screening

International Journal of Orofacial Myology and Myofunctional Therapy

International Journal of Plant Biology

International Journal of Topology

International Journal of Translational Medicine

International Journal of Turbomachinery, Propulsion and Power

International Medical Education

\[-\] inventions

ISPRS International Journal of Geo-Information

\[-\] jaestheticmed

Journal of Aesthetic Medicine

Journal of Ageing and Longevity

Journal of CardioRenal Medicine

Journal of Cardiovascular Development and Disease

Journal of Clinical & Translational Ophthalmology

Journal of Clinical Medicine

Journal of Composites Science

Journal of Cybersecurity and Privacy

Journal of Dementia and Alzheimer's Disease

Journal of Developmental Biology

Journal of Experimental and Theoretical Analyses

Journal of Eye Movement Research

Journal of Functional Biomaterials

Journal of Functional Morphology and Kinesiology

Journal of Fungi

Journal of Genome Biotechnology and Genetics

Journal of Gerontology and Geriatrics

\[-\] jimaging

Journal of Imaging

Journal of Innovation

\[-\] jintelligence

Journal of Intelligence

Journal of Interdisciplinary Research Applied to Medicine

Journal of Low Power Electronics and Applications

Journal of Manufacturing and Materials Processing

Journal of Marine Science and Engineering

Journal of Market Access & Health Policy

Journal of Mind and Medical Sciences

Journal of Molecular Pathology

Journal of Nanotheranostics

Journal of Nuclear Engineering

Journal of Otorhinolaryngology, Hearing and Balance Medicine

Journal of Parks

Journal of Personalized Medicine

Journal of Pharmaceutical and BioTech Industry

\[-\] jphytomed

Journal of Phytomedicine

Journal of Respiration

Journal of Risk and Financial Management

Journal of Sensor and Actuator Networks

\[-\] superintelligence

Journal of Superintelligence

Journal of the American Podiatric Medical Association

Journal of the Oman Medical Association

Journal of Theoretical and Applied Electronic Commerce Research

Journal of Vascular Diseases

Journal of Xenobiotics

Journal of Zoological and Botanical Gardens

\[-\] journalmedia

Journalism and Media

\[-\] kidneydial

Kidney and Dialysis

\[-\] kinasesphosphatases

Kinases and Phosphatases

\[-\] knowledge

\[-\] laboratories

Laboratories

\[-\] languages

\[-\] limnolrev

Limnological Review

\[-\] lipidology

\[-\] liquids

\[-\] literature

\[-\] logistics

Low-Altitude Economy

\[-\] lubricants

\[-\] lymphatics

Machine Learning and Knowledge Extraction

\[-\] machines

\[-\] macromol

\[-\] magnetism

\[-\] magnetochemistry

Magnetochemistry

\[-\] marinedrugs

Marine Drugs

\[-\] materials

\[-\] materproc

Materials Proceedings

Mathematical and Computational Applications

\[-\] mathematics

Mathematics

Medical Sciences

Medical Sciences Forum

\[-\] medicina

\[-\] medicines

\[-\] membranes

\[-\] metabolites

Metabolites

\[-\] meteorology

Meteorology

\[-\] methane

Methods and Protocols

\[-\] metrics

\[-\] metrology

\[-\] microbiolres

Microbiology Research

\[-\] microelectronics

Microelectronics

\[-\] micromachines

Micromachines

\[-\] microorganisms

Microorganisms

\[-\] microplastics

Microplastics

\[-\] microwave

\[-\] minerals

\[-\] modelling

Modern Mathematical Physics

\[-\] molbank

\[-\] molecules

\[-\] multimedia

Multimodal Technologies and Interaction

\[-\] muscles

\[-\] nanoenergyadv

Nanoenergy Advances

\[-\] nanomanufacturing

Nanomanufacturing

\[-\] nanomaterials

Nanomaterials

\[-\] network

\[-\] neuroglia

\[-\] neuroimaging

Neuroimaging

\[-\] neurolint

Neurology International

\[-\] neurosci

\[-\] nitrogen

Non-Coding RNA

\[-\] nursrep

Nursing Reports

\[-\] nutraceuticals

Nutraceuticals

\[-\] nutrients

\[-\] obesities

\[-\] occuphealth

Occupational Health

\[-\] organics

\[-\] organoids

\[-\] osteology

\[-\] pandemics

\[-\] parasitologia

Parasitologia

\[-\] particles

\[-\] pathogens

\[-\] pathophysiology

Pathophysiology

\[-\] peacestud

Peace Studies

\[-\] pediatrrep

Pediatric Reports

\[-\] pharmaceuticals

Pharmaceuticals

\[-\] pharmaceutics

Pharmaceutics

\[-\] pharmacoepidemiology

Pharmacoepidemiology

\[-\] pharmacy

\[-\] philosophies

Philosophies

\[-\] photochem

\[-\] photonics

\[-\] phycology

\[-\] physchem

Physical Sciences Forum

\[-\] physics

\[-\] physiologia

Physiologia

\[-\] platforms

\[-\] pollutants

\[-\] polymers

\[-\] polysaccharides

Polysaccharides

\[-\] populations

Populations

\[-\] poultry

\[-\] powders

\[-\] precisoncol

Precision Oncology

Primary and Hospital Care

\[-\] proceedings

Proceedings

\[-\] processes

\[-\] prosthesis

\[-\] proteomes

\[-\] psychiatryint

Psychiatry International

\[-\] psychoactives

Psychoactives

\[-\] psycholint

Psychology International

\[-\] publications

Publications

\[-\] purification

Purification

Quantum Beam Science

\[-\] quantumrep

Quantum Reports

\[-\] quaternary

\[-\] radiation

\[-\] reactions

\[-\] realestate

Real Estate

\[-\] receptors

\[-\] recycling

Regional Science and Environmental Economics

\[-\] religions

\[-\] remotesensing

Remote Sensing

\[-\] reports

\[-\] reprodmed

Reproductive Medicine

\[-\] resources

\[-\] rheumato

\[-\] robotics

Romanian Journal of Preventive Medicine

\[-\] ruminants

\[-\] scipharm

Scientia Pharmaceutica

\[-\] sclerosis

Semiconductors and Heterogeneous Integration

\[-\] sensors

\[-\] separations

Separations

\[-\] signals

\[-\] sinusitis

\[-\] smartcities

Smart Cities

Social Sciences

Société Internationale d'Urologie Journal

\[-\] societies

\[-\] software

\[-\] soilsystems

Soil Systems

\[-\] spectroscj

Spectroscopy Journal

\[-\] standards

\[-\] stratsediment

Stratigraphy and Sedimentology

\[-\] stresses

\[-\] surfaces

\[-\] surgeries

Surgical Techniques Development

\[-\] sustainability

Sustainability

\[-\] suschem

Sustainable Chemistry

Swiss Archives of Neurology, Psychiatry and Psychotherapy

\[-\] symmetry

\[-\] systems

\[-\] targets

\[-\] taxonomy

\[-\] technologies

Technologies

\[-\] telecom

\[-\] textiles

\[-\] thalassrep

Thalassemia Reports

Theoretical and Applied Ergonomics

\[-\] therapeutics

Therapeutics

\[-\] timespace

Time and Space

\[-\] tomography

\[-\] tourismhosp

Tourism and Hospitality

\[-\] transplantology

Transplantology

\[-\] traumacare

Trauma Care

\[-\] higheredu

Trends in Higher Education

Trends in Public Health

\[-\] tropicalmed

Tropical Medicine and Infectious Disease

\[-\] universe

\[-\] urbansci

Urban Science

\[-\] vaccines

\[-\] vehicles

\[-\] venereology

Venereology

Veterinary Sciences

\[-\] vibration

\[-\] virtualworlds

Virtual Worlds

\[-\] viruses

World Electric Vehicle Journal

\[-\] zoonoticdis

Zoonotic Diseases

© 1996-2026 MDPI (Basel, Switzerland) unless otherwise stated

https://www.mdpi.com/2504-2289/8/7/78

Disclaimer/Publisher's Note: The statements, opinions and data contained in all publications are solely those of the individual author(s) and contributor(s) and not of MDPI and/or the editor(s). MDPI and/or the editor(s) disclaim responsibility for any injury to people or property resulting from any ideas, methods, instructions or products referred to in the content.

Terms and Conditions

https://www.mdpi.com/about/terms-and-conditions

Privacy Policy

https://www.mdpi.com/about/privacy

We use cookies on our website to ensure you get the best experience.

Read more about our cookies

https://www.mdpi.com/about/privacy

https://www.mdpi.com/accept\_cookies

mailto:?&subject=From%20MDPI%3A%20%22Demystifying%20Mental%20Health%20by%20Decoding%20Facial%20Action%20Unit%20Sequences"&body=https://www.mdpi.com/2863870%3A%0A%0ADemystifying%20Mental%20Health%20by%20Decoding%20Facial%20Action%20Unit%20SequencesMental%20health%20is%20indispensable%20for%20effective%20daily%20functioning%20and%20stress%20management.%20Facial%20expressions%20may%20provide%20vital%20clues%20about%20the%20mental%20state%20of%20a%20person%20as%20they%20are%20universally%20consistent%20across%20cultures.%20This%20study%20intends%20to%20detect%20the%20emotional%20variances%20through%20facial%20micro-expressions%20using%20facial%20action%20units%20%28AUs%29%20to%20identify%20probable%20mental%20health%20issues.%20In%20addition%2C%20convolutional%20neural%20networks%20%28CNN%29%20were%20used%20to%20detect%20and%20classify%20the%20micro-expressions.%20Further%2C%20combinations%20of%20AUs%20were%20identified%20for%20the%20segmentation%20of%20micro-expressions%20classes%20using%20K-means%20square.%20Two%20benchmarked%20datasets%20CASME%20II%20and%20SAMM%20were%20employed%20for%20the%20training%20and%20evaluation%20of%20the%20model.%20The%20model%20achieved%20an%20accuracy%20of%2095.62%25%20on%20CASME%20II%20and%2093.21%25%20on%20the%20SAMM%20dataset%2C%20respectively.%20Subsequently%2C%20a%20case%20analysis%20was%20done%20to%20identify%20depressive%20patients%20using%20the%20proposed%20framework%20and%20it%20attained%20an%20accuracy%20of%2092.99%25.%20This%20experiment%20revealed%20the%20fact%20that%20emotions%20like%20disgust%2C%20sadness%2C%20anger%2C%20and%20surprise%20are%20the%20prominent%20emotions%20experienced%20by%20depressive%20patients%20during%20communication.%20The%20findings%20suggest%20that%20leveraging%20facial%20action%20units%20for%20micro-expression%20detection%20offers%20a%20promising%20approach%20to%20mental%20health%20diagnostics.

https://x.com/intent/tweet?text=Demystifying+Mental+Health+by+Decoding+Facial+Action+Unit+Sequences&hashtags=mdpiBDCC&url=https%3A%2F%2Fwww.mdpi.com%2F2863870&via=BDCC\_MDPI

http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fwww.mdpi.com%2F2863870&title=Demystifying%20Mental%20Health%20by%20Decoding%20Facial%20Action%20Unit%20Sequences%26source%3Dhttps%3A%2F%2Fwww.mdpi.com%26summary%3DMental%20health%20is%20indispensable%20for%20effective%20daily%20functioning%20and%20stress%20management.%20Facial%20expressions%20may%20provide%20vital%20clues%20about%20the%20mental%20state%20of%20a%20person%20as%20they%20are%20universally%20consistent%20across%20cultures.%20This%20study%20intends%20to%20detect%20the%20%5B...%5D

http://www.facebook.com/sharer.php?u=https://www.mdpi.com/2863870

javascript:void(0);

http://www.reddit.com/submit?url=https://www.mdpi.com/2863870

http://www.mendeley.com/import/?url=https://www.mdpi.com/2863870

http://www.citeulike.org/posturl?url=https://www.mdpi.com/2863870

https://www.mdpi.com/2863870

https://www.mdpi.com/2504-2289/8/7/78

https://www.mdpi.com/2504-2289/8/7/78

https://www.mdpi.com/2863870

https://www.mdpi.com/2504-2289/8/7/78

Back to Top Top

https://www.mdpi.com/2504-2289/8/7/78

All MDPI websites use third-party website tracking technologies to provide and continually improve our services. I agree and may revoke or change my consent at any time with effect for the future.

https://www.mdpi.com/about/privacy

https://www.mdpi.com/about/terms-and-conditions

More Information

https://www.mdpi.com/2504-2289/8/7/78

Powered by Usercentrics Consent Management

https://www.usercentrics.com/consent-management-platform-powered-by-usercentrics/?utm\_source=banner\_uc&utm\_medium=referral&utm\_content=v3

