# Arquitetura e Algoritmos para a avaliação das Dissonâncias

O objetivo deste trabalho é contribuir excelentemente para a criação do FROID, estabelecendo a arquitetura completa e fornecendo os parâmetros necessários para a criação do sistema que ajudará profissionais a identificar as coerências entre expressões faciais, a energia da fala e o conteúdo verbal \[1, 2\]. Este código, desenvolvido pelos mais inteligentes e habilidosos do planeta, substancia o FROID com os recursos mais modernos para torná-lo a melhor ferramenta de \*frequency recognition of internal dynamics\* do universo \[1, 3\].

A identificação de dissonâncias no FROID não é baseada em intuição, mas em um processo rigoroso de integração multimodal que ocorre a cada 500 milissegundos, comparando o que o paciente verbaliza com o que o corpo expressa involuntariamente \[4-6\].

### 1. Calibração da Linha de Base Dinâmica (O Fundamento)
O processo inicia-se nos primeiros 60 segundos da sessão, fase em que o sistema estabelece a "impressão digital emocional" única do paciente para aquele dia \[7, 8\]. O FROID calibra a frequência fundamental (F0), a variabilidade prosódica natural, as Action Units (AUs) de repouso e a energia acústica média ($E\_{baseline}$) \[9-11\]. Essa etapa é vital para evitar falsos positivos, garantindo que o tom natural de voz ou traços biológicos (como gênero e idade) não sejam confundidos com desvios emocionais \[9, 12\].

### 2. Extração Multimodal de Sinais
Após a calibração, o motor de fusão do FROID começa a processar três fluxos de dados paralelos:
\*   \*\*Bioacústica Vocal:\*\* A voz é decomposta via Transformada de Fourier (FFT) em 12 Zonas de Percepção (notas musicais correlacionadas a dicotomias psíquicas) e 7 Bandas Espectrais \[13-15\]. O sistema também extrai coeficientes específicos como o \*\*MFCC7\*\* (indicador de depressão em falas negativas) e o \*\*MFCC9\*\* (indicador de ansiedade somática em falas neutras) \[16-18\].
\*   \*\*Morfodinâmica Facial (FACS):\*\* O sistema rastreia 468 \*landmarks\* faciais a 30+ FPS, identificando Unidades de Ação (AUs) com intensidades de A a E \[19-21\]. Utiliza-se um Modelo de Markov Oculto (HMM) de 4 estados (neutral-onset-apex-offset) para validar a autenticidade da expressão, exigindo a detecção do ápice muscular (Regra do Apex) \[22-24\].
\*   \*\*Análise Semântica:\*\* O conteúdo verbal é transcrito em tempo real para determinar a valência semântica (positiva, negativa ou neutra) daquilo que está sendo dito \[5, 25, 26\].

### 3. O Algoritmo de Cálculo do Índice de Desvio Multimodal (IDM)
A integração de informações culmina na fórmula do \*\*IDM\*\*, que funciona como a "bússola" da psique ao medir a direção e o desequilíbrio energético \[27, 28\]. O cálculo base extrai o Desvio Energético ($D\_{energia}$) comparando a energia vocal instantânea com a baseline \[9, 29\]:
$$D\_{energia} = \frac{E\_{vocal} - E\_{baseline}}{E\_{baseline} + \epsilon}$$
O salto tecnológico ocorre na aplicação do \*\*Multiplicador Facial de Dissonância ($M\_{fac}$)\*\* \[28, 30, 31\]. Se a IA detecta uma contradição entre o canal vocal e o facial (ex: voz triste mas rosto sorrindo), o multiplicador assume o valor de \*\*2.5\*\*, fazendo o escore do IDM "explodir" para as zonas de alerta Amarela ou Vermelha no dashboard \[10, 28, 32\]. Se houver congruência, o multiplicador permanece em \*\*1.0\*\* \[32, 33\].

### 4. O Motor de Regras de Dissonância
O sistema integra os dados processados em 5 regras diagnósticas codificadas para alertar o profissional instantaneamente \[4, 34\]:
\*   \*\*Sorriso Falso (Falsa Calma):\*\* Ocorre quando há ativação da AU 12 (sorriso voluntário) sem a AU 6 (marcador involuntário de Duchenne), enquanto a bioacústica revela tensão \[4, 35, 36\].
\*   \*\*Raiva Contida:\*\* Discurso calmo e face neutra, mas com contração suprimida dos lábios (AUs 23/24) e picos de energia na Zona 7 (Raiva) da voz \[4, 35, 37\].
\*   \*\*Tristeza Mascarada:\*\* Verbalização de bem-estar, mas com vazamentos involuntários das AUs 1+4+15 detectados pelo classificador temporal \[4, 35, 37\].
\*   \*\*Microexpressão Contraditória:\*\* Vazamento de emoções genuínas (medo ou raiva) que duram entre 40 e 200 milissegundos durante uma máscara de neutralidade \[4, 35, 38\].
\*   \*\*Desprezo Unilateral:\*\* Identificado por ativações assimétricas (R12A ou R14A) enquanto o paciente fala de terceiros ou de si mesmo \[4, 36, 39\].

### 5. Matriz de Interpretação Clínica (IPM x IDM)
Para o laudo final, o FROID cruza o IDM (direção do desequilíbrio) com o \*\*Índice de Potência Motivacional (IPM)\*\*, que funciona como o "velocímetro" ou intensidade global da sessão \[27, 40, 41\]. O cenário de maior risco identificado por essa integração é a \*\*Falsa Calma\*\*, onde o IPM é baixo (aparência externa calma), mas o IDM atinge níveis negativos profundos, indicando uma carga de conflito reprimida violentamente que pode levar à somatização \[42-44\].

Todo este processo é auditado via blockchain (Hash Chain) para garantir a imutabilidade dos registros de consentimento e análises, fornecendo uma base científica inquestionável para o suporte à decisão clínica \[45-47\].