---
sourceFile: "Recognizing Action Units for Facial Expression Analysis - PMC"
exportedBy: "Kortex"
exportDate: "2026-06-29T01:00:28.664Z"
---

# Recognizing Action Units for Facial Expression Analysis - PMC

aaa0ec37-94b7-4458-9365-bed4ad9724ae

Recognizing Action Units for Facial Expression Analysis - PMC

6ba6e42c-9557-4ef5-803d-9331dbfe573b

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/

Recognizing Action Units for Facial Expression Analysis - PMC

Skip to main content

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#main-content

An official website of the United States government

Here's how you know

Here's how you know

Official websites use .gov

website belongs to an official government organization in the United States.

Secure .gov websites use HTTPS

( Locked padlock icon ) or

means you've safely connected to the .gov website. Share sensitive information only on official, secure websites.

https://www.ncbi.nlm.nih.gov/myncbi/

Publications

https://www.ncbi.nlm.nih.gov/myncbi/collections/bibliography/

Account settings

https://www.ncbi.nlm.nih.gov/account/settings/

Search… Search NCBI

Primary site navigation

#### Logged in as:

https://www.ncbi.nlm.nih.gov/myncbi/

Publications

https://www.ncbi.nlm.nih.gov/myncbi/collections/bibliography/

Account settings

https://www.ncbi.nlm.nih.gov/account/settings/

https://pmc.ncbi.nlm.nih.gov/

Search PMC Full-Text Archive

Search in PMC

Journal List

https://pmc.ncbi.nlm.nih.gov/journals/

https://pmc.ncbi.nlm.nih.gov/about/userguide/

View on publisher site

Download PDF

Add to Collections

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/

As a library, NLM provides access to scientific literature. Inclusion in an NLM database does not imply endorsement of, or agreement with, the contents by NLM or the National Institutes of Health.

#### Learn more:

PMC Disclaimer

https://pmc.ncbi.nlm.nih.gov/about/disclaimer/

PMC Copyright Notice

https://pmc.ncbi.nlm.nih.gov/about/copyright/

IEEE Trans Pattern Anal Mach Intell

. Author manuscript; available in PMC: 2014 Sep 8.

#### Published in final edited form as:

#### IEEE Trans Pattern Anal Mach Intell. 2001 Feb;23(2):97–115. doi:

10.1109/34.908962

https://doi.org/10.1109/34.908962

Search in PMC

https://pmc.ncbi.nlm.nih.gov/search/?term="IEEE%20Trans%20Pattern%20Anal%20Mach%20Intell"\[jour\]

Search in PubMed

https://pubmed.ncbi.nlm.nih.gov/?term="IEEE%20Trans%20Pattern%20Anal%20Mach%20Intell"\[jour\]

View in NLM Catalog

https://www.ncbi.nlm.nih.gov/nlmcatalog?term="IEEE%20Trans%20Pattern%20Anal%20Mach%20Intell"\[Title%20Abbreviation\]

Add to search

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/?term=%22IEEE%20Trans%20Pattern%20Anal%20Mach%20Intell%22\[jour\]

Recognizing Action Units for Facial Expression Analysis

Ying-li Tian

https://pubmed.ncbi.nlm.nih.gov/?term="Tian%20YL"\[Author\]

Ying-li Tian

Robotics Institute, Carnegie Mellon University, Pittsburgh, PA 15213. yltian@cs.cmu.edu

Member, IEEE

Find articles by

Ying-li Tian

https://pubmed.ncbi.nlm.nih.gov/?term="Tian%20YL"\[Author\]

Takeo Kanade

https://pubmed.ncbi.nlm.nih.gov/?term="Kanade%20T"\[Author\]

Takeo Kanade

Robotics Institute, Carnegie Mellon University, Pittsburgh, PA 15213. tk@cs.cmu.edu

Fellow, IEEE

Find articles by

Takeo Kanade

https://pubmed.ncbi.nlm.nih.gov/?term="Kanade%20T"\[Author\]

Jeffrey F Cohn

https://pubmed.ncbi.nlm.nih.gov/?term="Cohn%20JF"\[Author\]

Jeffrey F Cohn

Robotics Institute, Carnegie Mellon University, Pittsburgh, and the Department of Psychology, University of Pittsburgh, Pittsburgh, PA 15260. jeffcohn@pitt.edu.

Member, IEEE

Find articles by

Jeffrey F Cohn

https://pubmed.ncbi.nlm.nih.gov/?term="Cohn%20JF"\[Author\]

Author information

Copyright and License information

Robotics Institute, Carnegie Mellon University, Pittsburgh, PA 15213. yltian@cs.cmu.edu

Robotics Institute, Carnegie Mellon University, Pittsburgh, PA 15213. tk@cs.cmu.edu

Robotics Institute, Carnegie Mellon University, Pittsburgh, and the Department of Psychology, University of Pittsburgh, Pittsburgh, PA 15260. jeffcohn@pitt.edu.

Ying-li Tian

: Member, IEEE

Takeo Kanade

: Fellow, IEEE

Jeffrey F Cohn

: Member, IEEE

© 2001 IEEE

PMC Copyright notice

https://pmc.ncbi.nlm.nih.gov/about/copyright/

#### PMCID: PMC4157835 NIHMSID: NIHMS248393 PMID:

https://pubmed.ncbi.nlm.nih.gov/25210210/

The publisher's version of this article is available at

IEEE Trans Pattern Anal Mach Intell

https://doi.org/10.1109/34.908962

Most automatic expression analysis systems attempt to recognize a small set of prototypic expressions, such as happiness, anger, surprise, and fear. Such prototypic expressions, however, occur rather infrequently. Human emotions and intentions are more often communicated by changes in one or a few discrete facial features. In this paper, we develop an Automatic Face Analysis (AFA) system to analyze facial expressions based on both permanent facial features (brows, eyes, mouth) and transient facial features (deepening of facial furrows) in a nearly frontal-view face image sequence. The AFA system recognizes fine-grained changes in facial expression into action units (AUs) of the Facial Action Coding System (FACS), instead of a few prototypic expressions. Multistate face and facial component models are proposed for tracking and modeling the various facial features, including lips, eyes, brows, cheeks, and furrows. During tracking, detailed parametric descriptions of the facial features are extracted. With these parameters as the inputs, a group of action units (neutral expression, six upper face AUs and 10 lower face AUs) are recognized whether they occur alone or in combinations. The system has achieved average recognition rates of 96.4 percent (95.4 percent if neutral expressions are excluded) for upper face AUs and 96.7 percent (95.6 percent with neutral expressions excluded) for lower face AUs. The generalizability of the system has been tested by using independent image databases collected and FACS-coded for ground-truth by different research teams.

Computer vision, multistate face and facial component models, facial expression analysis, facial action coding system, action units, AU combinations, neural network

1 Introduction

Facial expression is one of the most powerful, natural, and immediate means for human beings to communicate their emotions and intentions. The face can express emotion sooner than people verbalize or even realize their feelings. In the past decade, much progress has been made to build computer systems to understand and use this natural form of human communication \[

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#R4

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#R3

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#R8

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#R10

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#R16

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#R18

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#R24

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#R26

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#R28

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#R32

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#R37

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#R38

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#R36

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#R40

\]. Most such systems attempt to recognize a small set of prototypic emotional expressions, i.e., joy, surprise, anger, sadness, fear, and disgust. This practice may follow from the work of Darwin \[

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#R9

\] and more recently Ekman and Friesen \[

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#R13

\], Friesen \[

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#R12

\], and Izard et al. \[

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#R19

\] who proposed that basic emotions have corresponding prototypic facial expressions. In everyday life, however, such prototypic expressions occur relatively infrequently. Instead, emotion more often is communicated by subtle changes in one or a few discrete facial features, such as a tightening of the lips in anger or obliquely lowering the lip corners in sadness \[

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#R7

\]. Change in isolated features, especially in the area of the eyebrows or eyelids, is typical of paralinguistic displays; for instance, raising the brows signals greeting \[

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#R11

\]. To capture such subtlety of human emotion and paralinguistic communication, automated recognition of fine-grained changes in facial expression is needed.

1.1 Facial Action Coding System

Ekman and Friesen \[

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#R14

\] developed the Facial Action Coding System (FACS) for describing facial expressions by action units (AUs). Of 44 FACS AUs that they defined, 30 AUs are anatomically related to the contractions of specific facial muscles: 12 are for upper face, and 18 are for lower face. AUs can occur either singly or in combination. When AUs occur in combination they may be

, in which the combination does not change the appearance of the constituent AUs, or nonadditive, in which the appearance of the constituents does change. Although the number of atomic action units is relatively small, more than 7,000 different AU combinations have been observed \[

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#R30

\]. FACS provides the descriptive power necessary to describe the details of facial expression.

Commonly occurring AUs and some of the additive and nonadditive AU combinations are shown in Tables

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#T1

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#T2

. As an example of a nonadditive effect, AU 4 appears differently depending on whether it occurs alone or in combination with AU 1 (as in AU 1 + 4). When AU 4 occurs alone, the brows are drawn together and lowered. In AU 1 + 4, the brows are drawn together but are raised due to the action of AU 1. AU 1 + 2 is another example of nonadditive combinations. When AU 2 occurs alone, it not only raises the outer brow, but also often pulls up the inner brow which results in a very similar appearance to AU 1 + 2. These effects of the nonadditive AU combinations increase the difficulties of AU recognition.

Upper Face Action Units and Some Combinations

Eyes, brow, and cheek are relaxed.

Inner portion of the brows is raised.

Outer portion of the brows is raised.

Brows lowered and drawn together

Upper eyelids are raised.

Cheeks are raised.

Lower eyelids are raised.

Inner and outer portions of the brows are raised.

Medial portion of the brows is raised and pulled together.

Brows lowered and drawn together and upper eyelids are raised.

AU 1+2+5+6+7

Brows are pulled together and upward.

Brows and upper eyelids are raised.

Inner portion of brows and cheeks are raised.

Lower eyelids cheeks are raised.

Brows, eyelids, and cheeks are raised.

Open in a new tab

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/table/T1/

Lower Face Action Units and Some Combinations

Lips relaxed and closed.

The infraorbital triangle and center of the upper lip are pulled upwards. Nasal root wrinkling is present.

The infraorbital triangle is pushed upwards. Upper lip is raised. Causes angular bend in shape of upper lip. Nasal root wrinkle is absent.

Lip corners are pulled obliquely.

The lips and the lower portion of the nasolabial furrow are pulled pulled back laterally. The mouth is elongated.

The corners of the lips are pulled down.

The chin boss is pushed upwards.

Lips are relaxed and parted.

Lips are relaxed and parted; mandible is lowered.

Mouth stretched open and the mandible pulled downwards.

AU9+17+23+24

Lips tightened, narrowed, and pressed together.

AU 10+15+17

AU 17+23+24

Open in a new tab

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/table/T2/

Single AU 23 and AU 24 are not included in this table because our database happens to contain only occurences of their combination, but not individual ones.

1.2 Automated Facial Expression Analysis

Most approaches to automated facial expression analysis so far attempt to recognize a small set of prototypic emotional expressions. Suwa et al. \[

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#R31

\] presented an early attempt to analyze facial expressions by tracking the motion of 20 identified spots on an image sequence. Essa and Pentland \[

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#R16

\] developed a dynamic parametric model based on a 3D geometric mesh face model to recognize five prototypic expressions. Mase \[

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#R26

\] manually selected facial regions that corresponded to facial muscles and computed motion within these regions using optical flow. The work by Yacoob and Davis \[

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#R37

\] used optical flow like Mase's work, but tracked the motion of the surface regions of facial features (brows, eyes, nose, and mouth) instead of that of the underlying muscle groups. Zhang \[

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#R40

\] investigated the use of two types of facial features: the geometric positions of 34 fiducial points on a face and a set of multiscale, multiorientation Gabor wavelet coefficients at these points for facial expression recognition.

Automatic recognition of FACS action units (AU) is a difficult problem, and relatively little work has been reported. AUs have no quantitative definitions and, as noted, can appear in complex combinations. Mase \[

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#R26

\] and Essa \[

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#R16

\] described patterns of optical flow that corresponded to several AUs, but did not attempt to recognize them. Bartlett et al. \[

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#R2

\] and Donato et al. \[

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#R10

\] reported some of the most extensive experimental results of upper and lower face AU recognition. They both used image sequences that were free of head motion, manually aligned faces using three coordinates, rotated the images so that the eyes were in horizontal, scaled the images and, finally, cropped a window of 60 × 90 pixels. Their system was trained and tested using the leave-one-out cross-validation procedure, and the mean classification accuracy was calculated across all of the test cases. Bartlett et al. \[

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#R2

\] recognized six single upper face AUs (AU 1, AU 2, AU 4, AU 5, AU 6, and AU 7) but no AUs occurring in combinations. They achieved 90.9 percent accuracy by combining holistic spatial analysis and optical flow with local feature analysis in a hybrid system. Donato et al. \[

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#R10

\] compared several techniques for recognizing action units. These techniques included optical flow, principal component analysis, independent component analysis, local feature analysis, and Gabor wavelet representation. The best performances were obtained by using Gabor wavelet representation and independent component analysis with which a 95.5 percent average recognition rate was reported for six single upper face AUs (AU 1, AU 2, AU 4, AU 5, AU 6, and AU 7) and two lower face AUs and four AU combinations (AU 17, AU 18, AU 9 + 25, AU 10 + 25, AU 16 + 25, AU 20 + 25). For analysis purpose, they treated each combination as if it were a separate new AU.

The authors' group has developed a few versions of the facial expression analysis system. Cohn et al. \[

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#R8

\] and Lien et al. \[

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#R24

\] used dense-flow, feature-point tracking, and edge extraction to recognize four upper face AUs and two combinations (AU 4, AU 5, AU 6, AU 7, AU 1 + 2, and AU 1 + 4) and four lower face AUs and five combinations (AU 12, AU 25, AU 26, AU 27, AU 12 + 25, AU 20 + 25 ± 16, AU 15 + 17, AU 17 + 23 + 24, and AU 9 + 17 ± 25). Again, each AU combination was regarded as a separate new AU. The average recognition rate ranged from 80 percent to 92 percent depending on the method used and AUs recognized.

#### These previous versions have several limitations:

They require manual marking of 38 to 52 feature points around face landmarks in the initial input frame. A more automated system is desirable.

The initial input image is aligned with a standard face image by affine transformation, which assumes that any rigid head motion is in-plane.

The extraction of dense flow is relatively slow, which limits its usefulness for large databases and real-time applications.

Lip and eye feature tracking is not reliable because of the aperture problem and when features undergo a large amount of change in appearance, such as open to tightly closed mouth or eyes.

While they used three separate feature extraction modules, they were not integrated for the purpose of AU recognition. By integrating their outputs, it is likely that even higher accuracy could be achieved.

A separate hidden Markov model is necessary for each single AU and each AU combination. Because FACS consists of 44 AUs and potential combinations numbering in the thousands, a more efficient approach will be needed.

#### The current AFA system addresses many of these limitations:

Degree of manual preprocessing is reduced by using automatic face detection \[

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#R29

\]. Templates of face components are quickly adjusted in the first frame and then tracked automatically.

No image alignment is necessary, and in-plane and limited out-of-plane head motion can be handled.

To decrease processing time, the system uses a more efficient facial feature tracker instead of a computationally intensive dense-flow extractor. Processing now requires less than 1 second per frame pair.

To increase the robustness and accuracy of the feature extraction, multistate face-component models are devised. Facial feature tracking can cope with a large change of appearance and limited out-of-plane head motion.

Extracted features are represented and normalized based on an explicit face model that is invariant to image scale and in-plane head motion.

More AUs are recognized and they are recognized whether they occur alone or in combinations. Instead of one HMM for each AU or AU combination, the current system employs two Artificial Neural Networks (one for the upper face and one for the lower face) for AU recognition. It recognizes 16 of the 30 AUs that have a specific anatomic basis and occur frequently in emotion and paralinguistic communication.

2 Multistate Feature-Based AU Recognition

An automated facial expression analysis system must solve two problems: facial feature extraction and facial expression classification. In this paper, we describe our multistate feature-based AU recognition system, which explicitly analyzes appearance changes in localized facial features in a nearly frontal image sequence. Since each AU is associated with a specific set of facial muscles, we believe that accurate geometrical modeling and tracking of facial features will lead to better recognition results. Furthermore, the knowledge of exact facial feature positions could be useful for the area-based \[

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#R37

\], holistic analysis \[

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#R2

\], and optical-flow-based \[

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#R24

\] classifiers.

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#F1

depicts the overall structure of the AFA system. Given an image sequence, the region of the face and approximate location of individual face features are detected automatically in the initial frame \[

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#R29

\]. The contours of the face features and components then are adjusted manually in the initial frame. Both permanent (e.g., brows, eyes, lips) and transient (lines and furrows) face feature changes are automatically detected and tracked in the image sequence. Informed by FACS AUs, we group the facial features into separate collections of feature parameters because the facial actions in the upper and lower face are relatively independent for AU recognition \[

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#R14

\]. In the upper face, 15 parameters describe shape, motion, eye state, motion of brow and cheek, and furrows. In the lower face, nine parameters describe shape, motion, lip state, and furrows. These parameters are geometrically normalized to compensate for image scale and in-plane head motion.

Open in a new tab

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/figure/F1/

Feature-based automatic facial action analysis (AFA) system.

The facial feature parameters are fed to two neural-network-based classifiers. One recognizes six upper face AUs (AU 1, AU 2, AU 4, AU 5, AU 6, AU 7) and

, and the other recognizes 10 lower face AUs (AU 9, AU 10, AU 12, AU 15, AU 17, AU 20, AU 25, AU 26, AU 27, AU 23 + 24) and

. These classifiers are trained to respond to the designated AUs whether they occur singly or in combination. When AUs occur in combination, multiple output nodes could be excited. For the upper face, we have achieved an average recognition rate of 96.4 percent for 50 sample sequences of 14 subjects performing seven AUs (including

) singly or in combination. For the lower face, our system has achieved an average recognition rate of 96.7 percent for 63 sample sequences of 32 subjects performing 11 AUs (including

) singly or in combination. The generalizability of AFA has been tested further on an independent database recorded under different conditions and ground-truth coded by an independent laboratory. A 93.3 percent average recognition rate has been achieved for 122 sample sequences of 21 subjects for neutral expression and 16 AUs whether they occurred individually or in combinations.

3 Facial Feature Extraction

Contraction of the facial muscles produces changes in the direction and magnitude of the motion on the skin surface and in the appearance of permanent and transient facial features. Examples of permanent features are the lips, eyes, and any furrows that have become permanent with age. Transient features include facial lines and furrows that are not present at rest but appear with facial expressions. Even in a frontal face, the appearance and location of the facial features can change dramatically. For example, the eyes look qualitatively different when open and closed. Different components require different extraction and detection methods. Multistate models of facial components have been introduced to detect and track both transient and permanent features in an image sequence.

3.1 Multistate Face Component Models

To detect and track changes of facial components in near frontal images, we develop multistate facial component models. The models are illustrated in

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#T3

, which includes both permanent (i.e., lips, eyes, brows, and cheeks) and transient components (i.e., furrows). A three-state lip model describes lip state: open, closed, and tightly closed. A two-state model (open or closed) is used for each of the eyes. Each brow and cheek has a one-state model. Transient facial features, such as nasolabial furrows, have two states: present and absent.

Multistate Facial Component Models of a Frontal Face

Description/Feature

Tightly closed

Open in a new tab

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/table/T3/

3.2 Permanent Features

A three-state lip model represents open, closed, and tightly closed lips. A different lip contour template is prepared for each lip state. The open and closed lip contours are modeled by two parabolic arcs, which are described by six parameters: the lip center position (xc, yc), the lip shape (

), and the lip orientation (

). For tightly closed lips, the dark mouth line connecting the lip corners represents the position, orientation, and shape.

Tracking of lip features uses color, shape, and motion. In the first frame, the approximate position of the lip template is detected automatically. Then, it is adjusted manually by moving four key points. A Gaussian mixture model represents the color distribution of the pixels inside of the lip template \[

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#R27

\]. The details of our lip tracking algorithm have been presented in \[

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#R33

Most eye trackers developed so far are for open eyes and simply track the eye locations \[

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#R23

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#R39

\]. To recognize facial AUs, however, we need to detect whether the eyes are open or closed, the degree of eye opening, and the location and radius of the iris. For an open eye, the eye template (

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#T3

), is composed of a circle with three parameters (

) to model the iris and two parabolic arcs with six parameters (

) to model the boundaries of the eye. This template is the same as Yuille's \[

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#R39

\] except for the two points located at the center of the whites of the eyes. For a closed eye, the template is reduced to four parameters: two for the position of each of the eye corners.

The open-eye template is adjusted manually in the first frame by moving six points for each eye. We found that the outer corners are more difficult to track than the inner corners; for this reason, the inner corners of the eyes are tracked first. The outer corners then are located on the line that connects the inner corners at a distance of the eye width as estimated in the first frame.

The iris provides important information about the eye state. Part of the iris is normally visible if the eye is open. Intensity and edge information are used to detect the iris. We have observed that the eyelid edge is noisy even in a good quality image. However, the lower part of the iris is almost always visible and its edge is relatively clear if the eye is open. Thus, we use a half circle mask to filter the iris edge (

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#F2

). The radius of the iris circle template

is determined in the first frame, since it is stable except for large out-of-plane head motion. The radius of the circle is increased or decreased slightly (

so that it can vary between minimum radius (

) and maximum radius (

). The system determines that the iris is found when the following two conditions are satisfied: One is that the edges in the mask are at their maximum. The other is that the change in the average intensity is less than a threshold. Once the iris is located, the eye is determined to be open and the iris center is the iris mask center

. The eyelid contours then are tracked. For a closed eye, a line connecting the inner and outer corners of the eye is used as the eye boundary. The details of our eye-tracking algorithm have been presented in \[

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#R34

Open in a new tab

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/figure/F2/

Half circle iris mask. (

) is the iris center,

is the iris radius

is the minimum radius of the mask, and

is the maximum radius of the mask.

Brow and cheek

Features in the brow and cheek areas are also important for expression analysis. Each left or right brow has one model—a triangular template with six parameters (

). Also, each cheek has a similar six parameter downward triangular template model. Both brow and cheek templates are tracked using the Lucas-Kanade algorithm \[

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#R25

3.3 Transient Features

In addition to permanent features that move and change their shape and positions, facial motion also produces transient features that provide crucial information for recognition of certain AUs. Wrinkles and furrows appear perpendicular to the direction of the motion of the activated muscles. Contraction of the

muscle, for instance, produces vertical furrows between the brows, which is coded in FACS as AU 4, while contraction of the medial portion of the

muscle (AU 1) causes horizontal wrinkling in the center of the forehead.

Some of these transient features may become permanent with age. Permanent crow's-feet wrinkles around the outside corners of the eyes, which are characteristic of AU 6, are common in adults but not in children. When wrinkles and furrows become permanent, contraction of the corresponding muscles produces only changes in their appearance, such as deepening or lengthening. The presence or absence of the furrows in a face image can be determined by edge feature analysis \[

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#R22

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#R24

\], or by eigenimage analysis \[

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#R21

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#R35

\]. Terzopoulos and Waters \[

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#R32

\] detected the nasolabial furrows for driving a face animator, but with artificial markers. Kwon and Lobo \[

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#R22

\] detected furrows using snakes to classify pictures of people into different age groups. Our previous system \[

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#R24

\] detected horizontal, vertical, and diagonal edges using a complex face template.

In our current system, we detect wrinkles in the nasolabial region, the nasal root, and the areas lateral to the outer corners of the eyes (

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#F3

). These areas are located using the tracked locations of the corresponding permanent features. We classify each of the wrinkles into one of two states: present and absent. Compared with the neutral frame, the wrinkle state is classified as present if wrinkles appear, deepen, or lengthen. Otherwise, it is absent.

Open in a new tab

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/figure/F3/

The areas for nasolabial furrows, nasal root, and outer eye corners.

We use a Canny edge detector to quantify the amount and orientation of furrows \[

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#R6

\]. For nasal root wrinkles and crow's-feet wrinkles, we compare the number of edge pixels

in the wrinkle areas of the current frame with the number of edge pixels

of the first frame. If the ratio

is larger than a threshold, the furrows are determined to be present. Otherwise, the furrows are absent. For nasolabial furrows, the existence of vertical to diagonal connected edges is used for classification. If the connected edge pixels are larger than a threshold, the nasolabial furrow is determined to be present and is modeled as a line. The orientation of the furrow is represented as the angle between the furrow line and line connecting the eye inner corners. This angle changes according to different AUs. For example, the nasolabial furrow angle of AU 9 or AU 10 is larger than that of AU 12.

3.4 Examples of Feature Extraction

Permanent Features

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#F4

shows the results of tracking permanent features for the same subject with different expressions. In

Figs. 4a, 4b, and 4d

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#F4

, the lips are tracked as they change in state from open to closed and tightly closed. The iris position and eye boundaries are tracked while the eye changes from widely opened to tightly closed and blink (

Figs. 4b, 4c, and 4d

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#F4

). Notice that the semicircular iris model tracks the iris even when the iris is only partially visible. Figs.

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#F5

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#F6

show examples of tracking in subjects who vary in age, sex, skin color, and in amount of out-plane head motion. Difficulty occurs in eye tracking when the eye becomes extremely narrow. For example, in

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#F5

, the left eye in the last image is mistakenly determined to be closed because the iris was too small to be detected. In these examples, face size varies between 80 × 90 and 200 × 220 pixels. For display purpose, images have been cropped to reduce space. Additional results can be found at

http://www.cs.cmu.edu/~face

http://www.cs.cmu.edu/~face

Open in a new tab

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/figure/F4/

Permanent feature tracking results for different expressions of same subject. Note appearance changes in eye and mouth states. In this and the following figures, images have been cropped for display purpose. Face size varies between 80 × 90 and 200 × 220 pixels.

Open in a new tab

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/figure/F5/

Permanent feature tracking results for different subjects.

Open in a new tab

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/figure/F6/

Permanent feature tracking results with head motions. (a) Head yaw. (b) Head pitch. (c) Head up and left with background motion.

Transient Features

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#F7

shows the results of nasolabial furrow detection for different subjects and AUs. The nasolabial furrow angles systematically vary between AU 9 and AU 12 (

Fig. 7a and 7b

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#F7

). For some images, the nasolabial furrow is detected only on one side. In the first image of

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#F7

, only the left nasolabial furrow exists, and it is correctly detected. In the middle image of

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#F7

, the right nasolabial furrow is missed because the length of the detected edges is less than threshold. The results of nasal root and crow's-feet wrinkle detection are shown in

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#F8

. Generally, the crow's-feet wrinkles are present for AU 6, and the nasal root wrinkles appear for AU 9.

Open in a new tab

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/figure/F7/

Nasolabial furrow detection results.

Open in a new tab

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/figure/F8/

Nasal root and crow's-feet wrinkle detection. For the left image of (a), (b), and (c), crow's-feet wrinkles are present. For the right image of (a), (b), and (c), the nasal root wrinkles appear.

4 Facial Feature Representation and AU Recognition by Neural Networks

We transform the extracted features into a set of parameters for AU recognition. We first define a face coordinate system. Because the inner corners of the eyes are most reliably detected and their relative position is unaffected by muscle contraction, we define the

-axis as the line connecting two inner corners of eyes and the

-axis as perpendicular to it. We split the facial features into two groups (upper face and lower face) of parameters because facial actions in the upper face have little interaction with facial motion in lower face and vice versa \[

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#R14

Upper Face Features

We represent the upper face features by 15 parameters, which are defined in

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#T4

. Of these, 12 parameters describe the motion and shape of the eyes, brows, and cheeks, two parameters describe the state of the crow's-feet wrinkles, and one parameter describes the distance between the brows. To remove the effects of variation in planar head motion and scale between image sequences in face size, all parameters are computed as ratios of their current values to that in the initial frame.

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#F9

shows the coordinate system and the parameter definitions.

Upper Face Feature Representation for AU Recognition

Permanent features (Left and right)

Other features

Inner brow motion (

Outer brow motion (

Eye height (

Distance of brows (

>0, Inner brow move up.

>0, Outer brow move up.

>0, Eye height increases.

<0 Two brows drawn together.

Eye top lid motion (

Eye bottom lid motion (

Cheek motion (

crows-feet wrinkles

W left/right

> 0, Eye top lid move up.

> 0, Eye bottom lid move up.

> 0, Cheek move up.

W left/right

= 1, Left/right crows feet wrinkle present.

Open in a new tab

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/table/T4/

Open in a new tab

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/figure/F9/

Upper face features.

) are the height of left eye and right eye;

is the distance between brows;

are the motion of left cheek and right cheek.

are the motion of the inner part of left brow and right brow.

are the motion of the outer part of left brow and right brow.

are the left and right crow's-feet wrinkle areas.

Lower Face Features

Nine parameters represent the lower face features (

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#T5

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#F10

). Of these, six parameters describe lip shape, state and motion, and three describe the furrows in the nasolabial and nasal root regions. These parameters are normalized by using the ratios of the current feature values to that of the neutral frame.

Lower Face Feature Representation for AUs Recognition

Permanent features

Lip height (

Lip width (

Left lip corner motion (

> 0, lip height increases.

> 0, lip width increases.

> 0, left lip corner moves up.

Right lip corner (

Top lip motion (

Bottom lip motion (

>0, right lip corner moves up.

>0, top lip moves up.

>0, bottom lip moves up.

Transient features

Left nasolibial furrow angle (

Right nasolibial furrow angle (

State of nasal root wrinkles (

Left nasolibial furrow present with angle

Left nasolibial furrow present with angle

= 1, nasal root wrinkles present.

Open in a new tab

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/table/T5/

Open in a new tab

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/figure/F10/

Lower face features.

are the top and bottom lip heights;

is the lip width;

is the distance between the left lip corner and eye inner corners line;

is the distance between the right lip corner and eye inner corners line;

is the nasal root area.

AU Recognition by Neural Networks

We use three-layer neural networks with one hidden layer to recognize AUs by a standard back-propagation method \[

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#R29

\]. Separate networks are used for the upper- and lower face. For AU recognition in the upper face, the inputs are the 15 parameters shown in

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#T4

. The outputs are the six single AUs (AU 1, AU 2, AU 4, AU 5, AU 6, and AU7) and

. In the lower face, the inputs are the seven parameters shown in

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#T5

and the outputs are 10 single AUs ( AU 9, AU 10, AU 12, AU 15, AU 17, AU 20, AU 23 + 24, AU 25, AU 26, and AU 27) and

. These networks are trained to respond to the designated AUs whether they occur singly or in combination. When AUs occur in combination, multiple output nodes are excited.

5 Experimental Evaluations

We conducted three experiments to evaluate the performance of our system. The first is AU recognition in the upper face when image data contain only single AUs. The second is AU recognition in the upper and lower face when image data contain both single AUs and combinations. The third experiment evaluates the generalizability of our system by using completely disjointed databases for training and testing, while image data contain both single AUs and combinations. Finally, we compared the performance of our system with that of other AU recognition systems.

5.1 Facial Expression Image Databases

Two databases were used to evaluate our system: the Cohn-Kanade AU-Coded Face Expression Image Database \[

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#R20

\] and Ekman-Hager Facial Action Exemplars \[

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#R15

Cohn-Kanade AU-Coded Face Expression Image Database

We have been developing a large-scale database for promoting quantitative study of facial expression analysis \[

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#R20

\]. The database currently contains a recording of the facial behavior of 210 adults who are 18 to 50 years old, 69 percent female and 31 percent male, and 81 percent Caucasian, 13 percent African, and 6 percent other groups. Over 90 percent of the subjects had no prior experience in FACS. Subjects were instructed by an experimenter to perform single AUs and AU combinations. Subjects' facial behavior was recorded in an observation room. Image sequences with in-plane and limited out-of-plane motion were included.

The image sequences began with a neutral face and were digitized into 640 × 480 pixel arrays with either 8-bit gray-scale or 24-bit color values. To date, 1,917 image sequences of 182 subjects have been FACS coded by certified FACS coders for either the entire sequence or target AUs. Approximately 15 percent of these sequences were coded by two independent certified FACS coders to validate the accuracy of the coding. Interobserver agreement was quantified with coefficient kappa, which is the proportion of agreement above what would be expected to occur by chance \[

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#R17

\]. The mean kappas for interobserver agreement were 0.82 for target AUs and 0.75 for frame-by-frame coding.

Ekman-Hager Facial Action Exemplars

This database was provided by P. Ekman at the Human Interaction Laboratory, University of California, San Francisco, and contains images that were collected by Hager, Methvin, and Irwin. Bartlett et al. \[

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#R2

\] and Donato et al. \[

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#R10

\] used this database to train and test their AU recognition systems. The Ekman-Hager database includes 24 Caucasian subjects (12 males and 12 females). Each image sequence consists of six to eight frames that were sampled from a longer image sequence. Image sequences begin with a neutral expression (or weak facial actions) and end with stronger facial actions. AUs were coded for each frame. Sequences containing rigid head motion detectable by a human observer were excluded. Some of the image sequences contain large lighting changes between frames and we normalized intensity to keep the average intensity constant throughout the image sequence.

5.2 Upper Face AU Recognition for Image Data Containing Only Single AUs

In the first experiment, we used a neural network-based recognizer having the structure shown in

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#F11

. The inputs to the network were the upper face feature parameters shown in

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#T4

. The outputs were the same set of six single AUs (AU 1, AU 2, AU 4, AU 5, AU 6, AU 7); these are the same set that were used by Bartlett and Donato. In addition, we included an output node for

. The output node that showed the highest value was interpreted as the recognized AU. We tested various numbers of hidden units and found that six hidden units gave the best performance.

Open in a new tab

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/figure/F11/

Neural network-based recognizer for single AUs in the upper face. The inputs are the feature parameters, and the output is one label out of six single AUs and

From the Ekman-Hager database, we selected image sequences in which only a single AU occurred in the upper face. 99 image sequences from 23 subjects met this criterion. These 99 image sequences we used are the superset of the 80 image sequences used by Bartlett and Donato. The initial and final two frames in each image sequence were used. As shown in

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#T6

, the image sequences were assigned to training and testing sets in two ways. In

, the sequences were randomly selected, so the same subject was allowed to appear in both training and testing sets. In

, no subject could appear in both training and testing sets; testing was performed done with novel faces.

Details of Training and Testing Data from Ekman-Hager Database that Are Used for Single AU Recognition in the Upper Face

| Data Set || number of Sequences | Single AUs ||||||||

| ^^ | ^^ | ^^ | AU1 | AU2 | AU4 | AU5 | AU6 | AU7 |

| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |

| 47 | 14 | 12 | 16 | 22 | 12 | 18 | 47 | 141 |

| 52 | 14 | 12 | 20 | 24 | 14 | 20 | 52 | 156 |

| 50 | 18 | 14 | 14 | 18 | 22 | 16 | 50 | 152 |

| 49 | 10 | 10 | 22 | 28 | 4 | 22 | 49 | 145 |

Open in a new tab

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/table/T6/

, some subjects appear in both training and testing sets. In

, no subject appears in both training and testing sets.

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#T7

shows the recognition results with the

testing set. The average recognition rate was 88.5 percent when samples of

were excluded (Recognizing neutral faces is easier), and 92.3 percent when samples of

were included. For the

test set (i.e., novel faces), the recognition rate remained virtually identical: 89.4 percent (

exclusive) and 92.9 percent (

inclusive), which is shown in

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#T8

AU Recognition for Single AUs on

Training and Testing Sets in Experiment 1

| || Recognition outputs |||||||

| ^^ | ^^ | AU1 | AU2 | AU4 | AU5 | AU6 | AU7 |

| --- | --- | --- | --- | --- | --- | --- | --- | --- |

| 0 | 0 | 0 | 0 | 0 | 0 | 52 |

| Recognition Rate ||

| ^^ | ^^ | 92.3% (including

) |||||| ^^ |

Open in a new tab

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/table/T7/

A same subject could appear in both training and testing sets. The numbers in bold are results excluding

AU Recognition for Single AUs on

Train and Testing Sets in Experiment 1

| || Recognition outputs |||||||

| ^^ | ^^ | AU1 | AU2 | AU4 | AU5 | AU6 | AU7 |

| --- | --- | --- | --- | --- | --- | --- | --- | --- |

| 0 | 0 | 0 | 0 | 0 | 0 | 49 |

| Recognition Rate ||

| ^^ | ^^ | 92.9% (including

) |||||| ^^ |

Open in a new tab

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/table/T8/

No subject appears in both training and testing sets. The numbers in bold are results excluding

5.3 Upper and Lower Face AU Recognition for Image Sequences Containing Both Single AUs and Combinations

Because AUs can occur either singly or in combinations, an AU recognition system must have the ability to recognize them however they occur. All previous AU recognition systems \[

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#R2

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#R10

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#R24

\] were trained and tested on single AUs only. In these systems, even when AU combinations were included, each combination was treated as if it were a separate AU. Because potential AU combinations number in the thousands, this method of separately treating AU combinations is impractical. In our second experiment, we trained a neural network to recognize AUs singly and in combinations by allowing multiple output units of the networks to fire when the input consists of AU combinations.

Upper Face AUs

The neural network-based recognition system for AU combination is shown in

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#F12

. The network has a similar structure to that used in Experiment 1, where the output nodes correspond to six single AUs plus

. However, the network for recognizing AU combinations is trained so that when an AU combination is presented, multiple output nodes that correspond to the component AUs are excited. In training, all of the output nodes that correspond to the input AU components are set to have the same value. For example, when a training input is AU 1 + 2 + 4, the output values are trained to be 1.0 for AU 1, AU 2, and AU 4; 0.0 for the remaining AUs and

. At the runtime, AUs whose output nodes show values higher than the threshold are considered to be recognized.

Open in a new tab

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/figure/F12/

Neural network-based recognizer for AU combinations in the upper face.

A total of 236 image sequences of 23 subjects from the Ekman-Hager database (99 image sequences containing only single AUs and 137 image sequences containing AU combinations) were used for recognition of AUs in the upper face. We split them into training (186 sequences) and testing (50 sequences) sets by subjects (9 subjects for training and 14 subjects for testing) to ensure that the same subjects did not appear in both training and testing. Testing, therefore, was done with “novel faces.” From experiments, we have found that it was necessary to increase the number of hidden units from six to 12 to obtain optimized performance.

Because input sequences could contain one or more AUs, several outcomes were possible.

denotes that the recognized results were completely identical to the input samples.

Partially correct

denotes that some, but not all of the AUs were recognized (

Missing AUs

) or that AUs that did not occur were misrecognized in addition to the one(s) that did (

). If none of the AUs that occurred were recognized, the result was

Using (1) and (2), we calculated recognition- and false-alarm rates for input samples and input AU components, respectively. Human FACS coders typically use the latter to calculate percentage agreement. We believe, however, that the recognition rates based on input samples are the more conservative measures.

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#T9

shows a summary of the AU combination recognition results of 50 test image sequences of 14 subjects from the Ekman-Hager database. For input samples, we achieved average recognition and false alarm rates of 88 percent and 6.7 percent, respectively, when

was included, and 82 percent and 12 percent, respectively, when

was excluded. AU component-wise, an average recognition rate of 96.4 percent and a false alarm rate of 6.3 percent were achieved when

was included and a recognition rate of 95.4 percent and a false alarm rate of 8.2 percent was obtained when

was excluded.

Upper Face AU Recognition with AU Combinations in Experiment 2

| Actual AUs || Samples | Recognized AUs ||||

| ^^ | ^^ | ^^ |

Partially correct

| ^^ | ^^ | ^^ | ^^ |

Missing AUs

| --- | --- | --- | --- | --- | --- | --- |

| - | 4(AU 1 + AU 2) | - |

| - | - | 2(AU 1 + AU 2) 2(AU 1 + AU 2 + AU 4) | - |

| - | - | - |

| - | - | - |

| - | - | - |

| - | 2(AU 6 + AU 7) | - |

| - | - | - |

| - | - | - |

| 2(AU 1 + AU 2 + AU 4)

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#TFN6

| - | - | - |

| 2(AU 1) | - | - |

| 2(AU 4) | - | - |

| 2(AU 6) | - | - |

|| 50 | 50 | - | - | - |

| With respect to samples | Total |

| ^^ | ^^ | 150 | 132 | ^^ | ^^ | ^^ |

| ^^ | Recognition rate |

| ^^ | ^^ | 88% (including

| ^^ | False alarm |

| ^^ | ^^ | 6.7% (including

| With respect to AU components | Total |

| 8 | 14 | - |

| ^^ | ^^ | 222 | 214 | ^^ | ^^ | ^^ |

| ^^ | Recognition rate |

| ^^ | ^^ | 96.4% (including

| ^^ | False alarm |

| ^^ | ^^ | 6.3% (including

Open in a new tab

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/table/T9/

The numbers in bold are results excluding NEUTRAL. The Missing AUs column shows the AUs that are missed. The Extra AUs column lists the extra AUs that are misrecognized.

The recognized AU with “\*” indicates that it includes both Missing AUs and Extra AUs.

Recognition rates in Experiment 2 were slightly higher than those in Experiment 1. There are two possible reasons: One is that in the neural network used in Experiment 2, multiple output nodes could be excited to allow for recognition of AUs occurring in combinations. Another reason maybe that a larger training data set was used in Experiment 2.

Lower Face AUs

The same structure of the neural network-based recognition scheme, as shown in

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#F12

, was used, except that the input feature parameters and the output component AUs now are those for the lower face. The inputs were the lower face feature parameters shown in

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#T5

. The outputs of the neural network were the 11 single AUs (AU 9, AU 10, AU 12, AU 15, AU 17, AU 20, AU 25, AU 26, AU 27, AU 23 + 24, and

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#T2

). Note that AU 23 + 24 is modeled as a single unit, instead of as AU 23 and AU 24 separately, because they almost always occurred together in our data. Use of 12 hidden units achieved the best performance in this experiment.

A total of 463 image sequences from the Cohn-Kanade AU-Coded Face Expression Image Database were used for lower face AU recognition. Of these, 400 image sequences were used as the training data and 63 sequences were used as the testing data. The test data set included 10 single AUs,

, and 11 AU combinations (such as AU 12 + 25, AU 15 + 17 + 23, AU 9 + 17 + 23 + 24, and AU 17 + 20 + 26) from 32 subjects; none of these subjects appeared in training data set. Some of the image sequences contained limited planar and out-of-plane head motions.

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#T10

shows a summary of the AU recognition results for the lower face when image sequences contain both single AUs and AU combinations. As above, we report the recognition and false alarm rates based on both the number of input samples and the number of AU components (see (

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#FD1

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#FD2

)). With respect to the input samples, an average recognition rate of 95.8 percent was achieved with a false alarm rate of 4.2 percent when

was included and a recognition rate of 93.7 percent and a false alarm rate of 6.4 percent when

was excluded. With respect to AU components, an average recognition rate of 96.7 percent was achieved with a false alarm rate of 2.9 percent when

was included, and a recognition rate of 95.6 percent with a false alarm rate of 3.9 percent was obtained when

was excluded.

Lower Face AU Recognition Results in Experiment 2

| Actual AUs || Samples | Recognized AUs ||||

| ^^ | ^^ | ^^ |

Partially correct

| ^^ | ^^ | ^^ | ^^ |

Missing AUs

| --- | --- | --- | --- | --- | --- | --- |

| - | - | - |

| - | - | - |

| - | - | - |

| - | - | - |

| - | - | - |

| - | - | - |

| - | - | - |

| - | - | 3(AU 25) |

| - | - | - |

| - | - | - | - |

| - | - | - |

AU9+17+23+24

| - | - | - |

| - | - | - |

| 1(AU 17) | - | - |

| ^^ | ^^ | ^^ | ^^ | 2(AU 10 +AU 12)\* || ^^ |

| - | - | - |

| - | - | - |

| - | - | - |

| - | 2(AU 12 + AU 25)\* | | - |

| - | - | - |

| - | - | - |

| - | - | - |

|| 63 | 63 | - | - | - |

| With respect to samples | Total No. of input samples |

| ^^ | ^^ | 189 | 181 | ^^ | ^^ | ^^ |

| ^^ | Recognition rate of samples |

| ^^ | ^^ | 95.8% (including

| ^^ | False alarm of samples |

| ^^ | ^^ | 4.2% (including

| With respect to AU components | Total No. of AUs |

| 5 | 7 | 3 |

| ^^ | ^^ | 243 | 235 | ^^ | ^^ | ^^ |

| ^^ | Recognition rate of AUs |

| ^^ | ^^ | 96.7% (including

| ^^ | False alarm of AUs |

| ^^ | ^^ | 2.9% (including

Open in a new tab

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/table/T10/

Major Causes of the Misidentifications

Most of the misidentifications come from confusions between similar AUs: AU1 and AU2, AU6 and AU7, and AU25 and AU26. The confusions between AU 1 and AU 2 were caused by the strong correlation between them. The action of AU 2, which raises the outer portion of the brow, tends to pull the inner brow up as well (see

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#T1

). Both AU 6 and AU 7 raise the lower eyelids and are often confused by human AU coders as well \[

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#R8

\]. All the mistakes of AU 26 were due to confusion with AU 25. AU 25 and AU 26 contain parted lips but differ only with respect to motion of the jaw, but jaw motion was not detected or used in the current system.

5.4 Generalizability between Databases

To evaluate the generalizability of our system, we trained the system on one database and tested it on another independent image database that was collected and FACS coded for ground-truth by a different research team. One was Cohn-Kanade database and the other was the Ekman-Hager database. This procedure ensured a more rigorous test of generalizability than more usual methods which divide a single database into training and testing sets.

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#T11

summarizes the generalizability of our system.

Generalizability to Independent Databases

| || Test databases || Train databases |

| ^^ | ^^ | Cohn-Kanade | Ekman-Hager | ^^ |

| --- | --- | --- | --- | --- |

| Recognition Rate | upper face |

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#T9

) | Ekman- Hager |

| ^^ | lower face | 96.7% (

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#T10

| Cohn- Kanade |

Open in a new tab

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/table/T11/

The numbers in bold are results from independent databases.

For upper face AU recognition, the network was trained on 186 image sequences of nine subjects from the Ekman-Hager database and tested on 72 image sequences of seven subjects from the Cohn-Kanade database. Of the 72 image sequences, 55 consisted of single AUs (AU 1, AU 2, AU 4, AU 5, AU 6, and AU 7) and the others contained AU combinations such as AU 1 + 2, AU 1 + 2 + 4, and AU 6 + 7. We achieved a recognition rate of 93.2 percent and a false alarm of 2 percent (when samples of

were included), which is only slightly (3-4 percent) lower than the case when the Ekman-Hager database was used for both training and testing.

For lower face AU recognition, the network was trained on 400 image sequences of 46 subjects from the Cohn-Kanade database and tested on 50 image sequences of 14 subjects from the Ekman-Hager database. Of the 50 image sequences, half contained AU combinations, such as AU 10 + 17, AU 10 + 25, AU 12 + 25, AU 15 + 17, and AU 20 + 25. No instances of AU 23 + 24 were available in the Ekman-Hager database. We achieved a recognition rate of 93.4 percent (when samples of

were included). These results were again only slightly lower than those of using the same database. The system showed high generalizability.

5.5 Comparison with Other AU Recognition Systems

We compare the current AFA system's performance with that of Cohn et al. \[

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#R8

\], Lien et al. \[

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#R24

\], Bartlett et al. \[

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#R2

\], and Donato et al. \[

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#R10

\]. The comparisons are summarized in

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#T12

. When performing comparison of recognition results in general, it is important to keep in mind differences in experimental procedures between systems. For example, scoring methods may be either by dividing the data set into training and testing sets \[

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#R8

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#R24

\] or by using a leave-one-out cross-validation procedure \[

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#R2

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#R10

\]. Even when the same data set is used, the particular AUs that were recognized or the specific image sequence that were used for evaluation are not necessarily the same. Therefore, minor differences in recognition rates between systems are not meaningful.

Comparison with Other AU Recognition Systems

Recognition rates

Treatment of AU combinations

AUs to be recognized

Current AFA system

Feature-based

88.5% (old faces)

AU 1, 2, 4, AU 5, 6, 7.

Ekman- Hager

89.4% (novel faces)

AU 9,10,12,15, AU17,20,25,26, AU27,23+24.

Cohn- Kanade

Bartlett et al. \[

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#R2

Feature-based

85.3% (old faces)

AU 1, 2, 4, AU 5, 6, 7.

Ekman- Hager

57% (novel faces)

Donato et al. \[

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#R10

ICA or Gabor wavelet

AU 1, 2, 4, AU 5, 6, 7.

Ekman- Hager

70.3%-85.6%

ICA or Gabor

AU17,18,9+25 AU10+25,16+25

70.3%-85.6%

Cohn et al.\[

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#R8

Feature-Tracking

AU 1+2,1+4, 4, AU 5, 6, 7.

Cohn- Kanade (Subset)

AU12,6+12+25, AU20+25,15+17, AU 17+23+24,9+17. AU 25, 26, 27

Lien et al.\[

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#R24

AU 1+2,1+4, AU 4.

Cohn- Kanade (Subset)

Edge-detection

Feature-Tracking

AU1+2,1+4, 4, AU 5, 6, 7.

AU12,6+12+25, AU20+25,15+17, AU17+23+24,9+17.

Feature-Tracking

AU12,6+12+25, AU20+25,15+17, AU17+23+24,9+17. AU 25, 26, 27

Edge-detection

AU9+17,12+25.

Open in a new tab

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/table/T12/

In the fourth column, “No” means that no AU combination was recognized. “Yes=Yes” means that AU combinations were recognized and AUs in combination were recognizable individually. “Yes=No” means that AU combinations were recognized but each AU combination was treated as if it were a separate new AU.

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#T12

, the systems were compared along several characteristics: feature extraction methods, recognition rates, treatment of AU combinations, AUs recognized, and databases used. The terms “old faces” and “novel faces” in the third column requires some explanation. “Old faces” means that in obtaining the recognition rates, some subjects appear in both training and testing sets. “Novel faces” means no same subject appears in both training and testing sets; this is obviously a little more difficult case than “Old faces.” In the fourth column, the terms “

” are used to describe how the AU combinations are treated. “

” means that no AU combination was recognized. “

” means that AU combinations were recognized and AUs in combination were recognizable individually. “

” means that AU combinations were recognized but each AU combination was treated as if it were a separate new AU. Our current AFA system, while being able to recognize a larger number of AUs and AU combinations, shows the best or near the best recognition rates even for the tests with “novel faces” or in tests where independent different databases are used for training and testing.

6 Conclusion

Automatically recognizing facial expressions is important to understand human emotion and paralinguistic communication, to design multimodal user interfaces, and to relate applications, such as human identification. The facial action coding system (FACS) developed by Ekman and Friesen \[

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#R14

\] is considered to be one of the best and accepted foundations for recognizing facial expressions. Our feature-based automatic face analysis (AFA) system has shown improvement in AU recognition over previous systems.

It has been reported \[

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#R2

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#R5

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#R40

\] that holistic template-based methods (including image decomposition with image kernels such as Gabors, Eigenfaces, and Independent Component Images) outperform explicit parameterization of facial features. Our comparison indicates that a feature-based method performs just as well as the best holistic template-based method and in more complex data. It may be premature to conclude that one or the other approach is superior. Recovering FACS-AUs from video using automatic computer vision techniques is not an easy task and numerous challenges remain \[

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#R20

\]. We feel that further efforts will be required for combining both approaches in order to achieve the optimal performance, and that tests with a substantially large database are called for \[

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#R1

Acknowledgments

The authors would like to thank Paul Ekman, at the Human Interaction Laboratory, University of California, San Francisco for providing the Ekman-Hager database. The authors also thank Zara Ambadar, Bethany Peters, and Michelle Lemenager for processing the images. The authors appreciate the helpful comments and suggestions of Marian Bartlett, Simon Baker, Karen Schmidt, and anonymous reviewers. This work was supported by the National Institute of Mental Health grant R01 MH51435.

Ying-li Tian

received the BS and MS degrees in optical engineering from TianJin University, China, in 1987 and 1990, and the PhD degree in electrical engineering from the Chinese University of Hong Kong, in 1996. After holding a faculty position at National Laboratory of Pattern Recognition, Chinese Academy of Sciences, Beijing, she joined Carnegie Mellon University in 1998, where she is currently a postdoctoral fellow of the Robotics Institute. Her current research focuses on a wide range of computer vision problems from photometric modeling and shape from shading, to human identification, 3D reconstruction, motion analysis, and facial expression analysis. She is a member of the IEEE.

Takeo Kanade

received the Doctoral degree in electrical engineering from Kyoto University, Japan, in 1974. After holding a faculty position at Department of Information Science, Kyoto University, he joined Carnegie Mellon University in 1980. He is currently U.A. Helen Whitaker University Professor of computer science and director of the Robotics Institute. Dr. Kanade has worked in multiple areas of robotics: computer vision, manipulators, autonomous mobile robots, and sensors. He has written more than 200 technical papers and reports in these areas, as well as more than 10 patents. He has been the principal investigator of a dozen major vision and robotics projects at Carnegie Mellon. Dr. Kanade has been elected to the National Academy of Engineering. He is a fellow of the IEEE, the ACM, a founding fellow of the American Association of Artificial Intelligence, and the founding editor of the

International Journal of Computer Vision

. He has received several awards including the C&C Award, the Joseph Engelberger Award, JARA Award, Otto Franc Award, Yokogawa Prize, and Marr Prize Award. Dr. Kanade has served the government, industry, and as a university advisory or on consultant committees, including Aeronautics and Space Engineering Board (ASEB) of the National Research Council, NASA's Advanced Technology Advisory Committee, and the Advisory Board of Canadian Institute for Advanced Research.

Jeffrey F. Cohn

received the PhD degree in clinical psychology from the University of Massachusetts at Amherst in 1983. He is an associate professor of psychology and psychiatry at the University of Pittsburgh and an adjunct faculty member at the Robotics Institute, Carnegie Mellon University. Dr. Cohn's primary research interests are emotion and paralinguistic communication, developmental psychopathology, face image and prosodic analysis, and human-computer interaction. He has published more than 60 peer reviewed articles and conference proceedings on these topics. He is member of the IEEE.

Recommended for acceptance by K.W. Bowyer.

For information on obtaining reprints of this article, please send: tpami@computer.org, and reference IEEECS Log Number 112006.

Contributor Information

Ying-li Tian, Robotics Institute, Carnegie Mellon University, Pittsburgh, PA 15213. yltian@cs.cmu.edu.

Takeo Kanade, Robotics Institute, Carnegie Mellon University, Pittsburgh, PA 15213. tk@cs.cmu.edu.

Jeffrey F. Cohn, Robotics Institute, Carnegie Mellon University, Pittsburgh, and the Department of Psychology, University of Pittsburgh, Pittsburgh, PA 15260. jeffcohn@pitt.edu..

\[1\]. Facial Expression Coding Project. 2000. cooperation and competition between Carnegie Mellon Univ. and Univ. of California, San Diego, unpublished.

\[2\]. Bartlett M, Hager J, Ekman P, Sejnowski T. Measuring Facial Expressions by Computer Image Analysis. Psychophysiology. 1999;36:253–264. doi: 10.1017/s0048577299971664. \[

https://doi.org/10.1017/s0048577299971664

https://pubmed.ncbi.nlm.nih.gov/10194972/

Google Scholar

https://scholar.google.com/scholar\_lookup?journal=Psychophysiology&title=Measuring%20Facial%20Expressions%20by%20Computer%20Image%20Analysis&author=M%20Bartlett&author=J%20Hager&author=P%20Ekman&author=T%20Sejnowski&volume=36&publication\_year=1999&pages=253-264&pmid=10194972&doi=10.1017/s0048577299971664&

\[3\]. Black MJ, Yacoob Y. Tracking and Recognizing Rigid and Nonrigid Facial Motions Using Local Parametric Models of Image Motion. Proc. Int'l Conf. Computer Vision.1995. pp. 374–381. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?Black%20MJ,%20Yacoob%20Y.%20Tracking%20and%20Recognizing%20Rigid%20and%20Nonrigid%20Facial%20Motions%20Using%20Local%20Parametric%20Models%20of%20Image%20Motion.%20Proc.%20Int%E2%80%99l%20Conf.%20Computer%20Vision.1995.%20pp.%20374%E2%80%93381.

\[4\]. Black MJ, Yacoob Y. Recognizing Facial Expressions in Image Sequences Using Local Parameterized Models of Image Motion. Int'l J. Computer Vision. 1997 Oct.25(no. 1):23–48. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?journal=Int%E2%80%99l%20J.%20Computer%20Vision&title=Recognizing%20Facial%20Expressions%20in%20Image%20Sequences%20Using%20Local%20Parameterized%20Models%20of%20Image%20Motion&author=MJ%20Black&author=Y%20Yacoob&volume=25&issue=no.%201&publication\_year=1997&pages=23-48&

\[5\]. Brunelli R, Poggio T. Face Recognition: Features versus Templates. IEEE Trans. Pattern Analysis and Machine Intelligence. 1993 Oct.15(no. 10):1042–1052. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?journal=IEEE%20Trans.%20Pattern%20Analysis%20and%20Machine%20Intelligence&title=Face%20Recognition:%20Features%20versus%20Templates&author=R%20Brunelli&author=T%20Poggio&volume=15&issue=no.%2010&publication\_year=1993&pages=1042-1052&

\[6\]. Canny J. A Computational Approach to Edge Detection. IEEE Trans. Pattern Analysis Machine Intelligence. 1986 Jun;8(no. 6) \[

https://pubmed.ncbi.nlm.nih.gov/21869365/

Google Scholar

https://scholar.google.com/scholar\_lookup?journal=IEEE%20Trans.%20Pattern%20Analysis%20Machine%20Intelligence&title=A%20Computational%20Approach%20to%20Edge%20Detection&author=J%20Canny&volume=8&issue=no.%206&publication\_year=1986&pmid=21869365&

\[7\]. Carroll JM, Russell J. Facial Expression in Hollywood's Portrayal of Emotion. J. Personality and Social Psychology. 1997;72:164–176. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?journal=J.%20Personality%20and%20Social%20Psychology&title=Facial%20Expression%20in%20Hollywood%E2%80%99s%20Portrayal%20of%20Emotion&author=JM%20Carroll&author=J%20Russell&volume=72&publication\_year=1997&pages=164-176&

\[8\]. Cohn JF, Zlochower AJ, Lien J, Kanade T. Automated Face Analysis by Feature Point Tracking has High Concurrent Validity with Manual Faces Coding. Psychophysiology. 1999;36:35–43. doi: 10.1017/s0048577299971184. \[

https://doi.org/10.1017/s0048577299971184

https://pubmed.ncbi.nlm.nih.gov/10098378/

Google Scholar

https://scholar.google.com/scholar\_lookup?journal=Psychophysiology&title=Automated%20Face%20Analysis%20by%20Feature%20Point%20Tracking%20has%20High%20Concurrent%20Validity%20with%20Manual%20Faces%20Coding&author=JF%20Cohn&author=AJ%20Zlochower&author=J%20Lien&author=T%20Kanade&volume=36&publication\_year=1999&pages=35-43&pmid=10098378&doi=10.1017/s0048577299971184&

\[9\]. Darwin C. In: The Expression of Emotions in Man and Animals. Murray John., editor. Univ. of Chicago Press; 1965. reprinted by. 1872. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=The%20Expression%20of%20Emotions%20in%20Man%20and%20Animals&author=C%20Darwin&publication\_year=1965&

\[10\]. Donato G, Bartlett MS, Hager JC, Ekman P, Sejnowski TJ. Classifying Facial Actions. IEEE Trans. Pattern Analysis and Machine Intelligence. 1999 Oct.21(no. 10):974–989. doi: 10.1109/34.799905. \[

https://doi.org/10.1109/34.799905

PMC free article

https://pmc.ncbi.nlm.nih.gov/articles/PMC3008166/

https://pubmed.ncbi.nlm.nih.gov/21188284/

Google Scholar

https://scholar.google.com/scholar\_lookup?journal=IEEE%20Trans.%20Pattern%20Analysis%20and%20Machine%20Intelligence&title=Classifying%20Facial%20Actions&author=G%20Donato&author=MS%20Bartlett&author=JC%20Hager&author=P%20Ekman&author=TJ%20Sejnowski&volume=21&issue=no.%2010&publication\_year=1999&pages=974-989&pmid=21188284&doi=10.1109/34.799905&

\[11\]. Eibl-Eihesfeldt I. Human Ethology. Aldine de Gruvter; New York: 1989. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Human%20Ethology&author=I%20Eibl-Eihesfeldt&publication\_year=1989&

\[12\]. Ekman P. Facial Expression and Emotion. Am. Psychologist. 1993;48:384–392. doi: 10.1037//0003-066x.48.4.384. \[

https://doi.org/10.1037//0003-066x.48.4.384

https://pubmed.ncbi.nlm.nih.gov/8512154/

Google Scholar

https://scholar.google.com/scholar\_lookup?journal=Am.%20Psychologist&title=Facial%20Expression%20and%20Emotion&author=P%20Ekman&volume=48&publication\_year=1993&pages=384-392&pmid=8512154&doi=10.1037//0003-066x.48.4.384&

\[13\]. Ekman P, Friesen WV. Pictures of Facial Affect. Consulting Psychologist; Palo Alto, Calif.: 1976. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Pictures%20of%20Facial%20Affect&author=P%20Ekman&author=WV%20Friesen&publication\_year=1976&

\[14\]. Ekman P, Friesen WV. The Facial Action Coding System: A Technique for The Measurement of Facial Movement. Consulting Psychologists Press; San Francisco: 1978. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=The%20Facial%20Action%20Coding%20System:%20A%20Technique%20for%20The%20Measurement%20of%20Facial%20Movement&author=P%20Ekman&author=WV%20Friesen&publication\_year=1978&

\[15\]. Ekman P, Hager J, Methvin CH, Irwin W. Ekman-Hager Facial Action Exemplars. Human Interaction Laboratory, Univ. of California; San Francisco: unpublished data. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Ekman-Hager%20Facial%20Action%20Exemplars&author=P%20Ekman&author=J%20Hager&author=CH%20Methvin&author=W%20Irwin&

\[16\]. Essa IA, Pentland AP. Coding, Analysis, Interpretation, and Recognition of Facial Expressions. IEEE Trans. Pattern Analysis and Machine Intelligence. 1997 Jul;19(no. 7):757–763. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?journal=IEEE%20Trans.%20Pattern%20Analysis%20and%20Machine%20Intelligence&title=Coding,%20Analysis,%20Interpretation,%20and%20Recognition%20of%20Facial%20Expressions&author=IA%20Essa&author=AP%20Pentland&volume=19&issue=no.%207&publication\_year=1997&pages=757-763&

\[17\]. Fleiss J. Statistical Methods for Rates and Proportions. Wiley; New York: 1981. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Statistical%20Methods%20for%20Rates%20and%20Proportions&author=J%20Fleiss&publication\_year=1981&

\[18\]. Fukui K, Yamaguchi O. Facial Feature Point Extraction Method Based on Combination of Shape Extraction and Pattern Matching. Systems and Computers in Japan. 1998;29(no. 6):49–58. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?journal=Systems%20and%20Computers%20in%20Japan&title=Facial%20Feature%20Point%20Extraction%20Method%20Based%20on%20Combination%20of%20Shape%20Extraction%20and%20Pattern%20Matching&author=K%20Fukui&author=O%20Yamaguchi&volume=29&issue=no.%206&publication\_year=1998&pages=49-58&

\[19\]. Izard C, Dougherty L, Hembree EA. Univ. of Delaware; 1983. A System for Identifying Affect Expressions by Holistic Judgments. unpublished manuscript. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?Izard%20C,%20Dougherty%20L,%20Hembree%20EA.%20Univ.%20of%20Delaware;%201983.%20A%20System%20for%20Identifying%20Affect%20Expressions%20by%20Holistic%20Judgments.%20unpublished%20manuscript.

\[20\]. Kanade T, Cohn J, Tian Y. Comprehensive Database for Facial Expression Analysis. Proc. Int'l Conf. Face and Gesture Recognition.Mar. 2000. pp. 46–53. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?Kanade%20T,%20Cohn%20J,%20Tian%20Y.%20Comprehensive%20Database%20for%20Facial%20Expression%20Analysis.%20Proc.%20Int%E2%80%99l%20Conf.%20Face%20and%20Gesture%20Recognition.Mar.%202000.%20pp.%2046%E2%80%9353.

\[21\]. Kirby M, Sirovich L. Application of the k-l Procedure for the Characterization of Human Faces. IEEE Trans. Pattern Analysis and Machine Intelligence. 1990 Jan.12(no. 1):103–108. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?journal=IEEE%20Trans.%20Pattern%20Analysis%20and%20Machine%20Intelligence&title=Application%20of%20the%20k-l%20Procedure%20for%20the%20Characterization%20of%20Human%20Faces&author=M%20Kirby&author=L%20Sirovich&volume=12&issue=no.%201&publication\_year=1990&pages=103-108&

\[22\]. Kwon Y, Lobo N. Age Classification from Facial Images. Proc. IEEE Conf. Computer Vision and Pattern Recognition.1994. pp. 762–767. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?Kwon%20Y,%20Lobo%20N.%20Age%20Classification%20from%20Facial%20Images.%20Proc.%20IEEE%20Conf.%20Computer%20Vision%20and%20Pattern%20Recognition.1994.%20pp.%20762%E2%80%93767.

\[23\]. Lam K, Yan H. Locating and Extracting the Eye in Human Face Images. Pattern Recognition. 1996;29(no. 5):771–779. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?journal=Pattern%20Recognition&title=Locating%20and%20Extracting%20the%20Eye%20in%20Human%20Face%20Images&author=K%20Lam&author=H%20Yan&volume=29&issue=no.%205&publication\_year=1996&pages=771-779&

\[24\]. Lien J-JJ, Kanade T, Cohn JF, Li CC. Detection, Tracking, and Classification of Action Units in Facial Expression. J. Robotics and Autonomous System. 2000;31:131–146. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?journal=J.%20Robotics%20and%20Autonomous%20System&title=Detection,%20Tracking,%20and%20Classification%20of%20Action%20Units%20in%20Facial%20Expression&author=J-JJ%20Lien&author=T%20Kanade&author=JF%20Cohn&author=CC%20Li&volume=31&publication\_year=2000&pages=131-146&

\[25\]. Lucas B, Kanade T. An Interative Image Registration Technique with an Application in Stereo Vision. Proc. Seventh Int'l Joint Conf. Artificial Intelligence.1981. pp. 674–679. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?Lucas%20B,%20Kanade%20T.%20An%20Interative%20Image%20Registration%20Technique%20with%20an%20Application%20in%20Stereo%20Vision.%20Proc.%20Seventh%20Int%E2%80%99l%20Joint%20Conf.%20Artificial%20Intelligence.1981.%20pp.%20674%E2%80%93679.

\[26\]. Mase K. Recognition of Facial Expression from Optical Flow. IEICE Trans. 1991 Oct.E74(no. 10):3474–3483. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?journal=IEICE%20Trans&title=Recognition%20of%20Facial%20Expression%20from%20Optical%20Flow&author=K%20Mase&volume=E74&issue=no.%2010&publication\_year=1991&pages=3474-3483&

\[27\]. Rao RR. PhD thesis. Electrical Eng., Georgia Inst. of Technology; 1998. Audio-Visual Interaction in Multimedia. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=PhD%20thesis&author=RR%20Rao&publication\_year=1998&

\[28\]. Rosenblum M, Yacoob Y, Davis LS. Human Expression Recognition from Motion Using a Radial Basis Function Network Archtecture. IEEE Trans. Neural Network. 1996;7(no. 5):1121–1138. doi: 10.1109/72.536309. \[

https://doi.org/10.1109/72.536309

https://pubmed.ncbi.nlm.nih.gov/18263509/

Google Scholar

https://scholar.google.com/scholar\_lookup?journal=IEEE%20Trans.%20Neural%20Network&title=Human%20Expression%20Recognition%20from%20Motion%20Using%20a%20Radial%20Basis%20Function%20Network%20Archtecture&author=M%20Rosenblum&author=Y%20Yacoob&author=LS%20Davis&volume=7&issue=no.%205&publication\_year=1996&pages=1121-1138&pmid=18263509&doi=10.1109/72.536309&

\[29\]. Rowley HA, Baluja S, Kanade T. Neural Network-Based Face Detection. IEEE Trans. Pattern Analysis and Machine intelligence. 1998 Jan.20(no. 1):23–38. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?journal=IEEE%20Trans.%20Pattern%20Analysis%20and%20Machine%20intelligence&title=Neural%20Network-Based%20Face%20Detection&author=HA%20Rowley&author=S%20Baluja&author=T%20Kanade&volume=20&issue=no.%201&publication\_year=1998&pages=23-38&

\[30\]. Scherer K, Ekman P. Handbook of Methods in Nonverbal Behavior Research. Cambridge Univ. Press; Cambridge, UK: 1982. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Handbook%20of%20Methods%20in%20Nonverbal%20Behavior%20Research&author=K%20Scherer&author=P%20Ekman&publication\_year=1982&

\[31\]. Suwa M, Sugie N, Fujimora K. A Preliminary Note on Pattern Recognition of Human Emotional Expression. Proc. Int'l Joint Conf. Pattern Recognition.1978. pp. 408–410. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?Suwa%20M,%20Sugie%20N,%20Fujimora%20K.%20A%20Preliminary%20Note%20on%20Pattern%20Recognition%20of%20Human%20Emotional%20Expression.%20Proc.%20Int%E2%80%99l%20Joint%20Conf.%20Pattern%20Recognition.1978.%20pp.%20408%E2%80%93410.

\[32\]. Terzopoulos D, Waters K. Analysis of Facial Images Using Physical and Anatomical Models. Proc. IEEE Int'l Conf. Computer Vision.1990. pp. 727–732. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?Terzopoulos%20D,%20Waters%20K.%20Analysis%20of%20Facial%20Images%20Using%20Physical%20and%20Anatomical%20Models.%20Proc.%20IEEE%20Int%E2%80%99l%20Conf.%20Computer%20Vision.1990.%20pp.%20727%E2%80%93732.

\[33\]. Tian Y, Kanade T, Cohn J. Robust Lip Tracking by Combining Shape, Color, and Motion. Proc. Asian Conf. Computer Vision.2000. pp. 1040–1045. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?Tian%20Y,%20Kanade%20T,%20Cohn%20J.%20Robust%20Lip%20Tracking%20by%20Combining%20Shape,%20Color,%20and%20Motion.%20Proc.%20Asian%20Conf.%20Computer%20Vision.2000.%20pp.%201040%E2%80%931045.

\[34\]. Tian Y, Kanade T, Cohn J. Dual-State Parametric Eye Tracking. Proc. Int'l Conf. Face and Gesture Recognition.Mar. 2000. pp. 110–115. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?Tian%20Y,%20Kanade%20T,%20Cohn%20J.%20Dual-State%20Parametric%20Eye%20Tracking.%20Proc.%20Int%E2%80%99l%20Conf.%20Face%20and%20Gesture%20Recognition.Mar.%202000.%20pp.%20110%E2%80%93115.

\[35\]. Turk M, Pentland A. Face Recognition Using Eigenfaces. Proc. IEEE Conf. Computer Vision and Pattern Recognition.1991. pp. 586–591. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?Turk%20M,%20Pentland%20A.%20Face%20Recognition%20Using%20Eigenfaces.%20Proc.%20IEEE%20Conf.%20Computer%20Vision%20and%20Pattern%20Recognition.1991.%20pp.%20586%E2%80%93591.

\[36\]. Yacoob Y, Black MJ. Parameterized Modeling and Recognition of Activities. Proc. of the Sixth Int'l Conf. Computer Vision.1998. pp. 120–127. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?Yacoob%20Y,%20Black%20MJ.%20Parameterized%20Modeling%20and%20Recognition%20of%20Activities.%20Proc.%20of%20the%20Sixth%20Int%E2%80%99l%20Conf.%20Computer%20Vision.1998.%20pp.%20120%E2%80%93127.

\[37\]. Yacoob Y, Davis LS. Recognizing Human Facial Expression from Long Image Sequences Using Optical Flow. IEEE Trans. Pattern Analysis and Machine Intelligence. 1996 Jun;18(no. 6):636–642. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?journal=IEEE%20Trans.%20Pattern%20Analysis%20and%20Machine%20Intelligence&title=Recognizing%20Human%20Facial%20Expression%20from%20Long%20Image%20Sequences%20Using%20Optical%20Flow&author=Y%20Yacoob&author=LS%20Davis&volume=18&issue=no.%206&publication\_year=1996&pages=636-642&

\[38\]. Yacoob Y, Lam H, Davis L. Recognizing Face Showing Expressions. Proc. Int'l Workshop Automatic Face and Gesture Recognition. 1995 \[

Google Scholar

https://scholar.google.com/scholar\_lookup?journal=Proc.%20Int%E2%80%99l%20Workshop%20Automatic%20Face%20and%20Gesture%20Recognition&title=Recognizing%20Face%20Showing%20Expressions&author=Y%20Yacoob&author=H%20Lam&author=L%20Davis&publication\_year=1995&

\[39\]. Yuille A, Haallinan P, Cohen DS. Feature Extraction from Faces Using Deformable Templates. Int'l J. Computer Vision. 1992;8(no. 2):99–111. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?journal=Int%E2%80%99l%20J.%20Computer%20Vision&title=Feature%20Extraction%20from%20Faces%20Using%20Deformable%20Templates&author=A%20Yuille&author=P%20Haallinan&author=DS%20Cohen&volume=8&issue=no.%202&publication\_year=1992&pages=99-111&

\[40\]. Zhang Z. Feature-Based Facial Expression Recognition: Sensitivity Analysis and Experiments with a Multilayer Perceptron. Int'l J. Pattern Recognition and Artificial Intelligence. 1999;13(no. 6):893–911. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?journal=Int%E2%80%99l%20J.%20Pattern%20Recognition%20and%20Artificial%20Intelligence&title=Feature-Based%20Facial%20Expression%20Recognition:%20Sensitivity%20Analysis%20and%20Experiments%20with%20a%20Multilayer%20Perceptron&author=Z%20Zhang&volume=13&issue=no.%206&publication\_year=1999&pages=893-911&

View on publisher site

https://doi.org/10.1109/34.908962

PDF (1.9 MB)

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/pdf/nihms-248393.pdf

Collections

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/

Similar articles

Cited by other articles

Links to NCBI Databases

On this page

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#abstract1

1 Introduction

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#S1

2 Multistate Feature-Based AU Recognition

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#S4

3 Facial Feature Extraction

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#S5

4 Facial Feature Representation and AU Recognition by Neural Networks

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#S15

5 Experimental Evaluations

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#S19

6 Conclusion

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#S30

Acknowledgments

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#S31

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#d36e1133

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#fn-group1

Contributor Information

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#\_ci93\_

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/#ref-list1

Download .nbib .nbib

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/

Format: AMA APA MLA NLM

Add to Collections

Create a new collection

\[x\] existing

Add to an existing collection

Name your collection \*

Choose a collection

Unable to load your collection due to an error

Please try again

https://pmc.ncbi.nlm.nih.gov/articles/PMC4157835/

Follow NCBI

NCBI on X (formerly known as Twitter)

https://twitter.com/ncbi

NCBI on Facebook

https://www.facebook.com/ncbi.nlm

NCBI on LinkedIn

https://www.linkedin.com/company/ncbinlm

NCBI on GitHub

https://github.com/ncbi

NCBI RSS feed

https://ncbiinsights.ncbi.nlm.nih.gov/

Connect with NLM

NLM on X (formerly known as Twitter)

https://twitter.com/nlm\_nih

NLM on Facebook

https://www.facebook.com/nationallibraryofmedicine

NLM on YouTube

https://www.youtube.com/user/NLMNIH

\[National Library of Medicine 8600 Rockville Pike Bethesda, MD 20894\](https://www.google.com/maps/place/8600+Rockville+Pike,+Bethesda,+MD+20894/%4038.9959508,            -77.101021,17z/data%3D!3m1!4b1!4m5!3m4!1s0x89b7c95e25765ddb%3A0x19156f88b27635b8!8m2!3d38.9959508!            4d-77.0988323)

Web Policies

https://www.nlm.nih.gov/web\_policies.html

https://www.nih.gov/institutes-nih/nih-office-director/office-communications-public-liaison/freedom-information-act-office

HHS Vulnerability Disclosure

https://www.hhs.gov/vulnerability-disclosure-policy/index.html

https://support.nlm.nih.gov/?pagename=cloudpmc-viewer%3Apmc%3Aarticle%3Amanuscript

Accessibility

https://www.nlm.nih.gov/accessibility.html

https://www.nlm.nih.gov/careers/careers.html

https://www.nlm.nih.gov/

https://www.nih.gov/

https://www.hhs.gov/

https://www.usa.gov/

Back to Top

