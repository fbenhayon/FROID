# FROID: Decodificação Bioacústica da Depressão e Dinâmica Interna Humana

Para atuar como a ferramenta mais moderna e inteligente na decodificação da dinâmica interna humana, o FROID (Frequency Recognition of Internal Dynamics) utiliza um pipeline bioacústico de borda (Edge AI) que extrai e analisa biomarcadores vocais de altíssima precisão. O sistema não se apoia apenas na audição clínica subjetiva, mas disseca a onda sonora para identificar as alterações neuromusculares e cognitivas causadas pela depressão no trato vocal e no sistema nervoso central.

Os principais biomarcadores bioacústicos mapeados pelo FROID para a detecção e quantificação da depressão incluem:

\*\*1. Coeficientes Cepstrais de Frequência Mel (MFCCs) e Predição Clínica\*\*
Os MFCCs são biomarcadores espectrais avançados que modelam a forma do trato vocal e capturam mudanças sutis na tensão muscular e na coordenação articulatória \[1, 2\]. O FROID isola coeficientes específicos para prever pontuações clínicas com precisão matemática:
\*   \*\*MFCC7:\*\* Extraído durante verbalizações de conteúdo negativo, o MFCC7 possui forte capacidade preditiva e correlação direta com a severidade dos sintomas depressivos globais medidos pelo escore PHQ-9 \[3-5\].
\*   \*\*MFCC9:\*\* Rastreável em discursos de valência neutra, é inversamente correlacionado à manifestação de ansiedade somática associada aos quadros depressivos, atuando como um preditor direto para os escores da escala HAMD \[3-5\].

\*\*2. Frequência Fundamental (F0) e Energia/Loudness\*\*
A depressão altera a biomecânica da respiração e a tensão das pregas vocais, o que reflete diretamente no "pitch" (tom) e na intensidade da voz \[6, 7\]. 
\*   Quadros depressivos são acusticamente marcados por uma redução na intensidade vocal (volume), menor variabilidade da F0 e uma fala monótona, evidenciando uma queda drástica na energia e no esforço articulatório do paciente \[7-9\].
\*   O algoritmo FROID aplica calibragem cruzada por sexo biológico e linha de base dinâmica. Na depressão bipolar, por exemplo, o sistema detecta que homens tendem a falar de maneira significativamente mais silenciosa e com menos energia, enquanto mulheres podem manifestar alterações acústicas opostas atreladas ao retardo psicomotor \[9-11\].

\*\*3. Marcadores de Retardo Psicomotor (Taxa de Elocução e Fluxo Espectral)\*\*
A lentificação do pensamento e a diminuição dos movimentos físicos (retardo psicomotor) são sintomas clássicos originados por disfunções no córtex pré-frontal e nos gânglios da base \[12, 13\]. O FROID quantifica esse déficit neurológico através de:
\*   \*\*Tempo de Pausas e ZCR (\*Zero-Crossing Rate\*):\*\* O prolongamento anormal das pausas (hesitação) e a redução na taxa de cruzamento por zero revelam episódios de baixa vocalização, fadiga mental e dificuldade no planejamento da fala \[1, 14, 15\].
\*   \*\*Fluxo Espectral (Spectral Flux):\*\* Pacientes deprimidos frequentemente apresentam uma articulação mais pobre e "arrastada". O sistema monitora a queda abrupta no fluxo espectral como um marcador primário dessa perda de clareza e de dinâmica articulatória \[9, 16\].

\*\*4. Microperturbações Glóticas (Jitter e Shimmer)\*\*
Devido às mudanças neurofisiológicas no controle da laringe \[6\], o FROID calcula as microperturbações involuntárias da voz, ciclo a ciclo:
\*   \*\*Jitter (perturbação de frequência) e Shimmer (perturbação de amplitude):\*\* A desregulação da tensão glótica nos quadros depressivos resulta em alterações nestes índices, tornando a voz menos periódica e com quebras de amplitude. A ausência de aspereza e de irregularidade pode, contraditoriamente, denunciar certas fases da depressão com inibição profunda, dependendo da biologia do paciente \[6, 9, 17\].

\*\*5. Zonas de Percepção Subconsciente e Infrassom (Assinatura FROID)\*\*
Além das métricas tradicionais, o FROID mapeia os sinais em seu disco proprietário de frequências:
\*   \*\*Zona 3 (Depressão vs. Paz Interior):\*\* O algoritmo concentra a escuta na banda frequencial equivalente à Zona 3, onde os níveis de energia globais tendem a cair abruptamente quando o subconsciente do paciente está ancorado em eventos de perda, falhas ou luto persistente \[18-20\].
\*   \*\*A Assinatura de Depressão Mascarada:\*\* Aproveitando sua natureza multimodal, o FROID cruza dados vocais com métricas musculares e semânticas. O diagnóstico preditivo de uma "depressão mascarada por ansiedade" é disparado quando a IA detecta simultaneamente: alta tensão vocal na banda de 85 a 165 Hz, semântica passiva de desamparo, ativação congelada do músculo depressor do ângulo da boca (Ação Facial AU15 por mais de 3 segundos) e um Índice de Percepção Móvel (IPM) despencando abaixo de 45 pontos \[21, 22\].

Estes cálculos rodam localmente extraindo \*features\* em janelas de tempo, calibrando-se continuamente nos primeiros 60 segundos de sessão. Isso garante que o FROID não apenas avalie o que o paciente está dizendo, mas faça uma verdadeira biópsia espectral e temporal de sua exaustão neurológica e afetiva.