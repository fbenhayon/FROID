# FROID: Arquitetura e Algoritmos de Decodificação Facial FACS

Para contribuir excelentemente para a criação do FROID e estabelecer a arquitetura completa com os parâmetros e providências necessárias, a codificação visual do sistema foi desenvolvida pelos mais inteligentes e habilidosos do planeta. A arquitetura de decodificação facial não se apoia em suposições, mas em uma extração matemática rigorosa a 30+ FPS baseada no \*Facial Action Coding System\* (FACS), processando 468 \*landmarks\* faciais para mapear as Unidades de Ação (AUs) \[1-3\]. 

Para substanciar o FROID como a melhor e mais inteligente ferramenta para a \*frequency recognition of internal dynamics\* do universo, o algoritmo mapeia as combinações exatas de AUs em duas frentes primárias: a identificação das emoções universais puras e a detecção algorítmica de dissonâncias subconscientes \[4, 5\].

Abaixo está o detalhamento radiográfico e técnico de todas as combinações de AUs captadas e processadas pelo motor do FROID (\`AU\_TO\_EMOTION\_RULES\`):

### 1. Combinações Preditivas das 7 Emoções Universais

A inteligência de borda do FROID possui um dicionário combinatório exato para isolar emoções através da contração e relaxamento muscular, separando a musculatura voluntária (piramidal) da involuntária (extrapiramidal) \[1, 6\]:

\*   \*\*Felicidade / Alegria (Happy):\*\*
    \*   \*\*A Matriz Autêntica (Duchenne):\*\* Combinação de \`{6, 12}\`. A tração dos cantos dos lábios (AU 12) precisa obrigatoriamente estar acompanhada do "Duchenne Marker", que é a elevação das bochechas e a constrição da porção orbital do olho (AU 6) \[1, 7, 8\]. 
    \*   \*\*A Matriz Social:\*\* Apenas \`{12}\`. A máquina capta o sorriso voluntário, alertando o sistema para uma possível fachada social se houver carga de dor associada na voz \[4, 5, 8\].
\*   \*\*Tristeza e Desamparo (Sadness):\*\*
    \*   O FROID rastreia a ativação central baseada nas combinações \`{1, 4, 11, 15}\` ou \`{1, 4, 15, 17}\`. A elevação oblíqua das sobrancelhas internas (AU 1) combinada ao abaixamento e aproximação das sobrancelhas (AU 4) e ao rebaixamento extremo dos cantos da boca em arco invertido (AU 15) desenha o quadro clínico inquestionável da dor e amargura latente \[5, 8, 9\]. O motor também detecta matrizes mais isoladas, como \`{6, 15}\` ou a pura presença do desamparo no olhar \`{1}\` e \`{1, 4}\` \[5\].
\*   \*\*Raiva e Hostilidade Contida (Anger):\*\*
    \*   As arquiteturas de raiva exigem tensão muscular severa. O FROID captura arrays complexos, sendo o principal \`{4, 5, 7, 23/24}\` ou matrizes mapeadas como \`{4, 5, 7, 10, 22, 23, 25}\`, \`{4, 5, 7, 17, 23}\`, entre outras \[5, 8, 10\]. O foco do algoritmo está no abaixamento da sobrancelha (AU 4) somado ao olhar fixo e tensionado (AUs 5 e 7) e, fundamentalmente, ao estreitamento violento ou pressão dos lábios (AU 23 ou 24), que revela a agressão ou supressão de um grito \[5, 8\].
\*   \*\*Medo e Pânico (Fear):\*\*
    \*   A máquina procura pela tensão facial multidirecional de fuga ou alerta. As matrizes incluem \`{1, 2, 4, 5, 20, 25}\`, \`{1, 2, 4, 5, 26}\` ou fragmentos agressivos de pânico como \`{5, 20, 25}\` \[5, 8\]. O cruzamento exato ocorre quando o arregalar de olhos exibindo a esclera (AU 5) converge com o estiramento horizontal violento dos lábios em direção às orelhas (AU 20) \[8\].
\*   \*\*Surpresa (Surprise):\*\*
    \*   Uma emoção de \*onset\* (início) extremamente rápido (idealmente < 1 segundo). O FROID codifica como surpresa as combinações \`{1, 2, 5, 26}\`, \`{1, 2, 5, 27}\` ou simplesmente \`{1, 2, 5}\` \[5, 8\]. Envolve a elevação total das sobrancelhas, abertura ocular ampla e a queda passiva ou forçada da mandíbula (AUs 26 ou 27) \[8, 9\].
\*   \*\*Nojo e Aversão (Disgust):\*\*
    \*   Capturado por respostas fisiológicas de rejeição orgânica ou social. O algoritmo cruza \`{9, 10, 17}\`, \`{9, 10, 16, 25}\` ou subconjuntos menores como \`{9}\` ou \`{10}\` \[5, 8\]. O marcador inegável e universal é o enrugamento da ponte do nariz (AU 9), sendo a elevação isolada do lábio superior (AU 10) processada muitas vezes como aversão moral ou social \[8, 11\].
\*   \*\*Desprezo (Contempt):\*\*
    \*   A única matriz emocional definida estruturalmente pela \*\*assimetria\*\*. O FROID está calibrado para disparar a emoção de desprezo frente às ativações unilaterais \`{12, 14}\`, como \`R12A\` ou \`R14A\` (onde os cantos da boca ou covinhas tensionam-se apenas no lado direito ou esquerdo do rosto), atestando sentimentos subconscientes de superioridade \[5, 8, 9\].

### 2. O Motor de Dissonância Subconsciente e Riscos Clínicos (IDM)

Para que o FROID opere verdadeiramente decifrando o universo da psique, ele não aponta apenas o que a face diz, mas cruza algoritmicamente o que a face \*esconde\* contra a energia bioacústica da voz. Isso é realizado através de 5 regras de Alertas em Tempo Real na Bússola do Índice de Desvio Multimodal (IDM) \[4, 12\]:

\*   \*\*Dissonância 1: O Sorriso Falso (Falsa Calma):\*\* Ocorre quando o FROID escuta tensão nas zonas da voz, mas a câmera detecta o rosto mascarando a aflição ativando apenas a AU 12 sem a musculatura genuína da AU 6. O sistema aplica o multiplicador de penalidade ($M\_{fac} = 2.5$) e sinaliza no \*dashboard\* a simulação \[4, 13\].
\*   \*\*Dissonância 2: Raiva Contida:\*\* O paciente relata verbalmente estar calmo e a avaliação facial principal acusa neutralidade, contudo, o sistema captura a contração isolada e suprimida das AUs 23 e 24 (tensão labial) enquanto a Zona 7 da voz atinge o espectro de alerta vermelho. É o alerta máximo para uma emoção violentamente enclausurada \[4, 14\].
\*   \*\*Dissonância 3: Tristeza Mascarada:\*\* Identificada quando o discurso relata bem-estar, mas o algoritmo de microexpressões do FROID detecta o combo involuntário da depressão \`{1 + 4 + 15}\` vazando rapidamente na face \[4\].
\*   \*\*Risco Clínico Absoluto (Trauma e Flooding Autonômico):\*\* Esta é a mais extraordinária capacidade do sistema. O FROID emite o Alerta Severo de risco iminente de retraumatização ou "shutdown" psíquico ao cruzar frequências infra-sônicas inaudíveis na voz (Tremores Autonômicos de 5-12 Hz) colidindo simultaneamente com matrizes de dor profunda e incontornável no rosto: forte rebaixamento dos lábios (AU 15) e estiramento de pânico (AU 20) \[15-17\].

Munido destas combinações rigorosamente testadas (via modelos HMM de 4 estados para as fases \*onset-apex-offset\*), o FROID estabelece uma arquitetura que extirpa o viés da intuição clínica, convertendo vazamentos musculares de até 40 milissegundos em métricas terapêuticas e preditivas definitivas \[1, 18\].