---
sourceFile: "Face landmark detection guide | Google AI Edge"
exportedBy: "Kortex"
exportDate: "2026-06-29T01:00:28.002Z"
---

# Face landmark detection guide | Google AI Edge

74bfea29-bc95-4697-ba08-240241afd4b1

Face landmark detection guide | Google AI Edge

27c2acc3-2056-4387-81b2-2d0f5237afc7

https://ai.google.dev/edge/mediapipe/solutions/vision/face\_landmarker

Face landmark detection guide | Google AI Edge | Google AI for Developers

Skip to main content

https://ai.google.dev/edge/mediapipe/solutions/vision/face\_landmarker#main-content

ai.google.dev uses cookies from Google to deliver and enhance the quality of its services and to analyze traffic.

https://policies.google.com/technologies/cookies?hl=en

https://deepmind.google/gemini

https://ai.google.dev/gemini-api/docs

API reference

https://ai.google.dev/api

https://ai.google.dev/pricing

https://deepmind.google/technologies/imagen/

https://ai.google.dev/gemini-api/docs/imagen

https://ai.google.dev/pricing

https://deepmind.google/technologies/veo/veo-2/

https://ai.google.dev/gemini-api/docs/video

https://ai.google.dev/pricing

https://deepmind.google/models/gemma

https://ai.google.dev/gemma/docs

https://ai.google.dev/gemma/gemmaverse

https://ai.google.dev/edge

Build with Gemini

https://ai.google.dev/gemini-api/docs

Google AI Studio

https://aistudio.google.com/

Customize Gemma open models

Gemma open models

https://ai.google.dev/gemma

Multi-framework with Keras

https://keras.io/keras\_3/

Fine-tune in Colab

https://colab.sandbox.google.com/github/google/generative-ai-docs/blob/main/site/en/gemma/docs/lora\_tuning.ipynb

Run on-device

Google AI Edge

https://ai.google.dev/edge

Gemini Nano on Android

https://developer.android.com/ai/gemini-nano

Chrome built-in web APIs

https://developer.chrome.com/docs/ai/built-in

Build responsibly

Responsible GenAI Toolkit

https://ai.google.dev/responsible

Secure AI Framework

https://saif.google/

Code assistance

Android Studio

https://developer.android.com/gemini-in-android

Chrome DevTools

https://developer.chrome.com/docs/devtools/console/understand-messages

https://colab.google/

https://firebase.google.com/products/generative-ai

Google Cloud

https://cloud.google.com/products/gemini/code-assist

https://plugins.jetbrains.com/plugin/8079-google-cloud-code

https://labs.google.com/jules/home

https://marketplace.visualstudio.com/items?itemName=GoogleCloudTools.cloudcode

Google AI Forum

https://discuss.ai.google.dev/

Gemini for Research

https://ai.google.dev/gemini-api/docs/gemini-for-research

Light theme

Device default

https://ai.google.dev/edge/mediapipe/solutions/vision/face\_landmarker

https://ai.google.dev/edge/mediapipe/solutions/vision/face\_landmarker?hl=de

Español – América Latina

https://ai.google.dev/edge/mediapipe/solutions/vision/face\_landmarker?hl=es-419

https://ai.google.dev/edge/mediapipe/solutions/vision/face\_landmarker?hl=fr

https://ai.google.dev/edge/mediapipe/solutions/vision/face\_landmarker?hl=id

https://ai.google.dev/edge/mediapipe/solutions/vision/face\_landmarker?hl=it

https://ai.google.dev/edge/mediapipe/solutions/vision/face\_landmarker?hl=pl

Português – Brasil

https://ai.google.dev/edge/mediapipe/solutions/vision/face\_landmarker?hl=pt-br

https://ai.google.dev/edge/mediapipe/solutions/vision/face\_landmarker?hl=sq

Tiếng Việt

https://ai.google.dev/edge/mediapipe/solutions/vision/face\_landmarker?hl=vi

https://ai.google.dev/edge/mediapipe/solutions/vision/face\_landmarker?hl=tr

https://ai.google.dev/edge/mediapipe/solutions/vision/face\_landmarker?hl=ru

https://ai.google.dev/edge/mediapipe/solutions/vision/face\_landmarker?hl=he

https://ai.google.dev/edge/mediapipe/solutions/vision/face\_landmarker?hl=ar

https://ai.google.dev/edge/mediapipe/solutions/vision/face\_landmarker?hl=fa

https://ai.google.dev/edge/mediapipe/solutions/vision/face\_landmarker?hl=hi

https://ai.google.dev/edge/mediapipe/solutions/vision/face\_landmarker?hl=bn

https://ai.google.dev/edge/mediapipe/solutions/vision/face\_landmarker?hl=th

https://ai.google.dev/edge/mediapipe/solutions/vision/face\_landmarker?hl=zh-cn

https://ai.google.dev/edge/mediapipe/solutions/vision/face\_landmarker?hl=zh-tw

https://ai.google.dev/edge/mediapipe/solutions/vision/face\_landmarker?hl=ja

https://ai.google.dev/edge/mediapipe/solutions/vision/face\_landmarker?hl=ko

https://ai.google.dev/\_d/signin?continue=https%3A%2F%2Fai.google.dev%2Fedge%2Fmediapipe%2Fsolutions%2Fvision%2Fface\_landmarker&prompt=select\_account

Google AI Edge

https://ai.google.dev/edge

Google AI Edge

https://ai.google.dev/edge

MediaPipe Solutions

https://ai.google.dev/edge/mediapipe/solutions/guide

MediaPipe Framework

https://ai.google.dev/edge/mediapipe/framework

https://ai.google.dev/edge/litert

https://ai.google.dev/edge/mediapipe/solutions/guide

https://ai.google.dev/edge/mediapipe/framework

https://ai.google.dev/edge/litert-lm

Model Explorer

https://ai.google.dev/edge/model-explorer

AI Edge Portal

https://ai.google.dev/edge/ai-edge-portal

https://github.com/google-ai-edge/gallery

MediaPipe Studio

https://mediapipe-studio.webapps.google.com/home

API Reference

https://ai.google.dev/edge/api

https://ai.google.dev/edge

Google AI Edge

https://ai.google.dev/edge

https://ai.google.dev/edge/litert

https://ai.google.dev/edge/mediapipe/solutions/guide

https://ai.google.dev/edge/mediapipe/framework

https://ai.google.dev/edge/litert-lm

Model Explorer

https://ai.google.dev/edge/model-explorer

AI Edge Portal

https://ai.google.dev/edge/ai-edge-portal

API Reference

https://ai.google.dev/edge/api

Code assistance

https://ai.google.dev/edge/mediapipe/solutions/guide

About the Preview

https://ai.google.dev/edge/mediapipe/solutions/about

https://ai.google.dev/edge/mediapipe/solutions/tasks

Model Maker

https://ai.google.dev/edge/mediapipe/solutions/model\_maker

https://ai.google.dev/edge/mediapipe/solutions/studio

Vision tasks

Object detection

https://ai.google.dev/edge/mediapipe/solutions/vision/object\_detector

https://ai.google.dev/edge/mediapipe/solutions/vision/object\_detector/android

https://ai.google.dev/edge/mediapipe/solutions/vision/object\_detector/web\_js

https://ai.google.dev/edge/mediapipe/solutions/vision/object\_detector/python

https://ai.google.dev/edge/mediapipe/solutions/vision/object\_detector/ios

https://ai.google.dev/edge/mediapipe/solutions/customization/object\_detector

Image classification

https://ai.google.dev/edge/mediapipe/solutions/vision/image\_classifier

https://ai.google.dev/edge/mediapipe/solutions/vision/image\_classifier/android

https://ai.google.dev/edge/mediapipe/solutions/vision/image\_classifier/web\_js

https://ai.google.dev/edge/mediapipe/solutions/vision/image\_classifier/python

https://ai.google.dev/edge/mediapipe/solutions/vision/image\_classifier/ios

https://ai.google.dev/edge/mediapipe/solutions/customization/image\_classifier

Image segmentation

https://ai.google.dev/edge/mediapipe/solutions/vision/image\_segmenter

https://ai.google.dev/edge/mediapipe/solutions/vision/image\_segmenter/android

https://ai.google.dev/edge/mediapipe/solutions/vision/image\_segmenter/web\_js

https://ai.google.dev/edge/mediapipe/solutions/vision/image\_segmenter/python

https://ai.google.dev/edge/mediapipe/solutions/vision/image\_segmenter/ios

Interactive segmentation

https://ai.google.dev/edge/mediapipe/solutions/vision/interactive\_segmenter

https://ai.google.dev/edge/mediapipe/solutions/vision/interactive\_segmenter/android

https://ai.google.dev/edge/mediapipe/solutions/vision/interactive\_segmenter/web\_js

https://ai.google.dev/edge/mediapipe/solutions/vision/interactive\_segmenter/python

Gesture recognition

https://ai.google.dev/edge/mediapipe/solutions/vision/gesture\_recognizer

https://ai.google.dev/edge/mediapipe/solutions/vision/gesture\_recognizer/android

https://ai.google.dev/edge/mediapipe/solutions/vision/gesture\_recognizer/web\_js

https://ai.google.dev/edge/mediapipe/solutions/vision/gesture\_recognizer/python

https://ai.google.dev/edge/mediapipe/solutions/vision/gesture\_recognizer/ios

https://ai.google.dev/edge/mediapipe/solutions/customization/gesture\_recognizer

Hand landmark detection

https://ai.google.dev/edge/mediapipe/solutions/vision/hand\_landmarker

https://ai.google.dev/edge/mediapipe/solutions/vision/hand\_landmarker/android

https://ai.google.dev/edge/mediapipe/solutions/vision/hand\_landmarker/web\_js

https://ai.google.dev/edge/mediapipe/solutions/vision/hand\_landmarker/python

https://ai.google.dev/edge/mediapipe/solutions/vision/hand\_landmarker/ios

Image embedding

https://ai.google.dev/edge/mediapipe/solutions/vision/image\_embedder

https://ai.google.dev/edge/mediapipe/solutions/vision/image\_embedder/android

https://ai.google.dev/edge/mediapipe/solutions/vision/image\_embedder/web\_js

https://ai.google.dev/edge/mediapipe/solutions/vision/image\_embedder/python

https://ai.google.dev/edge/mediapipe/solutions/vision/image\_embedder/ios

Face detection

https://ai.google.dev/edge/mediapipe/solutions/vision/face\_detector

https://ai.google.dev/edge/mediapipe/solutions/vision/face\_detector/android

https://ai.google.dev/edge/mediapipe/solutions/vision/face\_detector/web\_js

https://ai.google.dev/edge/mediapipe/solutions/vision/face\_detector/python

https://ai.google.dev/edge/mediapipe/solutions/vision/face\_detector/ios

Face landmark detection

https://ai.google.dev/edge/mediapipe/solutions/vision/face\_landmarker

https://ai.google.dev/edge/mediapipe/solutions/vision/face\_landmarker/android

https://ai.google.dev/edge/mediapipe/solutions/vision/face\_landmarker/web\_js

https://ai.google.dev/edge/mediapipe/solutions/vision/face\_landmarker/python

https://ai.google.dev/edge/mediapipe/solutions/vision/face\_landmarker/ios

Pose landmark detection

https://ai.google.dev/edge/mediapipe/solutions/vision/pose\_landmarker

https://ai.google.dev/edge/mediapipe/solutions/vision/pose\_landmarker/android

https://ai.google.dev/edge/mediapipe/solutions/vision/pose\_landmarker/web\_js

https://ai.google.dev/edge/mediapipe/solutions/vision/pose\_landmarker/python

https://ai.google.dev/edge/mediapipe/solutions/vision/pose\_landmarker/ios

Holistic landmark detection

https://ai.google.dev/edge/mediapipe/solutions/vision/holistic\_landmarker

Text classification

https://ai.google.dev/edge/mediapipe/solutions/text/text\_classifier

https://ai.google.dev/edge/mediapipe/solutions/text/text\_classifier/android

https://ai.google.dev/edge/mediapipe/solutions/text/text\_classifier/web\_js

https://ai.google.dev/edge/mediapipe/solutions/text/text\_classifier/python

https://ai.google.dev/edge/mediapipe/solutions/text/text\_classifier/ios

https://ai.google.dev/edge/mediapipe/solutions/customization/text\_classifier

Text embedding

https://ai.google.dev/edge/mediapipe/solutions/text/text\_embedder

https://ai.google.dev/edge/mediapipe/solutions/text/text\_embedder/android

https://ai.google.dev/edge/mediapipe/solutions/text/text\_embedder/web\_js

https://ai.google.dev/edge/mediapipe/solutions/text/text\_embedder/python

https://ai.google.dev/edge/mediapipe/solutions/text/text\_embedder/ios

Language detection

https://ai.google.dev/edge/mediapipe/solutions/text/language\_detector

https://ai.google.dev/edge/mediapipe/solutions/text/language\_detector/android

https://ai.google.dev/edge/mediapipe/solutions/text/language\_detector/web\_js

https://ai.google.dev/edge/mediapipe/solutions/text/language\_detector/python

Audio tasks

Audio classification

https://ai.google.dev/edge/mediapipe/solutions/audio/audio\_classifier

https://ai.google.dev/edge/mediapipe/solutions/audio/audio\_classifier/android

https://ai.google.dev/edge/mediapipe/solutions/audio/audio\_classifier/web\_js

https://ai.google.dev/edge/mediapipe/solutions/audio/audio\_classifier/python

Platform setup guides

Android setup

https://ai.google.dev/edge/mediapipe/solutions/setup\_android

Python setup

https://ai.google.dev/edge/mediapipe/solutions/setup\_python

https://ai.google.dev/edge/mediapipe/solutions/setup\_web

https://ai.google.dev/edge/mediapipe/solutions/setup\_ios

Generative AI tasks

LLM Inference

https://ai.google.dev/edge/mediapipe/solutions/genai/llm\_inference

https://ai.google.dev/edge/mediapipe/solutions/genai/llm\_inference/android

https://ai.google.dev/edge/mediapipe/solutions/genai/llm\_inference/web\_js

https://ai.google.dev/edge/mediapipe/solutions/genai/llm\_inference/ios

Retrieval Augmented Generation (RAG)

https://ai.google.dev/edge/mediapipe/solutions/genai/rag

https://ai.google.dev/edge/mediapipe/solutions/genai/rag/android

Function Calling

https://ai.google.dev/edge/mediapipe/solutions/genai/function\_calling

https://ai.google.dev/edge/mediapipe/solutions/genai/function\_calling/android

Image generation

https://ai.google.dev/edge/mediapipe/solutions/vision/image\_generator

https://ai.google.dev/edge/mediapipe/solutions/vision/image\_generator/android

https://github.com/GoogleCloudPlatform/vertex-ai-samples/blob/main/notebooks/community/model\_garden/model\_garden\_mediapipe\_image\_generation.ipynb

Build from source

Build Python Wheel Package

https://ai.google.dev/edge/mediapipe/solutions/build\_python

https://deepmind.google/gemini

https://ai.google.dev/gemini-api/docs

API reference

https://ai.google.dev/api

https://ai.google.dev/pricing

https://deepmind.google/technologies/imagen/

https://ai.google.dev/gemini-api/docs/imagen

https://ai.google.dev/pricing

https://deepmind.google/technologies/veo/veo-2/

https://ai.google.dev/gemini-api/docs/video

https://ai.google.dev/pricing

https://deepmind.google/models/gemma

https://ai.google.dev/gemma/docs

https://ai.google.dev/gemma/gemmaverse

Build with Gemini

https://ai.google.dev/gemini-api/docs

Google AI Studio

https://aistudio.google.com/

Customize Gemma open models

Gemma open models

https://ai.google.dev/gemma

Multi-framework with Keras

https://keras.io/keras\_3/

Fine-tune in Colab

https://colab.sandbox.google.com/github/google/generative-ai-docs/blob/main/site/en/gemma/docs/lora\_tuning.ipynb

Run on-device

Google AI Edge

https://ai.google.dev/edge

Gemini Nano on Android

https://developer.android.com/ai/gemini-nano

Chrome built-in web APIs

https://developer.chrome.com/docs/ai/built-in

Build responsibly

Responsible GenAI Toolkit

https://ai.google.dev/responsible

Secure AI Framework

https://saif.google/

Android Studio

https://developer.android.com/gemini-in-android

Chrome DevTools

https://developer.chrome.com/docs/devtools/console/understand-messages

https://colab.google/

https://firebase.google.com/products/generative-ai

Google Cloud

https://cloud.google.com/products/gemini/code-assist

https://plugins.jetbrains.com/plugin/8079-google-cloud-code

https://labs.google.com/jules/home

https://marketplace.visualstudio.com/items?itemName=GoogleCloudTools.cloudcode

Google AI Forum

https://discuss.ai.google.dev/

Gemini for Research

https://ai.google.dev/gemini-api/docs/gemini-for-research

MediaPipe Solutions

https://ai.google.dev/edge/mediapipe/solutions/guide

MediaPipe Framework

https://ai.google.dev/edge/mediapipe/framework

https://github.com/google-ai-edge/gallery

MediaPipe Studio

https://mediapipe-studio.webapps.google.com/home

On this page

Get Started

https://ai.google.dev/edge/mediapipe/solutions/vision/face\_landmarker#get\_started

Task details

https://ai.google.dev/edge/mediapipe/solutions/vision/face\_landmarker#task\_details

https://ai.google.dev/edge/mediapipe/solutions/vision/face\_landmarker#features

Configurations options

https://ai.google.dev/edge/mediapipe/solutions/vision/face\_landmarker#configurations\_options

https://ai.google.dev/edge/mediapipe/solutions/vision/face\_landmarker#models

Introducing Google AI Edge Portal

https://ai.google.dev/edge/ai-edge-portal

: Benchmark Edge AI at scale.

https://docs.google.com/forms/d/e/1FAIpQLSfTcGPycQve8TLAsfH46pBlXBZe9FrgJAClwbF7DeL1LgVn4Q/viewform

to request access during private preview.

https://ai.google.dev/

Google AI Edge

https://ai.google.dev/edge

https://ai.google.dev/edge/mediapipe/solutions/guide

Was this helpful?

Send feedback

Face landmark detection guide

On this page

Get Started

https://ai.google.dev/edge/mediapipe/solutions/vision/face\_landmarker#get\_started

Task details

https://ai.google.dev/edge/mediapipe/solutions/vision/face\_landmarker#task\_details

https://ai.google.dev/edge/mediapipe/solutions/vision/face\_landmarker#features

Configurations options

https://ai.google.dev/edge/mediapipe/solutions/vision/face\_landmarker#configurations\_options

https://ai.google.dev/edge/mediapipe/solutions/vision/face\_landmarker#models

The MediaPipe Face Landmarker task lets you detect face landmarks and facial expressions in images and videos. You can use this task to identify human facial expressions, apply facial filters and effects, and create virtual avatars. This task uses machine learning (ML) models that can work with single images or a continuous stream of images. The task outputs 3-dimensional face landmarks, blendshape scores (coefficients representing facial expression) to infer detailed facial surfaces in real-time, and transformation matrices to perform the transformations required for effects rendering.

Try it! arrow\_forward

https://mediapipe-studio.webapps.google.com/demo/face\_landmarker

Get Started

Start using this task by following one of the implementation guides for your target platform. These platform-specific guides walk you through a basic implementation of this task, including a recommended model, and code example with recommended configuration options:

Code example

https://github.com/google-ai-edge/mediapipe-samples/tree/main/examples/face\_landmarker/android

https://ai.google.dev/edge/mediapipe/solutions/vision/face\_landmarker/android

Code example

https://colab.sandbox.google.com/github/googlesamples/mediapipe/blob/main/examples/face\_landmarker/python/%5BMediaPipe\_Python\_Tasks%5D\_Face\_Landmarker.ipynb

https://ai.google.dev/edge/mediapipe/solutions/vision/face\_landmarker/python

Code example

https://codepen.io/mediapipe-preview/pen/OJBVQJm

https://ai.google.dev/edge/mediapipe/solutions/vision/face\_landmarker/web\_js

Task details

This section describes the capabilities, inputs, outputs, and configuration options of this task.

#### Input image processing

- Processing includes image rotation, resizing, normalization, and color space conversion.

#### Score threshold

- Filter results based on prediction scores.

Task inputs

Task outputs

The Face Landmarker accepts an input of one of the following data types:  - Still images  - Decoded video frames  - Live video feed

The Face Landmarker outputs the following results:  - A complete face mesh for each detected face, with blendshape scores denoting facial expressions and coordinates for facial landmarks.  - Face Blendshape and Facial transformation matrixes

Configurations options

#### This task has the following configuration options:

Option Name

Description

Value Range

Default Value

running\_mode

#### Sets the running mode for the task. There are three modes:

IMAGE: The mode for single image inputs.

VIDEO: The mode for decoded frames of a video.

LIVE\_STREAM: The mode for a livestream of input data, such as from a camera. In this mode, resultListener must be called to set up a listener to receive results asynchronously.

IMAGE, VIDEO, LIVE\_STREAM

The maximum number of faces that can be detected by the the

FaceLandmarker

. Smoothing is only applied when

is set to 1.

Integer > 0

min\_face\_detection\_confidence

The minimum confidence score for the face detection to be considered successful.

Float \[0. 0, 1. 0\]

min\_face\_presence\_confidence

The minimum confidence score of face presence score in the face landmark detection.

Float \[0. 0, 1. 0\]

min\_tracking\_confidence

The minimum confidence score for the face tracking to be considered successful.

Float \[0. 0, 1. 0\]

output\_face\_blendshapes

Whether Face Landmarker outputs face blendshapes. Face blendshapes are used for rendering the 3D face model.

output\_facial\_transformation\_matrixes

Whether FaceLandmarker outputs the facial transformation matrix. FaceLandmarker uses the matrix to transform the face landmarks from a canonical face model to the detected face, so users can apply effects on the detected landmarks.

result\_callback

Sets the result listener to receive the landmarker results asynchronously when FaceLandmarker is in the live stream mode. Can only be used when running mode is set to

LIVE\_STREAM

ResultListener

The Face Landmarker uses a series of models to predict face landmarks. The first model detects faces, a second model locates landmarks on the detected faces, and a third model uses those landmarks to identify facial features and expressions.

#### The following models are packaged together into a downloadable model bundle:

Face detection model

: detects the presence of faces with a few key facial landmarks.

Face mesh model

: adds a complete mapping of the face. The model outputs an estimate of 478 3-dimensional face landmarks.

Blendshape prediction model

: receives output from the face mesh model predicts 52 blendshape scores, which are coefficients representing facial different expressions.

The face detection model is the

BlazeFace short-range

https://developers.google.com/mediapipe/solutions/vision/face\_detector#blazeface\_short-range

model, a lightweight and accurate face detector optimized for mobile GPU inference. For more information, see the

Face Detector

https://ai.google.dev/edge/mediapipe/solutions/vision/face\_detector/index

The image below shows a complete mapping of facial landmarks from the model bundle output.

For a more detailed view of the face landmarks, see the

full-size image

https://storage.googleapis.com/mediapipe-assets/documentation/mediapipe\_face\_landmark\_fullsize.png

This MediaPipe Solutions Preview is an early release.

https://ai.google.dev/edge/mediapipe/solutions/about#notice

Model bundle

Input shape

Model Cards

FaceLandmarker

https://storage.googleapis.com/mediapipe-models/face\_landmarker/face\_landmarker/float16/latest/face\_landmarker.task

FaceDetector: 192 x 192 FaceMesh-V2: 256 x 256 Blendshape: 1 x 146 x 2

FaceDetector

https://storage.googleapis.com/mediapipe-assets/MediaPipe%20BlazeFace%20Model%20Card%20(Short%20Range).pdf

FaceMesh-V2

https://storage.googleapis.com/mediapipe-assets/Model%20Card%20MediaPipe%20Face%20Mesh%20V2.pdf

https://storage.googleapis.com/mediapipe-assets/Model%20Card%20Blendshape%20V2.pdf

https://storage.googleapis.com/mediapipe-models/face\_landmarker/face\_landmarker/float16/latest/face\_landmarker.task

Was this helpful?

Send feedback

Except as otherwise noted, the content of this page is licensed under the

Creative Commons Attribution 4.0 License

https://creativecommons.org/licenses/by/4.0/

, and code samples are licensed under the

Apache 2.0 License

https://www.apache.org/licenses/LICENSE-2.0

. For details, see the

Google Developers Site Policies

https://developers.google.com/site-policies

. Java is a registered trademark of Oracle and/or its affiliates.

Last updated 2026-01-29 UTC.

https://policies.google.com/terms

https://policies.google.com/privacy

Manage cookies

https://ai.google.dev/edge/mediapipe/solutions/vision/face\_landmarker

https://ai.google.dev/edge/mediapipe/solutions/vision/face\_landmarker

https://ai.google.dev/edge/mediapipe/solutions/vision/face\_landmarker?hl=de

Español – América Latina

https://ai.google.dev/edge/mediapipe/solutions/vision/face\_landmarker?hl=es-419

https://ai.google.dev/edge/mediapipe/solutions/vision/face\_landmarker?hl=fr

https://ai.google.dev/edge/mediapipe/solutions/vision/face\_landmarker?hl=id

https://ai.google.dev/edge/mediapipe/solutions/vision/face\_landmarker?hl=it

https://ai.google.dev/edge/mediapipe/solutions/vision/face\_landmarker?hl=pl

Português – Brasil

https://ai.google.dev/edge/mediapipe/solutions/vision/face\_landmarker?hl=pt-br

https://ai.google.dev/edge/mediapipe/solutions/vision/face\_landmarker?hl=sq

Tiếng Việt

https://ai.google.dev/edge/mediapipe/solutions/vision/face\_landmarker?hl=vi

https://ai.google.dev/edge/mediapipe/solutions/vision/face\_landmarker?hl=tr

https://ai.google.dev/edge/mediapipe/solutions/vision/face\_landmarker?hl=ru

https://ai.google.dev/edge/mediapipe/solutions/vision/face\_landmarker?hl=he

https://ai.google.dev/edge/mediapipe/solutions/vision/face\_landmarker?hl=ar

https://ai.google.dev/edge/mediapipe/solutions/vision/face\_landmarker?hl=fa

https://ai.google.dev/edge/mediapipe/solutions/vision/face\_landmarker?hl=hi

https://ai.google.dev/edge/mediapipe/solutions/vision/face\_landmarker?hl=bn

https://ai.google.dev/edge/mediapipe/solutions/vision/face\_landmarker?hl=th

https://ai.google.dev/edge/mediapipe/solutions/vision/face\_landmarker?hl=zh-cn

https://ai.google.dev/edge/mediapipe/solutions/vision/face\_landmarker?hl=zh-tw

https://ai.google.dev/edge/mediapipe/solutions/vision/face\_landmarker?hl=ja

https://ai.google.dev/edge/mediapipe/solutions/vision/face\_landmarker?hl=ko

