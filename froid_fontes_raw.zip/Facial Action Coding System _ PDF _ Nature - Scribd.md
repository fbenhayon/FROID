---
sourceFile: "Facial Action Coding System | PDF | Nature - Scribd"
exportedBy: "Kortex"
exportDate: "2026-06-29T01:00:28.054Z"
---

# Facial Action Coding System | PDF | Nature - Scribd

aa675e8b-dbda-4857-b18d-50d316b00e38

Facial Action Coding System | PDF | Nature - Scribd

19b4768b-5cd5-48df-948d-bdcdb1a57f19

https://www.scribd.com/document/325603628/Facial-Action-Coding-System-1

Facial Action Coding System | PDF | Nature

Skip to main content

Open navigation menu

https://www.scribd.com/document/325603628/Facial-Action-Coding-System-1#sidebar

Close suggestions Search Search

en Change Language, English

https://www.scribd.com/upload-document

100%(3) 100% found this document useful (3 votes)

8K views 120 pages

Facial Action Coding System

Introduction to facial measurement

Uploaded by

https://www.scribd.com/user/332103624/Jasmina

AI-enhanced title

© © All Rights Reserved

We take content rights seriously. If you suspect this is your content,

claim it here

https://support.scribd.com/hc/en-us/articles/210129146-REPORT-COPYRIGHT-INFRINGEMENTS-AND-ABUSE-HERE

Available Formats

Download as DOCX, PDF, TXT or read online on Scribd

Save Save Facial Action Coding System\[1\] For Later

100% 100% found this document useful, undefined

0%, undefined

100%(3) 100% found this document useful (3 votes)

8K views 120 pages

Facial Action Coding System

Introduction to facial measurement

Uploaded by

https://www.scribd.com/user/332103624/Jasmina

AI-enhanced title

© © All Rights Reserved

We take content rights seriously. If you suspect this is your content,

claim it here

https://support.scribd.com/hc/en-us/articles/210129146-REPORT-COPYRIGHT-INFRINGEMENTS-AND-ABUSE-HERE

Available Formats

Download as DOCX, PDF, TXT or read online on Scribd

Go to previous items Go to next items

Save Save Facial Action Coding System\[1\] For Later

100% 100% found this document useful, undefined

0%, undefined

Save Facial Action Coding System\[1\] For Later

Published by A Human Face

666 Malibu Drive, Salt Lake City UT 84107

Made in the United States of America, 2002

ISBN 0-931835-01-1

Facial Action Coding System

HTML Demonstration Version

Paul Ekman, Ph.D.

Wallace V. Friesen, Ph.D.

Joseph C. Hager, Ph.D.

Copyright 2002 Paul Ekman, Wallace V. Friesen, & Joseph C. Hager

All Rights Reserved.

This manual and its entire contents, including all graphics, images, software, and digital video, are furnished for the use of the reader

under license and are protected by United States and International Copyright laws. No rights under the copyright law are transferred to

the purchaser, and this product may be used or copied only under the terms of license. No part of the publication may be reproduced,

stored in a retrieval system, or transmitted, in any form or by any means, electronic, mechanical, recording, or otherwise, without the

prior expressed written permission of the authors. These restrictions mean that the purchaser, reader, user, or anyone else cannot copy

the files from the CD ROM to any computer storage mechanism, cannot permit access to the CD ROM via networked computers, cannot

post, mail, or copy any portion of the contents of this manual on any type of computer for transmission to others, cannot make derivative

images from the images provided, and cannot make duplicates of this CD ROM. No duplicate or facsimile of any printed portion of the text

or images in the contents of this CD ROM can be made.

The purchaser has permission to print one paper copy (hardcopy) of the Manual and the Investigator's Guide (licenses for additional

copies can be purchased), to print as many copies of the FACS score sheets as needed, and to copy and to run the software program on

any computer.

For complete statement of license, warrantee, and disclaimers, see the LICENSE text file.

Preface to the CD ROM Version vii

Introduction to Facial Measurement 1

Purpose and Overview 1

Terminology 2

Learning Procedure 5

How to Interpret the Illustrations of Muscles 6

How to Read the AU Sections 6

Introduction to the Reference Sections 11

Upper Face Action Units 15

Action Unit 4 - Brow Lowerer 17

Action Unit 1 - Inner Brow Raiser 20

Action Unit 2 - Outer Brow Raiser 22

Action Unit 5 - Upper Lid Raiser 24

Action Unit 7 - Lid Tightener 28

Action Unit 6 - Cheek Raiser and Lid Compressor 31

Introduction to AUs 43, 45, 46 35

Action Unit 43 - Eye Closure - Optional 36

Action Unit 45 - Blink - Optional 39

Action Unit 46 - Wink - Optional 40

Subtle Differences Among Single Action Units in the Upper Face 41

Action Unit Combinations in the Upper Face 43

Action Unit Combination 4+5 44

Action Unit Combination 5+7 48

Action Unit Combination 1+4 51

Action Unit Combination 1+2 54

Action Unit Combination 1+2+4 56

Action Unit Combination 1+2+5 59

Action Unit Combinations 6+43E, 7+43E 62

Other Action Unit Combinations in the Upper Face 65

Subtle Differences Involving Action Units in the Upper Face 67

Alternative Rules Involving Upper Face Actions 71

Scoring Upper Face Action Units 73

Notation 73

Score Sheet 73

Scoring Procedure 74

Summary of Scoring Steps 80

Interrelationship Among Scoring Steps 81

A Warning 81

Examples of Scoring 81

Final Advice Before Scoring 87

Practice Scoring 87

Lower Face Action Units - Up/Down Actions 91

Action Unit 9 - Nose Wrinkler 93

Action Unit 10 - Upper Lip Raiser 95

Action Unit 17 - Chin Raiser 98

Action Unit 15 - Lip Corner Depressor 100

Action Units 25, 26, 27 - Lips Part, Jaw Drop, Mouth Stretch 103

Action Units 16 and 16+25 - Lower Lip Depressor 113

Subtle Differences Among Single Up/Down Action Units in the Lower Face 118

Action Unit Combinations Involving Up/Down Actions 120

Action Unit Combination - 9+16+25 121

Action Unit Combination - 10+16+25 126

Action Unit Combination - 9+17 130

Action Unit Combinations - 10+15, 10+17, 15+17, 10+15+17 133

Other Action Unit Combinations Involving Up/Down Actions 138

Practice Scoring 139

Subtle Differences Involving Up/Down Actions in the Lower Face 141

Alternative Rules Involving Up/Down Actions 144

Lower Face Action Units - Horizontal Actions 145

Action Unit 20 - Lip Stretcher 146

Action Unit 14 - Dimpler 148

Subtle Differences Among Single Horizontal Action Units in the Lower Face 151

Action Unit Combinations Involving Horizontal and Up/Down Actions 153

Action Unit Combinations - 20+26, 20+27 154

Action Unit Combination - 10+14 159

Action Unit Combination - 14+17 162

Action Unit Combination - 10+20+25 165

Practice Scoring 169

Subtle Differences Involving Horizontal Actions in the Lower Face 171

Lower face Action Units - Oblique Actions 175

Action Unit 11 - Nasolabial Furrow Deepener 176

Action Unit 12 - Lip Corner Puller 178

Action Unit 13 - Sharp Lip Puller 182

Subtle Differences Among Single Oblique Action Units in the Lower Face 185

Action Unit Combinations Involving Oblique Actions 187

Action Unit Combinations - 6+12, 7+12, 6+7+12 188

Action Unit Combinations - 10+12+25, 12+16+25, 10+12+16+25 194

Action Unit Combinations - 12+26, 12+27 200

Action Unit Combination - 12+17 205

Action Unit Combinations - 12+15, 12+15+17, 6+12+15, 6+12+15+17 208

Practice Scoring 222

Subtle Differences Involving Oblique Actions in the Lower Face 225

Lower Face Action Units - Orbital Actions 231

Action Unit 18 - Lip Pucker 233

Action Unit 22 and 22+25 - Lip Funneler 235

Action Unit 23 - Lip Tightener 237

Action Unit 24 - Lip Presser 241

Action Unit 28 and 26+28 - Lips Suck 243

Subtle Differences Among Single Orbital Action Units in the Lower Face 245

Action Unit Combinations Involving Orbital Actions 246

Action Unit Combination - 10+23+25 247

Action Unit Combinations - 12+23, 12+24 251

Action Unit Combination - 14+23 256

Action Unit Combinations - 17+23, 17+24 259

Action Unit Combinations - 6+12+17+23 or 12+17+23 263

Action Unit Combination - 10+17+23 268

Action Unit Combination - 18+23 272

Action Unit Combination - 15+23 274

Action Unit Combination - 23+25+26 277

Action Unit Combination - 22+23+25 281

Action Unit Combination - 20+23+25 284

Practice Scoring 288

Subtle Differences Involving Orbital Actions in the Lower Face 290

Miscellaneous Actions and Supplementary Codes 295

Action Units 8+25 - Lips Toward Each Other 296

Action Descriptor 19 - Tongue Show 298

Action Unit 21 - Neck Tightener 300

Action Descriptor 29 - Jaw Thrust 302

Action Descriptor 30 - Jaw Sideways 304

Action Unit 31 - Jaw Clencher 306

Action Descriptor 32 - Bite 308

Action Descriptor 33 - Blow 310

Action Descriptor 34 - Puff 311

Action Descriptor 35 - Suck 312

Action Descriptor 36 - Bulge 314

Action Descriptor 37 - Lip Wipe 316

Action Unit 38 - Nostril Dilator 317

Action Unit 39 - Nostril Compressor 319

Eye Movement Codes M68, 69, and M69 321

Visibility Codes 70, 71, 72, and 73 322

Head Movement Code M83 323

Gross Behavior Codes 40, 50, 80, 81, 82, 84, 85, 91, 92 324

Practice Scoring 325

Subtle Differences Involving the Miscellaneous Actions 326

Head and Eye Positions 329

51 - Head Turn Left

52 - Head Turn Right 331

53 - Head Up 333

54 - Head Down 334

55 - Head Tilt Left

56 - Head Tilt Right 336

Head movement codes M55 and M56 338

57 - Head Forward

58 - Head Back 339

Head Movement Codes M57, M59, and M60 340

61 - Eyes Turn Left

62 - Eyes Turn Right 341

Eye Movement Codes M61 and M62 343

63 - Eyes Up

64 - Eyes Down 344

65 - Walleye 347

66 - Cross-eye 347

#### Chapter 10:

Scoring Procedure 349

Notation 349

Score Sheet 350

Instructions for Scoring Lower Face and Upper Face 351

#### Chapter 11:

Advanced Scoring Techniques 357

Scoring AUs During Speech 357

Identifying Facial Events 359

Scoring Action Units as Unilateral or Asymmetrical 370

#### Appendix I:

#### Appendix II:

Index to Video Examples 377

Scores for Reference Example Images and Videos 381

#### Appendix III:

Master Subtle Differences Table 435

#### Appendix IV:

Master Table of Alternative AUs 455

Example Images

Subject Index 457

Reference Example Images 465

Practice Images

Score Sheet

Practice Images 499

Facial Action Coding System: Score Sheet 513

Chapter 1: Introduction to Facial Measurement

Purpose and Overview

The Facial Action Coding System (FACS) Manual teaches you how to recognize and score the Action Units (AUs), which represent the

muscular activity that produces momentary changes in facial appearance. The changes in facial appearance for each AU are explained in

words and illustrated in images (usually made from original still photographs) and digital video (usually made from original film or

videotape). The images and videos of the Action Units and Action Unit combinations are listed in Appendix II, approximately in the order

in which they are first mentioned in the Manual. The reference example images appear in the first part in Appendix II, followed by the

video examples. This table contains the final scoring for the reference example images and videos. An index of the videos ordered by AU

comprises Appendix I, the Index to Video Examples, which is cross-referenced to the filename of the video on CD ROM and the scoring

commentary in Appendix II. These files can be used to play the video separately from using the Manual.

The illustrations are not meant to be taken literally - they exemplify but do not typify. The exact appearance change varies from

one person to another depending upon their bone structure, variations in the facial musculature, fatty deposits, permanent wrinkles,

shape of features, etc. Common elements appear across people in the changes that occur in an Action Unit. These elements are

detailed and emphasized in the manual, and you will learn with experience to recognize them. One important way to focus upon

these common elements is to make each action on your own face and observe in a mirror how it differs and how it is similar to what

is shown in the images and video. Also, examine the similarities and differences shown by other people who are learning this facial

measurement procedure with you. Finally, score the practice images and videos to help you learn the common elements.

The AUs are presented and are to be learned in groups. The groups are based upon the location and/or type of action involved.

First, you learn the AUs in the Upper Face, which affect the eyebrows, forehead, and eyelids. Then, the Lower Face AUs are

presented in five groups: Up/Down, Horizontal, Oblique, Orbital, and Miscellaneous Actions. After learning each group, you practice

scoring facial behavior and verify your scores before proceeding to the next group of AUs.

Within each group of AUs, each AU is explained in three sections that have the following names:

A. Appearance Changes

B. How to do the Action Unit

C. Intensity Scoring for the Action Unit.

Later, in referring to a particular part of the Manual, these abbreviations, A, B, and C will be used. Thus, if you read the

instruction, "see 4secC" you should look under Action Unit number 4 in Section C ("Intensity Scoring for AU 4"). A more detailed

presentation of these three sections can be found later in this chapter.

This Manual is written so that it can serve two purposes: as a basis for initial learning and as a reference when scoring facial

behavior. To be useful as a reference, the Manual contains information that is not relevant or even understandable until you have

learned the entire system. Usually, such materials are listed separately under the Reference heading. When you encounter such a

section, disregard it until after you have learned the Action Units that are mentioned in the chapter. Sometimes, other parts of the

Manual besides the Reference section will mention Action Units that you have not yet learned. For example, the chapter on the

Upper Face contains some mention of Lower Face Action Units. You do not need to look those AUs up or understand them in your

initial learning. You will return to the chapters many times when scoring, and then you will understand how these sections are

After the Manual introduces you to all of the individual AUs within a group, it explains the subtle differences among these AUs.

Then, the Manual describes some of the combinations of two or more AUs, including the subtle differences among these

combinations, and the specific difficulties in scoring two or more co-occurring AUs, such as how to score the AUs when one AU

interferes with detecting another.

Initially, on first reading, you may find that certain issues are not clear. Instead of trying to clarify such issues immediately, you

should continue reading up to the AU Combinations section of a chapter before returning and working harder to understand the

material in the A, B, and C sections for individual AUs. Avoid skimming, but if you cannot figure something out, at least continue

through the single AUs and the first Subtle Difference Table. If the difficulty is in recognizing the changes due to a particular AU, you

may be able to understand the distinction better after reading about the AU in combination with the other AUs.

Terminology

In order to describe changes in facial appearance you must learn a few terms which refer to particular areas and features of the face and

the changes in them. Figure 1-1 illustrates some of the features of the face, which are explained in Table 1-1. Tables 1-2, 1-3, and 1-4

define additional terms that describe other aspects of the face. Check the definitions of each of these terms with the illustrations in Figure

1-1. Rather than trying to memorize all these new terms now, simply read them and look carefully at any illustrations of them. These

terms are used to describe Action Units in Chapter 2. When you encounter each term there, you can return to the illustration and tables to

look up the definition. The terms will become understandable in the context of their use. By the time you have finished Chapter 2, you will

have learned the terminology.

Area of the forehead between the eyebrows.

ROOT OF NOSE

The beginning of the nose between the eyes; also called the nasal root.

EYE APERTURE

The degree to which the eye is open; the eye opening.

EYE COVER FOLD

The skin between the eyebrows and the palprebral part of the upper eyelid (the part that contacts the eyeball), which

folds into the eye socket.

LOWER EYELID

A place below the lower eyelid where a line or wrinkle may appear. A line or wrinkle may be permanently etched into

the face; if so, it will deepen with certain AUs. If not, it should appear when these AUs are contracted.

INFRAORBITAL

A place where a line or wrinkle may appear parallel to and below the lower eyelid running from near the inner corner

of the eye and following the cheek bone laterally.

NOSTRIL WINGS

The fleshy skin of the side of the nose that forms the outside of each nostril.

A place where a line or wrinkle may appear which begins adjacent to the nostril wings and runs down and outwards

beyond the lip corners. In some people it is permanently etched in the face; if so, it will deepen with certain AUs. If

not, it will appear on most peoples' faces with certain AUs.

The vertical depression in the center of the upper lip directly under the tip of the nose.

The skin covering the bone of the chin.

The white part of the eyeball.

Table 1-1: Terms that name areas and features of the face

#### Figure 1-1:

Names and locations of facial areas and parts.

The appearance of the lips can change in so many ways that it is necessary to define a few terms specifically for this feature.

Table 1-2 contains these terms and definitions.

The mouth appears to be longer than usual in the horizontal plane.

The mouth appears to be shorter than usual in the horizontal plane.

The red part of the lip is less visible or narrower than usual (opposite of widen).

The red part of the lip is revealed more or wider than usual (opposite of narrow).

The lips appear flattened against the teeth. They protrude less than usual. Does not involve sucking in the lips.

The lips come forward or out away from the face more than usual, (opposite of flatten).

The lips appear tight, the lips are not relaxed or loose. The muscle within the lips has contracted.

The lips are pulled and the skin stretched like a rubber band.

The lips are turned, or rolled, inwards, disappearing entirely or almost entirely, but they are not tightened, pressed, or

Table 1-2: Terms that describe appearance changes in the lip and other features

Some of the terms used to describe the lip in Table 1-2 are also used to describe other parts of the face, but the same basic

meaning applies. Examples are:

Narrow is used to describe a decrease in the eye aperture.

Widen is used to describe an increase in the eye aperture.

Widen is used in reference to enlarging the opening of the nostril and may also be used to refer to the extent of mouth opening in AUs 25,

Flatten is used to refer to the effect of AU 20 on the cheek area that reduces its curvature.

Tighten is used to describe the appearance of the lower and upper eyelids.

In discussing changes in the appearance of the skin, the words bulge, bag and pouch are used. These terms have somewhat

overlapping meaning, but can be distinguished as described in Table 1-3.

BULGE A protrusion of the skin, where the skin is pushed outward by muscle, or by skin being stretched over the eyeball or bone.

Loose skin which wrinkles as it is gathered together or pushed; a bag remains loose, not taut; it may be permanent, but will thicken

or become larger or more prominent with certain actions.

A pocket-like shape, often protrudes like a bulge; also, may be permanent in some faces, but certain actions will make it more

Table 1-3: Terms that describe transient excrescences of the skin

The distinctions between bulge, bag and pouch are subtle; often the three occur together, or what happens involves something in

between them. When they are discussed in the context of a particular action, appearance change, and visual example, you will

understand the terms better.

The terms furrow, wrinkle, and line are used to describe another aspect of the appearance of the skin as described in the

following table:

A surface line with no depth, usually quite fine in terms of width. Some faces may show permanent surface lines; these may

deepen to a wrinkle when certain actions occur.

A line which has some depth and often has more width than a surface line; some faces may show no permanent wrinkles, but they

will appear with certain actions. Other faces may show permanent wrinkles but they will deepen with certain actions.

This term describes a place on the face where certain wrinkles may appear: lower eyelid furrow; infraorbital furrow; or nasolabial

furrow (see Figure 1-1). In some faces there is no wrinkle or line in such a facial location until there is action. Some faces show a

line permanently, but it will deepen to a wrinkle with certain actions, e.g., some faces show a permanent line in the lower eyelid

furrow, infraorbital furrow or nasolabial furrow, which will deepen with an action.

Table 1-4: Terms that describe marks in the skin

These distinctions might not be clear now, but when you read Chapter 2, where these terms are used in context with visual

examples, their meaning will clarify. You may find it useful to refer back to these definitions.

In discussing Intensity Scoring for an Action Unit, we explain how to score variations in the strength of the actions, which result

in variations in the intensity of the appearance change. You will learn to score intensity, with the terms A, B, C, D, and E referring

to how strong the action is, from barely detectable to the highest levels. In assessing the intensity of an AU, we use the following

terminology to distinguish different levels of Action Unit involvement. An Action Unit can be totally uninvolved, or it can be involved

to the following degrees:

.Trace..Slight...Marked...Pronounced...Severe...Extreme..Maximum.

The meaning of this scale of evidence will become apparent as you study the FACS illustrations in each chapter. You will learn

what is meant by trace, slight, etc., in practice scoring where you will apply this scale. We provide intensity scoring criteria for each

AU and explanations with behavioral examples that establish what we mean.

The chapters that describe AUs discuss the differences among them, their inter-relationships, and how the co-occurrence or

simultaneous presence of AUs can affect the detection and scoring of an AU. For example, one AU can affect the appearance or

mask the presence of another AU. In such situations, the AU that obscures another AU is referred to as the dominant AU, and the

obscured AU as the non-dominant or subordinate AU1. These issues are usually found in descriptions of appearance changes due

to an AU and in tables of subtle differences between AUs and AU combinations. Another issue is alternative scores, when it is up

to you to choose which AU best describes the appearance change. These relationships are explained further near the end of this

chapter and are applied to specific AUs in tables at the end of chapters.

Other terms describe separate aspects of scoring. The apex of an action is the point of greatest excursion or change within that

action. For example, if an Action Unit raises the inner corner of the eye brow, the apex is the moment when the greatest raise first

occurs. The apex is not an absolute amount of change, but the greatest change that occurs for a particular Action Unit in a

particular instance or event. It is when the action is strongest for that event. In some research, the first frame when apex is

reached is noted; in other scoring, the duration of the apex, before the action begins to decline, is measured. Scoring ofunilateral

actions, where the action occurs on only one side of the face, uses the abbreviation "L" for left and "R" for right placed in front of

the AU number. To indicate a unilateral score, but without indicating the side on which the action occurs, a "U" prefix is used (e.g., a

wink is U46). The asymmetry of an action, where the action occurs on both sides, but is stronger on one side of the face than the

other, is noted simply by the "A" prefix, but also has a more detailed scoring notation. Unilateral and asymmetry scoring is

explained fully in Chapter 11.

In the first edition of this manual, there were many scoring rules based on the consideration of dominance that were designed to improve scoring reliability.

Further experience with FACS showed that these co-occurrence rules were unnecessary and hard to follow, and most were formally eliminated in 1992

and are not found in this edition.

Learning Procedure

Chapter 2 introduces you to the AUs of the Upper Face, and as you read the remainder of this chapter, you should look ahead to Chapter 2

to begin applying the logic of FACS. Chapter 2 will take you longer to learn than the chapters that follow it. Beyond learning the

descriptions of these AUs, more AUs are described than in later chapters, and you are learning about AUs and the logic of FACS for the

first time. Also, until you have read Chapter 3, and learned how to score, and actually have practiced scoring, you will not know exactly

how you use the material in Chapter 2. Be patient, some issues will become clearer after you have learned scoring procedures.

It is important that you study the Manual but not that you memorize anything by rote. Your study should be to understand. You

will use the Manual as a reference to remind you of the necessary information for scoring. In your initial use of FACS, you will

repeatedly look things up in the Manual. Over time you will absorb the material, and will check the Manual less frequently.

The remaining sections in this chapter discuss how the description of each AU in subsequent chapters is organized, with

particular reference to Chapter 2. The text explains how the A, B, and C sections are used to understand and score an AU.

How to Interpret the Illustrations of Muscles

Most chapters in the manual that contain descriptions of AUs begin with illustrations of the muscles underlying the actions covered. Take a

look now at the muscle illustrations in Figure 2-1 on page 15, which show the muscles in the upper face. The face labeled "Muscular

Anatomy" shows where the muscle fibers are anatomically located. The face labeled "Muscular Action" schematically indicates the location

and direction of action for each muscle. The numbers that appear in the figure refer to the numbers for each Action Unit described in the

chapter. The location of the circled number in the Muscular Action illustration approximates where the muscle emerges from the bony

structure (also known as its origin). The other end of the line indicates approximately where the muscle attaches to the soft tissue of the

face (also known as its insertion or attachment). When a muscle is contracted, the pull is always toward the circle where the

muscleemerges, drawing the soft tissue towards that point, usually bunching or wrinkling the skin perpendicularly to the line of muscle

pull. For example, the muscle that underlies Action Unit 1 emerges from the bony structure high in the forehead region and attaches at

its other end to the soft tissue below the medial portion of the eyebrow. Look at Figure 2-1 to be sure you understand how the origin and

attachment are diagrammed in the Muscular Action illustration. When AU 1 contracts, the skin in the medial area of the eyebrow is pulled

upwards towards the top of the forehead, raising the inner corner of the eyebrow. Horizontal wrinkles form in the medial portion of the

forehead. These are the kinds of signs that you use to determine what muscle has acted.

The two muscular illustrations that begin each chapter show each muscle on only one side of the face. In reality, the

muscles normally exist symmetrically on both sides of the face. Throughout most of the chapters on AUs, you learn the

appearance changes that occur when there is bilateral action of each Action Unit or AU combination. In Chapter 11, you learn

when and how to score an action that occurs unilaterally or occurs more strongly on one side of the face than the other.

When each AU is described, refer to the two muscular illustrations at the beginning of the chapter. They will help you to

understand how the action occurs, why facial appearance changes in the way it does, and how to make that movement occur

on your own face.

How to Read the AU Sections

Each AU is identified by a number and name (for example, the first AU explained is "AU 4 - Brow Lowerer"). Names like "Brow Lowerer"

are provided as a more meaningful handle than the more arbitrary numbers, and might make it easier for you to relate to the AUs as you

begin learning this Facial Action Coding System. You need not try to memorize the names because as you learn, you will find that

youstop relying on the names and increasingly refer to the AUs by numbers. Experienced FACS coders name facial behaviors with a string

of numbers for each AU present, e.g., one-two-five-twenty. It is important that you learn the number that designates each AU, but not the

name. Unfortunately, we have not been able to make this task easier by any logical relationships among the numbers. The assignment of

an AU to a number is arbitrary and has no mnemonic, for example, consecutive AU numbers do not correspond to AUs with similar

appearance changes. Likewise, the first AU in the chapter on Upper Face AUs is Action Unit 4, rather than AU 1.

The description of each AU begins with a short paragraph highlighting the muscle that underlies the AU, its location and general

action. This description refers to the illustrations at the beginning of each chapter showing muscular anatomy and muscular action.

Begin by taking a look at AU 4 on page 17, reading the opening description, and looking at the illustrations in Figure 2-1 relevant to

AU 4. Knowing where in the face the muscle acts and its general mode and direction of action is the first step in understanding how

to score the action. Look at how the muscle is shaped and from where and to where it runs. Notice that AU 4 runs from the lateral

parts of the nasal root obliquely to insert above the center of the eyebrow in the forehead and that two other strands of AU 4 run

from near the nasal root upwards into the forehead. From the "Muscular Action" diagram of Figure 2-1, you know that this muscle

will pull the skin at the center of the eyebrow towards the root of the nose and pull the skin in the center of the forehead down. Now

you are able to understand how this muscle produces the appearance changes described in Section A. Study the opening description

and the corresponding illustrations at the beginning of each chapter carefully every time you read about a new AU. Think about how

AU 4 is located in respect to the other muscles in the illustrations.

Section A - Appearance Changes

Section A lists the most important appearance changes produced by the muscle that allow this action to be distinguished from other AUs.

This section includes both a description of the movements that occur with the action of the muscle and the static appearance of the face

when that action is held for a period of time (or frozen in a still photograph). For example, read each of these appearance changes for AU

4 on page 18 and try to visualize each appearance change that is described. Be sure you know the meaning of any specialized terms

describing the face and the muscular action. You may need to refer to the definitions of terms in the tables in this chapter beginning

At the end of Section A is a short summary of the relevant images and videos suggested for study. The caption or title of a

reference example image or video merely indicates what AUs the example represents, not its complete FACS score. Appendix II

contains the complete FACS score for each example. Thumbnails of the images in Section A provide a visual overview and index of

the images relevant to the current AU, but for studying the appearances, you should examine larger images. If you are reading

online, click on the blue link of the thumbnail caption's text to see the Manual page with the image, or click on the thumbnail itself

to see the image in your external viewer. Click on the "page xx for score" blue text link to see the full FACS score for the item. When

you browse the Reference Example section, you can also show the neutral for the person in the image by clicking on the image's

caption, though this link is not highlighted by color. If you are reading a paper copy, page to the page number indicated to see the

example image. If you are reading an online version and want to see the video, click on the thumbnail caption's blue text link to

view the video with your internal viewer or the thumbnail itself to view it in an external viewer. If you are reading a printed version,

look up the video filename in Appendix I and view the file on the CD ROM using your computer and the appropriate video viewer.

Look for each appearance change listed in Section A in each of the AU depictions. Not all appearance changes may be apparent in

any given example, but you should decide whether you can see each or not. As you read through the appearance changes for an

#### AU, study the accompanying image(s) and video(s) carefully. Identify:

the parts of the face that have moved and the direction of their movement;

the wrinkles that have appeared or have deepened;

the alterations in the shape of the facial parts.

If you find that the appearance changes resulting from the action are difficult to detect, compare the image showing the AU with

a image where no action has occurred (i.e., the face is neutral). The video can be more helpful than the image when studying subtle

actions due to the motion that can be seen. Read the scoring commentaries in Appendix II to clarify what appearance changes are

relevant to scoring each example image or video.

Section B - How to do the AU

One of the most important activities in the practice of scoring faces is making AUs on your own face while looking in a mirror to compare

with what you see on another's face. Thus, it is very important to try to make the action on your own face accurately. Section B describes

how to make the AU, suggests techniques for recruiting the muscle, and offers tips on the most likely mistakes to avoid. Your goal is to try

to produce the one muscular action described without any other AU. Do not settle for less than perfection. Keep working on making the

action until you can perform it well. It may take daily practice for months before you can do some of the difficult AUs. No one we have

observed is able to make every AU with little or no practice, but everyone does better with more practice. Even if you cannot perform an

AU perfectly, you must know what it is about your performance that is deficient.

Imitate the image and video and compare your face with those in the illustrations. Be certain that you have made the correct AU

and no additional AUs. If you fail to mimic the appearance in a image or video, place your hand along the Action Unit's muscle

pathway. Try to feel the muscle contract under your fingers. Flatten your hand against your face so you can distinguish other AUs in

the surrounding area. Persist until you can move only the AU you are studying. When you are satisfied that you can make the AU,

do it repeatedly and study the effects it has on the surface of your face. If you have difficulty, try making the AU on only one side of

your face. If possible, add the action on the other side. If you cannot do that, study the effect of the unilateral action.

Show your performance of each AU to other people who are learning FACS with you. Let them study the effects on your face. Let

them correct your attempts if they believe you are making other AUs.

Look at the faces of other people in your training group to see how their face appears. Carefully note variations you observe on

others' faces. Make suggestions about what is accurate or inaccurate about each other's attempts to do the action. The more faces

you see doing the action, the more you will understand the range of appearances that the AU produces, and also how other actions

contribute to the appearance of the target action. If you are doubtful that others are making the correct AU or are making additional

AUs, touch their faces. Feel whether there is tension along the pathway of the muscles that underlie the AU you are studying, and

not tension elsewhere.

You may find some AUs are difficult, if not impossible, to perform singly. Learn the appearance changes and the movement of

such an Action Unit from the images and video and from what you can see on the faces of the other members of your group. Don't

become discouraged. Continue trying to make each AU as you proceed through the Manual. As you learn to perform other

neighboring AUs, return to those that gave you difficulty. Because you become more aware of the way your face feels when making

each of the AUs, you may find it possible to do AUs you earlier found to be difficult.

AU 4 is a good action to start performing as it is easy to do. Look now at the B section for AU 4 on page 18. The instruction for

this easy movement is short, and no special motivation for its performance appears, but several common problems that can occur

are noted, and last resort measures for producing this action are suggested.

Section C - Intensity Scoring

FACS uses conventions or rules to set thresholds for scoring the intensities of an Action Unit. Section C for each Action Unit or combination

describes the changes in appearance that distinguish one AU from another and provide criteria for scoring intensities of an AU. Whether

you score intensity or not, and for which AUs intensity is scored, will depend upon the purposes of the investigation (see

the Investigator's Guide to FACS).

When evidence of any specific AU is absent, the face is in a neutral (or baseline) scoring condition. When evidence of an AU is

present, intensity of an Action Unit can be scored on a five-point ordinal scale. The letters A, B, C, D, and E refer to the intensity of

an action. These letters are written immediately after the number of the AU to indicate how much of the total appearance change

that can potentially be caused by the AU is actually present, e.g., 4B or 4E. There is a correspondence between the five point FACS

intensity notation and the scale of evidence of an AU's presence that defines the thresholds or criteria for scoring intensity levels

listed in Section C.

The general relationship between the scale of evidence and the A-B-C-D-E intensity scoring is diagrammed in Figure 1-2.

Figure 1-2: Relation between the Scale of Evidence and Intensity Scores

Generally, the A level refers to a trace of the action; B, slight evidence; C, marked or pronounced; D, severe or extreme; and

E, maximum evidence. For some AUs, this relationship is a bit different, so for each AU, the criteria for each intensity level in terms

of the scale of evidence is listed in Section C.

There are two important points about the A-B-C-D-E scoring scale to keep in mind. It is not an equal interval scale; the C and D

levels cover a larger range of appearance changes than the other levels, and most of the range of AU movement falls in these

levels. The A, B, and E levels are defined as very narrow ranges. Second, each letter refers to a range of behaviors; even

thetrace of A and the maximum of E refer to a limited range of appearance changes rather than a single point, as might be implied

otherwise by the term "maximum." In the paragraphs below, the criteria for scoring intensity are considered in more detail.

If there is little action, it may be very difficult to distinguish an AU from no activity. Sometimes it may not be possible to

determine whether any action at all has occurred, or you may think something moved or happened, but it is not possible to

determine exactly which AU. This is especially so when you are scoring a still photograph where you cannot see the movement itself,

only the consequence of the action. In such situations, a change in lighting, head position, or transient shadows can give the

impression of a different expression even when no action occurs. Even with a motion record, however, it may not be possible to

distinguish an action from a baseline, or one AU from another if the action is below a certain threshold. On these occasions, you will

not score a change in facial behavior, i.e., when you see something so barely noticeable that it is too small to allow you to choose an

AU to describe what you see. Such unscorable changes could be merely artifacts in the visual record or a result of a mechanical

force other than muscular action (e.g., a gust of wind); or they could be changes that are so subtle, that even though it is certain

something happened, it is not possible to determine which AU or combination of AUs produced it.

On the other hand, the activity in the face may be barely noticeable, but trace evidence of an Action Unit is sufficient for you to

decide that a particular AU is present. This AU has an intensity of A, a trace of evidence, but enough to convince you of its presence.

After several hundred hours of facial scoring with FACS, you will become expert at discriminating these traces of evidence about an

AU as you practice careful examination of minute changes in the face. You will learn to infer that a particular AU has occurred as you

become increasingly adept at discriminating appearance changes in the face and as you discuss with other FACS scorers what it

takes to be sure about trace evidence. Accurately detecting trace evidence of an AU is an ability that will elevate your skills to the

expert class. This learning process is another important reason why training with others and discussing your scoring of faces that

show subtle changes are important activities.

A crucial anchor for scoring the range of intensities of each AU is the set of criteria for scoring a B level of intensity. All the AUs

have explicit criteria in Section C for scoring the B intensity. The set of criteria for scoring the B intensity of an AU may be only one

appearance change, or it may include more than one, or it may allow a choice among appearance changes. More than one

appearance change in the set of criteria is indicated by an "and" between appearance changes. Choice among appearance changes

is indicated by "or" between appearance changes. If the evidence for an AU is present, but does not meet the B level criteria, then

the intensity must be A. If the criteria are met, then the intensity must be B or greater. You must obtain enough facial scoring skill

to be able accurately to detect and identify AUs that have a B intensity in order to function as an effective facial scorer. This level of

skill is the minimum objective of the training provided by this manual, and is required to pass the FACS Final Test. Thorough study

of this manual and sufficient practice will enable you to reliably score B level AUs; subsequent experience will enable you see all the

A level actions.

The C level of intensity is typically distinguished from the B level by a set of criteria that establishes how much more evidence of

the AU is required beyond the B level to score it as C. As muscular activity increases, more appearance changes become visible, and

appearance changes already present become more evident. Your task in scoring the intensity of an AU is to assess the amount of

appearance change present and represent it as an intensity score. It is not possible for us to enumerate all the combinations of

appearance changes that provide the evidence for each intensity level beyond the B range. Instead, you must rely on the meaning

of the scale of evidence to score these higher intensities. We provide examples of what appearance changes constitute a set of

criteria for each level. For example, the B level of an AU might require the slight evidence of an appearance change, while the C

level requires the marked evidence of the same change. Alternatively, the B level might require slightevidence on either one or

another change, while the C level requires both changes to be present and at least one marked. These are merely examples. Other

combinations of appearance changes listed in Section A might also comprise evidence of the C level, but we have not provided an

explicit guideline. Your experience in scoring the whole range of intensities for each AU will allow you to assess the overall degree of

appearance change and cast it into an intensity score. Again, it is by practice and experience, together with discussions among your

facial scoring colleagues, that will enable you to reliably assess intensities of AUs.

Similar to the distinction between B and C, the threshold for the D level of intensity from the C level is a different, higher point

on the scale of evidence for the appearance changes that identify the AU. Again, the criteria for the C, D, and E levels are example

criteria; you must factor in the range of appearance changes possible to assign an intensity score. The D level is more than the C

level of evidence, but less than the maximum evidence usually required for E.

The E level of intensity is generally scored when the maximum evidence, or nearly maximum evidence, of change is present. The

intense muscular contractions of the E level combine with the person's individual physical characteristics to produce changes in

appearance that vary somewhat across different people. Your experience in scoring different individuals will enable you to grasp

what constitutes the maximum level of appearance change for each person and AU. Again, considerable practice and comparison of

your scores and assessment of faces with other coders is an important aspect of the learning process.

There are some additional important points about scoring intensity. One concern is scoring intensity when you do not actually

observe the motion in the face that is caused by the muscular action. Sometimes, you may not be able to see a movement occur

because there is a break in the motion record, noise, the person moves out of view, etc. Also, you may be using FACS to score still

photographs. In Section C, you sometimes find explicit criteria that must be met if you cannot see the actual movement.

Sometimes, no such instructions are given. In either case, you score the AU if you can infer that the consequence of the movement

has occurred as described by the intensity criteria. In instances where there are separate criteria for when no motion is observed,

you use the changed intensity criteria. Generally, for the B level, the criteria to be met when the motion is not observed are stricter

or harder to meet than those listed for when motion is observed. In a motion record, score the AU at the B level if it meets either

set of criteria, for when motion is observed or when it is not.

Sometimes, the involvement of other AUs with an AU you are scoring for intensity affects the criteria for scoring the B level of

intensity. For example, you may be considering scoring two AUs, one of which produces some of the same appearance changes that

are produced by the other. In such a case, additional evidence for one AU may be required beyond the evidence that might be

produced by the other AU. Guidelines for scoring in these situations are provided in the Reference section that may appear for an

The Manual describes the appearance changes due to combinations of AUs, as well as those of individual AUs. The list of

examples of appearance changes for scoring intensity in a combination of AUs is often limited to combinations of AUs with the same

intensity or to intensity of only a target AU with the other AU intensities unspecified. Of course, combinations of AUs with different

intensities are more common than combinations of all equal intensities, but the number of possible combinations of intensities

increases vastly with each additional AU in a combination. It is not practical to list all these combinations, and this list is not needed.

You should be able to use the guidelines that are provided to extrapolate intensity scoring to combinations of intensities where no

example is provided. You should assess the magnitude of the appearance changes in total, the relative contribution of each AU to

the total appearance, and the magnitude of appearance change due to each separate AU to produce a set of intensities for the AUs

that best represents these assessments.

Most intensity criteria refer to the degree of an appearance change or to the number of appearance changes. The intensity scores

for some AUs involve a criterion in terms of a time duration or some other benchmark.

In summary, it is important to remember that movements of the skin and other features of the face are the basis for determining

both the particular AU that has occurred and the intensity of the AU. These movements have a direction, and they produce

bunching, bagging, pouching, and wrinkling between the origin of the muscle and its attachment, as well as flattening, stretching,

and pulling in other areas. Section A lists the most important appearance changes characteristic of each AU. Section C lists how

some or all of these appearance changes are used to score the intensity of the AU, as well as further information about how these

changes distinguish each AU. FACS coders are like detectives searching for evidence in the changing facial appearance that shows

which AU (or AUs) acted. The coder's task is use the guidelines described in Sections A and C to deduce from the signs observed

what AUs (or AU) moved the skin and other features, and how much of each AU occurred. In making these decisions, the strategy is

twofold: score the AU or AU combination that best explains the appearances detected, and include only the AUs necessary to

explain the appearances. Use the criteria provided in the Manual as guidelines, together with your own experience and

understanding of the range of appearance changes each individual can manifest, to determine the scores that you assign. Practice in

scoring many individuals in different situations is an essential ingredient in obtaining the experience needed to detect the signs and

assign the score.

Look now at Section C for AU 4 on page 18. Study the criteria for each level, and notice how closely the levels for AU 4

correspond to the general description of intensity levels above. Look at the images and video of AU 4 to see how these criteria were

applied to each example. At this point, the material in this section and the next may not be completely clear to you, but after you

learn Chapter 2, read through the sections here again with more concrete examples in mind, and any confusion will evaporate.

Introduction to the Reference Sections

The descriptions of AUs and AU combinations in the A, B, C sections, together with the example images and video, are the primary

learning vehicles in this Manual, but you will also use this material frequently as reference when you score the face. Beyond these didactic

materials, some sections of the Manual become more important after you have learned the AUs and combinations, when you begin to

score faces productively. This material is primarily in the form of tables. Some of the material is specific to a particular AU, and is found

after the AU's A, B, C sections. Other material is relevant to contrasts among multiple AUs or combinations, and is generally found at the

end of chapters or between major parts of chapters. Both types of reference materials are discussed further below, but first, we must look

in more detail at the general effects of multiple simultaneous AUs, or co-occurrence.

Co-occurring actions can produce appearance changes that are relatively independent, changes in which one action masks

another, or a new and distinctive set of appearances. When the combination of Action Units responsible for a set of appearance

changes is additive, the decisions you need to make to score an AU are still relatively straightforward. In such additive cases, the

appearance changes of each separate AU are relatively independent and produce in the combination the sum of all these distinct

changes caused by the separate AUs. Evidence of each AU remains clearly recognizable because they have combined without

distorting or changing the appearances due to each separate AU. In some cases, additive changes are totally independent, with no

AU affecting the appearance of any other, such as when the AUs are in different areas of the face. These combinations are the

easiest to score by extrapolating from the appearances described for each separate AU, and are not represented in separate A, B, C

sections of the Manual. In other cases, the co-occurring AUs are in the same area of the face and combine to produce an

appearance that is a straightforward sum of their separate appearances. Many of these additive combinations have their own AU

Combination A, B, C sections that describe the combination, which you read while learning just as the single AU sections. A good

example of such an additive combination is 1+2, which is described beginning on page 54. Look at the Section A appearance

changes for combination 1+2 and compare them to the appearance changes for AU 1 on page 20 and for AU 2 on page 22. You can

see that the appearance changes for 1+2, although they describe a different appearance from either AU 1 or AU 2 alone, are a sum

of the appearance changes due to the separate AUs, with neither AU distorting or masking the appearances of the other. These

additive changes make scoring the constituent AUs relatively easy.

Scoring the AUs responsible for an appearance change becomes more difficult, however, if the combination of AUs is not additive,

but produces an appearance that is in some way different from the separate appearances caused by the individual AUs. A

combination which is different is one where the appearance changes are not simply the sum of the appearances of the constituent

AUs, but create distinctively new appearance changes. All such combinations that create different, distinctive appearances in the

upper face have been explained and their appearances detailed in separate AU Combination A, B, C sections. For example, look now

at one of these distinctive combinations, 1+2+4 beginning on page 56. Read the appearance changes in Section A and compare

them to the appearance changes for AU combination 1+2 on page 54 and AU 4 on page 17. You can see that the opposed lifting of

the eyebrows due to 1+2 and the lowering due to 4 tend to counteract each other, masking and changing the signs of each. The

pulling together of skin in the forehead by AU 4 also creates a new pattern of lines in the forehead that differs from 4 alone and

from the relatively straight, horizontal wrinkles of 1+2. This is a pattern that is distinctive of 1+2+4.

When the appearance changes associated with a particular AU are altered by the action of other AUs or combinations of AUs, the

signs relevant to the criteria for scoring an AU's intensity level can become easier or harder to detect. The most common example of

this interaction of AUs is that two or more of the AUs in a combination produce some of the same appearance changes used as

intensity criteria for at least one of the AUs. This overlapping of appearance changes might require setting criteria for the B intensity

higher, in the form of an increased appearance change or an additional appearance change, to adjust for their effects in the

combined appearance. Occasionally, the effect on facial appearance of the interacting combination is noticeably different from what

might be expected from summing the effects of each individual AU in the combination. In these instances it is sometimes necessary

to specify different criteria for the scoring the B level of intensity of one or more of the AUs involved.

When different criteria have been specified for an AU in situations like those described above, these criteria are described after

the criteria for the single AU, or there is a cross-reference to a Section C or Reference section where the criteria for the combination

were described. You do not need to read these qualified criteria in your first pass through the material, and you do not need to

understand them in your initial study of the single actions. They are explained later in the sections for AU combinations. These

qualified criteria are listed in this manner for later convenience when you use Section C and the Reference for single AUs as a

reference in scoring. You do need to know what these tables contain and how they work, so take a brief look now at the Reference

section for AU 4 on page 19. The first column indicates the problematic combination of AUs; the second indicates the target AU, or

the AU whose intensity criteria are being modified. This table shows, for example, that when AU 4 co-occurs with AUs 1 or 2 or

both, the criteria for scoring 4B change. The third column of the table shows what the changed criteria are, or where to find the

criteria. For example, when 4 co-occurs with both 1 and 2, lookup the changed criteria in Section C of the description for AU

combination 1+2+4 (or in our abbreviated notation, 1+2+4secC). When 4 co-occurs with 1, use the criteria in the row for

combination 1+4. In cases like these, where the appearance changes produced by the AUs (e.g., 1+2 v. 4) are opposite, you

generally need less evidence of the target AU or to emphasize another criterion. Now look at the line in the table for 4+6. In this

case, because 6 can produce some of the same appearance changes that 4 produces, we require somewhat more evidence of 4 in

order to score 4B.

Subtle Differences sections contain reference material that deals with multiple actions and combinations, and they usually appear

near the end of chapters. The purpose of Subtle Differences tables is to highlight signs that are useful in distinguishing among

similar AUs and combinations. They may contrast the appearance differences between single AUs, combinations, or single AUs and

combinations. Subtle Differences sections do not describe all differences, but only those aspects of movement and appearance

changes that are most relevant in distinguishing two Action Units or Action Unit combinations or in detecting the AU's action.

The Subtle Differences tables also contain notes about the interaction of appearance changes when multiple actions co-occur.

When actions co-occur, one AU can interfere with detecting another AU by hiding or masking the signs of its action. The AU that

obscures is call the dominant AU because its appearances are apparent, while tending to eclipse the signs of the other,

orsubordinate, AU. Look in the Subtle Differences table beginning on page 66 and find the comparison 6 versus 6+7. AU 6 is the

dominant AU because it masks the presence of AU 7. FACS scorers say that 6 dominates 7, and thus special care needs to be

taken when looking for signs of 7 when 6 is present. The discussion of 6 versus 6+7 points out the difficulties and suggests

techniques for clarifying the presence of AU 7 when AU 6 acts.

We urge you read the Subtle Differences tables carefully as you work through each chapter the first time. By reading them, you

will become aware of the appearance changes that are important for distinguishing among AUs and sharpen your understanding of

the appearance changes that cause problems when trying to distinguish AUs. They also provide warnings about discerning actions

when AUs co-occur. Subtle Differences tables become really important later when you are scoring faces in a productive environment.

These tables are one of the first places to turn when you are trying to decide between scoring one AU or another. A master table of

Subtle Differences is in Appendix III.

Alternative scores describe yet another relationship among AUs. Alternatives are mutually exclusive scores. The many reasons

why two AUs are alternatives include:

it may not be possible anatomically to do both AUs simultaneously,

the logic of FACS precludes the scoring of both AUs.

Table 2-3 on page 71 shows the alternative rules for upper face actions. In the first column of the table, the AUs that are

alternatives are listed. The alternative nature of the pair is designated using the @ sign. The second column of the table provides

the rationale for why the AUs are alternative. You can score one or the other of the AUs, but not both. A master table of alternatives

is in Appendix IV.

Now that our introduction to the features of the AU chapters is complete, you are ready to read Chapter 2 from beginning to end.

This chapter contains much material and introduces you to new ways of seeing faces. Take your time and work through all the

exercises and share experiences with your training cohort. After studying Chapter 2 carefully, you will be ready to practice what you

have learned by scoring upper face behaviors. Chapter 3 explains how to score facial behavior using the Facial Action Coding

apter 2: Upper Face Action Units

Muscular Anatomy

Muscular Action

Figure 2-1. Muscles underlying upper face Action Units.

Figure 2-1 shows the muscles that underlie the Action Units (AUs) responsible for changing the appearance of the eyebrows,

forehead, eye cover fold, and the upper and lower eyelids.

In this chapter, you first learn AU 4, which lowers and draws the eyebrows together. Then you learn AU 1, which raises the inner

corner of the brow, and then AU 2, which raises the outer corner of the brow. The next two AUs concern the eyelids: AU 5 raises the

upper eyelid, widening the eye aperture; AU 7 tightens the eyelids, narrowing the eye aperture. Then you learn AU 6, which circles

the eye, narrowing it by pulling in more skin from around the eye than AU 7. Next are a series of AUs concerned with the eyelids,

some of which involve complex actions. AU 43 indicates lowering of the upper eyelid, which causes changes in appearance from an

eyelid droop to a relaxed eye closure. AU 45 is a blink and AU 46 is a wink.

The locations of the muscles in the upper face are shown in the two illustrations of Figure 2-1. The location of AU 5 is not marked

in Figure 2-1 because it is hidden in the eye socket, as explained below. AUs 43, 45, and 46 are not illustrated because they involve

criteria for actions that are difficult to portray in a static image.

Following the sections on these single AUs is a table that contrasts the Subtle Differences among many of these AUs. After

studying this table, you might want to review and study again the descriptions of single AUs, or you may continue on to the next

sections that give descriptions of AU Combinations. After several combinations of the single AUs are described, there is another

table comparing Subtle Differences among AU combinations and single AUs.

Action Unit 4 - Brow Lowerer

Figure 2-1 shows the three muscle strands that underlie this action. One strand runs obliquely in the forehead. It emerges near the root

of the nose below the glabella and runs up and outward to a point of attachment in the forehead above the eyebrow. This strand, the

most powerful of the three, pulls the eyebrows together and lowers the brow. Another strand runs more vertically. It emerges from the

root of the nose below the glabella and fans out in the center of the forehead, where it attaches. A third strand runs from the glabella to

the medial corner of the eyebrow. Typically these three strands act together, although there may be more of one strand than another

involved in any particular action. We have carefully considered measuring these strands separately, but have concluded that doing so is

replete with difficulties. For a discussion of the issues and how measuring the separate strands might be done, see the Investigator's

A. Appearance Changes due to AU 4

Lowers the eyebrow. In different instances it may be only the inner portion of the eyebrow that is lowered or it may be both inner and

central portions that are lowered, or it may appear that the entire eyebrow is lowered.

Pushes the eye cover fold downwards and may narrow the eye aperture.

3. Pulls the eyebrows closer together.

Produces vertical wrinkles between the eyebrows, which may be deep. In some people the wrinkles between the eyebrows may not be

vertical but at a 45 degree angle, or both angled and vertical. May also produce one or more horizontal wrinkles at the root of the nose. If

the vertical, angled, or horizontal wrinkles are permanently etched, they deepen.

May produce an oblique wrinkle or muscle bulge running from the middle of the forehead above the middle of the eyebrow down to the

inner corner of the brow, or a series of rippling bulges above and medial to the eyebrow center.

Sometimes AU 4 shows appearance changes 1 and 2 and almost no evidence of appearance changes 3 and 4; or the reverse.

Either way, if the brows are lowered, drawn together or both lowered and drawn together, score AU 4.

Compare images 4i, 4ii and 0. The action is more subtle in 4i than 4ii. Compare 4i with 0 to see that the brow is both lowered

and drawn together. Compare 4i with w4. Note the wrinkles between the brows are more angular than vertical in w4. The

thumbnails below are merely reminders and an index of the relevant images but do not show the details of the appearance changes

you need to know. Be sure to study the larger images by turning to the indicated page if you are reading a printed version, or

clicking on the links if you are reading an online version. Inspect the video of 4.

The page number links show the image or video in this frame, and thumbnails show them in your external viewer. The page

number link next to the thumbnail caption shows the reference example image; the page number link preceding the "for score"

label shows the complete FACS scoring commentary for the image.

4i page 466

4ii page 466

w0 page 465

w4 page 465

page 413 for score

B. How to do AU 4

This movement is easy for most people to do. Lower your eyebrows and pull them together. Try not to wrinkle your nose (if your nose is

wrinkling, you are doing AU 9). If you are unable to make this movement so it looks like 4i or 4ii, turn to the description of AU 9

onpage 93. Make the nose wrinkling movement of AU 9, and watch what happens to your eyebrows. Notice that they come down and

together. Now try to move your eyebrows without moving AU 9. Alternatively, imagine yourself puzzled with a problem that you can't

figure out; you may make AU 4. If you are still unable to make this movement, use your fingers to push the skin on your face so you look

like 4ii. Then try to hold that appearance when you take your fingers away.

Once you can make AU 4, try doing a weak version so that you look more like picture 4i than 4ii. Once you look like 4i, pull down

and together harder so you look like 4ii.

C. Intensity Scoring1 for AU 4

The appearance changes for AU 4 are sufficiently present to indicate AU 4, but are insufficient to score 4B (e.g., a trace of brow lowering

and/or a trace of pulling together).

Inner and/or central portion of brow lowered slightly, pushing down or reducing visibility of medial portion of eye cover fold.

Brows pulled together slightly; if you do not see the movement, you must see a wrinkle or muscle bulge between brows. If a wrinkle or

muscle bulge is permanent (in the neutral face), it must increase slightly.

(Note that in 4i, 4ii and w4 both the brow lowering and pulling together criteria are present.)

Both the brow lowering and pulling together of the criteria for 4B are present and at least one is marked, e.g., one step greater

thanslight, but the evidence is less than the criteria for 4D.

Both the brow lowering and pulling together of the criteria for 4B are present and at least one is severe, but the evidence is less than the

criteria for 4E.

Brow pulling together or lowering is maximum.

Reference: AU 4

Actions of Special Relevance to AU 4

Certain head and eye movements or position changes have special significance in regard to AUs 4, 5, or 7, and you should carefully

inspect the face for these actions when you score 4, 5, or 7, even when not otherwise scoring head/eye positions. Use the definitions of

these AUs when AUs 4, 5, and 7 occur, either separately or in combination with other AUs.

Summary of AU

See Description for Details

Head and/or Eyes Look at Other Person

"Eye Movement Codes M68, 69, and M69" on page 321

Eyes Positioned to Look at Other Person

"Eye Movement Codes M68, 69, and M69" on page 321

Problematic

Combination of

Target Action of

Use These Criteria or See the Section Indicated

To score 4B with

see 1+2+4secC on page 57

To score 4B with

see 1+2+4secC on page 57

To score 4B with

see 1+2+4secC on page 57

To score 4B with

see 1+4 entry below

Inner corners of the eyebrows pulled slightly closer together than in neutral face;

and, one of the following two changes:

Criteria for 4B in

wrinkling or muscle bunching between the eyebrows. If this sign is evident in

the neutral face, then it must increase slightly.

oblique wrinkle or bulge running from the mid-forehead to inner corner of

eyebrow. If present in neutral, it must increase slightly.

Criteria for 4B in

Criteria for 4B in

Both criteria 1 and 2 for 4B described in 4secC alone are required

Since 9 also lowers the eyebrow, and may also draw the eyebrows together to

some extent, or makes it difficult to see the pulling together of the eyebrow by AU

Inner corners of the eyebrows pulled together markedly,

Central portions of the eyebrow and skin above the eyebrow pulled

together markedly.

Action Units or Combinations That Change the Intensity Scoring for Scoring AU 4

See Introduction to Intensity Scoring on page 8 for definition of terminology used in describing the intensity scoring of an AU.

Action Unit 1 - Inner Brow Raiser

One large muscle in the scalp and forehead raises the eyebrows. It runs vertically from the top of the head to the eyebrows and covers

virtually the entire forehead. The medial (or central) portion of this muscle (AU 1) can act separately from the lateral portion of this

muscle (AU 2). Figure 2-1 shows that the movement of AU 1 is to pull the medial part of the brow and center of the forehead upwards.

A. Appearance Changes due to AU 1

Pulls the inner portion of the eyebrows upwards.

For many people, produces an oblique or

shape to the eyebrows.

Causes the skin in the center of the forehead to wrinkle horizontally. These wrinkles usually do not run across the entire forehead, but

are limited to the center. The wrinkles may be curved, raised more in the center than at the ends, rather than horizontal. These wrinkles

may not appear in infants or children. If there are permanently etched lines or wrinkles in the central area of the forehead, they deepen.

Don't be confused because the outer corner of the brows may move medially a little bit. This movement is from the pulling on the inner

part of the brow. If the outer corner moves with AU 1, it moves towards the center line rather than with the upward movement due to AU

Compare image 1 with the neutral image 0, and inspect the video of AU 1. The video begins with a trace of AU 1 already evident.

page 413 for score

B. How to do AU 1

Raising the inner corners of the eyebrows is a difficult movement for most people to make voluntarily without adding AU 2. If you cannot

do it, try the following:

Raise your entire brow upwards (see images of AU combination 1+2 on page 471). Then try to raise just the inner corner, using AU 1.

Add AU 4 to AU 1, pulling the brows together as you pull up the inner corners; if you succeed in this, you will look like the image 1+4

on page 470. Then try to do AU 1 alone without AU 4.

Place your fingers on the inner corners of your eyebrows and push your eyebrows up so they will look like image 1. Then, see if you can

hold the appearance when you take your fingers away.

Once you can do AU 1, touch the outer corners of your brows to verify that AU 2 is not also acting. Make sure you do not not

include AU 4 with AU 1. It may take many hours of practice to learn how to do AU 1. If you cannot do it after five or ten minutes,

proceed to the next section, and come back and try again later.

C. Intensity Scoring for AU 1

The appearance changes for AU 1 are sufficiently present to indicate AU 1, but are insufficient to score 1B (e.g., a trace of brow raising at

the inner corners).

Inner corners of brows raised slightly manifest by hair moving or evidence of muscle bulge developing, showing that the inner corner

area has been pulled up. In some people the eyebrows will not move but the skin above them will move upwards.

If you did not see the brow move, it must additionally have evidence that either criterion 1 is marked;

Slight wrinkles in center of forehead; if such wrinkles are permanent, they must increase slightly.

In a child you might never see criterion 2. In such instances, if you did not see the brow move, then you must rely upon criterion 1, but it

must be marked not slight.

Both the inner brow raising and wrinkling in the center of the forehead of the criteria for 1B are present together and at least one

ismarked, e.g., one step greater than slight, but the evidence is less than the criteria for 1D.

Both the inner brow raising and wrinkling in the center of the forehead of the criteria for 1B are present and both are at least severe,but

the evidence is less than the criteria for 1E.

All the signs of AU 1 are present and the inner brow raising and wrinkling in the center of the forehead are in the maximum range.

Reference: AU 1

AU 9 can recruit a strand of AU 4 that pulls down the eyebrows, counteracting small actions of AU 1 and making it difficult to see, but AU

1 can overcome this effect and must be scored.

Problematic Combination of

Target Action of Adjusted

Use These Criteria or See the Section

To score 1B with 2

see l+2secC on page 54

To score 1B with 2+4

see 1+2+4secC on page 57

Action Units or Combinations That Change the Intensity Scoring for AU 1

Action Unit 2 - Outer Brow Raiser

Figure 2-1 shows that the muscle that underlies AU 2 originates in the forehead and is attached to the skin in the area around the brows.

It is the lateral part of the same muscle that underlies AU 1. In AU 2 the action is upwards, pulling the eyebrows and the adjacent skin in

the lateral portion of the forehead upwards towards the hairline.

A. Appearance Changes due to AU 2

Pulls the lateral (outer) portion of the eyebrows upwards.

Produces an arched

shape to the eyebrows.

Causes the lateral portion of the eye cover fold to be stretched upwards.

In some people, causes short horizontal wrinkles to appear above the lateral portions of the eyebrows. There may also be wrinkles

produced in the medial portion of the forehead, but they are not as deep as the lateral ones.

Don't be confused if the inner corners of the brows move a little bit. This is from the pulling of the lateral part of the brow by 2 and not

due to the inner corner being pulled upwards by AU 1.

Compare images 2 and 0 and inspect the video of AU 2. Note in both the images and video that AU 2 is often stronger on one

side of the face than on the other. (The action of 2 depicted in the video is not simultaneous on both sides of the face because of

difficulty in voluntarily performing this AU.)

page 413 for score

B. How to do AU 2

This is a difficult movement for most people to make voluntarily without adding AU 1. If you have difficulty, try the following:

Make the movement unilaterally. It is often easier with one eyebrow than the other. Also, it may help for you to make AU 4 on one side of

your face, pulling one eyebrow down while you use AU 2 to lift the outer corner of the other eyebrow.

Lift your entire eyebrow, using both 1 and 2 (see the image 1+2 on page 471). Then try to lift only the outer corners, using AU 2 without

Using your fingers push up the outer corners of your eyebrow to see how it changes the appearance of your face. Try to hold the

appearance when you take your fingers away.

Raise your entire brow (1+2), then holding it up as hard as you can, wrinkle your nose as strongly as you can so you look like the FACS

image 9+25 on page 473. Notice that the nose wrinkling pulls the inner corners of your brows back down, cancelling some of the effects

of AU 1. You are left primarily with an AU 2 in your brows. Now that you can see what it looks like, try to do AU 2 without nose wrinkling.

C. Intensity Scoring for AU 2

The appearance changes for AU 2 are sufficiently present to indicate AU 2, but are insufficient to score 2B (e.g., a trace of brow raising at

the outer corners).

Lateral portion of brow pulled upward slightly, changing the shape of brow,

Lateral portion of eye cover fold stretched slightly.

If you did not see the brow move then you must find evidence for the additional criterion below, and at least one criterion (1, 2, or 3)

must be marked with the other two slight.

Horizontal or curved wrinkles above lateral portion of brow. If these wrinkles are in the neutral face, they must increase

eitherslightly or markedly.

In a child, you might never see criterion 3. In such instances, if you did not see the brow move then you must rely just upon criteria 1

and 2, but one of them must be marked and the other slight.

The lateral brow raising, lateral eye cover fold stretching, and wrinkling in the lateral part of the forehead of the criteria for 2B are present

together and at least two are marked, e.g., one step greater than slight, but the evidence is less than the criteria for 2D.

The lateral brow raising, lateral eye cover fold stretching, and wrinkling in the lateral part of the forehead of the criteria for 2B are present

together and at least two are severe, but the evidence is less than the criteria for 2E.

All the signs of AU 2 are present and the lateral raising of the brow, eye cover fold stretching, and wrinkling in the lateral portion of the

brow are in the maximum range.

Reference: AU 2

Problematic Combination of

Target Action of Adjusted

Use These Criteria or See the Section

To score 2B with 1

see l+2secC on page 54

To score 2B with 1+4

see 1+2+4secC page 57

Action Units or Combinations That Change the Intensity Scoring for AU 2

Action Unit 5 - Upper Lid Raiser

This AU pulls the upper eyelid back into the eye socket. When the upper eyelid relaxes, the upper eyelid falls down over the eyeball (see

AU 43 on page 36), and when completely relaxed, it closes the eyes (AU 43E). In the usual eyes open position, there is some contraction

of the muscle that underlies AU 5, but AU 5 designates the appearance changes when the contraction goes beyond the usual, pulling the

lid further back into the eye socket. AU 5 is not shown in Figure 2-1 because the muscle reaching back into the eye socket could not be

represented in the facial view shown in that figure.

A. Appearance Changes due to AU 5

Widens the eye aperture.

Raises the upper eyelid so that some or all of the upper eyelid disappears from view. In some people the upper eyelid is not visible when

the face is neutral, and the disappearance of their upper eyelid cannot be used to determine the action of AU 5.

As a result of the raising of the upper eyelid, more of the upper portion of the eyeball is exposed. How much is exposed depends upon

how much of the upper portion of the eyeball is normally exposed in the neutral position and how strong AU 5 is. Sclera above the iris

may also be exposed depending upon the position of the upper lid in the neutral face and how strong AU 5 is.

As a result of the raising of the upper eyelid, the shape of the upper rim of the eye changes as portions medially and/or laterally are

pulled up. This changed shape of the eye usually results in exposure of more sclera adjacent to the iris medially and/or laterally. Thus, AU

5 causes sclera exposure above the iris (appearance change 3 above), and changes the sclera exposure adjacent to the iris laterally and

Due to the changes described under appearance changes 3 and 4 above, the person seems to be staring in a fixed fashion, almost as if

the eyeball were protruding.

The lower eyelid also raises, very minutely, when there is a strong AU 5. This happens because the strong AU 5 pulls the skin around the

eye, including the lower lid, upwards. It is important to note that this small raise of the lower eyelid due to AU 5 does not involve any

evidence of tightening of the skin below the lower lid, which is characteristic of AU 7, described later on page 28.

If the evidence of AU 5 is apparent in only one eye, score it as bilateral not unilateral.

Compare images 5i and w5i with 0 and w0. Note the 5ii and w5ii images show more action of AU 5 than the 5i and w5i images.

Inspect the video of AU 5.

5i page 467

5ii page 467

w0 page 465

w5i page 467

w5ii page 467

B. How to do AU 5

This movement is easy. Raise your upper eyelid as hard as you can so you can feel it pushing upwards against your eye cover fold.

Observe whether or not sclera is exposed. If you have any difficulty, just try to open your eyes as wide as you can, increasing your field of

vision and bulging your eyes. Try to do a weak version.

C. Intensity Scoring for AU 5

For scoring AU 5 alone or in any combination not listed in the Reference section for AU 5 below, use the following guidelines:

The appearance changes for AU 5 are sufficiently present to indicate AU 5, but are insufficient to score 5B (e.g., a trace of upper lid

raising that exposes more of the iris or sclera).

If the upper lid covers part of the iris in the neutral face, upper lid raise must be sufficient to expose virtually (very nearly) the entire iris,

but no more than a hairline of sclera must be exposed above the iris. If more than a hairline of sclera shows, score 5C, 5D, or 5E.

If the entire iris shows in the neutral face, upper lid raise must be sufficient to expose sclera above iris, more than just a hairline of sclera

is required to be exposed, but not much more. If much more than a hairline of sclera, score 5C, 5D, or 5E).

The sclera exposed is more than allowed by the 5B criteria, i.e., if the upper lid covers part of the iris in the neutral face, slightlymore

than a hairline of sclera is exposed; or if entire iris shows in the neutral face, markedly more sclera must be revealed, but the evidence is

less than the criteria for 5D. When the eyes are deeply set or in some Asian faces, you may never see sclera in 5CDE, and you must make

the decision based upon how much wider the eye aperture has become.

The amount of sclera exposed must be severely more than exposed in the neutral face, but the evidence is less than the criteria for 5E.

The upper eyelid is raised as much as the person can do, and close to the maximum sclera that the person can show is exposed above the

iris, and there must be a bulging or staring appearance without doubt.

Intensity may vary for the two sides of the face, but give only one score that represents the higher intensity. Examine photo w5ii.

Note the E level is reached on only one side of the face. But the score of E is given to the entire AU 5.

Reference: AU 5

Actions of Special Relevance to AU 5

Certain head and eye movements or position changes have special significance in regard to AUs 4, 5, or 7, and you should carefully

inspect the face for these actions when you score 4, 5, or 7, even when not otherwise scoring head/eye positions. Use the definitions of

these AUs when AUs 4, 5, and 7 occur, either separately or in combination with other AUs.

Summary of AU

Head and/or Eyes Look at Other Person

See Description for Details

"Eye Movement Codes M68, 69, and M69" on page 321

Eyes Positioned to Look at Other Person

"Eye Movement Codes M68, 69, and M69" on page 321

When AU 5 occurs in the combinations listed in the table for this Reference section, the criteria for scoring the intensity of AU 5

are not the same as for AU 5 alone. Instead, use the criteria following the table to score AU 5.

Problematic Combination of AUs (or any

combination containing these combinations)

Use this rule for scoring intensity of AU 5

Use intensity criteria immediately following this table.

Use intensity criteria immediately following this table.

Use intensity criteria immediately following this table.

Use intensity criteria immediately following this table.

Use intensity criteria immediately following this table.

Use intensity criteria immediately following this table.

Anytime 5 is scored with 9, regardless of the other AUs that are also

scored, use the criteria listed for 4+5secC on page 45.

Action Units or Combinations That Change the Intensity Scoring for AU 5

The intensity criteria in any of the combinations listed above or any larger combination that includes those that are listed are:

AU 5A in combinations listed above

The appearance changes for AU 5 are sufficiently present to indicate AU 5 in these combinations, but are insufficient to score 5B as

defined below (e.g., a harsh staring or bulging quality to the eye).

AU 5B in combinations listed above

Top of iris must be revealed as it usually is in neutral.

There must be a harsh staring or bulging quality to the eye.

AU 5C in combinations listed above

More reveal of the top of the iris than usual in neutral, marked pushing up of the upper eyelid against the skin above the eye cover fold,

and a markedly harsh staring or bulging quality to the eye, but the evidence is less than the criteria for 5D below.

AU 5D in combinations listed above

More reveal of the top of the iris than usual in neutral, severe pushing of the upper eyelid against the skin above the eye cover fold, and

a severely harsh staring or bulging quality to the eye, but the evidence is less than the criteria for 5E below.

AU 5E in combinations listed above

The upper eyelid is raised to push up against the skin above the eye cover fold to a maximum degree, more than a hairline of sclera is

exposed above the iris, and maximum harsh staring or bulging quality to eye without doubt. Again note that in people with deeply set

eyes or some Asians, sclera will never show in a 5E, and you will have to make the judgment based on widening of the eye aperture, or

the maximum amount of iris that appears capable of exposure by 5.

Action Unit 7 - Lid Tightener

Figure 2-1 shows a muscle that circles the eye orbit that is the basis for AU 7. This muscle runs in and near the eyelids. When it is

contracted, AU 7 pulls both upper and lower eyelids and some adjacent skin below the eye together and towards the inner eye corner.

A. Appearance Changes due to AU 7

Tightens eyelids.

Narrows eye aperture.

May be more apparent in lower eyelid area than in upper eyelid.

Raises the lower lid so it covers more of the eyeball than is usually covered.

The raised lower lid may become more straight than curved in shape; or, just the medial portion inverted, e.g. from a

The raising of the skin below the lower eyelid causes a bulge to appear in the lower lid.

May cause the lower eyelid furrow to become evident as a line or wrinkle, or if the furrow is a permanent part of the face, it becomes

If AU 6 is evident on one side of the face and 7 on the other side, score bilateral 6, unless you are scoring asymmetry.

When 7 is maximum, the appearance of a squint results.

Compare images 7 and w7 with 0 and w0. Note that in image 7E, the eyes remain open a slit; if closed, 7E+43E would be

scored. Note that in w7 there is a trace of brow lowering, sufficient to score 4A. Inspect the video of AU 7.

7E page 469

w0 page 465

w7 page 468

page 414 for score

B. How to do AU 7

This movement is fairly easy to do. Tense your eyelids but not enough to close your eyelids completely. Do it as weakly as you can. If you

have difficulty, think about narrowing your eye aperture to a slit so that you can see your eyelashes. Be careful you are not also lowering

your eyebrow (AU 4). Be careful you are not also wrinkling your nose (AU 9). Be careful you are not also raising your cheeks (AU 6).

C. Intensity Scoring for AU 7

The appearance changes for AU 7 are sufficiently present to indicate AU 7, but are insufficient to score 7B (e.g., a trace of narrowing not

due to other AUs).

There is a slight narrowing of the eye aperture (due primarily to lower lid raise) that is not produced by:

AU 4, which in lowering the brow may also narrow the eye aperture. If AU 4 is present you must be certain the lower lid has also been

raised in order to score AU 7.

AU 6, which narrows the eye aperture, and obscures the presence of AU 7. Later, you will learn that if the signs of AU 6 are present, it is

difficult to see the signs of AU 7, especially without motion that allows you to see the addition or subtraction of the 7 action.

AU 12 or 13, which can be strong enough to have narrowed the eye aperture. More specifically, when the actions of 12 or 13 are strong, 6

is likely to be scored as well. With a weak to moderate 12 where AU 6 is not evident, AU 7 is easier to score separately from AU 6. You will

learn AU 12 and 13 in Chapter 6.

AU 9, which can be strong enough to narrow the eye aperture. AU 9 can obscure the presence of 7, and unless the actions of 7 and 9 are

sequential in a motion record, it is difficult to see the signs of 7, especially if AU 9 is strong. You will learn about AU 9 in Chapter 4.

AU 43, which in addition to drooping the upper lid may also entail a small lower lid raise; if AU 43 can be scored, then to score 7 criterion 2

or 3 below must be met (i.e., mere narrowing is insufficient for scoring AU 7 when AU 43 is narrowing the eye). For scoring 7 in the

combination of 7+43E, see the section on Action Unit Combination 7+43E on page 62.

The lower lid is raised and the skin below the eye is drawn up and/or medially towards the inner corner of the eye slightly.

Slight bulge or pouch of the lower eyelid skin as it is pushed up.

Note that images 7 and w7 meet both criteria 1 and 3.

If you did not see the lower lid move up, then criterion 1 must be marked not slight and criterion 3 must be met.

At least two of the criteria for AU 7B, narrowing of the eye aperture, raising of the lower lid, or bulging/pouching of the lower eyelid are

present and at least one is marked, but the evidence is less than the criteria for 7D.

Narrowing of the eye aperture, raising of the lower lid, and bulging/pouching of the lower eyelid are all present and at least one of these

is severe, but the evidence is less than the criteria for 7E.

The narrowing of the eye aperture and raising and stretching of the lower lid are present and in the maximum range, hiding most of the

iris and pulling skin below the lower eyelid towards the root of the nose.

Tension in the eyelids and the bagging, bulging, or tensing of the lower eyelid is present and severe.

Reference: AU 7

Actions of Special Relevance to AU 7

Certain head and eye movements or position changes have special significance in regard to AUs 4, 5, or 7, and you should carefully

inspect the face for these actions when you score 4, 5, or 7, even when not otherwise scoring head/eye positions. Use the definitions of

these AUs when AUs 4, 5, and 7 occur, either separately or in combination with other AUs.

Summary of AU

See Description for Details

Head and/or Eyes Look at Other Person

"Eye Movement Codes M68, 69, and M69" on page 321

Eyes Positioned to Look at Other Person

"Eye Movement Codes M68, 69, and M69" on page 321

One or more of the appearance changes due to AU 7 can be produced by several other AUs. For example, bunching and wrinkling

of the lower eyelid can be produced by 6, 9, 10, 12, and 13. Narrowing of the eye aperture can be produced by 4, 6, and 43. These

signs can hide the signs of a co-occurring 7, but typically, AU 7 can be discerned by its production of additional signs, e.g., eyelid

straightening, or by wrinkling, bagging, or narrowing that is beyond what might be produced by the masking AU alone. It is

important to discern whether 7 is present or not in combinations with these other AUs, and you must be certain about its presence,

so while you will not score 7 based merely on evidence that some other AU might produce, you will look for these additional signs

that reveal its presence when scoring 7 in combination with these AUs.

Problematic

Combination

Use These Criteria or See the Section Indicated

To score 7B

Use the criteria for 7B alone on page 28.

To score 7B

Use the criteria for 5+7B on page 49.

To score 7B

If you use criterion 1 for 7B in 7secC, the evidence must be more than just the narrowing

due to AU 4.

You cannot use criterion 1 for 7B in 7secC - narrowing of the eye aperture - since AU 5

widens the eye. Criterion 2 for 7B in 7secC calls for lower lid raise and the skin pulled up

and/or medially. AU 5 can cause a trace of lower lid raise and upward pull on the skin below

the lid (but not medial pull), so be careful if using this criterion.

To score 7B

#### If you see the movement:

Criterion 2 or 3 for 7B in 7secC, being cautious about AU 5's contribution to criterion 2.

#### If you do not see the movement:

Criterion 3 for 7B must be met - slight bulge

slight pouching of the lower eyelid skin as it is pushed up.

To score 7B

Use criteria for 7B+12 in this table below.

To score 7B

Use criteria for 7B+12 in this table below.

To score 7B

Use criteria for 7B+12 in this table below.

Criteria for

7B in 7+12:

Criterion 3 (bulging/pouching) for 7B in 7secCon page 28 cannot be used: criterion 1

(narrowing) or 2 (raising) must be marked. See the description of the 7+12 combination

on page 188.

To score 7B

Use criteria for 7B+12 in this table above.

Criteria for

7B in 7+43:

tightening of the lids.

Action Units or Combinations That Change the Intensity Scoring for AU 7

To score 7B in any combination that includes 4 or 5 with 6, 12 or 13 use the criteria for 7+12 in the table above.

Action Unit 6 - Cheek Raiser and Lid Compressor

Figure 2-1 shows that the muscle underlying AU 6 (like that responsible for AU 7) circles the eye orbit, but it has a larger circumference

that extends into the eyebrow and below the lower eye furrow. Action Unit 6 pulls skin towards the eye.

A. Appearance Changes due to AU 6

Draws skin towards the eye from the temple and cheeks as the outer band of muscle around the eye constricts.

Raises the infraorbital triangle, lifting the cheek upwards.

Pushes the skin surrounding the eye towards the eye socket, which can narrow the eye aperture, bag or wrinkle the skin below the eye,

and push the eye cover fold down and/or change its shape.

May cause crow's feet lines or wrinkles to appear, extending radially from the outer corners of the eye aperture.

Deepens the lower eyelid furrow. (Apparent in image w6 more than in 6.)

May lower lateral portion of the eyebrows to a small extent (in image w6 not 6).

#### A strong AU 6 may:

a. Make evident or deepen the nasolabial furrow.

b. Raise the outer portions of the upper lip to a small extent.

c. Make evident or deepen the infraorbital furrow, so that this wrinkle runs across the top of the infraorbital triangle in a straight or

crescent-like shape.

If there is evidence of 6 on one side of the face and 7 on the other side, score it as a bilateral 6, unless you are scoring the asymmetry of

If you are considering scoring AU 4 in the presence of AU 6, the brows must be lowered and pulled together since AU 6 may

lower the brow as well, see the Reference for AU 4 on page 19.

Compare the images of 6 and w6 with 0 and w0. Note that the appearance changes are more evident in w6 than 6. In w6 it is

easier to see the raising of the infraorbital triangle and the outer portions of the upper lip, the deepening of the nasolabial furrow,

the deepening of the lower eyelid furrow and the infraorbital furrow. Note that in images 6 and w6, AU 7 has combined with AU 6,

which is apparent from the eye aperture that is narrowed beyond what 6 can do alone, the pulling up and raising of the lower eyelid

onto the eyeball producing bulging and wrinkling beyond what 6 can do, and the pulling up of the skin of the lower lid at the inner

corners which 6 cannot do. You should compare 7 and w7 with 6 and w6 to see the appearances of AU 7 that are common and the

appearance changes AU 6 introduces on these faces.

For a better distinction between these Action Units, examine the videos of AUs 6, 7, and 6+7. Note in the video of 6, it is mostly

the outer ring of skin around the eye that is affected, while in the video of 7, the inner ring of skin is affected. Examine the 6 video

to see how much AU 6 alone can affect the lower eyelid's position and the wrinkling of the lower lid and compare this effect with

what happens to the lower lid in the 7 video (6 pushes up the lower lid a bit by its constriction of the outer ring, 7 pulls it up more

on the eyeball). Similarly, note the subtle differences between the effects of 6 and 7 on the upper eyelid. You can see in Figure 2

that the muscle underlying AU 6 runs through the skin of the cover fold, but the muscle of AU 7 runs through the palprebral part of

the upper eyelid (the part on the eyeball). In general, 7 pulls the upper eyelid down, but 6 affects mostly the eye cover fold. On this

person's face, AU 7 pulls the eyelid down and the cover fold passively lowers with it; in contrast, AU 6 constricts the skin of the eye

cover fold, which you can barely see here in wrinkles on the eye cover fold, but has little effect on the position of the upper eyelid.

Such effects of 6 and 7 on the upper eyelid vary widely because of the variations in the shapes and positions of structures in the eye

socket (e.g., all three people in the examples have relatively little exposure of the eye cover fold but some people have a great

deal). All such differences can be traced back to the different locations of the muscles underlying 6 and 7 depicted in Figure 2-1.

Next, look at the inner corners of the eyes, where the tear duct lies, and notice what happens to this wedge of opening when 6

versus 7 occurs (narrows in 7, not 6). Also, note the medial pulling of the skin of the lower lid towards the inner eye corner in 7, not

Finally, look at the kind of wrinkles 6 and 7 make at the outer corners of the eyes. AU 7 can make limited, short wrinkles (crow's

toes), but AU 6 makes more extensive wrinkles both above and below the eye corners and extending into adjacent regions. These

crow's feet of AU 6 hide the crow's toes wrinkles of AU 7 when they occur together. Make sure you understand why 7 is scored with

6 in the two 6 example images (6 and w6). Now look at the two 6+7 videos to see how these two AUs combine, and how you can

detect that both are present by looking for the signs discussed above.

Usually, when the evidence supports scoring AU 6, there is enough independent evidence of AU 7 to score it, but AU 6 does not

necessitate the presence of AU 7. Most people add AU 7 to deliberate performances of AU 6, and 6 without 7 is not a typical

behavior. Yet, you must make the determination as to whether 7 is present each time you see 6. If there is not the kind of

independent evidence of 7 discussed here, score 6 alone. See the discussion of subtle differences between 6 vs. 7, and 6 vs. 6+7 in

Table 2-1 on page 41 for summary information on differentiating these AUs.

In the 6+7ii video, a trace of AU 12 (smile) occurred, lifting the lip corners a little bit. See the scoring commentaries for the

reference examples in Appendix II for more details on scoring these items.

w0 page 465

w6 page 468

page 414 for score

page 414 for score

video 6+7ii

page 415 for score

B. How to do AU 6

This action is difficult to produce on demand without including other actions, especially 7. Concentrate on lifting your cheeks without

actively raising up the lip corners (that is AU 12). Take time in trying this Action Unit as it may not be possible to do it at first. If you have

difficulty:

Try making AU 15 (see the AU 15 description on page 100). While holding 15 on your face try to lift your cheeks upwards. Once you can do

6+15, try 6 alone.

Try AU 9 (see the AU 9 description on page 93), while holding it on your face add 6. Once you can do 6+9, try 6 alone.

Try AU 12 (see the AU 12 description on page 178), note what happens around your eyes. Now try to do that same appearance without

moving your lip corners.

Try winking, using your cheek in the wink. Note how your cheek lifts. Now do that cheek lift without the wink.

Try squinting your eyes as though to block out a bright sun, and although this motivation is likely to produce AUs 4 and 7 as well, you can

refine these movements to exclude all but AU 6.

C. Intensity Scoring for AU 6

The appearance changes for AU 6 are sufficiently present to indicate AU 6, but are insufficient to score 6B (e.g., slight crow's feet

orslight cheek raise).

Marked change on either criterion 1 or 2 below or slight on both 1 and 2 is sufficient to score 6B.

Crow's feet wrinkles; if present in neutral, they must increase.

Infraorbital triangle raise: cheeks up, infraorbital furrow deepened, and bags or wrinkles under eyes; if present in neutral, the furrow and

either bags or wrinkles under the eyes must increase.

(Note that w6 meets or exceeds criteria 1 and 2 for 6B above. For the 6 image, criterion 1 is marked; the image shows

onlyslight changes on cheeks up, but not on infraorbital furrow deepening or bags or wrinkles, criterion 2.)

The crow's feet wrinkling and infraorbital triangle raising criteria for 6B are both present and both are at least marked, but the evidence is

less than the criteria for 6D.

The crow's feet wrinkling and infraorbital triangle raising criteria for 6B are both present and both are at least severe, but the evidence is

less than the criteria for 6E.

Crow's feet wrinkling and infraorbital triangle raising are both present, with the infraorbital triangle and cheek raising in

the maximumrange.

L6+R7 or R6+L7: If 6 can be scored on one side of the face and 7 on the other side, score as bilateral 6, unless you are scoring

Reference: AU 6

If there are appearance changes that suggest AU 6, but you are not certain that 6 is present, and there are changes in the lower face

(cheek raise and deepening of nasolabial furrow) that are not due to lower face AUs 9, 10, 12, or 13, then consider scoring AU 11.

If you are uncertain whether the signs of 6 have increased from neutral, consider scoring 7, 11, or no score.

Problematic

Combination

Use These Criteria or See the Section Indicated

Criteria for

crow's feet wrinkles

infraorbital triangle raise: cheek raise, infraorbital furrow deepen, bags or wrinkles

under the eyes.

To score 6B

Use criteria for 6B+9 in this table above. (Note that AU 9 makes AU 10 difficult to detect.)

To score 6B

Use the criteria for 6B+9 in this table above.

Criteria for

a. Marked crow's feet wrinkles.

b. Slight infraorbital triangle raise: cheek raise, infraorbital furrow deepening, bags or wrinkles

under the eye.

c. Slight additional evidence of the constricting action of AU 6.

The complete guidelines for scoring the intensity of 6 in this combination and with 12

generally are presented in the description of the 6+12 combination beginning on page 188.

These guidelines are also used in the detailed procedure for scoring combinations of 6, 12,

15, and 17 on page 219.

To score 6B

Use the criteria for 6B+9+12 in this table above (same as 6B+12).

To score 6B

Use the criteria for 6B+9 in this table above.

To score 6B

Use the criteria for 6B+9+12 in this table above. If the intensity of AU 12 is C, D, or E, you

must see the outer corners of the brows lower slightly or the upper eye cover come

down slightly.

To score 6B

Use the criteria for 6B+9+12 in this table above (same as 6B+12). Note that 12 and 15 are

antagonistic actions and they are difficult to score together, especially without a motion

record of their independent actions.

To score 6B

Use the criteria for 6B+9+12 in this table above.

To score 6B

WARNING: The criteria for scoring 6B in 6B+15 are the same as for scoring 6B alone.

However, when 6 and 15 act simultaneously, the usual lifting of the entire infraorbital

triangle may not be so evident. AU 15 pulls down the lower portion of the infraorbital triangle

and therefore may restrict the lifting of AU 6 to the lateral and extreme upper portions.

To score 6B

WARNING: The criteria for scoring 6B in 6B+20 are the same as for scoring 6B alone.

However, the combined effects of 6 and 20 on the infraorbital triangle may alter the usual

lifting of the entire area. AU 20 stretches the lower portion of the infraorbital triangle

laterally, thus inhibiting the upward movement of that portion. However, the effects of AU 6

should be evident from the lifting in the upper and lateral portions of the infraorbital triangle.

Action Units or Combinations That Change the Intensity Scoring for AU 6

Introduction to AUs 43, 45, 46

These AUs involve the action of the muscles that you have already learned - those that underlie AU 5 and AU 7. Because their appearance

is different from AUs 5 or 7 alone, they are described as separate AUs. AUs 43, 45, and 46 are listed as optional, as we expect that they

will not always need to be measured. Although listed as optional, study and score them, except AU 45 (Blink), if they occur in practice

AU 43 provides a code for comprehensive scoring of the degree of upper eyelid lowering that, at the E level, results in eye

closure. It is listed as optional as most studies will not require complete information about this action. However, there are research

questions where this information is needed.

In almost all studies, it is best to know when the eyes are closed completely (AU 43E). Therefore, even though scoring AU 43 is

described as optional, it is suggested that AU 43E be scored routinely, even when not scoring the other intensities of AU 43.

AUs 45 and 46 are variations on eye closure. In 45, you score a brief eye closure in a blink. You are given a time rule for

differentiating blinks (AU 45) from eye closures (AU 43E) and both a time rule and a qualitative feature for discriminating a

unilateral blink (AU 45) from a wink (AU 46).

Action Unit 43 - Eye Closure - Optional

Although scoring AU 43 is optional, we strongly suggest scoring AU 43 at the E intensity when it occurs.

The same muscle, which when contracted raises the upper eyelid (AU 5) and when partially relaxed lets it droop, allows the eye

to close when totally relaxed. There should be no sign of tension in the eyelids, no evidence of a 7. Later in the description of

combinations, you will learn how to score 6+43E or 7+43E for tense or tight eye closures.

Notice that the intensity scoring of AU 5 and AU 43 refer to the normal eye aperture. When the opening becomes greater than

normal, AU 5 should be scored; when less than normal, AU 43 might be scored. Thus, the intensity scoring for AU 43 in relation to

muscular contraction is opposite to that of AU 5. In AU 43, the more the muscle relaxes, the higher the intensity score;

correspondingly, the more the appearance of 43 is evident, the higher the intensity score for AU 43.

A. Appearance Changes due to AU 43

The eyelid droops down reducing the eye aperture.

More surface of the upper eyelid is exposed than usual. In some people part of the upper lid is always visible, but more becomes exposed

as the upper eyelid relaxes.

If the lid is not just drooped, but additionally there is some very limited tightening of the lids or lifting of the lower lid (due to AU 7), AU

43 is scored with AU 7 (see combinations 6+43 and 7+43 on page 62).

In AU 43E, the eyes are completely closed, but there is no sign of tension in the lids and no squeezing or tightening. If there are such

signs of tightening or tension, score 43E with 6 or 7.

Inspect the images showing various intensities of AU 43. Image 43i shows a 43B, 43ii shows 43D, 43iii shows 43E.

43i page 469

43ii page 469

43iii page 469

B. How to do AU 43

This movement is easy to make. First, try to do only a small amount of AU 43. Let your eyelid relax and droop in a sleepy way, without

looking downwards. As motivation, you might think of the hypnotist's suggestion "your eyes are getting heavier." When you do this

movement, you may not be able to see yourself in a mirror. Have someone else check you or try to relax only one upper eyelid while

checking yourself.

Then, let your upper eyelid relax almost completely, so that just the barest slit of an opening remains (43D). You will not be able

to see yourself do this. Observe it on another person. Often you can see no iris at all, but you can see that the upper eyelashes are

not resting upon the lower eyelashes.

Finally, close your eyes without squeezing. You can observe this action on another person. Try closing one eye so you can look in

the mirror at it yourself with the other eye. This range of distance between the upper and lower eyelids due to relaxing of the upper

eyelid, from a trace less than the normal opening to closed, is what you will use to score the intensities of AU 43.

C. Intensity Scoring for AU 43

At all levels of intensity, eyes must remain fully or partially closed for more than be attributable to eye positions (e.g., looking down, AU

The appearance changes for AU 43 are sufficiently present to indicate the lowering of the upper eyelid of AU 43, but are insufficient to

score 43B (e.g., a trace increase in upper eyelid exposure and slightly narrowed eye aperture). However, the eyelid must remain in the

scored position for

There is a slight increase in the amount of upper eyelid exposure that is not merely the result of a 1+2

2. The eye aperture is markedly less wide than usual.

The increase of upper eyelid exposure must be at least marked and the decrease in eye aperture must be at least pronounced, but the

signs are insufficient to score 43D.

The eye aperture is almost as narrowed as possible without being closed.

The eyelids are relaxed, not tensed.

The eyes are definitely closed as manifested by the upper and lower lids touching for more than

#### If the action is unilateral:

Eye must remain closed more than 2 seconds.

If the eye closure duration is more than for scoring AU 46 are met.

If there is any doubt about whether the eyes are closed, do not score 43E, but score 43D. See the section on Subtle Differences

between 43D and 43E.

Reference: AU 43

Problematic

Combination of

Target Action of

Adjusted Criteria

Use These Criteria or See the Section Indicated

Criterion for scoring

Raising the brows causes some of the upper eyelid to be exposed. To score 43A or

43A or 43B in

43B with 1+2, the upper eyelid must have been relaxed to expose more eyelid

than could be due to 1+2 alone.

Criterion for scoring

43E in 6+43E,

Eyes are definitely closed. With AU 6 they are squeezed closed, accompanied by

the cheek raising of AU 6; with AU 7 they are tightened closed by the constricting

action of AU 7 immediately around the eyelids.

6+L43E, 6+R43E

Criterion for scoring

The eye that is closed is squeezed shut for more than 2 seconds, accompanied by

a Unilateral 43E with

the cheek raising of AU 6.

7+R43E, 7+L43E

Criterion for scoring

an Unilateral 43E

The eye that is closed is tightened shut for more than 2 seconds.

Action Units or Combinations That Change the Intensity Scoring for AU 43

Action Unit 45 - Blink - Optional

Blinking, a quick eye closure and return to eyes open, involves a sequence of actions that happens very quickly, using muscles that are

the basis for Action Units you have already learned - those relevant to AUs 5, 7, and 43. Earlier you learned that raising the upper lid (AU

was due to the contraction of the same muscle which, when partially relaxed, causes the upper eyelid to droop (e.g., 43B), or when

completely relaxed, lets the eyes close (AU 43E). You also learned that the eyelids can be tightened (AU 7); later you will learn the eyes

can be tightened-closed (7+43E). In the blink, there is a very rapid sequence of actions in which the upper eyelid raising muscle relaxes

and the lid-tightening muscle contracts, closing the eye, followed in a fraction of a second by relaxation of the lid-tightening muscle and

contraction of the upper lid raising muscle to open the eye again.

A. Appearance Changes due to AU 45

Eyes close and open very quickly with no pause or hesitation in the closed position. The eyes (or one eye in a unilateral blink) must close

or nearly close for a moment, and then return to an open position.

If bilateral, the eyes cannot be closed more than cannot be scored in a still photograph. If bilateral and the eyes remain closed more than

should be scored as eyes closed (43E). If eye closure is unilateral and does not exceed scoring it as a wink (AU 46), i.e., if the unilateral

closure is less than wink. To score a unilateral blink, the eye closure must not appear to be intentional (see AU 46).

There is no video or image of AU 45. Watch someone else blink or look for blinks that have occurred spontaneously in the video

records of other AUs.

B. How to do AU 45

Blinking is very easy to do. Try blinking with one eye, so you can watch with the other eye. Or, look at someone else blink. Blinking

happens quickly, and AU 45 alone does not involve tightening and wrinkling around the eye, which is due to the addition of AU 6 or AU 7.

C. Intensity Scoring for AU 45

AU 45 is not scored for intensity. Apparent squeezing or pressing in a blink, sometimes quite noticeable on faces of people affected by

organic or psychological disabilities, can be captured by scoring AUs 6 and 7 for intensity.

Action Unit 46 - Wink - Optional

AU 45 (Blink) has the same muscle actions in the same sequence, except that in AU 46, the wink, the lowering of the upper lid is slower,

there is a pause or hesitation during the closure, and it is unilateral. Blinks are typically bilateral. If the duration of the wink exceeds two

seconds, the action should be scored U43E (eyes closed). The appearance of a wink (AU 46) is unlike that of a unilateral 43E or a

unilateral 45 (blink) in that there is an intentional quality to the movement; there may be accompanying head movement, and there

seems to be a deliberate pause or hesitation during closure even though the closure may be very brief.

A. Appearance Changes due to AU 46

One eye closes briefly, pausing longer than for a unilateral blink, before opening again. The eye closure must be unilateral and have a

deliberate pause or hesitation.

The eye closure must be shorter than 2 seconds. AU 46 cannot be scored in a still photograph.

May or may not include evidence of tightening of the eyelids (as in a unilateral 7+43E), or tightening plus infraorbital triangle raise and

crow's feet (as in a unilateral 6+43E). The eye closure of a unilateral 43E, unilateral 6+43E, or unilateral 7+43E is scored as AU 46 if the

duration of the eye closure is less than 2 seconds, and there appears to be a deliberate pause or hesitation.

AU 46 must be scored unilaterally indicating which eye winked, i.e., R46 or L46.

Examine the video example for AU 46.

B. How to do AU 46

Some people have a much easier time performing winks than others, but quickly closing one eye briefly is an easy movement for most

people. If you have difficulty in trying to shut only one eye, try instead to keep one eye open while you blink. Wink while watching with

the other eye. Do a unilateral 46 wink, a unilateral 6+46 wink, and a unilateral 7+46 wink. Try reversing the eye you wink.

C. Intensity Scoring for AU 46

There is no intensity scoring for AU 46; consider scoring AUs 6 or 7 to capture apparent intensity differences in winks.

Subtle Differences Among Single Action Units in the Upper Face

You have now been introduced to all of the Action Units in the upper face. Before turning to the combinations of these AUs, we will

describe ways to distinguish between particular AUs which differ in subtle ways. Later, when you have learned combinations of upper face

AUs, we will describe more subtle differences between single AUs and combinations, and between particular combinations.

Compare the video example of each contrast, checking it against the text. Appendix I is an index of the AUs and combinations

appearing in video. It will help you find the AUs contrasted below. Also, compare the images for each contrast.

Subtle Differences

When it appears that AU 5 has acted on only the left or right side, it is very likely that there is at least a trace of movement of the other

upper eyelid. If there is at least a trace, score AU 5 as bilateral and score the intensity of the eyelid raise equal to the side with greater

intensity. Be very cautious about scoring U5 to be certain there is no trace on the other side.

Both AUs share the appearance changes of narrowing the eye aperture, and changing the appearance of the skin below the lower

the most important difference is that the infraorbital triangle is raised in 6 but not in 7: evident in more prominent, raised cheeks and

a more apparent or deepened infraorbital furrow which takes on a more horizontal or crescent shape.

AU 6 can lower the outer corner of the eyebrow while AU 7 cannot.

the bagging or wrinkling of the skin below the eye occurs more in 6 than in 7 and extends further down the face in 6 than in 7.

crow's feet in 6 not in 7; or, if in 7, a single line or wrinkle (or toe), not many lines or wrinkles (or feet).

some pulling upwards of upper-lip and skin above upper-lip in an extreme 6, but not in 7.

skin below the eye is drawn up and medially towards the inner corner of the eye in 7, not 6.

a bulge may appear in the lower eyelid skin in both 6 and 7, although it is due to a different action (pulling of the skin over the

eyeball in 7, or pushing of the skin up by the drawing in action of 6), and usually appears somewhat different.

AU 6, unlike 7, pushes down on the eye cover fold by constricting skin above it.

If you are uncertain whether the signs of 6 have increased from neutral, consider scoring 7 or 11. If 6 is evident on one side of the

face and 7 on the other side, score bilateral 6, unless the purpose of the study is to examine asymmetry.

In drawing the skin in towards the eye, AU 6 makes it difficult to see the lid tightening action of AU 7. When the question is whether

AUs 6 and 7 have combined, watch for the independent tightening and movement of the lower eyelid in these combinations. When

the onset or offset of the two AUs is not synchronized, the AU 7 is more easily detectable. Also, check for signs of 7 that are not

produced by 6 alone, as indicated in the comparison of 6 vs. 6+7 below. If you cannot detect independent evidence of the 7 from the

6, do not score the 7.

AU 7 is very difficult to detect when simultaneously involved with AU 6, and the more intense the 6, the more it covers the action of

First, check for signs of asynchrony in the actions of 6 and 7. Look at the moments when these AUs begin to act or later when they

relax. For example, if the lower eyelid is pulled medially during initial action of a possible 6+7, then AU 7 is acting with 6. If during

relaxation the extreme inner corner of the lower eyelid moves laterally and not only downward, AU 7 must have been on the face, not

6 alone. Second, check the signs of 7 that 6 does not produce. Besides the medial pulling of the lower eyelid by 7, AU 7, not 6, pulls

the upper eyelid down. AU 6 pushes the skin of the lower eyelid up to produce wrinkling in the lower eyelid, but AU 7pulls it up even

more onto the eyeball to cover more of the eyeball than 6 alone can do. Often, you can distinguish this wrinkling of the lower eyelid,

which can be produced by either 6 or 7, from the bulging of the skin as it is pulled up onto the eyeball by AU 7. If in doubt that 7 has

acted with 6, score 6 alone.

AU 43 can be scored without scoring 7, but it is rare that 7 can be scored without at least a 43A unless AU 5 has acted with 7 to lift

the upper eyelid. If 7 is scored, it is not necessary to score 43 and its intensity unless the study is examining the degree of eye

closures, regardless of the action that causes them. If upper eyelid closure is being scored comprehensively and 7 can be scored and

the upper lid is lowered, score 7+43 and score the intensity of 43 to reflect the degree that the upper eyelid is pulled downward.

In both 43B and 7 there is a narrowing of the eye aperture, but the action that is responsible differs. In 7 it is primarily a tightening

action, while in 43 alone it is primarily due only to drooping or relaxing. AU 7 is more visible on the lower eyelid although it changes

both lids, while 43 is an upper eyelid action. In 43B the upper eyelid is so relaxed that it droops down covering more of the iris than

in neutral. In 7 the lids are tightened, the lower lid raised by the tightening, the upper lid pulled down. The clue to 7 is watching the

lower lid go up, the skin below the lower lid pulled towards the root of the nose, and the bulging of the skin in the lower lid.

In both 7E and 43D the eye aperture is very narrow. However, 43D is primarily an upper eyelid action; the upper eyelid being

lowered gently or relaxed so that the eye is almost closed. AU 7E is 7 at its most extreme intensity; therefore, the narrowing of the

eye aperture is due to the extreme raising and tensing of the lower lid and pulling down of the upper lid. If the cues of AU 7 are

clearly present and the eyes are open only a slit, and a comprehensive scoring of eye closure is not required, score it as 7E; otherwise,

score 7E+43. Examine the images 7E and 43ii on page 469.

In 43E alone the eyelids appear relaxed. In 7+4E3 the eyelids are tightened together, not relaxed. Examine the images 7+43

on page 473 and 43iii on page 469.

In 43E, the eyes are definitely closed for at least that the lids are touching or resting on each other, and the lashes are together. The

upper and lower eyelids touch together and stay together for at least lids, score 43D not 43E. You will not see any part of the eyeball

between the lids or the glistening of the lower lid's wet tissues when the eyes close, and the lower eyelashes are obscured by the

upper lid and lashes when an eye closes. If the eyes are almost closed, score 43D.

If the eyes remain closed for more than actions are unilateral, see U43E vs. 46 and U45 vs. 46.

AU 46 must be unilateral. If the eye closure is longer than 2 seconds, it must be 43E or some combination of 6 or 7 with 43E. If the

eye closure is under 2 seconds, but longer than lateral eye closure or a wink. Decide by determining if you think there was an

intentional quality to the closure, perhaps shown in the movement itself or by an accompanying head movement, or deliberate pause

during the moment the eye is closed. These are signs of the wink (AU 46), not an eye closure (AU 43E). As AU 46 must be

unilateral, score R46 or L46.

In a wink one eye closes and is usually held closed for a longer duration than a blink. A blink cannot exceed tinguishing a wink from

a blink is when the eye closure is unilateral and does not exceed score a wink (46) that is less than closed.

Table 2-1 Subtle Differences Among Single Upper Face Action Units

Action Unit Combinations in the Upper Face

You will now learn a number of Action Unit combinations which involve the single AUs you now know. Not all the possible combinations of

these AUs will be shown and described, but some of the most common ones and most problematic ones to score are included. When you

learn each new AU combination, refer back to the images of the single AUs which are involved and to Figure 2-1, which shows the location

and direction of action of the component elements.

Combination

6+43E, 7+43E

Other combinations

Action Unit Combination 4+5

A. Appearance Changes due to AU Combination 4+5

The elements described separately for AUs 4 and 5 combine, modifying the appearance changes due to AU 4 alone or AU 5 alone. The

modified changes involve the appearance of the eye aperture, the upper eyelid and the amount of sclera exposed.

Lowers the inner and central portions of the eyebrow.

Pulls the eyebrows closer together.

Produces vertical wrinkles between the eyebrows. In some people the wrinkles between the eyebrows may not be vertical but at a 45

degree angle, or both angled and vertical. May also produce one or more horizontal wrinkles at the root of the nose. If the vertical,

angled, or horizontal wrinkles are permanently etched, they deepen.

The eye cover fold is pushed downwards by AU 4 and may narrow the eye aperture, while AU 5 widens the eye aperture. The resulting

eye aperture from these opposing actions is a compromise between the two actions.

May produce a wrinkle or muscle bulge running from the middle of the forehead above the middle of the eyebrow down to the inner

corner of the brow, or a series of rippling bulges above and medial to the eyebrow center.

Raises the upper eyelid so that some or all of the upper eyelid may disappear. In some people the upper eyelid disappears solely with the

action of AU 4. In some people the upper eyelid is not visible when their face is neutral.

In some people, AU 5 exposes the sclera above the iris. In others, the sclera does not show due to the lowering action of AU 4.

May change the shape of the upper eye rim as some part of the upper lid is pulled up by AU 5 exposing sclera adjacent to the iris.

The combination of appearance changes 7 and 8 and the pressure of AU 5 upwards against the downward push of AU 4 gives the

appearance of a harsh stare.

If the appearance changes for AU 4 are bilateral, but for AU 5 are evident on only one eye, it is not scored as a unilateral action, but as

a bilateral 4+5.

Compare image 4+5 with images 4i, 4ii, and 5 and image w4+5 with images w4, w5i, and w5ii. Also inspect the video of 4+5.

The video depictions begin with 4 already evident. Many of the other video depictions of AU combinations begin with one of the AUs

already on the face.

4i page 466

4ii page 466

5i page 467

5ii page 467

4+5 page 470

w0 page 465

w4 page 465

w5i page 467

w5ii page 467

w4+5 page 470

page 415 for score

B. How to do AU Combination 4+5

Follow the instructions for each Action Unit separately and do them together. For convenience, the instructions for each AU are repeated

below. Try doing AU 4 first, then add AU 5. Push the eyelid up with AU 5 as hard as you can against AU 4 and notice the change in the

shape of the upper eyelid and eye cover fold. Notice the change in the appearance of the eye in terms of harsh, staring, bulging quality.

AU 4 (repeated from page 18): This movement is easy for most people to do. Lower your eyebrows and pull them together. Try

not to wrinkle your nose (if your nose is wrinkling, you are doing AU 9). If you are unable to make this movement so it looks like 4i

or 4ii, turn to the description of AU 9 on page 93. Make the nose wrinkling movement of AU 9, and watch what happens to your

eyebrows. Notice that they come down and together. Now try to move your eyebrows without moving AU 9. Alternatively, imagine

yourself puzzled with a problem that you can't figure out; you may make AU 4. If you are still unable to make this movement, use

your fingers to push the skin on your face so you look like 4ii. Then try to hold that appearance when you take your fingers away.

AU 5 (repeated from page 25): This movement is easy. Raise your upper eyelid as hard as you can so you can feel it pushing

upwards against your eye cover fold. Observe whether or not sclera is exposed. If you have any difficulty, just try to open your eyes

as wide as you can, increasing your field of vision and bulging your eyes. Try to do a weak version.

C. Intensity Scoring for AU Combination 4+5

The intensity criteria for AU 4 in the combination 4+5 are unchanged from AU 4 alone. The criteria for AU 5 in the combination 4+5 are

altered significantly since many of those changes are concealed by AU 4. If AU 4 is present, it lowers the eye cover fold so that the top

part of the eyeball is less visible than in the neutral face (compare images 4 and 0, w4 and w0). Adding AU 5 to AU 4 counteracts the

downward push by 4 on the eye cover fold as 5 pushes the upper lid up against it. You can recognize the addition of AU 5 to AU 4 by

observing that the top of the eyeball is not as covered as it would be from the influence of AU 4's action alone, but instead has about as

much exposure as the neutral version. The net effect of the opposite influence of AUs 4 and 5 on the eye cover fold is that when the

intensities of the two actions units are roughly equal, about as much shows of the top part of the eye in 4+5 as in the neutral face

(compare 4+5 with 0 and w4+5 with w0). When the intensity of AU 4 is greater than the intensity of AU 5, the eye cover fold is pushed

down to cover the upper eyeball more. When the intensity of AU 5 is greater than the intensity of AU 4, the eye cover fold is moved up to

reveal the upper eyeball more.

In the criteria below, the intensity scoring of AU 5 is described for combinations in which the intensity of AU 4 is roughly equal.

Of course, any combination of the intensities of AUs 4 and 5 might occur in the combination of 4+5, and the determination of their

intensity scores depends upon your evaluation of the balance of effects contributed by AUs 4 and 5. Start by scoring the intensity of

AU 4, then decide how intense the action of AU 5 must be to produce the appearance you see. A difficulty in scoring AU 5 with

higher intensities of AU 4 is that the AU 4 pushes the skin of the brow so low that it sometimes obscures the view of signs of AU 5,

especially for people with deeper set eyes. In this case, you must rely on what signs of AU 5 you are able to see, especially the

changes in the exposure of the iris and the staring quality of the eye, and extrapolate from them to infer the intensity of AU 5.

The intensity criteria for AU 4 in combination 4+5 are unchanged from AU 4 alone and are repeated below.1

The appearance changes for AU 4 are sufficiently present to indicate AU 4, but are insufficient to score 4B (e.g., a trace of brow lowering

and/or a trace of pulling together).

Inner and/or central portion of brow lowered slightly, pushing down or reducing visibility of medial portion of eye cover fold.

Brows pulled together slightly; if you do not see the movement, you must see a wrinkle or muscle bulge between brows. If a wrinkle or

muscle bulge is permanent (in the neutral face), it must increase slightly.

Both the brow lowering and pulling together of the criteria for 4B are present and at least one is marked, e.g., one step greater

thanslight, but the evidence is less than the criteria for 4D.

Both the brow lowering and pulling together of the criteria for 4B are present and at least one is severe, but the evidence is less than the

criteria for 4E.

Brow pulling together or lowering is maximum.

The criteria for AU 5 in the combination 4+5 presented below are altered significantly from 5 alone.

AU 5A in AU Combination 4A+5A

The Appearance Changes for AU 5 in 4+5 are sufficiently present to indicate AU 5, but are insufficient to score 5B in 4+5 (e.g., atrace of

staring quality). Because a 4A may have relatively little effect on the eye cover fold, it may be easier to see the action of 5 in the

presence of 4A than when AU 4 is stronger.

AU 5B in AU Combination 4B+5B

The top of the iris is revealed about as it usually is.

There is a slight harsh staring or bulging quality to the eye, due to slight changes in the amount of sclera exposed adjacent to the iris.

If sclera shows that does not show in neutral, you can score 4+5. If sclera does not show, signs 1 and 2 are sufficient to score 4B+5B. If

sclera shows in the neutral face, it must increase slightly.

AU 5C in AU Combination 4C+5C

The top of the iris is revealed slightly more than it is in neutral, and the line of the eyelid is markedly affected by the opposition of AUs 4

The harsh staring or bulging quality to the eye is marked, due to changes in the amount of sclera exposed adjacent to the iris or to

bulging of the eyeball.

AU 5D in AU Combination 4D+5D

The top of the iris is revealed at least severely more or a hair line of sclera is visible, and the shape of the line of the upper eyelid

is severely affected by the opposition of AUs 4 and 5, which produces much tension.

The harsh staring or bulging quality to the eye is severe, due to changes in the amount of sclera exposed adjacent to the iris.

AU 5E in AU Combination 4E+5E

If the view of the eyeball is clear, more than a hairline of sclera is exposed above the iris, and a harsh staring or bulging quality to the eye

is readily apparent and near maximum. If the brow hides the view of the upper lid you have to extrapolate the position of the eyelid by

observing the iris that you can see to infer the strength of AU 5. In some Asian and other faces, sclera is never be seen above the iris

even at high intensity, so you must calibrate the maximum raising of the eyelid to what appears to be the maximum amount of iris

See the Reference for AU 5 on page 26 for other combinations that include 4+5 where these same criteria for scoring the

intensity of AU 5 apply.

Section C in the descriptions of AU combinations repeats for convenience in scoring the intensity guidelines for AUs that do not change from the AU in

isolation. Revised intensity guidelines are also presented. You can immediately tell the difference between the repeated versus the changed criteria from

the headings for each intensity. The changed criteria include the phrase "in AU Combination" followed by the combination under discussion, because

these criteria are specific to that combination. The heading for the unchanged criteria simply lists the AU described.

Action Unit Combination 5+7

A. Appearance Changes due to AU Combination 5+7

Some of the elements described separately for AUs 5 and 7 are combined when both AUs are present. AU 5 cancels the effect of AU 7 on

the upper eyelid, so that 5 shapes the upper lid and 7 shapes the lower lid.

Raises the upper eyelid; the upper eyelid may disappear from view. (Compare images 5+7 with 7). The upper lid may not be raised as

severely as in AU 5 alone, since AU 7 tends to pull it down. (Compare images 5+7 and 5).

As a result of the raising of the upper eyelid, more of the upper portion of the eye is exposed. How much is exposed depends upon how

much of the upper portion of the eyeball is normally exposed in the neutral position and how strong the action of AU 5 is. Sclera above

the iris may also be exposed depending upon the position of the upper eyelid in the neutral face and how strong AU 5 is.

As a result of the raising of the upper eyelid, the shape of the upper rim of the eye changes as portions of the lid medially and/or

laterally are pulled up. This changed shape of the eye usually results in exposure of more sclera adjacent to the iris medially and/or

Due to the changes described under 2 and 3 above, the person seems to be staring in a fixed fashion, almost as if the eyeball were

protruding.

Tightens the lower eyelid, making it raised to a small extent and more straightened or raised in the center. (Compare 5+7 and 5.)

Can bulge the skin below the eye.

Pulls the skin below the eye up and medially towards the inner corner of the eye.

Usually makes the lower eyelid furrow evident or deepens it if it is permanently etched.

AU 5 widens the eye aperture while AU 7 narrows the eye aperture, the resulting eye aperture is a compromise between the two actions.

If the appearance changes for AU 5 are evident only in one eye and AU 7 is evident in both.

Compare the combination of AUs in image 5+7 with the separate AUs in images 5 and 7. Inspect the video of 5+7.

5i page 467

5ii page 467

5+7 page 470

page 415 for score

B. How to do AU Combination 5+7

Follow the instructions, repeated below, for each AU separately. Try doing 5, then adding 7. Note that 7 tends to pull the upper eyelid

down, diminishing the appearance of 5. Force 5 back, against the pressure of 7, but maintaining 7's effect on the lower lid.

AU 5 (repeated from page 25): This movement is easy. Raise your upper eyelid as hard as you can so you can feel it pushing

upwards against your eye cover fold. Observe whether or not sclera is exposed. If you have any difficulty, just try to open your eyes

as wide as you can, increasing your field of vision and bulging your eyes. Try to do a weak version.

AU 7 (repeated from page 28): This movement is fairly easy to do. Tense your eyelids but not enough to close your eyelids

completely. Do it as weakly as you can. If you have difficulty, think about narrowing your eye aperture to a slit so that you can see

your eyelashes. Be careful you are not also lowering your eyebrow (AU 4). Be careful you are not also wrinkling your nose (AU 9).

Be careful you are not also raising your cheeks (AU 6).

C. Intensity Scoring for AU Combination 5+7

The criteria for AU 5 in AU Combinations of 5+7 are unchanged from AU5 alone and are repeated below. There is only a minor

modification of those for AU 7B.

The appearance changes for AU 5 are sufficiently present to indicate AU 5, but are insufficient to score 5B (e.g., a trace of upper lid

raising that exposes more of the iris or sclera).

If the upper lid covers part of the iris in the neutral face, upper lid raise must be sufficient to expose virtually (very nearly) the entire iris,

but no more than a hairline of sclera must be exposed above the iris. If more than a hairline of sclera shows, score 5C, 5D, or 5E.

If the entire iris shows in the neutral face, upper lid raise must be sufficient to expose sclera above iris, more than just a hairline of sclera

is required to be exposed, but not much more. If much more than a hairline of sclera, score 5C, 5D, or 5E).

The sclera exposed is more than allowed by the 5B criteria, i.e., if the upper lid covers part of the iris in the neutral face, slightlymore

than a hairline of sclera is exposed; or if entire iris shows in the neutral face, markedly more sclera must be revealed, but the evidence is

less than the criteria for 5D. When the eyes are deeply set or in some Asian faces, you may never see sclera in 5CDE, and you must make

the decision based upon how much wider the eye aperture has become.

The amount of sclera exposed must be severely more than exposed in the neutral face, but the evidence is less than the criteria for 5E.

The upper eyelid is raised as much as the person can do, and close to the maximum sclera that the person can show is exposed above the

iris, and there must be a bulging or staring appearance without doubt.

Intensity may vary for the two sides of the face, but give only one score that represents the higher intensity. Examine photo w5ii.

Note the E level is reached on only one side of the face. But the score of E is given to the entire AU 5.

The intensity criteria for AU 7 in combination 5+7 presented below are modified from 7 alone.

AU 7A in AU Combination 5+7

The appearance changes for AU 7 in 5+7 are sufficiently present to indicate AU 7, but are insufficient to score 7B in 5+7 (e.g., atrace of

lower lid raising).

AU 7B in AU Combination 5+7

The lower lid is raised and the skin below the eye is drawn up and medially towards the inner corner of the eye slightly.

If you did not see the lower lid move up, then the following criterion must be met.

The raising of the lower eyelid skin over the bottom of the eyeball causes a slight bulge to appear in the lower lid, since this skin is

stretched over the bottom of the eyeball.

Note the AU 7B in image 5+7 meets criterion 2.

AU 7C in AU Combination 5+7

At least marked change in the criteria listed for 7B, but the evidence is less than the criteria for 7D in 5+7.

AU 7D in AU Combination 5+7

At least severe change in the criteria listed for 7B, but the evidence is less than the criteria for AU 7E in 5+7.

AU 7E in AU Combination 5+7

The raising of the lower lid is and the drawing of the skin towards the inner eye corners is in the maximum range.

Action Unit Combination 1+4

A. Appearance Changes due to AU Combination 1+4

The combination of these two AUs maintains the raising action from AU 1 with the drawing together action of AU 4. The lowering effect of

4 is counteracted or restricted to the outer portions of the brow.

Pulls the medial portion of the eyebrows upwards and together.

2. Produces an oblique shape

to the eyebrows, (see l+4i, l+4ii). In some people the brows do not take on this shape but more of

a dip in the center with a small pull up at the inner corners

(see j1+4).

Pulls medially and up on the mid to inner portions of the upper eyelid and eye cover fold, pulls the lateral portion of the brow down,

producing a triangular shape to the upper eyelid (if it is visible) and eye cover fold.

Causes the skin in the center of the forehead to wrinkle horizontally. These wrinkles usually do not run across the forehead but are

limited to the center. The wrinkles may be curved rather than horizontal or form an omega shape in some people. These wrinkles may not

appear in infants or children.

May cause vertical lines, wrinkles or bunching of skin to appear between the eyebrows (1+4ii more than 1+4i), as the brows are drawn

In some people, the primary appearance change is an oblique wrinkle or bulge running from mid-forehead above the center of the brow

to the inner brow corner area. The brows may or may not appear to be drawn together; but the inner corners are pulled up as their

centers are pulled or held down.

Compare AU combination 1+4 in images l+4i and l+4ii with the individual AUs in images 1 and 4. Also compare image j0 with

images j1+4 and with l+4ii. Inspect the video of 1+4.

1+4ii page 471

j0 page 465

4i page 466

j1+4 page 471

4ii page 466

1+4i page 470

page 415 for score

B. How to do AU Combination 1+4

It is usually easier to do 1+4 than 1 alone. Follow the instructions, repeated below, for doing AU 1, adding 4, as you do AU 1.

AU 1 (repeated from page 20): Raising the inner corners of the eyebrows is a difficult movement for most people to make

voluntarily without adding AU 2. If you cannot do it, try the following:

Raise your entire brow upwards (see images of AU combination 1+2 on page 471). Then try to raise just the inner corner, using AU 1.

Add AU 4 to AU 1, pulling the brows together as you pull up the inner corners; if you succeed in this, you will look like the image 1+4

on page 470.

Place your fingers on the inner corners of your eyebrows and push your eyebrows up so they will look like image 1. Then, see if you can

hold the appearance when you take your fingers away.

Once you can do AU 1, touch the outer corners of your brows to verify that AU 2 is not also acting.

AU 4 (repeated from page 18): This movement is easy for most people to do. Lower your eyebrows and pull them together. Try

not to wrinkle your nose (if your nose is wrinkling, you are doing AU 9). If you are unable to make this movement so it looks like 4i

or 4ii, turn to the description of AU 9 on page 93. Make the nose wrinkling movement of AU 9, and watch what happens to your

eyebrows. Notice that they come down and together. Now try to move your eyebrows without moving AU 9. Alternatively, imagine

yourself puzzled with a problem that you can't figure out; you may make AU 4. If you are still unable to make this movement, use

your fingers to push the skin on your face so you look like 4ii. Then try to hold that appearance when you take your fingers away.

C. Intensity Scoring for AU Combination 1+4

The criteria for AU 1 in AU Combinations of 1+4 are unchanged from AU 1 alone, and are repeated below. The criteria for AU 4 are altered

since AU 1 counteracts the lowering effect of 4.

The appearance changes for AU 1 are sufficiently present to indicate AU 1, but are insufficient to score 1B (e.g., a trace of brow raising at

the inner corners).

Inner corners of brows raised slightly manifest by hair moving or evidence of muscle bulge developing, showing that the inner corner

area has been pulled up. In some people the eyebrows will not move but the skin above them will move upwards.

If you did not see the brow move, it must additionally have evidence that either criterion 1 is marked;

Slight wrinkles in center of forehead; if such wrinkles are permanent, they must increase slightly.

In a child you might never see criterion 2. In such instances, if you did not see the brow move, then you must rely upon criterion 1, but it

must be marked not slight.

Both the inner brow raising and wrinkling in the center of the forehead of the criteria for 1B are present together and at least one

ismarked, e.g., one step greater than slight, but the evidence is less than the criteria for 1D.

Both the inner brow raising and wrinkling in the center of the forehead of the criteria for 1B are present and both are at least severe,but

the evidence is less than the criteria for 1E.

All the signs of AU 1 are present and the inner brow raising and wrinkling in the center of the forehead are in the maximum range.

The intensity criteria for AU 4 in combination 1+4 are different from those for 4 alone.

AU 4A in AU Combination 1+4

The appearance changes for AU 4 in 1+4 are sufficiently present to indicate AU 4, but are insufficient to score 4B in 1+4 (e.g., inner brow

corners pulled together a trace and a trace of brow wrinkling).

AU 4B in AU Combination 1+4

The inner corners of the brows pulled slightly closer together than in the neutral face,

and, one of the following two changes:

There is slight wrinkling or muscle bunching between the brows. If this sign is evident in the neutral face then it must increaseslightly.

Slight wrinkle or bulge running from the forehead above the eyebrow to the inner corner of the brow. If present in neutral, must

increase slightly.

AU 4C in AU Combination 1+4

The inner corners of the brows pulled markedly closer together than in the neutral face,

marked wrinkling/bunching, bulging in the medial part of the forehead.

AU 4D in AU Combination 1+4

The inner corners of the brows pulled severely closer together than in the neutral face,

severe wrinkling/bunching, bulging in the medial part of the forehead.

AU 4E in AU Combination 1+4

The inner corners of the brows pulled maximally closer together than in the neutral face,

maximum wrinkling/bunching, bulging in the medial part of the forehead.

Action Unit Combination 1+2

A. Appearance Changes due to AU Combination 1+2

The combination of these two Action Units raises the inner (AU 1) and the outer (AU 2) corners of the eyebrows, producing changes in

appearance which are the product of their joint action.

1. Pulls the entire eyebrow (medial to lateral parts) upwards.

Produces an arched, curved appearance to the shape of the eyebrow.

Bunches the skin in the forehead so that horizontal wrinkles appear across the entire forehead. The wrinkles may not appear in infants,

children, and a few adults.

Stretches the eye cover fold so that it is more apparent.

In some people (those with deeply set eyes) the stretching of the eye cover fold reveals their upper eyelid, which usually is concealed by

the eye cover fold.

Compare the image 1+2 with image 0. Inspect the video of AUs 1+2.

1+2 page 471

w0 page 465

page 416 for score

B. How to do AU Combination 1+2

This behavior should be easy for you to do. Simply lift your eyebrows up, both ends as high as you can. Note the wrinkling in your

forehead. In some people the wrinkling does not occur but the skin is still bunched up. In some people these wrinkles are permanently

etched (see 0 and w0) but they deepen noticeably when 1+2 acts. Suppress any tendency you may also have to lift your upper eyelid (AU

when performing 1+2. Make sure you are not pulling your brows together (AU 4) when you lift them.

C. Intensity Scoring for AU Combination 1+2

The criteria for AU 1 and those for AU 2 are altered significantly in this combination from the criteria for each alone. Do not use Section C

for AUs 1 and 2, you must use the criteria listed below for the total configuration 1+2. The criteria for intensity scoring are described for

roughly equal intensities of AUs 1 and 2. Of course, any combination of intensities of AUs 1 and 2 can occur in action unit combination

1+2, and to score these intensities (e.g., 1B+2C), you must consider the relative contribution of the separate AUs in the combination you

score against the criteria listed below. When considering whether AU 2 is present when the action of AU 1 is clearly evident, be sure that

any lifting of the outer eyebrows is not due merely to the action of AU 1 alone, as can occur with stronger AU 1s.

AUs 1A+2A in AU Combination 1+2

The appearance changes for AUs 1+2 are sufficiently present to indicate AU 1+2, but are insufficient to score 1B+2B (e.g., the entire

brow is raised a trace).

AUs 1B+2B in AU Combination 1+2

Entire brow raised slightly.

#### If you did not see the brows move it must also meet the additional criteria:

Slight horizontal wrinkles1 or muscle bunching reaching across forehead. If horizontal wrinkles are evident in the neutral face, change

from the neutral appearance must be slight.

Slightly more exposure of eye cover fold than in neutral.

If there is no wrinkling or bunching in the brow, but the brow raise and exposure of the eye cover fold is marked, you can score 1+2.

AU 1C+2C in AU Combination 1+2

Entire brow is raised at least markedly, but less than for level 1D+2D. Wrinkling and eye cover fold exposure should both be evident and

at least one should be at least marked, but the evidence is less than the criteria for 1D+2D.

AU 1D+2D in AU Combination 1+2

Entire brow is raised at least severely. Wrinkling and eye cover fold exposure should both be evident and at least one should be at

least severe, but the evidence is less than the criteria for 1E+2E.

AU 1E+2E in AU Combination 1+2

The entire brow is raised maximally.

If you are scoring the face of an infant or child who never shows forehead wrinkles with AUs 1+2 or 1+2+4, then the wrinkling criterion needs to be

discounted, and you must rely on the other criteria.

Action Unit Combination 1+2+4

A. Appearance Changes due to AU Combination 1+2+4

This combination of AUs pulls the brows upwards and together, but neither of these changes is as large as is found separately with AU 4

alone or with the AU 1+2 combination. The changes in appearance in 1+2+4 are not simply the addition of those for the separate AUs,

but are a new, somewhat different product of their joint action.

Pulls the entire brow (medial to lateral) upwards, but not as much as due to 1+2 alone because AU 4 pulls down on the brow.

Pulls the eyebrows together, but not as close together as in AU 4 alone. Compare images of 1+2+4 with those of 4. Note also that the

eyebrows are closer together in l+2+4ii, where there is more action of AU 4, than in 1+2+4i. Compare both with 1+2. Even in l+2+4i,

there is evidence that the eyebrows are pulled towards each other.

Flattens the shape of the eyebrow between the inner corner and the middle portion of the eyebrow. In some people (j1+2+4) there may

be a small downward curve in between these two points. Usually the outer corners of the brows are level with the inner corners, or if

lower than the inner corner, the outer corners are up sufficiently to expose the lateral portion of the upper eyelid. (Compare j1+2+4 with

Bunches the skin in the central portion of the forehead so that horizontal wrinkles or wrinkles that show a little upward curve appear in

the center of the forehead. These wrinkles may not appear in infants, children and some adults.

May cause an oblique wrinkle line or muscle bunching to appear following the pathway of one of the strands of AU 4. This wrinkle runs

from the inner corner of the eyebrow, up and outwards to a point in the forehead above the middle of the eyebrows. This is more

apparent in l+2+4ii than l+2+4i.

Inspect the images and video of 1+2+4.

1+2+4ii page 472

1+2 page 471

j0 page 465

4i page 466

j1+4 page 471

4ii page 466

j1+2+4 page 471

1+2+4i page 472

video 1+2+4

page 416 for score

B. How to do AU Combination 1+2+4

This is a difficult combination for most people to make. First, try the 1+2 action, which is easy. Let that go and try the 4 action, which is

also easy. The instructions for these actions are repeated below. Now try both at once.

AU Combination 1+2 (repeated from page 54): This behavior should be easy for you to do. Simply lift your eyebrows up, both

ends as high as you can. Note the wrinkling in your forehead. In some people the wrinkling does not occur but the skin is still

bunched up. In some people these wrinkles are permanently etched (see 0 and w0) but they deepen noticeably when 1+2 acts.

Suppress any tendency you may also have to lift your upper eyelid (AU 5) when performing 1+2.

AU 4 (repeated from page 18): This movement is easy for most people to do. Lower your eyebrows and pull them together. Try

not to wrinkle your nose (if your nose is wrinkling, you are doing AU 9). If you are unable to make this movement so it looks like 4i

or 4ii, turn to the description of AU 9 on page 93. Make the nose wrinkling movement of AU 9, and watch what happens to your

eyebrows. Notice that they come down and together. Now try to move your eyebrows without moving AU 9. Alternatively, imagine

yourself puzzled with a problem that you can't figure out; you may make AU 4. If you are still unable to make this movement, use

your fingers to push the skin on your face so you look like 4ii. Then try to hold that appearance when you take your fingers away.

#### If you don't succeed try the following:

Make the 1+2 action, holding it on your face, then add in the 4.

Make the 4 action, holding it on your face, then try to add in the 1+2.

Make the 1+2 action, and use your finger-tips to push the inner corners of the eyebrows together. Note the change in appearance that

occurs. Try to hold this appearance when you take your fingers away.

C. Intensity Scoring for AU Combination 1+2+4

The intensity criteria for AUs 1, 2, or 1+2, and 4 are altered significantly from their separate descriptions. Do not use Section C for AUs 1,

2, 1+2, or 4; you must use the criteria listed below for the total configuration 1+2+4. For the example intensity criteria listed below, the

component AUs are given the same intensity, but of course, any combination of intensities can be scored for the AUs. To determine the

separate intensities, you need to evaluate the relative magnitudes and contributions of the separate AUs in the action you score against

the criteria listed below. For example, if you see a 1+2+4 in which the contribution of AUs 1+2 is at the B level, but the contribution of AU

4 is more than described for the 1B+2B+4B combination below, you might score 1B+2B+4C, and so forth.

AU 1A+2A+4A in AU Combination 1+2+4

The appearance changes for AUs 1+2+4 are sufficiently present to indicate AU 1+2+4, but are insufficient to score 1B+2B+4B (e.g.,

atrace of brow raising and a trace of pulling together in a straight rather than arched shape).

AU 1B+2B+4B in AU Combination 1+2+4

Entire brow raised slightly, and pulled together slightly. Because AU 4 pulls down against the raise of 1+2, the eyebrow may not be

raised very high.

The eyebrows appear more straightened than arched (arched if only 1+2, but the addition of AU 4 pulling them together straightens

them); or, there is a small downward curve between the inner and middle portion of the brow.

AU 1C+2C+4C in AU Combination 1+2+4

The brow raising and pulling together is marked and the straightening is apparent, but the evidence is less than the criteria for the D

levels of these actions combined.

AU 1D+2D+4D in AU Combination 1+2+4

The brow raising and pulling together is severe and the straightening is apparent, but the evidence is less than the criteria for the E levels

of these actions combined.

AU 1E+2E+4E in AU Combination 1+2+4

The brow raising and pulling together is maximum and the straightening is apparent.

Often it is difficult to determine if it is 1+2 or 1+2+4, whether it is 1+4 or 1+2+4, or occasionally whether it is 2+4 or 1+2+4. If

you are having difficulty determining if 1 and 2 have occurred, use the following steps.

First, determine if AU 4 has acted. There must be evidence that the eyebrows have been pulled together and the position of the

eyebrows is sufficient evidence. The following cues may also be helpful, but not required:

wrinkle or muscle bulge between eyebrows.

wrinkle or muscle bulge running down from the forehead above the eyebrow to the middle to inner portion of the eyebrow.

Second, determine if AU 1 has acted. There must be evidence that the inner portion of the eyebrows have been raised and the

raised position of the brow is sufficient. Usual, but not required, is the presence of horizontal wrinkles confined to the middle portion

of the forehead.

Finally, there must be evidence that the lifting action of AU 2 has occurred. If you have determined that AU 4 has acted, you

must expect that the lifting of AU 2 may not be as evident in the position of the brow, as AU 4 tends to lower the brow. The

following cues that the lateral portion of the brow has been raised should be helpful, but not required:

increased exposure of the outer portion of the upper eyelid. If not increased, the lateral, upper eyelid exposure is as much as it is in

increased exposure of the outer portion of the upper eyelid cover fold or at least as exposed as in neutral.

short horizontal wrinkles above the outer portion of the eyebrow that are not continuous with the wrinkles caused by AU 1. These lateral

wrinkles may be completely disconnected from the wrinkles in the middle portion of the forehead, or the horizontal wrinkles often

observed with 1+2 have been disrupted into an irregular pattern by the oblique wrinkle or muscle bulge described as a cue of AU 4.

Use the guidelines that are provided above to determine how 1+2+4i, 1+2+4ii, and j1+2+4 met the criteria above for scoring

their assigned levels of intensity.

Action Unit Combination 1+2+5

A. Appearance Changes due to AU Combination 1+2+5

The combination of these three AUs raises the inner and outer portions of the brow and raises the upper eyelid. Most of the changes

described separately for AU Combination 1+2 and AU 5 are preserved, although the combination of 1+2+5 results in one minor changed

appearance (see appearance change 6 below).

Pulls the entire eyebrow (medial to lateral) upwards.

Produces an arched appearance to the shape of the eyebrow.

Bunches the skin of the forehead so that horizontal wrinkles appear across the entire forehead. These wrinkles may not appear in infants

and children.

Stretches the eye cover fold so that it is more apparent.

Widens the eye aperture.

The upper eyelid may be less evident than in a 1+2 without 5. The upper eyelid raise is as evident as in 5 alone but the disappearance of

the upper eyelid may be diminished by the stretching of the eye cover fold by 1+2.

As a result of the raising of the upper eyelid, more of the upper portion of the eye is exposed. How much is exposed depends upon how

much of the upper portion of the eyeball is normally exposed in the neutral position and how strong is the action of 5. Sclera above the

iris may also be exposed, depending upon the position of the upper lid in the neutral face and how strong is 5.

As a result of the raising of the upper eyelid, the shape of the eye changes as portions medially and/or laterally are pulled up. This

changed shape of the eye usually results in exposure of more sclera adjacent to the iris medially and/or laterally.

If the changes described under (6) and (7) above are strong, the person seems to be staring in a fixed fashion, almost as if the eyeball

was protruding.

If the evidence of 5 is shown in only one eye, score 5 as bilaterally present.

Compare images l+2+5i and 1+2+5ii with 1+2 and with 5i and 5ii. Note that 1+2+5i shows less extreme AU 5 than 1+2+5ii.

Inspect the video of 1+2+5.

5i page 467

5ii page 467

1+2 page 471

1+2+5i page 472

1+2+5ii page 472

1+2+5 video

page 416 for score

B. How to do AU Combination 1+2+5

Follow the instructions for 1+2 and for 5, repeated below. Do 1+2 first then add 5. Add just a weak 5 and then increase the amount of 5.

AU Combination 1+2 (repeated from page 54): This behavior should be easy for you to do. Simply lift your eyebrows up, both

ends as high as you can. Note the wrinkling in your forehead. In some people the wrinkling does not occur but the skin is still

bunched up. In some people these wrinkles are permanently etched (see 0 and w0) but they deepen noticeably when 1+2 acts.

Make sure you are not pulling your brows together (AU 4) when you lift them.

AU 5 (repeated from page 25): This movement is easy. Raise your upper eyelid as hard as you can so you can feel it pushing

upwards against your eye cover fold. Observe whether or not sclera is exposed. If you have any difficulty, just try to open your eyes

as wide as you can, increasing your field of vision and bulging your eyes. Try to do a weak version.

C. Intensity Scoring for AU Combination 1+2+5

The intensity criteria for 1+2+5 are a combination the criteria for 1+2 and 5. The intensity criteria guidelines for combination 1+2 and AU

5 are repeated below. The criteria for 1+2 are oriented to AUs that are roughly equal in strength. Any combination of intensities for

individual AUs can occur in the combinations of 1+2+5 and you have to carefully examine the appearance changes to determine the

relative intensities of the AUs.

AUs 1A+2A in AU Combination 1+2

The appearance changes for AUs 1+2 are sufficiently present to indicate AU 1+2, but are insufficient to score 1B+2B (e.g., the entire

brow is raised a trace).

AUs 1B+2B in AU Combination 1+2

Entire brow raised slightly.

#### If you did not see the brows move it must also meet the additional criteria:

Slight horizontal wrinkles1 or muscle bunching reaching across forehead. If horizontal wrinkles are evident in the neutral face, change

from the neutral appearance must be slight.

Slightly more exposure of eye cover fold than in neutral.

If there is no wrinkling or bunching in the brow, but the brow raise and exposure of the eye cover fold is marked, you can score 1+2.

AU 1C+2C in AU Combination 1+2

Entire brow is raised at least markedly, but less than for level 1D+2D. Wrinkling and eye cover fold exposure should both be evident and

at least one should be at least marked, but the evidence is less than the criteria for 1D+2D.

AU 1D+2D in AU Combination 1+2

Entire brow is raised at least severely. Wrinkling and eye cover fold exposure should both be evident and at least one should be at

least severe, but the evidence is less than the criteria for 1E+2E.

AU 1E+2E in AU Combination 1+2

The entire brow is raised maximally.

The appearance changes for AU 5 are sufficiently present to indicate AU 5, but are insufficient to score 5B (e.g., a trace of upper lid

raising that exposes more of the iris or sclera).

If the upper lid covers part of the iris in the neutral face, upper lid raise must be sufficient to expose virtually (very nearly) the entire iris,

but no more than a hairline of sclera must be exposed above the iris. If more than a hairline of sclera shows, score 5C, 5D, or 5E.

If the entire iris shows in the neutral face, upper lid raise must be sufficient to expose sclera above iris, more than just a hairline of sclera

is required to be exposed, but not much more. If much more than a hairline of sclera, score 5C, 5D, or 5E).

The sclera exposed is more than allowed by the 5B criteria, i.e., if the upper lid covers part of the iris in the neutral face, slightlymore

than a hairline of sclera is exposed; or if entire iris shows in the neutral face, markedly more sclera must be revealed, but the evidence is

less than the criteria for 5D. When the eyes are deeply set or in some Asian faces, you may never see sclera in 5CDE, and you must make

the decision based upon how much wider the eye aperture has become.

The amount of sclera exposed must be severely more than exposed in the neutral face, but the evidence is less than the criteria for 5E.

The upper eyelid is raised as much as the person can do, and close to the maximum sclera that the person can show is exposed above the

iris, and there must be a bulging or staring appearance without doubt.

Intensity may vary for the two sides of the face, but give only one score that represents the higher intensity. Examine photo w5ii.

Note the E level is reached on only one side of the face. But the score of E is given to the entire AU 5.

If you are scoring the face of an infant or child who never shows forehead wrinkles with AUs 1+2 or 1+2+4, then the wrinkling criterion needs to be

discounted, and you must rely on the other criteria.

Action Unit Combinations 6+43E, 7+43E

A. Appearance Changes due to AU Combinations 6+43E, 7+43E

Both combinations involve a closed eye (AU 43E) with the addition of tightening of the muscles around the eye. These two combinations

are best learned by considering them together.

1. The eyes are closed.

1. The eyes are closed.

Skin around a larger circumference than in 7+43E is pulled towards the eye.

2. Skin below the lower eyelid is

pulled towards the root of the

Infraorbital triangle raised, crow's feet wrinkles, and infraorbital furrow may deepen. Due to the

raising of the infraorbital triangle there may be bagging, or wrinkling of skin below the lower eyelid.

The eyebrows may be lowered to a limited extent.

3. Lower eyelid furrow may become

more evident.

The presence of AU 7 in the combination 6+7+43E may be difficult to detect. If you are in doubt about whether AU 7 is present

with 6+43E, score 6+43E. Compare the AU 43E in image 43iii with images 6+43E and 7+43E. Identify the differences between

6+43E and 7+43E. Although the brows are lowered in image 6+43E, the face is not scored as 4+6+43E. To score AU 4 in addition

to AU 6, the brows must also be drawn together. See 4+6 vs. 6 in Table 2-1 on page 41. Also inspect the video of 6+43E and

7+43E. The video shows 6+43E, then 7+43E.

43iii page 469

6+43E page 473

7+43E page 473

video 6+43E/7+43E

page 416 for score

B. How to do AU Combinations 6+43E and 7+43E

You may be able to perform these actions with one eye and look at yourself in the mirror with the other eye. Often, however, people

cannot do such unilateral actions, or cannot do them without muscle spasms. If that is the case, inspect this action on another person.

Close your eyes and relax completely, so you do just AU 43E. Then tighten AU 7 so that the skin of the lids and below the lower lid

tightens, pulling up and in towards the root of the nose. Then squeeze harder, adding AU 6 so that the infraorbital triangle raises, and

crow's feet wrinkles appear. Instructions for AUs 6 and 7 are repeated below.

AU 7 (repeated from page 28): This movement is fairly easy to do. Tense your eyelids but not enough to close your eyelids

completely. Do it as weakly as you can. If you have difficulty, think about narrowing your eye aperture to a slit so that you can see

your eyelashes. Be careful you are not also lowering your eyebrow (AU 4). Be careful you are not also wrinkling your nose (AU 9).

Be careful you are not also raising your cheeks (AU 6).

AU 6 (repeated from page 32): This action is difficult to produce on demand without including other actions, especially 7.

Concentrate on lifting your cheeks without actively raising up the lip corners (that is AU 12). Take time in trying this Action Unit as it

may not be possible to do it at first. If you have difficulty:

Try making AU 15 (see the AU 15 description on page 100). While holding 15 on your face try to lift your cheeks upwards. Once you can do

6+15, try 6 alone.

Try AU 9 (see the AU 9 description on page 93), while holding it on your face add 6. Once you can do 6+9, try 6 alone.

Try AU 12 (see the AU 12 description on page 178), note what happens around your eyes. Now try to do that same appearance without

moving your lip corners.

Try winking, using your cheek in the wink. Note how your cheek lifts. Now do that cheek lift without the wink.

Try squinting your eyes as though to block out a bright sun, and although this motivation is likely to produce AUs 4 and 7 as well, you can

refine these movements to exclude all but AU 6.

C. Intensity Scoring for AU Combinations 6+43E and 7+43E

The intensity criteria for scoring AU 6 in the combination of 6+43E are not changed from AU 6 alone. The criteria for scoring AU 43E in

these combinations are altered only slightly for bilateral versions of these combinations, but the criteria for intensity scoring of AU 7 are

changed significantly in its combination with AU 43E.

If the signs of AU 6 can be scored with 43, then be sure you can see the contribution of AU 7 independently of AU 6 in the form

of lower lid tightening and upward movement of the lower eyelid when you are considering scoring 6+7+43E.

The appearance changes for AU 6 are sufficiently present to indicate AU 6, but are insufficient to score 6B (e.g., slight crow's feet

orslight cheek raise).

Marked change on either criterion 1 or 2 below or slight on both 1 and 2 is sufficient to score 6B.

Crow's feet wrinkles; if present in neutral, they must increase.

Infraorbital triangle raise: cheeks up, infraorbital furrow deepened, and bags or wrinkles under eyes; if present in neutral, the furrow and

either bags or wrinkles under the eyes must increase.

The crow's feet wrinkling and infraorbital triangle raising criteria for 6B are both present and both are at least marked, but the evidence is

less than the criteria for 6D.

The crow's feet wrinkling and infraorbital triangle raising criteria for 6B are both present and both are at least severe, but the evidence is

less than the criteria for 6E.

Crow's feet wrinkling and infraorbital triangle raising are both present, with the infraorbital triangle and cheek raising in

the maximumrange.

The criteria for intensity scoring of AU 7 below are changed significantly in its combination with AU 43E from those for 7alone.

AU 7A in 7A+43E

The appearance changes for AU7 are sufficiently present to indicate AU 7, but are insufficient to score 7B (e.g., slight tightening of the

AU 7B in 7B+43E

Marked tightening of the lids.

#### Slight change on both of the signs below:

tightening of the lids

bulge or pouch in the lower eyelid skin.

AU 7C in 7C+43E

Pronounced tightening of the lids and presence of bagging and/or pouching in the lower eyelid skin, but the evidence is less than the

criteria for 7D.

AU 7D in 7D+43E

Extreme tightening of the lids and presence of bagging and/or pouching in the lower eyelid skin, but the evidence is less than the criteria

AU 7E in 7E+43E

Maximum tightening of the lids and presence of bagging and/or pouching in the lower eyelid skin.

The criteria for intensity scoring of AU 43 below are changed slightly in its combination with AU 7 from those for 43E alone.

AU43E in 7+43E or 6+43E

Eyes are definitely closed and remain closed for more than they are tightened closed.

Unilaterally of 6+43E and 7+43E

If L43E or R43E is scored unilaterally in combination with AUs 6 or 7, use the following criterion for scoring the eye closure:

The closed eye is tightened or squeezed shut for more than 2 seconds

Other Action Unit Combinations in the Upper Face

There are many other combinations of AUs in the upper face which combine two, three, four, or five of the AUs that have been illustrated

and discussed. They can be scored by examining combinations of appearance changes of the units or combinations that are described

above. They do not modify the appearance changes associated with the units explained earlier, but add appearance changes. They also do

not change the criteria for intensity scoring of the Action Units, but combine the rules for their component elements.

There is one exception which has to do with the intensity scoring for scoring AU 5 in certain combinations with AU 4. The

Reference section for AU 5 on page 26 lists the combinations containing AU 5 where the criteria for scoring intensity of AU 5 differ

from what is required when 5 is alone. In these combinations in the table, the action of AU 4 pushes down on the upper eyelid,

changing the criteria for scoring AU 5.

Note that 1+2+4+5 (see Figure 2-2), is not listed in this Table, even though it contains a 4 action. The upward pull of 1+2

counteracts the effects of AU 4 pushing down the upper lid, and therefore the intensity criteria for AU 5 alone are applied to this

combination. If only AU 1 or 2 combines with 4+5 or 4+5+7, then the effect of AU 4 is not counteracted and the revised criteria for

scoring the intensity of 5 as described after the Reference for AU 5 on page 26 are applied.

In all combinations including AU 5 which are not listed in the table in the Reference section for AU 5, the intensity criteria for AU

5 are the same as for AU 5 when it acts alone.

Figure 2-2 Action Unit combination 1+2+4+5

Subtle Differences Involving Action Units in the Upper Face

Table 2-2 lists characteristics of actions and combinations that can help you distinguish between sets of behaviors that differ only subtly.

Some of these subtle differences are between a single Action Unit and a combination of AUs; some are between two different

combinations. Since you will use this material as a reference when you encounter difficulties in scoring upper face behavior, the

information listed earlier on the subtle differences between single Action Units is repeated for easy reference.

Read Table 2-2 carefully. Study the relevant images and videos. Refer to Appendix I to locate the video comparisons that can be

Subtle Differences

#### In 1+4 but not 1:

inner eyebrow corners pulled together.

vertical wrinkle or muscle bulge between eyebrows.

1+4 more than 1:

if the eyebrow shape becomes oblique, it is more evident in 1+4.

if the eyebrow shape has a dip in the center and goes up at inner corner, it is more evident in 1+4.

#### May be present in 1+4 not in 1:

oblique wrinkle or muscle bulge running from the forehead above the eyebrow's center down medially towards inner corner of

Difficult only because in some people the action of 1+2 may lift the upper eyelid to a limited extent. Since you won't know when

this is the case, if the signs of 5 are present you score it as 1+2+5.

#### Present in 1+2+5 but not in 1+2:

if in neutral top portion of iris covered by upper eyelid, then all of top of iris should be revealed.

if in neutral iris top shows, then sclera is revealed.

person seems to be staring in fixed fashion if the 5 is strong.

See description in this table of difference between 1+2 and 1+2+4.

If there is clear evidence of 6, then to score 4+6, the brows must not only be lowered, but also must be pulled together.

When it appears that AU 5 has acted on only the left or right side, it is very likely that there is at least a trace of movement of the

other upper eyelid. If there is at least a trace, score AU 5 as bilateral and score the intensity of the eyelid raise equal to the side with

greater intensity. Be very cautious about scoring U5 to be certain there is no trace on the other side.

AU 7 is very difficult to detect when simultaneously involved with AU 6, and the more intense the 6, the more it covers the action

of 7. First, check for signs of asynchrony in the actions of 6 and 7. Look at the moments when these AUs begin to act or later when

they relax. For example, if the lower eyelid is pulled medially during initial action of a possible 6+7, then AU 7 is acting with 6. If

during relaxation the extreme inner corner of the lower eyelid moves laterally and not only downward, AU 7 must have been on the

face, not 6 alone. Second, check the signs of 7 that 6 does not produce. Besides the medial pulling of the lower eyelid by 7, AU 7,

not 6, pulls the upper eyelid down. AU 6 pushes the skin of the lower eyelid up to produce wrinkling in the lower eyelid, but AU

7 pulls it up even more onto the eyeball to cover more of the eyeball than 6 alone can do. Often, you can distinguish this wrinkling

of the lower eyelid, which can be produced by either 6 or 7, from the bulging of the skin as it is pulled up onto the eyeball by AU 7.

If in doubt that 7 has acted with 6, score 6 alone.

Both AUs share the appearance changes of narrowing the eye aperture, and changing the appearance of the skin below the lower

the most important difference is that the infraorbital triangle is raised in 6 but not in 7: evident in more prominent, raised cheeks

and a more apparent or deepened infraorbital furrow which takes on a more horizontal or crescent shape.

AU 6 can lower the outer corner of the eyebrow while AU 7 cannot.

the bagging or wrinkling of the skin below the eye occurs more in 6 than in 7 and extends further down the face in 6 than in 7.

crow's feet in 6 not in 7; or, if in 7, a single line or wrinkle (or toe), not many lines or wrinkles (or feet).

some pulling upwards of upper-lip and skin above upper-lip in an extreme 6, but not in 7.

skin below the eye is drawn up and medially towards the inner corner of the eye in 7, not 6.

a bulge may appear in the lower eyelid skin in both 6 and 7, although it is due to a different action (pulling of the skin over the

eyeball in 7, or pushing of the skin up by the drawing in action of 6), and usually appears somewhat different.

AU 6, unlike 7, pushes down on the eye cover fold by constricting skin above it.

If you are uncertain whether the signs of 6 have increased from neutral, consider scoring 7 or 11. If 6 is evident on one side of the

face and 7 on the other side, score bilateral 6, unless the purpose of the study is to examine asymmetry.

In drawing the skin in towards the eye, AU 6 makes it difficult to see the lid tightening action of AU 7. When the question is

whether AUs 6 and 7 have combined, watch for the independent tightening and movement of the lower eyelid in these

combinations. When the onset or offset of the two AUs is not synchronized, the AU 7 is more easily detectable. Also, check for

signs of 7 that are not produced by 6 alone, as indicated in the comparison of 6 vs. 6+7 above. If you cannot detect independent

evidence of the 7 from the 6, do not score the 7.

In addition to the signs of 6, the upper eyelids are relaxed so the eyes are almost closed in a slit in 6+43D. Note that neither upper

nor lower eyelid can be tensed in 6+43, if so, AU 7 must be present.

The eyes are closed in these combinations. In 7+43E the tightening affects primarily the eyelids, while in 6+43E the infraorbital

triangle is raised and crow's feet wrinkles appear.

When the eyes are squeezed and closed by the combination of AUs 6 and 43E, the addition of AU 7 can be difficult to see. When

considering scoring both 6 and 7 in addition to 43, look carefully for the independent tightening and movement of the lower lid

caused by 7 before scoring this combination.

AU 7E produces a squinting, narrowed eye aperture. AU 6 can narrow the eye aperture, but with different appearances from AU 7

(see Subtle Differences for 6 vs. 7), and AU 6 can act without causing an eye squint. If in addition to the squint of 7E, you see the

signs of AU 6, infraorbital triangle raise, drawing skin from the temple and cheeks towards the eye, etc., score as 6+7E. If you only

see the squint without these signs of 6, score 7E alone.

AU 43 can be scored without scoring 7. On the other hand, with all but the weakest 7, it is rare that 7 can be scored without

evidence of at least a trace of upper lid lowering or 43A, unless AU 5 has acted with 7 to lift the upper eyelid. If 7 is scored, it is not

necessary to score 43 and its intensity unless the study is examining the degree of eye closures, regardless of the action that causes

them. (Scoring 43E is always recommended, however.) If upper eyelid closure is being scored comprehensively and 7 can be

scored and the upper lid is lowered, score 7+43 and score the intensity of 43 to reflect the degree that the upper eyelid is pulled

In both 43B and 7 there is a narrowing of the eye aperture, but the action that is responsible differs. In 7 it is primarily a tightening

action, while in 43 alone it is primarily due only to drooping or relaxing. AU 7 is more visible on the lower eyelid although it

changes both lids, while 43 is an upper eyelid action. In 43B the upper eyelid is so relaxed that it droops down covering more of

the iris than in neutral. In 7 the lids are tightened, the lower lid raised by the tightening, the upper lid pulled down. The clue to 7 is

watching the lower lid go up, the skin below the lower lid pulled towards the root of the nose, and the bulging of the skin in the

In both 7E and 43D the eye aperture is very narrow. However, 43D is primarily an upper eyelid action; the upper eyelid being

lowered gently or relaxed so that the eye is almost closed. AU 7E is 7 at its most extreme intensity; therefore, the narrowing of the

eye aperture is due to the extreme raising and tensing of the lower lid and pulling down of the upper lid. If the cues of AU 7 are

clearly present and the eyes are open only a slit, and a comprehensive scoring of eye closure is not required, score it as 7E;

otherwise, score 7E+43.

In 43E alone the eyelids appear relaxed. In 7+4E3 the eyelids are tightened together, not relaxed.

In 43E, the eyes are definitely closed for at least that the lids are touching or resting on each other, and the lashes are together. The

upper and lower eyelids touch together and stay together for at least lids, score 43D not 43E. You cannot see any part of the eyeball

between the lids or the glistening of the lower lid's wet tissues when the eyes close, and the lower eyelashes are obscured by the

upper lid and lashes when an eye closes. If the eyes are almost closed, score 43D.

If the eyes remain closed for more than actions are unilateral, see U43E vs. 46 and U45 vs. 46.

AU 46 must be unilateral. If the eye closure is longer than 2 seconds, it must be 43E or some combination of 6 or 7 with 43E. If the

eye closure is under 2 seconds, but longer than lateral eye closure or a wink. Decide by determining if you think there was an

intentional quality to the closure, perhaps shown in the movement itself or by an accompanying head movement, or deliberate

pause during the moment the eye is closed. These are signs of the wink (AU 46), not an eye closure (AU 43E). As AU 46 must be

unilateral, score R46 or L46.

In a wink one eye closes and is usually held closed longer than a blink. A blink cannot exceed duration, but a wink can be as long

as 2 seconds. Therefore, the only difficulty in distinguishing a wink from a blink is when the eye closure is unilateral and does not

exceed is less than

Table 2-2: Subtle Differences for Action Units in the Upper Face

Alternative Rules Involving Upper Face Actions

Table 2-3 shows the alternate scores for upper face actions.

Alternative

If the upper lid is raised, it cannot also be scored as narrowed by 43 (e.g., drooped, closed to a slit, closed), tightened in 7E (a

squint), closed in a blink, or closed in a wink.

If the eyelid closure is decreasing, but the eyes remain open, they cannot also be scored closed in a blink or a wink. If the eyes

are closed in 43E, they cannot also be scored in a blink or in a wink because of the time of closure criterion.

If the eyes are in a blink, they cannot also wink.

Table 2-3: Alternative rules for upper face actions 1

In scoring facial behavior, if you see evidence of one AU listed in an Alternative table, you cannot score the presence of another AU paired with it in the

table. The symbol @ is used to stand for the word \`alternative.'

Reference Example Images

Common questions

Powered by AI

How can discrepancies between individual's facial features affect the scoring of Action Units?

Discrepancies in individual facial features can affect AU scoring by creating variability in how AUs manifest as appearance changes. For instance, some individuals may display permanent wrinkles that deepen with specific AUs, or exhibit subtle variations in eye aperture and skin bunching, impacting the standard criteria used for scoring. Coders must account for these variations and apply the intensity criteria contextually, sometimes altering scores based on individual differences in appearance .

How does Action Unit 7 differ in its effect on eyelids compared to other units like 43?

AU 7 primarily causes a tightening action, affecting both the upper and lower eyelids by raising the lower lid and pulling the upper lid down. In contrast, AU 43, especially in 43B, is characterized by drooping or relaxing of the upper eyelid, leading to a gentle lowering without tightening. The key difference lies in AU 7's visible effect on tightening and bulging of the skin in the lower eyelid, which AU 43 alone does not produce .

What role do Subtle Difference Tables play in the understanding of AUs according to the Manual?

Subtle Difference Tables help clarify the nuanced distinctions between individual AUs and their combinations, guiding coders in recognizing specific appearance changes and the unique combinations that create distinctive appearances. By comparing these subtle differences, coders can develop a more accurate comprehension when scoring facial expressions .

What are the distinctive appearance changes that occur in an AU combination that are not merely additive?

In AU combinations where the appearance changes are not simply additive, distinctively new appearance changes appear. These distinctive combinations alter appearance changes, creating features that differ from the sum of individual AUs. For example, in the 1+2+4 combination, the opposed lifting of the eyebrows by 1+2 and lowering by 4 interact to create a unique appearance with different wrinkle patterns in the forehead compared to the individual AUs acting alone .

In the AU Combination 4+5, what alterations are made to the criteria for intensity scoring of these units compared to them acting separately?

In the 4+5 combination, the criteria for AU 5 are significantly altered compared to when AU 5 acts alone. Many of AU 5's changes are concealed by AU 4, requiring adapted intensity scoring criteria to accurately reflect the combined effects. Meanwhile, the criteria for AU 4 remain unchanged, as its appearance is largely unaffected by AU 5 .

Why is it important for a coder to practice scoring in diverse situations according to the Manual?

Practicing scoring in diverse situations is essential for coders to gain the experience needed to accurately detect signs and assign scores. This hands-on experience aids in refining their understanding of the range of appearance changes and developing the ability to apply Manual's guidelines effectively across different individuals and conditions .

What is the significance of identifying non-additive effects in AU combinations?

Identifying non-additive effects in AU combinations is significant for accurately interpreting facial expressions, as these effects produce distinct appearances that differ from the sum of individual AUs. Recognizing these distinctive changes is crucial for precise scoring, especially when one AU modulates or conceals the expression of another, requiring adjusted criteria to match the observed changes .

How does the Manual suggest a reader should approach understanding the combination of Action Units (AUs)?

The Manual advises readers not to attempt to immediately resolve unclear issues regarding AU combinations. Instead, readers should continue reading to the AU Combinations section in a chapter before returning to earlier sections to enhance understanding of the A, B, and C sections for individual AUs. This progressive approach allows for a better grasp of the distinctions between individual and combined AUs, as the Manual gradually explains subtle differences among AUs and their combinations .

What role do appearance changes play in scoring the intensity of Action Units (AUs)?

Appearance changes are crucial for scoring AU intensity, as they provide observable cues that determine both the presence and the level of intensity of each AU. Coder's task is to assess these changes in total and consider how they contribute to the overall appearance to score the intensity appropriately. The movements of the skin, which manifest as bunching, bagging, or wrinkling, form the evidence needed to deduce the specific AUs involved and their intensity level .

How should a coder approach scoring if faced with overlapping appearance changes caused by multiple AUs?

When multiple AUs cause overlapping appearance changes, a coder must differentiate to determine which AU or combination best explains the appearances. This may involve setting criteria for higher intensity levels to account for the overlap. Qualified criteria are sometimes specified for scoring when combinations modify the appearance changes from what would be expected from individual AUs. Coders should use these modified criteria, found after the single AU criteria, to ensure accurate scoring .

You might also like

FACS: Facial Action Coding System Guide

https://www.scribd.com/document/747053328/FACS-Facial-Action-Coding-System

PDF 100% (1) FACS: Facial Action Coding System Guide 5 pages

Facs Lie To Me Paul Ekman

https://www.scribd.com/document/516014376/FACS-LIE-TO-ME-PAUL-EKMAN

PDF 100% (3) Facs Lie To Me Paul Ekman 181 pages

https://www.scribd.com/doc/51247620/InvGuide

PDF No ratings yet Inv Guide 197 pages

Head and Eye Movement in FACS

https://www.scribd.com/document/423950950/Paul-Ekman-Manual-FACS-Pages-352-357-Converted

PDF No ratings yet Head and Eye Movement in FACS 6 pages

FACES: A Dimensional Facial Coding Guide

https://www.scribd.com/document/650104607/FACES-manual

PDF No ratings yet FACES: A Dimensional Facial Coding Guide 14 pages

FACS: Understanding Facial Expressions

https://www.scribd.com/document/232142142/Facial-Action-Coding-System

PDF No ratings yet FACS: Understanding Facial Expressions 13 pages

Facial Action Coding System (FACS) : A White Paper by Noldus Information Technology

https://www.scribd.com/document/562117295/noldus-white-paper-facs

PDF No ratings yet Facial Action Coding System (FACS) : A White Paper by Noldus Information Technology 11 pages

Understanding Micro Expressions in Body Language

https://www.scribd.com/presentation/416032207/Non-Verbal-Body-Language-and-Microexpression

PDF 100% (5) Understanding Micro Expressions in Body Language 116 pages

Scoring Head and Eye Positions in FACS

https://www.scribd.com/document/423951190/Paul-Ekman-Manual-FACS-Paginas-341-345-Convertido

PDF No ratings yet Scoring Head and Eye Positions in FACS 5 pages

Paul Ekman Umasking The Face

https://www.scribd.com/document/230038662/Paul-Ekman-Umasking-the-Face

PDF 91% (11) Paul Ekman Umasking The Face 228 pages

Paul Ekman - What The Face Reveals PDF

https://www.scribd.com/doc/313566379/Paul-Ekman-What-The-Face-Reveals-pdf

PDF 100% (1) Paul Ekman - What The Face Reveals PDF 256 pages

Free PDF: Facial Action Coding System

https://www.scribd.com/document/358869551/Facial-Action-Coding-System-Free-PDF-eBook

PDF 25% (4) Free PDF: Facial Action Coding System 2 pages

Scoring Criteria for Lip Tightening

https://www.scribd.com/document/423954667/Paul-Ekman-Manual-FACS-Paginas-251-300-Convertido

PDF No ratings yet Scoring Criteria for Lip Tightening 50 pages

Intuition Practice: Emotion Recognition

https://www.scribd.com/document/49031258/Practice-Faces

PDF 80% (5) Intuition Practice: Emotion Recognition 6 pages

Guide to Reading Microexpressions

https://www.scribd.com/document/391419396/Guide-to-Reading-Microexpressions

PDF 100% (1) Guide to Reading Microexpressions 8 pages

Micro-Expressions: Detecting Lies & Emotions

https://www.scribd.com/presentation/200654998/Micro-Expressions2-120304225507-Phpapp02

PDF 100% (6) Micro-Expressions: Detecting Lies & Emotions 49 pages

Facual Recognition Technology

https://www.scribd.com/document/578003095/Facual-recognition-technology

PDF No ratings yet Facual Recognition Technology 17 pages

Insights from Paul Ekman's Emotions Revealed

https://www.scribd.com/doc/151915333/Emo-2

PDF No ratings yet Insights from Paul Ekman's Emotions Revealed 1 page

Mastering Human Lie Detection Techniques

https://www.scribd.com/document/261535271/Slides-How-to-Be-a-Human-Lie-Detector

PDF 100% (5) Mastering Human Lie Detection Techniques 89 pages

Training Planner Sample

https://www.scribd.com/document/440895185/training-planner-sample

PDF 60% (10) Training Planner Sample 6 pages

Pan Cultural Elements in Facial Display of Emotion PDF

https://www.scribd.com/doc/268465748/Pan-Cultural-Elements-In-Facial-Display-Of-Emotion-pdf

PDF No ratings yet Pan Cultural Elements in Facial Display of Emotion PDF 2 pages

John R. Schafer, Joe Navarro - Advanced Interviewing Techniques (2016)

https://www.scribd.com/document/697790470/John-R-Schafer-Joe-Navarro-Advanced-Interviewing-Techniques-2016

PDF 100% (5) John R. Schafer, Joe Navarro - Advanced Interviewing Techniques (2016) 219 pages

The Behavioral Table of Elements: Cell Key Index Gesture Types

https://www.scribd.com/document/505699565/the-behavioral-table-of-elements-version-2-0-1-1

PDF 100% (7) The Behavioral Table of Elements: Cell Key Index Gesture Types 12 pages

Imotions Guide FacialExpressions 2016 PDF

https://www.scribd.com/document/318318555/iMotions-Guide-FacialExpressions-2016-pdf

PDF 100% (2) Imotions Guide FacialExpressions 2016 PDF 44 pages

Facial Action Coding System Manual

https://www.scribd.com/document/433607509/Chapter-2

PDF No ratings yet Facial Action Coding System Manual 106 pages

FACS Manual: Facial Action Coding System

https://www.scribd.com/document/402879164/pe-pdf

PDF No ratings yet FACS Manual: Facial Action Coding System 527 pages

Understanding Facial Action Coding System

https://www.scribd.com/document/972749613/Facial-Action-Codes

PDF No ratings yet Understanding Facial Action Coding System 3 pages

Facial Action Coding System Explained

https://www.scribd.com/document/956123562/Facial-Coding-System

PDF No ratings yet Facial Action Coding System Explained 10 pages

Facial Action Coding System Practice Guide

https://www.scribd.com/document/423953910/expresiones

PDF No ratings yet Facial Action Coding System Practice Guide 50 pages

Thermal Patterns in Facial Expressions

https://www.scribd.com/document/78989044/Thermall-Analysis-of-Facial-Ms

PDF No ratings yet Thermal Patterns in Facial Expressions 8 pages

Understanding Ekman's Basic Emotions

https://www.scribd.com/doc/193321494/17-BasicEmotions-v1

PDF No ratings yet Understanding Ekman's Basic Emotions 39 pages

Understanding the Facial Action Coding System

https://www.scribd.com/document/727411964/FACSChapter-SAGEEncyclopedia

PDF No ratings yet Understanding the Facial Action Coding System 6 pages

Understanding Facial Expressions in Animation

https://www.scribd.com/doc/86450117/Facial-Expressions

PDF No ratings yet Understanding Facial Expressions in Animation 37 pages

Lower Face Action Units Explained

https://www.scribd.com/document/427097406/page-103

PDF No ratings yet Lower Face Action Units Explained 1 page

Express Yourself Workshop Note Guide

https://www.scribd.com/document/815538412/Express-Yourself-Workshop-Note-Guide

PDF No ratings yet Express Yourself Workshop Note Guide 6 pages

Comprehensive Facial Expression Database

https://www.scribd.com/document/392191950/Cohn-Kanade-Database

PDF No ratings yet Comprehensive Facial Expression Database 8 pages

Overview of Facial Action Coding System

https://www.scribd.com/document/488567627/Facial-Action-Coding-System

PDF No ratings yet Overview of Facial Action Coding System 34 pages

Facial Expressions and Emotions Guide

https://www.scribd.com/doc/272068817/Chapter-3-Assignment

PDF No ratings yet Facial Expressions and Emotions Guide 2 pages

Evaluating FACS Reliability in Emotions

https://www.scribd.com/document/80353884/Paper-of-Ekman

PDF No ratings yet Evaluating FACS Reliability in Emotions 17 pages

Comprehensive Facial Expression Database

https://www.scribd.com/document/39450954/10-1-1-41

PDF No ratings yet Comprehensive Facial Expression Database 8 pages

Facial Action Coding System Overview

https://www.scribd.com/document/18649644/Facial-Action-Coding-System

PDF 82% (11) Facial Action Coding System Overview 9 pages

Facial Musculature and Expression Analysis

https://www.scribd.com/document/451978299/Lecture-8-Face-Representation-pdf

PDF No ratings yet Facial Musculature and Expression Analysis 143 pages

Nonverbal Emotion Representation in CAVE

https://www.scribd.com/presentation/55534269/Intermediary-2

PDF No ratings yet Nonverbal Emotion Representation in CAVE 24 pages

FACS: Facial Action Coding System Guide

https://www.scribd.com/document/937413259/FACS-Facial-Action-Coding-System

PDF No ratings yet FACS: Facial Action Coding System Guide 5 pages

10 Ways To Screw Up An Ad Campaign and How To Create Ones That Work Barry H Cohen

https://www.scribd.com/document/1014371741/10-Ways-To-Screw-Up-An-Ad-Campaign-And-How-To-Create-Ones-That-Work-Barry-H-Cohen

PDF No ratings yet 10 Ways To Screw Up An Ad Campaign and How To Create Ones That Work Barry H Cohen 71 pages

Overview of the Facial Action Coding System

https://www.scribd.com/document/261047016/Facial-Action-Coding-System

PDF No ratings yet Overview of the Facial Action Coding System 14 pages

Abnormal Involuntary Movement Scale Guide

https://www.scribd.com/document/522773327/Abnormal-Involuntary-Movement-Scale

PDF No ratings yet Abnormal Involuntary Movement Scale Guide 2 pages

Anatomy and Development of the Face

https://www.scribd.com/document/838050417/Face-Lecturef02f-Copy

PDF No ratings yet Anatomy and Development of the Face 30 pages

Facial Action Units and Expressions Analysis

https://www.scribd.com/document/340017249/Pages-de-Cohn-Kanade-Database

PDF No ratings yet Facial Action Units and Expressions Analysis 1 page

Understanding Facial Action Units

https://www.scribd.com/document/519441104/Action-Units

PDF No ratings yet Understanding Facial Action Units 2 pages

What the Face Reveals: FACS Insights

https://www.scribd.com/document/824353153/What-the-Face-Reveals

PDF No ratings yet What the Face Reveals: FACS Insights 11 pages

Pone 0223905

https://www.scribd.com/document/850127823/pone-0223905

PDF No ratings yet Pone 0223905 18 pages

Sensory Integration Clinical Observations

https://www.scribd.com/document/956181584/Clinical-Observations-of-Sensory-Integration

PDF No ratings yet Sensory Integration Clinical Observations 7 pages

Facial Anatomy and Expression Mechanics

https://www.scribd.com/document/31564992/Face-Lecturef02f

PDF No ratings yet Facial Anatomy and Expression Mechanics 29 pages

AIMS Examination and Scoring Guide

https://www.scribd.com/document/829573644/AIMS-test

PDF No ratings yet AIMS Examination and Scoring Guide 1 page

Hammersmith Infant Neurological Exam

https://www.scribd.com/document/972840993/HINE-Proforma-07-07-17-With-Hypotonia-Score

PDF No ratings yet Hammersmith Infant Neurological Exam 5 pages

Understanding Nonverbal Communication

https://www.scribd.com/presentation/329485697/Non-Verbal-Communication-Business-Comm

PDF 100% (1) Understanding Nonverbal Communication 12 pages

@ebookmedicin MD DYNA CODES 2018

https://www.scribd.com/document/764067732/Ebookmedicin-MD-DYNA-CODES-2018

PDF 100% (3) @ebookmedicin MD DYNA CODES 2018 60 pages

Hammersmith Infant Neurological Exam

https://www.scribd.com/document/943797411/HINE-proforma-Spanish-25-02-19

PDF No ratings yet Hammersmith Infant Neurological Exam 5 pages

Long-Distance Facial Affect Transmission

https://www.scribd.com/document/473116004/Long-Distance-Transmission-of-Facial-Affect-Signals

PDF No ratings yet Long-Distance Facial Affect Transmission 6 pages

Understanding Neuromarketing Dynamics

https://www.scribd.com/presentation/330737625/Citat-Final

PDF No ratings yet Understanding Neuromarketing Dynamics 1 page

Marketing Research in Non-Profit Organizations: Professor Muris Čičić

https://www.scribd.com/presentation/330734687/Non-Profiit-MIS

PDF No ratings yet Marketing Research in Non-Profit Organizations: Professor Muris Čičić 50 pages

AIESEC and EYP: Non-Profit Insights

https://www.scribd.com/presentation/330734621/Mno

PDF No ratings yet AIESEC and EYP: Non-Profit Insights 14 pages

1930s America: Great Depression & Culture

https://www.scribd.com/presentation/330734204/Golden-1930-s-Prezentacija

PDF No ratings yet 1930s America: Great Depression & Culture 12 pages

How To Read People

https://www.scribd.com/document/325603945/How-to-Read-People-1

PDF No ratings yet How To Read People 93 pages

FDR's New Deal Response to the 1930s

https://www.scribd.com/document/330734090/1930

PDF No ratings yet FDR's New Deal Response to the 1930s 7 pages

Face Expression

https://www.scribd.com/document/325603372/Face-Expression-1

PDF 0% (1) Face Expression 18 pages

Fundamentals of Human Neuropsychology 8th Ed.

https://www.scribd.com/document/667551631/OceanofPDF-com-Fundamentals-of-Human-Neuropsychology-Kolb-BryanWhishaw-Ian-Q

PDF 100% (16) Fundamentals of Human Neuropsychology 8th Ed. 2,880 pages

The Neuropsychology of Emotion

https://www.scribd.com/document/134090796/The-Neuropsychology-of-Emotion

PDF 96% (54) The Neuropsychology of Emotion 532 pages

An Introduction To Brain and Behavior

https://www.scribd.com/document/663003505/An-Introduction-to-Brain-and-Behavior

PDF 100% (12) An Introduction To Brain and Behavior 2,471 pages

The Neuroscience of Intelligence

https://www.scribd.com/document/383934733/The-Neuroscience-of-Intelligence

PDF 100% (19) The Neuroscience of Intelligence 346 pages

DSM-5 Insanely Simplified

https://www.scribd.com/document/518196288/DSM-5-Insanely-Simplified

PDF 98% (44) DSM-5 Insanely Simplified 140 pages

Essentials of Neuropsychology

https://www.scribd.com/document/729786475/Essentials-of-Neuropsychology

PDF 91% (11) Essentials of Neuropsychology 201 pages

Functions of The Brain - A Conceptual Approach To Cognitive Neuroscience - Kok

https://www.scribd.com/document/492444686/Functions-of-the-Brain-A-Conceptual-Approach-to-Cognitive-Neuroscience-Kok

PDF 100% (16) Functions of The Brain - A Conceptual Approach To Cognitive Neuroscience - Kok 391 pages

Cognitive Neuroscience of Attention (Michael I. Posner (Ed.) )

https://www.scribd.com/document/621366623/Cognitive-Neuroscience-of-Attention-Michael-I-Posner-ed-z-lib-org

PDF 100% (14) Cognitive Neuroscience of Attention (Michael I. Posner (Ed.) ) 531 pages

Handbook of Personality Disorders PDF

https://www.scribd.com/document/485605209/HANDBOOK-OF-PERSONALITY-DISORDERS-pdf

PDF 95% (19) Handbook of Personality Disorders PDF 730 pages

Affective Neuroscience - Panksepp Jaak

https://www.scribd.com/document/488762664/Affective-Neuroscience-Panksepp-Jaak

PDF 94% (17) Affective Neuroscience - Panksepp Jaak 1,128 pages

Textbook of Personality Disorders

https://www.scribd.com/document/556105682/Textbook-of-Personality-Disorders

PDF 94% (18) Textbook of Personality Disorders 618 pages

Neurobiology of Mental Illness PDF

https://www.scribd.com/document/483478102/Neurobiology-of-Mental-Illness-booksmedicos-org-pdf

PDF 100% (13) Neurobiology of Mental Illness PDF 1,259 pages

The Interoceptive Mind PDF

https://www.scribd.com/document/444353534/The-Interoceptive-Mind-pdf

PDF 100% (16) The Interoceptive Mind PDF 369 pages

The Cambridge Handbook of Personality Psychology PDF

https://www.scribd.com/document/402021573/The-Cambridge-Handbook-of-Personality-Psychology-pdf

PDF 100% (23) The Cambridge Handbook of Personality Psychology PDF 906 pages

Cognitive Therapy Therapy Techniques For Retraining Your Brain - Jason M. Satterfield

https://www.scribd.com/doc/279581889/Cognitive-Therapy-Therapy-Techniques-for-Retraining-Your-Brain-Jason-M-Satterfield

PDF 97% (76) Cognitive Therapy Therapy Techniques For Retraining Your Brain - Jason M. Satterfield 222 pages

A Students Dictionary of Psychology and Neuroscience, 7th Edition (Hayes, Nicky, Stratton, Peter)

https://www.scribd.com/document/576480694/A-Students-Dictionary-of-Psychology-and-Neuroscience-7th-Edition-Hayes-Nicky-Stratton-Peter

PDF 100% (16) A Students Dictionary of Psychology and Neuroscience, 7th Edition (Hayes, Nicky, Stratton, Peter) 435 pages

Cognitive Neuroscience

https://www.scribd.com/document/85088695/Cognitive-Neuroscience

PDF 91% (23) Cognitive Neuroscience 526 pages

Bessel Van Der Kolk - The Body Keeps The Score - Brain, Mind, and Body in The Healing of Trauma-Penguin (2014)

https://www.scribd.com/document/665425801/Bessel-Van-Der-Kolk-The-Body-Keeps-the-Score-Brain-Mind-And-Body-in-the-Healing-of-Trauma-Penguin-2014

PDF 100% (28) Bessel Van Der Kolk - The Body Keeps The Score - Brain, Mind, and Body in The Healing of Trauma-Penguin (2014) 490 pages

Overview of the Five Factor Model

https://www.scribd.com/document/720947308/OXFORD-HANDBOOK-OF-THE-FIVE-FACTORS-MODEL

PDF 100% (10) Overview of the Five Factor Model 1,120 pages

Oxford Textbook of Psychopathology, 3rd Edition

https://www.scribd.com/document/613206930/Oxford-Textbook-of-Psychopathology-3rd-Edition

PDF 100% (15) Oxford Textbook of Psychopathology, 3rd Edition 873 pages

Gazzaniga. The Cognitive Neurosciences

https://www.scribd.com/doc/241226297/Gazzaniga-the-Cognitive-Neurosciences

PDF 91% (22) Gazzaniga. The Cognitive Neurosciences 1,377 pages

Human Affective Neuroscience (The Cambridge Handbook Of)

https://www.scribd.com/document/387039137/Human-Affective-Neuroscience-The-Cambridge-Handbook-of

PDF 93% (14) Human Affective Neuroscience (The Cambridge Handbook Of) 698 pages

Brain Mapping An Encyclopedic Reference (-PUNISHER-)

https://www.scribd.com/document/322300259/Brain-Mapping-an-Encyclopedic-Reference-PUNISHER

PDF 100% (14) Brain Mapping An Encyclopedic Reference (-PUNISHER-) 2,668 pages

Oxford Handbook of Human Motivation

https://www.scribd.com/document/654786935/Richard-Ryan-The-Oxford-Handbook-of-Human-Motivation-Oxford-University-Press-2019

PDF 100% (7) Oxford Handbook of Human Motivation 561 pages

Neurosciense of Memory

https://www.scribd.com/document/481857765/Neurosciense-of-memory

PDF 92% (13) Neurosciense of Memory 330 pages

Handbook of Neuroscience For The Behavioral Sciences 2 Vol Set Wiley (2009) PDF

https://www.scribd.com/document/453345969/Handbook-of-Neuroscience-for-the-Behavioral-Sciences-2-Vol-Set-Wiley-2009-pdf

PDF 100% (7) Handbook of Neuroscience For The Behavioral Sciences 2 Vol Set Wiley (2009) PDF 1,307 pages

Joseph LeDoux - (2014) - The Emotional Brain Revisited

https://www.scribd.com/document/394992007/Joseph-LeDoux-2014-The-Emotional-Brain-Revisited

PDF 100% (11) Joseph LeDoux - (2014) - The Emotional Brain Revisited 373 pages

Handbook of Applied Behavior Analysis (Wayne W. Fisher)

https://www.scribd.com/document/586574646/Handbook-of-Applied-Behavior-Analysis-Wayne-W-Fisher

PDF 100% (15) Handbook of Applied Behavior Analysis (Wayne W. Fisher) 643 pages

Romfracht Fiber Calculation Summary

https://www.scribd.com/document/824325217/Calcul-2-Dozaj-Fibre-Polipropilena-RoFero-Proiectare-Imosteel-23-01-2025

PDF No ratings yet Romfracht Fiber Calculation Summary 8 pages

Teaching Research Skills to Undergraduates

https://www.scribd.com/document/512577075/Articulo-s

PDF No ratings yet Teaching Research Skills to Undergraduates 35 pages

PLEXCO Pipe Fusion Qualification Guide

https://www.scribd.com/document/536969122/PLEXCO-Bulletin-No-105-Y-Yellowpipe-2406-Fusion-Procedures

PDF No ratings yet PLEXCO Pipe Fusion Qualification Guide 15 pages

Earth's Major Environmental Threats

https://www.scribd.com/document/713095211/aQUILA-1

PDF No ratings yet Earth's Major Environmental Threats 2 pages

Family, Life, and Environmental Ethics

https://www.scribd.com/document/901599015/Nurse-101

PDF No ratings yet Family, Life, and Environmental Ethics 4 pages

Understanding Human Acts and Morality

https://www.scribd.com/document/751207815/BANDADA-CHAPTER-3-ETHICS

PDF No ratings yet Understanding Human Acts and Morality 13 pages

HAZOP Study Overview and Process

https://www.scribd.com/document/675563283/Hazard-Operability-Study-HAZOP

PDF No ratings yet HAZOP Study Overview and Process 14 pages

Tameana: Vibrational Healing Practice

https://www.scribd.com/document/972278121/H-ama-Tameana

PDF 100% (1) Tameana: Vibrational Healing Practice 8 pages

Auto Expo 2023 Project Report Overview

https://www.scribd.com/document/727950513/Project-Management-Project

PDF No ratings yet Auto Expo 2023 Project Report Overview 14 pages

Aviation Management Curriculum Renewal Report

https://www.scribd.com/document/788423731/Aviation-Management-PDFDrive-1

PDF No ratings yet Aviation Management Curriculum Renewal Report 145 pages

Overview of Statistics and Data Analysis

https://www.scribd.com/document/720082041/umehabiba-2340-4448-3-Lec-1-2

PDF No ratings yet Overview of Statistics and Data Analysis 41 pages

Silliman University Physical Therapy Portfolio

https://www.scribd.com/document/729855044/Work-Immersion-Physical-Therapy-Softcopy

PDF No ratings yet Silliman University Physical Therapy Portfolio 72 pages

Understanding Quartiles in Statistics

https://www.scribd.com/document/652569146/LAS-MATH10-Q4-WK1

PDF No ratings yet Understanding Quartiles in Statistics 4 pages

Perspectives on Life's Meaning

https://www.scribd.com/presentation/820765870/The-Thinkers

PDF No ratings yet Perspectives on Life's Meaning 14 pages

Theistic Evolution vs. Intelligent Design

https://www.scribd.com/document/680813922/Theistic-Evolution-Intelligent-Design-And-the-Charge-of-Deism

PDF No ratings yet Theistic Evolution vs. Intelligent Design 14 pages

Kinematics and DH Parameters for Robots

https://www.scribd.com/document/743344116/Robotics-EX2

PDF No ratings yet Kinematics and DH Parameters for Robots 3 pages

Boosting Creativity in Employees

https://www.scribd.com/document/881630051/Acfroga2qufwu1pv-Hewfz6fcf64soanlefuz2kuw1g4h8mfiabuqq0mgykc-4mh6z5xkgxzvf1ll7nhdyuvtlq-Ffujexwy-63p-Thlripbjmwu-Wu-Xhaxpthxjup4-Ubdg-Mm4dojduaz7a4

PDF No ratings yet Boosting Creativity in Employees 6 pages

Discover Your Learning Style Assessment

https://www.scribd.com/document/902115439/Learning-Style

PDF No ratings yet Discover Your Learning Style Assessment 1 page

WDFC Phase-II SHE Risk Assessment Report

https://www.scribd.com/document/750617302/Risk-Assessment-P-M

PDF No ratings yet WDFC Phase-II SHE Risk Assessment Report 5 pages

IGCSE Chemistry: Rate of Reaction Experiments

https://www.scribd.com/document/952626386/6-2-Rate-of-Reaction-QP-pdf

PDF No ratings yet IGCSE Chemistry: Rate of Reaction Experiments 21 pages

Community vs. Population in Ecosystems

https://www.scribd.com/document/789534703/EDEXCEL-BIOLOGY-CHAPTER-END-TEST-ECOSYSTEM-2024

PDF No ratings yet Community vs. Population in Ecosystems 9 pages

Class 10 Mid-Term Syllabus 2024-25

https://www.scribd.com/document/769472813/G-10-MiD-Term-Syllabus-Portion-2024-25

PDF No ratings yet Class 10 Mid-Term Syllabus 2024-25 3 pages

Aviation History: From Myths to Machines

https://www.scribd.com/document/692617058/Chapter-1-Beginning-of-Aviation

PDF No ratings yet Aviation History: From Myths to Machines 29 pages

Grade 8 Math Learning Resources Inventory

https://www.scribd.com/document/468676689/Inventory-of-Available-LR-in-the-Curriculum-Guide-Aligned-with-the-MELCs-Math8Q1

PDF No ratings yet Grade 8 Math Learning Resources Inventory 7 pages

Point Charge and Grounded Sphere Analysis

https://www.scribd.com/document/759230525/Method-of-images-point-charge-and-sphere

PDF No ratings yet Point Charge and Grounded Sphere Analysis 3 pages

S&P TD-250/100 Duct Fan Specifications

https://www.scribd.com/document/752160988/TD-250100-220-240V-50-RE-5211320600-In-Line-Duct-Fans-443

PDF No ratings yet S&P TD-250/100 Duct Fan Specifications 2 pages

Effective Stakeholder Management Strategies

https://www.scribd.com/document/873861871/7-Stakeholder-Management-for-Communication

PDF No ratings yet Effective Stakeholder Management Strategies 8 pages

Radar Plotting Sheet Analysis for MV Amrta Jaya 1

https://www.scribd.com/document/609632107/Radar-Plotting-Sheet

PDF No ratings yet Radar Plotting Sheet Analysis for MV Amrta Jaya 1 9 pages

Shindi Town Water Supply Design Project

https://www.scribd.com/document/855271331/Shindi-Town-Water-Supply1

PDF No ratings yet Shindi Town Water Supply Design Project 88 pages

Maslach Burnout Inventory Student Survey MBI SS

https://www.scribd.com/document/1007253391/958327990-Maslach-Burnout-Inventory-Student-Survey-MBI-SS

PDF No ratings yet Maslach Burnout Inventory Student Survey MBI SS 1 page

Footer menu

Back to top

https://www.scribd.com/document/325603628/Facial-Action-Coding-System-1#global\_header

About Scribd, Inc.

https://www.scribdinc.com/about

https://www.slideshare.net/

Join our team!

https://www.scribdinc.com/careers

https://www.scribdinc.com/contact

http://support.scribd.com/hc/en-us

Accessibility

https://support.scribd.com/hc/en-us/articles/210129586-Accessibility-Notice

Purchase help

https://support.scribd.com/hc/en-us/sections/202246306

https://support.scribd.com/hc/en-us/articles/210129366

https://support.scribd.com/hc/en-us/articles/210129326-General-Terms-of-Use

https://www.scribd.com/privacy

https://support.scribd.com/hc/en-us/sections/202246086

Instagram Instagram

https://www.instagram.com/scribd/

Facebook Facebook

https://www.facebook.com/Scribd/

Pinterest Pinterest

https://www.pinterest.com/scribd/

Get our free apps

About Scribd, Inc.

https://www.scribdinc.com/about

https://www.slideshare.net/

Join our team!

https://www.scribdinc.com/careers

https://www.scribdinc.com/contact

https://support.scribd.com/hc/en-us/articles/210129326-General-Terms-of-Use

https://www.scribd.com/privacy

https://support.scribd.com/hc/en-us/sections/202246086

http://support.scribd.com/hc/en-us

Accessibility

https://support.scribd.com/hc/en-us/articles/210129586-Accessibility-Notice

Purchase help

https://support.scribd.com/hc/en-us/sections/202246306

https://support.scribd.com/hc/en-us/articles/210129366

Instagram Instagram

https://www.instagram.com/scribd/

Facebook Facebook

https://www.facebook.com/Scribd/

Pinterest Pinterest

https://www.pinterest.com/scribd/

Get our free apps

https://www.scribd.com/docs

Copyright © 2026 Scribd Inc.

We take content rights seriously.

https://support.scribd.com/hc/en-us/articles/210129026-Frequently-Asked-Questions-about-Copyrights-and-the-DMCA

in our FAQs or

report infringement here

https://support.scribd.com/hc/en-us/articles/210129146-REPORT-COPYRIGHT-INFRINGEMENTS-AND-ABUSE-HERE

We take content rights seriously.

https://support.scribd.com/hc/en-us/articles/210129026-Frequently-Asked-Questions-about-Copyrights-and-the-DMCA

in our FAQs or

report infringement here

https://support.scribd.com/hc/en-us/articles/210129146-REPORT-COPYRIGHT-INFRINGEMENTS-AND-ABUSE-HERE

Copyright © 2026 Scribd Inc.

