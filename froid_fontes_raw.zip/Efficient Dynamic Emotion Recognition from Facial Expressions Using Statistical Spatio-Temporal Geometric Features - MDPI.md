---
sourceFile: "Efficient Dynamic Emotion Recognition from Facial Expressions Using Statistical Spatio-Temporal Geometric Features - MDPI"
exportedBy: "Kortex"
exportDate: "2026-06-29T01:00:27.817Z"
---

# Efficient Dynamic Emotion Recognition from Facial Expressions Using Statistical Spatio-Temporal Geometric Features - MDPI

9adfa1a6-4a0f-4386-9565-c08ae7a95c16

Efficient Dynamic Emotion Recognition from Facial Expressions Using Statistical Spatio-Temporal Geometric Features - MDPI

d0c5a2a5-1232-4605-806c-995f2f36389a

https://www.mdpi.com/2504-2289/9/8/213

Efficient Dynamic Emotion Recognition from Facial Expressions Using Statistical Spatio-Temporal Geometric Features

Loading web-font Gyre-Pagella/Main/Regular

Next Article in Journal

Detection and Localization of Hidden IoT Devices in Unknown Environments Based on Channel Fingerprints

https://www.mdpi.com/2504-2289/9/8/214

Previous Article in Journal

Proposal of a Blockchain-Based Data Management System for Decentralized Artificial Intelligence Devices

https://www.mdpi.com/2504-2289/9/8/212

Previous Article in Special Issue

RecurrentOcc: An Efficient Real-Time Occupancy Prediction Model with Memory Mechanism

https://www.mdpi.com/2504-2289/9/7/176

Active Journals

https://www.mdpi.com/about/journals

Find a Journal

https://www.mdpi.com/about/journalfinder

Journal Proposal

https://www.mdpi.com/about/journals/proposal

Proceedings Series

https://www.mdpi.com/about/proceedings

\](https://www.mdpi.com/topics)

Information

For Authors

https://www.mdpi.com/authors

For Reviewers

https://www.mdpi.com/reviewers

For Editors

https://www.mdpi.com/editors

For Librarians

https://www.mdpi.com/librarians

For Publishers

https://www.mdpi.com/publishing\_services

For Societies

https://www.mdpi.com/societies

For Conference Organizers

https://www.mdpi.com/conference\_organizers

Open Access Policy

https://www.mdpi.com/openaccess

Institutional Open Access Program

https://www.mdpi.com/ioap

Special Issues Guidelines

https://www.mdpi.com/special\_issues\_guidelines

Editorial Process

https://www.mdpi.com/editorial\_process

Research and Publication Ethics

https://www.mdpi.com/ethics

Article Processing Charges

https://www.mdpi.com/apc

https://www.mdpi.com/awards

Testimonials

https://www.mdpi.com/testimonials

Author Services

\](https://www.mdpi.com/authors/english)

Initiatives

https://sciforum.net/

https://www.mdpi.com/books

Preprints.org

https://www.preprints.org/

https://www.scilit.com/

SciProfiles

https://sciprofiles.com/

Encyclopedia

https://encyclopedia.pub/

https://jams.pub/

Proceedings Series

https://www.mdpi.com/about/proceedings

https://www.mdpi.com/about

https://www.mdpi.com/about/contact

https://careers.mdpi.com/

https://www.mdpi.com/about/announcements

https://www.mdpi.com/about/press

http://blog.mdpi.com/

Sign In / Sign Up

https://www.mdpi.com/user/login

You can make submissions to other journals

https://susy.mdpi.com/user/manuscripts/upload

https://www.mdpi.com/2504-2289/9/8/213

You are accessing a machine-readable page. In order to be human-readable, please install an RSS reader.

https://www.mdpi.com/2504-2289/9/8/213

https://www.mdpi.com/2504-2289/9/8/213

https://www.mdpi.com/2504-2289/9/8/213

All articles published by MDPI are made immediately available worldwide under an open access license. No special permission is required to reuse all or part of the article published by MDPI, including figures and tables. For articles published under an open access Creative Common CC BY license, any part of the article may be reused without permission provided that the original article is clearly cited. For more information, please refer to

https://www.mdpi.com/openaccess

https://www.mdpi.com/openaccess

Feature papers represent the most advanced research with significant potential for high impact in the field. A Feature Paper should be a substantial original Article that involves several techniques or approaches, provides an outlook for future research directions and describes possible research applications.

Feature papers are submitted upon individual invitation or recommendation by the scientific editors and must receive positive feedback from the reviewers.

Editor's Choice articles are based on recommendations by the scientific editors of MDPI journals from around the world. Editors select a small number of articles recently published in the journal that they believe will be particularly interesting to readers, or important in the respective research area. The aim is to provide a snapshot of some of the most exciting work published in the various research areas of the journal.

Original Submission Date Received: .

You seem to have javascript disabled. Please note that many of the page functionalities won't work as expected without javascript enabled.

https://www.mdpi.com/2504-2289/9/8/213

zoom\_out\_map

https://www.mdpi.com/toggle\_desktop\_layout\_cookie

https://www.mdpi.com/2504-2289/9/8/213

https://www.mdpi.com/2504-2289/9/8/213

https://www.mdpi.com/about/journals

Active Journals

https://www.mdpi.com/about/journals

Find a Journal

https://www.mdpi.com/about/journalfinder

Journal Proposal

https://www.mdpi.com/about/journals/proposal

Proceedings Series

https://www.mdpi.com/about/proceedings

https://www.mdpi.com/topics

Information

https://www.mdpi.com/authors

For Authors

https://www.mdpi.com/authors

For Reviewers

https://www.mdpi.com/reviewers

For Editors

https://www.mdpi.com/editors

For Librarians

https://www.mdpi.com/librarians

For Publishers

https://www.mdpi.com/publishing\_services

For Societies

https://www.mdpi.com/societies

For Conference Organizers

https://www.mdpi.com/conference\_organizers

Open Access Policy

https://www.mdpi.com/openaccess

Institutional Open Access Program

https://www.mdpi.com/ioap

Special Issues Guidelines

https://www.mdpi.com/special\_issues\_guidelines

Editorial Process

https://www.mdpi.com/editorial\_process

Research and Publication Ethics

https://www.mdpi.com/ethics

Article Processing Charges

https://www.mdpi.com/apc

https://www.mdpi.com/awards

Testimonials

https://www.mdpi.com/testimonials

Author Services

https://www.mdpi.com/authors/english

Initiatives

https://www.mdpi.com/about/initiatives

https://sciforum.net/

https://www.mdpi.com/books

Preprints.org

https://www.preprints.org/

https://www.scilit.com/

SciProfiles

https://sciprofiles.com/

Encyclopedia

https://encyclopedia.pub/

https://jams.pub/

Proceedings Series

https://www.mdpi.com/about/proceedings

https://www.mdpi.com/about

https://www.mdpi.com/about

https://www.mdpi.com/about/contact

https://careers.mdpi.com/

https://www.mdpi.com/about/announcements

https://www.mdpi.com/about/press

http://blog.mdpi.com/

Sign In / Sign Up

https://www.mdpi.com/user/login

https://susy.mdpi.com/user/manuscripts/upload?journal=BDCC

#### Search for Articles:

Title / Keyword

Author / Affiliation / Email

All Journals

Accounting and Auditing

Acta Microbiologica Hellenica (AMH)

Administrative Sciences

Adolescents

Advances in Respiratory Medicine (ARM)

Aerobiology

Agriculture

AgriEngineering

Agrochemicals

AI Chemistry

AI for Engineering

AI in Education

AI in Medicine

AI Materials

Anesthesia Research

Antibiotics

Antioxidants

Applied Biosciences

Applied Mechanics

Applied Microbiology

Applied Nano

Applied Sciences

Applied System Innovation (ASI)

AppliedChem

AppliedMath

AppliedPhys

Aquaculture Journal

Architecture

Astronautics

Audiology Research

Behavioral Sciences

Big Data and Cognitive Computing (BDCC)

Bioengineering

Biology and Life Sciences Forum

Biomechanics

Biomedicines

BioMedInformatics

Biomimetics

Biomolecules

Bioresources and Bioproducts

Blockchains

Brain Sciences

C (Journal of Carbon Research)

Cardiogenetics

Cardiovascular Medicine

ChemEngineering

Chemistry Proceedings

Chemosensors

Clean Technologies (Clean Technol.)

Clinical and Translational Neuroscience (CTN)

Clinical Bioenergetics

Clinics and Practice

Clocks & Sleep

Colloids and Interfaces

Commodities

Complexities

Complications

Computation

Computer Sciences & Mathematics Forum

Condensed Matter

Conservation

Construction Materials

Corrosion and Materials Degradation (CMD)

Craniomaxillofacial Trauma & Reconstruction (CMTR)

Cryptography

Current Issues in Molecular Biology (CIMB)

Current Oncology

Dentistry Journal

Dermatopathology

Diabetology

Diagnostics

Disabilities

Drugs and Drug Candidates (DDC)

Econometrics

Education Sciences

Electricity

Electrochem

Electronic Materials

Electronics

Emergency Care and Medicine

Encyclopedia

Energy Storage and Applications (ESA)

Engineering Proceedings

Entropic and Disordered Matter (EDM)

Environmental and Earth Sciences Proceedings

Environmental Remediation

Environments

Epidemiologia

European Burn Journal (EBJ)

European Journal of Investigation in Health, Psychology and Education (EJIHPE)

Family Sciences

Fermentation

Forecasting

Forensic Sciences

Fossil Studies

Foundations

Fractal and Fractional (Fractal Fract)

Future Internet

Future Pharmacology

Future Transportation

Gastroenterology Insights

Gastrointestinal Disorders

Geographies

Geosciences

Geotechnics

Gout, Urate, and Crystal Deposition Disease (GUCDD)

Green Health

Hematology Reports

Horticulturae

Hydrobiology

Infectious Disease Reports

Informatics

Information

Infrastructures

Instruments

Intelligent Infrastructure and Construction

International Journal of Cognitive Sciences (IJCS)

International Journal of Environmental Medicine (IJEM)

International Journal of Environmental Research and Public Health (IJERPH)

International Journal of Financial Studies (IJFS)

International Journal of Molecular Sciences (IJMS)

International Journal of Neonatal Screening (IJNS)

International Journal of Orofacial Myology and Myofunctional Therapy (IJOM)

International Journal of Plant Biology (IJPB)

International Journal of Topology

International Journal of Translational Medicine (IJTM)

International Journal of Turbomachinery, Propulsion and Power (IJTPP)

International Medical Education (IME)

ISPRS International Journal of Geo-Information (IJGI)

Journal of Aesthetic Medicine (J. Aesthetic Med.)

Journal of Ageing and Longevity (JAL)

Journal of CardioRenal Medicine (JCRM)

Journal of Cardiovascular Development and Disease (JCDD)

Journal of Clinical & Translational Ophthalmology (JCTO)

Journal of Clinical Medicine (JCM)

Journal of Composites Science (J. Compos. Sci.)

Journal of Cybersecurity and Privacy (JCP)

Journal of Dementia and Alzheimer's Disease (JDAD)

Journal of Developmental Biology (JDB)

Journal of Experimental and Theoretical Analyses (JETA)

Journal of Eye Movement Research (JEMR)

Journal of Functional Biomaterials (JFB)

Journal of Functional Morphology and Kinesiology (JFMK)

Journal of Fungi (JoF)

Journal of Genome Biotechnology and Genetics (JGBG)

Journal of Gerontology and Geriatrics (JGG)

Journal of Imaging (J. Imaging)

Journal of Innovation

Journal of Intelligence (J. Intell.)

Journal of Interdisciplinary Research Applied to Medicine (JDReAM)

Journal of Low Power Electronics and Applications (JLPEA)

Journal of Manufacturing and Materials Processing (JMMP)

Journal of Marine Science and Engineering (JMSE)

Journal of Market Access & Health Policy (JMAHP)

Journal of Mind and Medical Sciences (JMMS)

Journal of Molecular Pathology (JMP)

Journal of Nanotheranostics (JNT)

Journal of Nuclear Engineering (JNE)

Journal of Otorhinolaryngology, Hearing and Balance Medicine (JOHBM)

Journal of Parks

Journal of Personalized Medicine (JPM)

Journal of Pharmaceutical and BioTech Industry (JPBI)

Journal of Phytomedicine

Journal of Respiration (JoR)

Journal of Risk and Financial Management (JRFM)

Journal of Sensor and Actuator Networks (JSAN)

Journal of Superintelligence

Journal of the American Podiatric Medical Association (JAPMA)

Journal of the Oman Medical Association (JOMA)

Journal of Theoretical and Applied Electronic Commerce Research (JTAER)

Journal of Vascular Diseases (JVD)

Journal of Xenobiotics (JoX)

Journal of Zoological and Botanical Gardens (JZBG)

Journalism and Media

Kidney and Dialysis

Kinases and Phosphatases

Laboratories

Limnological Review

Low-Altitude Economy

Machine Learning and Knowledge Extraction (MAKE)

Magnetochemistry

Marine Drugs

Materials Proceedings

Mathematical and Computational Applications (MCA)

Mathematics

Medical Sciences

Medical Sciences Forum

Metabolites

Meteorology

Methods and Protocols (MPs)

Microbiology Research

Microelectronics

Micromachines

Microorganisms

Microplastics

Modern Mathematical Physics

Multimodal Technologies and Interaction (MTI)

Nanoenergy Advances

Nanomanufacturing

Nanomaterials

Neuroimaging

Neurology International

Non-Coding RNA (ncRNA)

Nursing Reports

Nutraceuticals

Occupational Health

Parasitologia

Pathophysiology

Peace Studies

Pediatric Reports

Pharmaceuticals

Pharmaceutics

Pharmacoepidemiology

Philosophies

Physical Sciences Forum

Physiologia

Polysaccharides

Populations

Precision Oncology

Primary and Hospital Care (PHC)

Proceedings

Psychiatry International

Psychoactives

Psychology International

Publications

Purification

Quantum Beam Science (QuBS)

Quantum Reports

Real Estate

Regional Science and Environmental Economics (RSEE)

Remote Sensing

Reproductive Medicine (Reprod. Med.)

Romanian Journal of Preventive Medicine (RJPM)

Scientia Pharmaceutica (Sci. Pharm.)

Semiconductors and Heterogeneous Integration

Separations

Smart Cities

Social Sciences

Société Internationale d'Urologie Journal (SIUJ)

Soil Systems

Spectroscopy Journal

Stratigraphy and Sedimentology

Surgical Techniques Development

Sustainability

Sustainable Chemistry

Swiss Archives of Neurology, Psychiatry and Psychotherapy (SANPP)

Technologies

Thalassemia Reports

Theoretical and Applied Ergonomics

Therapeutics

Time and Space

Tourism and Hospitality

Transplantology

Trauma Care

Trends in Higher Education

Trends in Public Health

Tropical Medicine and Infectious Disease (TropicalMed)

Urban Science

Venereology

Veterinary Sciences

Virtual Worlds

World Electric Vehicle Journal (WEVJ)

Zoonotic Diseases

Big Data and Cognitive Computing (BDCC)

https://www.mdpi.com/2504-2289/9/8/213

Article Type

All Article Types

Communication

Book Review

Brief Communication

Brief Report

Case Report

Clinicopathological Challenge

Concept Paper

Conference Report

Data Descriptor

Expression of Concern

Extended Abstract

Field Guide

Giants in Urology

Interesting Images

New Book Received

Patent Summary

Perspective

Proceeding Paper

Project Report

Registered Report

Study Protocol

Systematic Review

Technical Note

Urology around the World

All Article Types

https://www.mdpi.com/2504-2289/9/8/213

Advanced Search

https://www.mdpi.com/2504-2289/9/8/213

All Sections

Artificial Intelligence and Multi-Agent Systems

Cognitive System

Data Mining and Machine Learning

Large Language Models and Embodied Intelligence

All Sections

https://www.mdpi.com/2504-2289/9/8/213

Special Issue

All Special Issues

Big Data and Cognitive Computing in 2023

Advanced Data Mining Techniques for IoT and Big Data

Advanced Machine Learning and Data Mining: A New Frontier in Artificial Intelligence Research

Advancements in Deep Learning and Deep Federated Learning Models

Advances and Applications of Deep Learning Methods and Image Processing

Advances in Complex Networks

Advances in Intelligent Defense Systems for the Internet of Things

Advances in Natural Language Processing and Text Mining

Advances in System Design and IoT Based Smart City

AI-Driven Pattern Recognition for Next-Generation Biometrics

AI, Computer Vision and Human–Robot Interaction

Application of Artificial Intelligence in Traffic Management

Application of Cloud Computing in Industrial Internet of Things

Application of Cloud Computing in Industrial Internet of Things—2nd Edition

Application of Deep Learning and Convolution Neural Networks for Social Healthcare

Application of Deep Neural Networks

Application of Semantic Technologies in Intelligent Environment

Applied Artificial Intelligence for Sustainability

Applied Data Science for Social Good

Applied Data Science for Social Good: 2nd Edition

Applied Deep Learning: Business and Industrial Applications

Artificial Cognition for Human-Robot Interaction

Artificial Cognitive Systems for Computer Vision

Artificial Intelligence (AI) and Natural Language Processing (NLP)

Artificial Intelligence and Multi-Agent Systems for Big Data

Artificial Intelligence and Natural Language Processing

Artificial Intelligence for Online Safety

Artificial Intelligence for Sustainability Development

Artificial Intelligence for Trustworthy Industrial Internet of Things

Artificial Intelligence in Digital Humanities

Artificial Intelligence in Sustainable Reconfigurable Manufacturing Systems and Operations Management

Artificial Superintelligence: Coordination & Strategy

Augmented Reality, Virtual Reality, and Computer Graphics

Big Data Analytic: From Accuracy to Interpretability

Big Data Analytics and Cloud Data Management

Big Data Analytics and Edge Computing: Recent Trends and Future

Big Data Analytics and Forecasting in Fashion

Big Data Analytics for Cultural Heritage

Big Data Analytics for Cultural Heritage 2nd Edition

Big Data Analytics for Social Services

Big Data Analytics with Machine Learning for Cyber Security

Big Data and Cognitive Computing in 2026

Big Data and Cognitive Computing: 5th Anniversary Feature Papers

Big Data and Cognitive Computing: Feature Papers 2018

Big Data and Cognitive Computing: Feature Papers 2020

Big Data and Data Science in Educational Research

Big Data and Information Science Technology

Big Data and Internet of Things

Big Data and Internet of Things in Smart Cities

Big Data and Machine Learning Applications for Material Removal, Additive and Hybrid Manufacturing Processes

Big Data and UN Sustainable Development Goals (SDGs)

Big Data in Computer-Aided Design

Big Data in Health Care Information Systems

Big Data in Omics Science: Challenges and Opportunities

Big Data System for Global Health

Big Music Data

Big-Data Driven Multi-Criteria Decision-Making

Bioinformatics Dry Laboratories for Research and Education: Computational Systems and Infrastructures

Blockchain and Cloud Computing in Big Data and Generative AI Era

Blockchain Meets IoT for Big Data

Brain-Inspired Hyperdimensional Computing: Theoretical Perspectives and Real-World Applications

Business Intelligence and Big Data in E-commerce

Challenges and Perspectives of Social Networks within Social Computing

Cognitive and Physiological Assessments in Human-Computer Interaction

Cognitive Services Integrating with Big Data, Clouds and IoT

Computational Collective Intelligence with Big Data–AI Society

Computational Finance and Big Data Analytics

Computational Intelligence: Spiking Neural Networks

Computational Models of Cognition and Learning

COVID-19: Medical Internet of Things and Big Data Analytics

Cross Modality Deep Learning and Knowledge Representation

Cyber Security in Big Data Era

Cybersecurity, Threat Analysis and the Management of Risk

Data Mining and the Future of Cybersecurity

Data Science in Health Care

Data Security and Privacy in Blockchain-Based Decentralized Applications

Data-Based Bioinformatics and Applications

Data, Structure, and Information in Artificial Intelligence

Deep Learning for Advanced Visual Representation and Analysis

Deep Learning Technology and Big Data Method for Business and Environmental Management

Deep Learning-Based Pose Estimation: Applications in Vision, Robotics, and Beyond

Deep Network Learning and Its Applications

Digital Health and Data Analytics in Public Health

Digital Twins for Complex Systems

Distributed Applications and Services for Future Internet

Edge Computing and Fog Computing on the Internet of Things

Educational Data Mining and Technology

Emerging Trends and Applications of Big Data in Robotic Systems

Energy-Efficient IoT (Internet of Things) and Big Data Challenges for Connected Intelligence

Fault Diagnosis and Detection Based on Deep Learning

Feature-Rich Artificial Intelligence Models and Applications of Cognition

Generative AI and Large Language Models

Graph-Based Data Mining and Social Network Analysis

Health Assessment in the Big Data Era

Human Factor in Information Systems Development and Management

Industrial Applications of IoT and Blockchain for Sustainable Environment

Industrial Data Mining and Machine Learning Applications

Information Security and Cyber Intelligence

Interactive Visual Analytics and Explainable AI for Big Data

Internet of Things (IoT) and Ambient Intelligence

Knowledge Modelling and Learning through Cognitive Networks

Knowledge Representation Formalisms for AI Applications

Learning with Big Data: Scalable Algorithms and Novel Applications

Low-Power Data Processing on the Edge: Solutions for Artificial Intelligence Hardware Acceleration

Machine and Deep Learning in Computer Vision Applications

Machine Learning and AI Technology for Sustainable Development

Machine Learning and Artificial Intelligence for Health Applications on Social Networks

Machine Learning and Data Analysis for Image Processing

Machine Learning and Data Analytics for Communication Networks in the 5G Era

Machine Learning Applications and Big Data Challenges

Machine Learning for Dependable Edge Computing Systems and Services

Machine Learning for Social Media Analysis

Machine Learning in Data Mining for Knowledge Discovery

Machine Learning Techniques on Biometrics and IoT Applications

Managing Cybersecurity Threats and Increasing Organizational Resilience

ML-Based Cognitive Network Management: For Better 6G Applications

Multimedia Systems for Multimedia Big Data

Natural Language Processing and Event Extraction for Big Data

Natural Language Processing Applications in Big Data

Perception and Detection of Intelligent Vision

Predictive Performance-Explainability Duality for Big Data Analytics-Powered Healthcare

Privacy-Enhancing Technologies of Data for Sustainable and Secure Cooperation

Quality and Security of Critical Infrastructure Systems

Real-Time Data Services for the Internet of Things

Recent Advances and Applications of Big Data and Distributed Computing Systems

Recent Advances in Big Data-Driven Prescriptive Analytics

Recent Advances in Deep Transfer Learning Applications for Image Processing Problems and Big Data

Recent Advances in Machine Learning Methods for Imperfect Large-Scale Data

Recommendation, Information Retrieval, and Exploratory Search

Research on Privacy and Data Security

Research Progress in Artificial Intelligence and Social Network Analysis

Resilient and Reliable Artificial Intelligence (AI) Systems

Review Papers in Big Data, Cloud-Based Data Analysis and Learning Systems

Revolutionizing Healthcare: Exploring the Latest Advances in Digital Health Technology

Security, Privacy, and Trust in Artificial Intelligence Applications

Semantic Web Technology and Recommender Systems

Semantic Web Technology and Recommender Systems 2nd Edition

Smart Communication Systems and Networks for Big Data

Smarter Healthcare via Big Data and Machine Learning

Speech Recognition and Machine Learning: Current Trends and Future

Sustainable Big Data Analytics and Machine Learning Technologies

Transforming Cyber Security Provision Through Utilizing Artificial Intelligence

Unlocking Minds and Machines: Advances in Cognitive Computing and Big Data Analytics

Virtual Reality, Augmented Reality, and Human-Computer Interaction

All Special Issues

https://www.mdpi.com/2504-2289/9/8/213

Logical Operator Operator

Search Text

Search Type

Affiliations

add\_circle\_outline

remove\_circle\_outline

https://www.mdpi.com/about/journals

https://www.mdpi.com/journal/BDCC

https://www.mdpi.com/2504-2289/9

https://www.mdpi.com/2504-2289/9/8

10.3390/bdcc9080213

https://www.mdpi.com/2504-2289/9/8/213

Submit to this Journal

https://susy.mdpi.com/user/manuscripts/upload?form%5Bjournal\_id%5D%3D245

Review for this Journal

https://susy.mdpi.com/volunteer/journals/review

Propose a Special Issue

https://www.mdpi.com/journalproposal/sendproposalspecialissue/BDCC

► ▼ Article Menu

https://www.mdpi.com/2504-2289/9/8/213

Article Menu

Academic Editors

https://www.mdpi.com/2504-2289/9/8/213#academic\_editors

Fabrizio Messina

https://sciprofiles.com/profile/250188?utm\_source=mdpi.com&utm\_medium=website&utm\_campaign=avatar\_name

Domenico Ursino

https://sciprofiles.com/profile/737373?utm\_source=mdpi.com&utm\_medium=website&utm\_campaign=avatar\_name

Recommended Articles

https://www.mdpi.com/2504-2289/9/8/213

Related Info Link

https://www.mdpi.com/2504-2289/9/8/213#related

Google Scholar

http://scholar.google.com/scholar?q=Efficient%20Dynamic%20Emotion%20Recognition%20from%20Facial%20Expressions%20Using%20Statistical%20Spatio-Temporal%20Geometric%20Features

More by Author Links

https://www.mdpi.com/2504-2289/9/8/213#authors

https://www.mdpi.com/2504-2289/9/8/213

Yaddaden, Y.

http://doaj.org/search/articles?source=%7B%22query%22%3A%7B%22query\_string%22%3A%7B%22query%22%3A%22%5C%22Yacine%20Yaddaden%5C%22%22%2C%22default\_operator%22%3A%22AND%22%2C%22default\_field%22%3A%22bibjson.author.name%22%7D%7D%7D

on Google Scholar

https://www.mdpi.com/2504-2289/9/8/213

Yaddaden, Y.

http://scholar.google.com/scholar?q=Yacine%20Yaddaden

https://www.mdpi.com/2504-2289/9/8/213

Yaddaden, Y.

http://www.pubmed.gov/?cmd=Search&term=Yacine%20Yaddaden

Article Views 2335

https://www.mdpi.com/2504-2289/9/8/213#metrics

Citations 2

https://www.mdpi.com/2504-2289/9/8/213#metrics

Table of Contents

https://www.mdpi.com/2504-2289/9/8/213#table\_of\_contents

https://www.mdpi.com/2504-2289/9/8/213#html-abstract

Introduction

https://www.mdpi.com/2504-2289/9/8/213#sec1-BDCC-09-00213

Fundamentals

https://www.mdpi.com/2504-2289/9/8/213#sec2-BDCC-09-00213

Related Works

https://www.mdpi.com/2504-2289/9/8/213#sec3-BDCC-09-00213

Limitations & Challenges

https://www.mdpi.com/2504-2289/9/8/213#sec4-BDCC-09-00213

Proposed Approach

https://www.mdpi.com/2504-2289/9/8/213#sec5-BDCC-09-00213

Experimentation & Evaluation

https://www.mdpi.com/2504-2289/9/8/213#sec6-BDCC-09-00213

Results & Discussion

https://www.mdpi.com/2504-2289/9/8/213#sec7-BDCC-09-00213

Conclusions & Future Work

https://www.mdpi.com/2504-2289/9/8/213#sec8-BDCC-09-00213

https://www.mdpi.com/2504-2289/9/8/213

Data Availability Statement

https://www.mdpi.com/2504-2289/9/8/213

Acknowledgments

https://www.mdpi.com/2504-2289/9/8/213#html-ack

Conflicts of Interest

https://www.mdpi.com/2504-2289/9/8/213

Abbreviations

https://www.mdpi.com/2504-2289/9/8/213#html-glossary

https://www.mdpi.com/2504-2289/9/8/213#html-references\_list

share Share

https://www.mdpi.com/2504-2289/9/8/213

announcement Help

https://www.mdpi.com/2504-2289/9/8/213

format\_quote Cite

javascript:void(0);

question\_answer Discuss in SciProfiles

https://sciprofiles.com/discussion-groups/public/10.3390/bdcc9080213?utm\_source=mpdi.com&utm\_medium=publication&utm\_campaign=discuss\_in\_sciprofiles

Find support for a specific problem in the support section of our website.

Get Support

https://www.mdpi.com/about/contactform

Please let us know what you think of our products and services.

Give Feedback

https://www.mdpi.com/feedback/send

Information

Visit our dedicated information section to learn more about MDPI.

Get Information

https://www.mdpi.com/authors

https://www.mdpi.com/2504-2289/9/8/213

JSmol Viewer

https://www.mdpi.com/2504-2289/9/8/213

Download PDF

https://www.mdpi.com/2504-2289/9/8/213/pdf?version=1755616597

Order Article Reprints

https://www.mdpi.com/2504-2289/9/8/213/reprints

#### Line Spacing:

#### Column Width:

#### Background:

Open Access Article

Efficient Dynamic Emotion Recognition from Facial Expressions Using Statistical Spatio-Temporal Geometric Features

Yacine Yaddaden

Yacine Yaddaden

SciProfiles

https://sciprofiles.com/profile/4351010?utm\_source=mdpi.com&utm\_medium=website&utm\_campaign=avatar\_name

https://scilit.com/scholars?q=Yacine%20Yaddaden

Preprints.org

https://www.preprints.org/search?condition\_blocks=\[{%22value%22:%22Yacine+Yaddaden%22,%22type%22:%22author%22,%22operator%22:null}\]&sort\_field=relevance&sort\_dir=desc&page=1&exact\_match=true

Google Scholar

https://scholar.google.com/scholar?q=Yacine+Yaddaden

mailto:yacine\_yaddaden@uqar.ca

Department of Mathematics, Computer Science and Engineering, Lévis Campus, Université du Québec à Rimouski, Lévis, QC G6V 0A6, Canada

Big Data Cogn. Comput.

https://doi.org/10.3390/bdcc9080213

https://doi.org/10.3390/bdcc9080213

Submission received: 1 May 2025 / Revised: 27 July 2025 / Accepted: 6 August 2025 / Published: 19 August 2025

(This article belongs to the Special Issue

Perception and Detection of Intelligent Vision

https://www.mdpi.com/journal/BDCC/special\_issues/J1F7WQC0W3

Download keyboard\_arrow\_down

https://www.mdpi.com/2504-2289/9/8/213

Download PDF

https://www.mdpi.com/2504-2289/9/8/213/pdf?version=1755616597

Download PDF with Cover

https://www.mdpi.com/2504-2289/9/8/213

Download XML

https://www.mdpi.com/2504-2289/9/8/213

Download Epub

https://www.mdpi.com/2504-2289/9/8/213/epub

Browse Figures

https://www.mdpi.com/2504-2289/9/8/213

https://pub.mdpi-res.com/BDCC/BDCC-09-00213/article\_deploy/html/images/BDCC-09-00213-g001.png?1755616704

https://pub.mdpi-res.com/BDCC/BDCC-09-00213/article\_deploy/html/images/BDCC-09-00213-g002.png?1755616705

https://pub.mdpi-res.com/BDCC/BDCC-09-00213/article\_deploy/html/images/BDCC-09-00213-g003.png?1755616707

https://pub.mdpi-res.com/BDCC/BDCC-09-00213/article\_deploy/html/images/BDCC-09-00213-g004.png?1755616708

https://pub.mdpi-res.com/BDCC/BDCC-09-00213/article\_deploy/html/images/BDCC-09-00213-g005.png?1755616709

Review Reports

https://www.mdpi.com/2504-2289/9/8/213/review\_report

Versions Notes

https://www.mdpi.com/2504-2289/9/8/213/notes

Article Views

https://www.mdpi.com/2504-2289/9/8/213#metrics

Citations -

https://www.mdpi.com/2504-2289/9/8/213#metrics

Automatic Facial Expression Recognition (AFER) is a key component of affective computing, enabling machines to recognize and interpret human emotions across various applications such as human–computer interaction, healthcare, entertainment, and social robotics. Dynamic AFER systems, which exploit image sequences, can capture the temporal evolution of facial expressions but often suffer from high computational costs, limiting their suitability for real-time use. In this paper, we propose an efficient dynamic AFER approach based on a novel spatio-temporal representation. Facial landmarks are extracted, and all possible Euclidean distances are computed to model the spatial structure. To capture temporal variations, three statistical metrics are applied to each distance sequence. A feature selection stage based on the Extremely Randomized Trees (ExtRa-Trees) algorithm is then performed to reduce dimensionality and enhance classification performance. Finally, the emotions are classified using a linear multi-class Support Vector Machine (SVM) and compared against the k-Nearest Neighbors ( k-NN) method. The proposed approach is evaluated on three benchmark datasets: CK+, MUG, and MMI, achieving recognition rates of 94.65%, 93.98%, and 75.59%, respectively. Our results demonstrate that the proposed method achieves a strong balance between accuracy and computational efficiency, making it well-suited for real-time facial expression recognition applications.

emotion recognition

https://www.mdpi.com/search?q=emotion+recognition

facial expression recognition

https://www.mdpi.com/search?q=facial+expression+recognition

dynamic facial analysis

https://www.mdpi.com/search?q=dynamic+facial+analysis

spatio-temporal representation

https://www.mdpi.com/search?q=spatio-temporal+representation

geometric features

https://www.mdpi.com/search?q=geometric+features

feature selection

https://www.mdpi.com/search?q=feature+selection

sequence-based approach

https://www.mdpi.com/search?q=sequence-based+approach

real-time applications

https://www.mdpi.com/search?q=real-time+applications

1. Introduction

Human beings are inherently social and rely heavily on communication to interact with one another. Emotions constitute a fundamental form of non-verbal communication and play a critical role in daily interactions \[

https://www.mdpi.com/2504-2289/9/8/213#B1-BDCC-09-00213

\]. The rapid development and widespread adoption of Information and Communication Technologies (ICT) have paved the way for the automatic recognition of human emotions, giving rise to numerous applications in fields such as Human–Computer Interaction (HCI), healthcare, entertainment, social robotics, and Ambient Assisted Living (AAL) \[

https://www.mdpi.com/2504-2289/9/8/213#B2-BDCC-09-00213

Emotions can be expressed and perceived through various modalities, including speech, body gestures, and facial expressions. Automatic emotion recognition systems can be unimodal, relying on a single modality, or multimodal, combining multiple sources of information to improve accuracy. Among these, facial expressions represent one of the most informative and widely studied modalities. According to Mehrabian's well-known study (1968) \[

https://www.mdpi.com/2504-2289/9/8/213#B1-BDCC-09-00213

\], approximately 55 % of emotional information is conveyed through facial expressions, while vocal and verbal cues account for 38 % and 7 % , respectively.

Among the foundational works in this field, Ekman and Friesen \[

https://www.mdpi.com/2504-2289/9/8/213#B3-BDCC-09-00213

\] introduced the concept of six basic emotions—happiness, sadness, anger, fear, surprise, and disgust—each with distinct facial signatures. Their Facial Action Coding System (FACS) \[

https://www.mdpi.com/2504-2289/9/8/213#B4-BDCC-09-00213

\] laid the groundwork for Automatic Facial Expression Recognition (AFER), providing a structured way to decode muscular movements into emotional states.

AFER systems can be broadly divided into static approaches, which analyze individual images, and dynamic ones, which process image sequences to capture temporal evolution. Although dynamic systems tend to achieve better recognition performance by incorporating motion and progression of expressions, they introduce new challenges in terms of model complexity and computational cost.

Several recent works have attempted to address these issues. For instance, Perveen et al. \[

https://www.mdpi.com/2504-2289/9/8/213#B5-BDCC-09-00213

\] proposed an efficient kernel-based spatio-temporal modeling approach; however, its reliance on global statistical patterns may limit its ability to capture fine-grained local deformations. Lopez-Gil and Garay-Vitoria \[

https://www.mdpi.com/2504-2289/9/8/213#B6-BDCC-09-00213

\] focused on frame-level classification for real-time efficiency, but their method lacks temporal context modeling, which is crucial for understanding subtle expression transitions.

To improve robustness, Shahid et al. \[

https://www.mdpi.com/2504-2289/9/8/213#B7-BDCC-09-00213

\] employed facial region segmentation and harmonic descriptors. While effective against occlusion and misalignment, this method depends heavily on accurate facial region division, which may be unreliable in real-world conditions. Similarly, Ngoc et al. \[

https://www.mdpi.com/2504-2289/9/8/213#B8-BDCC-09-00213

\] used a Directed Graph Neural Network over facial landmarks for dynamic modeling. Yet, such graph-based deep models often require large annotated datasets and significant computational resources, limiting their deployment in constrained environments.

Hybrid methods like those of Aghamaleki and Ashkani Chenarlogh \[

https://www.mdpi.com/2504-2289/9/8/213#B9-BDCC-09-00213

\], which combine handcrafted features with learned features, help mitigate data scarcity. However, these architectures still depend on deep neural networks and often fail to generalize across datasets without careful tuning. Moreover, methods that fuse appearance-based features often suffer from sensitivity to lighting, pose variations, and expression intensity.

In addition, despite advances in deep learning, the generalization of AFER systems remains a concern. Most models are trained and tested on small and controlled datasets, and their performance often degrades significantly when applied to more varied or spontaneous datasets, as shown in multiple comparative studies \[

https://www.mdpi.com/2504-2289/9/8/213#B5-BDCC-09-00213

https://www.mdpi.com/2504-2289/9/8/213#B7-BDCC-09-00213

https://www.mdpi.com/2504-2289/9/8/213#B8-BDCC-09-00213

Therefore, there is still a need for computationally efficient, geometrically grounded, and dataset-agnostic approaches to dynamic facial expression recognition—especially those capable of operating in real-time and under limited-resource constraints.

In this work, we propose such an approach: an efficient dynamic AFER method that recognizes emotions from facial expression sequences using only statistical geometric descriptors. The method is structured into three main stages. First, facial landmarks are detected, and all pairwise Euclidean distances are computed as spatial features. Then, temporal dynamics are encoded by computing three statistical measures over the sequence for each distance, yielding a compact spatio-temporal feature vector. To handle the high dimensionality of this vector, we apply a feature selection strategy based on the Extremely Randomized Trees (ExtRa-Trees) classifier. Finally, we evaluate two standard classifiers: multi-class Support Vector Machine (SVM) and k-Nearest Neighbors ( k-NN).

To assess the performance of the proposed method, we conduct experiments on three well-known benchmark datasets: CK+ \[

https://www.mdpi.com/2504-2289/9/8/213#B10-BDCC-09-00213

https://www.mdpi.com/2504-2289/9/8/213#B11-BDCC-09-00213

\], and MMI \[

https://www.mdpi.com/2504-2289/9/8/213#B12-BDCC-09-00213

\], analyzing both recognition accuracy and computational cost.

#### The main contributions of this paper are summarized as follows:

A novel geometry-based dynamic AFER pipeline

→ We introduce a lightweight and efficient facial expression recognition system that relies solely on facial landmark trajectories. By avoiding appearance-based or deep-learning features, our method significantly reduces computational cost and dependency on high-end hardware, making it well-suited for real-time and embedded applications.

spatio-temporal

representation of facial motion

→ We propose a simple yet effective statistical descriptor that models the temporal dynamics of facial expressions through the variation of distances and angles between landmarks over time. This handcrafted representation captures discriminative patterns without requiring large datasets or complex training procedures.

Extensive and comparative evaluation on benchmark datasets

→ We evaluate our method on three widely used dynamic benchmark datasets (CK+, MMI, and MUG) and provide a comparative analysis against eleven recent state-of-the-art approaches from the last five years. The results demonstrate that our method achieves competitive accuracy, especially given its low complexity and independence from deep neural networks.

The remainder of this paper is structured as follows.

https://www.mdpi.com/2504-2289/9/8/213#sec2-BDCC-09-00213

https://www.mdpi.com/2504-2289/9/8/213#sec3-BDCC-09-00213

present the fundamentals of AFER and review related work.

https://www.mdpi.com/2504-2289/9/8/213#sec4-BDCC-09-00213

discusses the current limitations and challenges of existing AFER methods.

https://www.mdpi.com/2504-2289/9/8/213#sec5-BDCC-09-00213

details the proposed approach, while

https://www.mdpi.com/2504-2289/9/8/213#sec6-BDCC-09-00213

describes the experimental setup and the datasets used for evaluation. The results and their interpretation are provided in

https://www.mdpi.com/2504-2289/9/8/213#sec7-BDCC-09-00213

https://www.mdpi.com/2504-2289/9/8/213#sec8-BDCC-09-00213

concludes the paper and outlines future research directions.

2. Fundamentals

A basic AFER system shares the same fundamental building blocks as a typical pattern recognition system \[

https://www.mdpi.com/2504-2289/9/8/213#B13-BDCC-09-00213

\]. As illustrated in

https://www.mdpi.com/2504-2289/9/8/213#fig\_body\_display\_BDCC-09-00213-f001

, the first block concerns the input, and depending on its nature, AFER systems can be classified into two main categories.

Basic building blocks of a common AFER system.

Static systems \[

https://www.mdpi.com/2504-2289/9/8/213#B14-BDCC-09-00213

\] recognize facial expressions from a single image. Generally, this type of system is less demanding in terms of computational time and resource consumption. However, static systems are limited in their ability to capture the temporal dynamics inherent to real-world facial expressions, which typically evolve through three distinct transitional phases: (1) Onset, marking the initial formation of the expression; (2) Apex, representing the peak of emotional intensity; and (3) Offset, characterizing the return to the neutral state. These phases reflect the natural progression of facial deformations, and their full characterization requires analyzing image sequences rather than isolated images.

To address this need, dynamic systems \[

https://www.mdpi.com/2504-2289/9/8/213#B5-BDCC-09-00213

https://www.mdpi.com/2504-2289/9/8/213#B15-BDCC-09-00213

https://www.mdpi.com/2504-2289/9/8/213#B16-BDCC-09-00213

\] have been introduced, capable of processing temporal information to better model the evolution of expressions. Furthermore, depending on how the input data are handled (see

https://www.mdpi.com/2504-2289/9/8/213#fig\_body\_display\_BDCC-09-00213-f001

), dynamic systems can be subdivided into two approaches:

Sequence-based

systems, which exploit the entire image sequence to build a comprehensive and temporal representation of the expression.

Frame-based

systems, which process each frame independently, without explicitly modeling the temporal continuity across frames.

Depending on the chosen data representation, the feature extraction block is adapted accordingly to process the input. As illustrated in

https://www.mdpi.com/2504-2289/9/8/213#fig\_body\_display\_BDCC-09-00213-f001

, three main types of descriptors can be distinguished in the context of AFER.

Geometric-based

features rely on the extraction of facial fiducial points to generate high-level representations \[

https://www.mdpi.com/2504-2289/9/8/213#B14-BDCC-09-00213

\], such as the Active Appearance Model (AAM) and the Active Shape Model (ASM) \[

https://www.mdpi.com/2504-2289/9/8/213#B17-BDCC-09-00213

Appearance-based

descriptors operate on the entire facial image to capture texture information, often through techniques such as the two-dimensional Discrete Wavelet Transform (DWT) \[

https://www.mdpi.com/2504-2289/9/8/213#B18-BDCC-09-00213

\] or the Local Binary Pattern (LBP) \[

https://www.mdpi.com/2504-2289/9/8/213#B19-BDCC-09-00213

Hybrid-based

descriptors combine both geometric and appearance features \[

https://www.mdpi.com/2504-2289/9/8/213#B18-BDCC-09-00213

\]. While hybrid approaches can enhance recognition accuracy, they also tend to increase system complexity, processing time, and computational load.

The feature selection block, although optional, plays a crucial role in improving system efficiency. It aims to reduce the dimensionality of feature vectors by retaining only the most relevant attributes, thereby eliminating redundant and noisy information.

Finally, the classification block typically relies on a supervised machine learning approach. It requires training on labeled samples to build a predictive model capable of classifying new, unlabeled inputs.

3. Related Works

Facial Expression Recognition (FER) has received significant attention, with a wide range of techniques proposed for both static and dynamic settings. Dynamic AFER systems, which analyze image sequences, are particularly effective in capturing the temporal evolution of expressions. However, these systems often encounter computational challenges that hinder real-time deployment.

To address these, Perveen et al. \[

https://www.mdpi.com/2504-2289/9/8/213#B5-BDCC-09-00213

\] proposed a kernel-based dynamic method using a universal Gaussian Mixture Model with a Mean Interval Kernel ( u GMM-MIK), capable of modeling local spatio-temporal patterns while maintaining global contextual variations. Their work shows that probability-based kernels provide strong discriminative capabilities, while matching kernels enhance computational efficiency. In a similar direction, Zhang et al. \[

https://www.mdpi.com/2504-2289/9/8/213#B15-BDCC-09-00213

\] developed a hybrid deep learning framework that fuses spatial and temporal CNNs through a Deep Belief Network (DBN), effectively combining spatio-temporal features for video-based FER.

To better exploit the temporal dimension, spatio-temporal fusion has been explored using both handcrafted and learned features. Aghamaleki and Ashkani Chenarlogh \[

https://www.mdpi.com/2504-2289/9/8/213#B9-BDCC-09-00213

\] introduced a multi-stream CNN architecture that combines traditional descriptors like LBP and Sobel edge maps with CNN-based features, offering a robust solution in contexts with limited training data. Further enhancing robustness, Shahid et al. \[

https://www.mdpi.com/2504-2289/9/8/213#B7-BDCC-09-00213

\] partitioned the face into eleven sub-regions and extracted harmonic shape descriptors to mitigate the impact of misalignments, lighting variations, and occlusions.

Feature selection also plays a critical role in balancing recognition performance with computational cost. Pham et al. \[

https://www.mdpi.com/2504-2289/9/8/213#B20-BDCC-09-00213

\] introduced a custom loss function that encourages intra-class compactness and inter-class separability, yielding highly discriminative CNN features. In another approach, Vaijayanthi and Arunnehru \[

https://www.mdpi.com/2504-2289/9/8/213#B21-BDCC-09-00213

\] employed dense SIFT features coupled with classical classifiers, showing improved adaptability across varying temporal and environmental conditions.

Regarding classification, several strategies have been proposed to handle the multi-class nature of emotion recognition. Sen et al. \[

https://www.mdpi.com/2504-2289/9/8/213#B17-BDCC-09-00213

\] utilized Directed Acyclic Graph SVMs (DAGSVM) to achieve accurate and efficient multi-emotion classification. Kartheek et al. \[

https://www.mdpi.com/2504-2289/9/8/213#B22-BDCC-09-00213

\] introduced Windmill Graph-based Feature Descriptors (WGFD), leveraging graph structures to encode local and global pixel relationships, which outperformed conventional descriptors when paired with multi-class SVMs.

For real-time applications, some studies emphasized lightweight solutions. Lopez-Gil and Garay-Vitoria \[

https://www.mdpi.com/2504-2289/9/8/213#B6-BDCC-09-00213

\] achieved near real-time performance by classifying individual frames using an ensemble of classifiers, striking a balance between accuracy and speed. Similarly, Perveen et al. \[

https://www.mdpi.com/2504-2289/9/8/213#B5-BDCC-09-00213

\] highlighted the potential of dynamic kernels to reduce computational burden while maintaining recognition performance.

Recent advances in deep learning have further pushed the field forward. Yang et al. \[

https://www.mdpi.com/2504-2289/9/8/213#B23-BDCC-09-00213

\] developed a multi-branch CNN with a multi-source loss function to boost generalization under uncontrolled conditions. Singh et al. \[

https://www.mdpi.com/2504-2289/9/8/213#B24-BDCC-09-00213

\] designed a hybrid architecture combining 3D-CNN and ConvLSTM modules, capturing temporal dependencies more effectively than standard LSTM-based models while preserving spatial features.

Several studies have explored hybrid representations. Mukhopadhyay et al. \[

https://www.mdpi.com/2504-2289/9/8/213#B25-BDCC-09-00213

\] integrated Completed Local Binary Patterns (CLBP) with CNNs to improve resilience to noise, pose, and lighting changes. Kumar Tataji et al. \[

https://www.mdpi.com/2504-2289/9/8/213#B26-BDCC-09-00213

\] proposed a Cross-Connected CNN (CC-CNN) that fuses handcrafted descriptors like Cyclopentane Feature Descriptor (CyFD) with learned features across multiple layers to extract both local and global information.

Handcrafted descriptors remain relevant in certain contexts. Verma et al. \[

https://www.mdpi.com/2504-2289/9/8/213#B27-BDCC-09-00213

\] introduced the Cross-Centroid Ripple Pattern (CRIP), which models spatial variation via centroid analysis across concentric ripples, enhancing the model's ability to detect spontaneous expressions and subtle changes under varying conditions.

In terms of architectural innovation, Reddy et al. \[

https://www.mdpi.com/2504-2289/9/8/213#B28-BDCC-09-00213

\] proposed the Deep Cross Feature Adaptive CNN (DCFA-CNN), a two-branch architecture extracting both shape and texture features via dedicated modules, followed by cross-feature fusion to better target expression-relevant regions.

To address the challenge of limited training data, transfer learning approaches have proven valuable. Li et al. \[

https://www.mdpi.com/2504-2289/9/8/213#B29-BDCC-09-00213

\] introduced a Feature Transfer Learning (FTL) framework that uses a large pre-trained model to guide a smaller FER model, aligning features via selective parameter sharing to accelerate convergence and retain flexibility.

Multimodal fusion has also emerged as a promising direction. Samadiani et al. \[

https://www.mdpi.com/2504-2289/9/8/213#B30-BDCC-09-00213

\] presented VERMFF, a multimodal framework combining visual (e.g., LBP, LBP-TOP) and audio modalities. A kernel-based sparse representation mechanism selects keyframes, while a random forest and decision-level fusion improve performance in unconstrained environments.

Graph-based approaches have recently gained traction. Ngoc et al. \[

https://www.mdpi.com/2504-2289/9/8/213#B8-BDCC-09-00213

\] proposed a Directed Graph Neural Network (DGNN) that represents facial landmarks as graph nodes connected via Delaunay triangulation. A master node is added to enhance global communication, and gated linear units (GLU) stabilize temporal modeling. The model's accuracy is further improved through late fusion with appearance-based CNNs.

Together, these studies highlight the critical importance of effective spatio-temporal feature modeling, discriminative classification, and computational efficiency in dynamic FER. Building upon these insights, our proposed method leverages statistical geometric spatio-temporal descriptors and optimized feature selection, offering a balanced solution that achieves competitive accuracy while remaining computationally lightweight—a valuable feature for real-time applications.

4. Limitations & Challenges

The review of existing dynamic FER methods highlights several recurrent and emerging challenges that limit their practical deployment, especially in real-time and unconstrained environments. These challenges, many of which remain critical in recent literature, can be categorized into computational, robustness, and representation-related limitations.

## Computational Complexity and Efficiency Challenges

Traditional deep learning models, despite achieving high accuracy, often come with excessive computational complexity, large parameter sizes, and significant memory and inference costs \[

https://www.mdpi.com/2504-2289/9/8/213#B31-BDCC-09-00213

https://www.mdpi.com/2504-2289/9/8/213#B32-BDCC-09-00213

https://www.mdpi.com/2504-2289/9/8/213#B33-BDCC-09-00213

https://www.mdpi.com/2504-2289/9/8/213#B34-BDCC-09-00213

https://www.mdpi.com/2504-2289/9/8/213#B35-BDCC-09-00213

https://www.mdpi.com/2504-2289/9/8/213#B36-BDCC-09-00213

\]. Recent state-of-the-art models such as POSTER++ \[

https://www.mdpi.com/2504-2289/9/8/213#B31-BDCC-09-00213

\] incorporate sophisticated components like two-stream pipelines, pyramidal feature extractors, and cross-attention mechanisms, achieving high accuracy but at the cost of high computational complexity and large parameter counts. This reliance on computationally intensive deep architectures, including 3D convolutions, recurrent units, or multi-branch designs \[

https://www.mdpi.com/2504-2289/9/8/213#B15-BDCC-09-00213

https://www.mdpi.com/2504-2289/9/8/213#B24-BDCC-09-00213

https://www.mdpi.com/2504-2289/9/8/213#B28-BDCC-09-00213

\], severely restricts their suitability for real-time applications and deployment on low-resource or embedded devices \[

https://www.mdpi.com/2504-2289/9/8/213#B32-BDCC-09-00213

https://www.mdpi.com/2504-2289/9/8/213#B34-BDCC-09-00213

https://www.mdpi.com/2504-2289/9/8/213#B35-BDCC-09-00213

Traditional attention mechanisms, such as vanilla cross-attention, often have quadratic complexity, making them unsuitable for low-latency applications \[

https://www.mdpi.com/2504-2289/9/8/213#B31-BDCC-09-00213

\]. While lightweight FER models \[

https://www.mdpi.com/2504-2289/9/8/213#B32-BDCC-09-00213

https://www.mdpi.com/2504-2289/9/8/213#B34-BDCC-09-00213

https://www.mdpi.com/2504-2289/9/8/213#B35-BDCC-09-00213

\] aim to address deployment constraints, they often sacrifice representation power, leading to limited accuracy and poor generalization, especially under varying illumination, occlusions, and pose variations.

## Robustness and Generalization Issues

Current AFER systems frequently demonstrate a lack of robustness in uncontrolled environments due to factors such as occlusions, pose variations, illumination changes, motion blur, and subtle/transient expressions \[

https://www.mdpi.com/2504-2289/9/8/213#B33-BDCC-09-00213

https://www.mdpi.com/2504-2289/9/8/213#B36-BDCC-09-00213

https://www.mdpi.com/2504-2289/9/8/213#B37-BDCC-09-00213

\]. Models trained in constrained, single-modality settings often fail to generalize well to “ in-the-wild” datasets, leading to a significant domain gap \[

https://www.mdpi.com/2504-2289/9/8/213#B33-BDCC-09-00213

https://www.mdpi.com/2504-2289/9/8/213#B36-BDCC-09-00213

\]. The reliance on unimodal input (e.g., RGB images) is often insufficient for resilience to noise or missing data \[

https://www.mdpi.com/2504-2289/9/8/213#B37-BDCC-09-00213

Multimodal approaches employing RGB, optical flow, depth, and landmarks \[

https://www.mdpi.com/2504-2289/9/8/213#B37-BDCC-09-00213

\] enhance robustness in uncontrolled settings, yet these methods remain computationally expensive and struggle to efficiently fuse diverse modalities in real time. Methods relying on optical flow can be sensitive to noise and occlusions \[

https://www.mdpi.com/2504-2289/9/8/213#B36-BDCC-09-00213

\], while 3D CNNs, despite capturing spatio-temporal properties, often lead to an increased number of training parameters \[

https://www.mdpi.com/2504-2289/9/8/213#B36-BDCC-09-00213

## Expression Modeling and Representation Challenges

A particularly pressing issue, highlighted in recent research, is the difficulty in recognizing compound expressions and modeling their inherent ambiguity in real-world conditions \[

https://www.mdpi.com/2504-2289/9/8/213#B38-BDCC-09-00213

\]. Most traditional models focus on basic emotions and struggle with nuanced combinations of expressions, failing to capture the overlapping nature and varying degrees of emotional states \[

https://www.mdpi.com/2504-2289/9/8/213#B38-BDCC-09-00213

\]. Hybrid architectures that combine CNNs and transformers \[

https://www.mdpi.com/2504-2289/9/8/213#B38-BDCC-09-00213

\] show promise in modeling the ambiguity and complexity of compound emotions, but face challenges in capturing fine-grained local textures while modeling global dependencies, requiring sophisticated multi-label learning schemes that complicate training and inference.

Challenges persist in efficiently handling multi-scale features and designing adaptive attention mechanisms \[

https://www.mdpi.com/2504-2289/9/8/213#B31-BDCC-09-00213

https://www.mdpi.com/2504-2289/9/8/213#B35-BDCC-09-00213

https://www.mdpi.com/2504-2289/9/8/213#B37-BDCC-09-00213

\]. There is a need for lightweight and effective feature fusion strategies that can capture both local texture and global dependencies without sacrificing efficiency \[

https://www.mdpi.com/2504-2289/9/8/213#B35-BDCC-09-00213

https://www.mdpi.com/2504-2289/9/8/213#B38-BDCC-09-00213

\]. Additionally, many CNN-based methods overly focus on central facial regions, neglecting subtle cues on the cheeks or forehead.

## Data and Training Limitations

The underlying data limitations remain a persistent challenge, as FER datasets are often small, suffer from class imbalance, and are tailored for specific tasks, leading to overfitting in deep models \[

https://www.mdpi.com/2504-2289/9/8/213#B33-BDCC-09-00213

https://www.mdpi.com/2504-2289/9/8/213#B36-BDCC-09-00213

\]. Training difficulties include the need for extensive hyperparameter tuning and sensitivity to class imbalance, particularly in accurately recognizing compound or subtle expressions \[

https://www.mdpi.com/2504-2289/9/8/213#B36-BDCC-09-00213

https://www.mdpi.com/2504-2289/9/8/213#B38-BDCC-09-00213

High dimensionality of feature vectors in handcrafted or hybrid methods increases memory footprint and inference latency, while temporal inconsistency and difficulties in preserving the authentic dynamics of facial sequences affect methods that rely on frame sampling or normalization \[

https://www.mdpi.com/2504-2289/9/8/213#B36-BDCC-09-00213

## Essential Requirements for Effective Dynamic FER Systems

Based on these observations and the latest research, we identify five essential requirements for an effective dynamic AFER system that aims to address these persistent and emerging challenges:

Preservation of sequence integrity without adding or removing frames, to maintain authentic temporal dynamics, crucial given the complexity of dynamic emotional evolution \[

https://www.mdpi.com/2504-2289/9/8/213#B37-BDCC-09-00213

Construction of a compact spatio-temporal representation that efficiently captures both spatial geometry and temporal evolution, directly addressing the need for lighter models and efficient feature fusion \[

https://www.mdpi.com/2504-2289/9/8/213#B31-BDCC-09-00213

https://www.mdpi.com/2504-2289/9/8/213#B32-BDCC-09-00213

Computational efficiency suitable for real-time use, avoiding heavy models or large feature vectors, enabling deployment on low-resource devices without sacrificing accuracy \[

https://www.mdpi.com/2504-2289/9/8/213#B31-BDCC-09-00213

https://www.mdpi.com/2504-2289/9/8/213#B32-BDCC-09-00213

https://www.mdpi.com/2504-2289/9/8/213#B34-BDCC-09-00213

https://www.mdpi.com/2504-2289/9/8/213#B35-BDCC-09-00213

Achieving competitive accuracy comparable to state-of-the-art methods, while balancing it with efficiency and demonstrating robustness across multiple benchmark datasets \[

https://www.mdpi.com/2504-2289/9/8/213#B33-BDCC-09-00213

Demonstrating robustness and generalization across diverse datasets and challenging “ in-the-wild” scenarios, including compound emotions, with interpretability and simplicity to facilitate deployment and maintenance \[

https://www.mdpi.com/2504-2289/9/8/213#B33-BDCC-09-00213

https://www.mdpi.com/2504-2289/9/8/213#B37-BDCC-09-00213

https://www.mdpi.com/2504-2289/9/8/213#B38-BDCC-09-00213

Our proposed method effectively addresses these challenges by relying on a purely geometric, statistical modeling of landmark-based distances over time. Unlike deep or hybrid models, it eschews deep feature extraction, sequence normalization, and complex attention mechanisms, producing a compact and discriminative spatio-temporal representation. This approach preserves the authentic temporal dynamics of sequences, substantially reduces computational load, and is highly suitable for real-time applications. Importantly, it achieves competitive accuracy and robust performance across multiple benchmark datasets, making it a practical and efficient alternative to existing complex methods.

5. Proposed Approach

As illustrated in

https://www.mdpi.com/2504-2289/9/8/213#fig\_body\_display\_BDCC-09-00213-f002

, the proposed dynamic AFER approach follows the same fundamental building blocks as a typical pattern recognition system (refer to

https://www.mdpi.com/2504-2289/9/8/213#sec2-BDCC-09-00213

). In our case, the input consists of a facial expression dataset where the number of frames per image sequence may vary.

Overview of our dynamic AFER approach.

In the following sections, we detail each component of the proposed dynamic AFER approach, namely feature extraction, feature selection, and classification.

## Feature Extraction

As discussed in

https://www.mdpi.com/2504-2289/9/8/213#sec2-BDCC-09-00213

, three types of features are commonly distinguished in the field of AFER. In our approach, we focus specifically on geometric-based features, which offer the advantage of being invariant to face translation, rotation, and illumination.

Before computing the feature vectors, we apply the Viola and Jones algorithm \[

https://www.mdpi.com/2504-2289/9/8/213#B39-BDCC-09-00213

\] to detect the face region (see

https://www.mdpi.com/2504-2289/9/8/213#fig\_body\_display\_BDCC-09-00213-f003

). As illustrated in

https://www.mdpi.com/2504-2289/9/8/213#fig\_body\_display\_BDCC-09-00213-f002

, our method requires a combination of two distinct representations: spatial and temporal.

Overview of the pre-processing steps.

The spatial representation involves extracting the facial shape. Several techniques, such as AAM and ASM, can be used for this purpose. However, we chose a more recent method introduced by Kazemi and Sullivan \[

https://www.mdpi.com/2504-2289/9/8/213#B40-BDCC-09-00213

\], which enables the extraction of sixty-eight facial fiducial points, as shown in

https://www.mdpi.com/2504-2289/9/8/213#fig\_body\_display\_BDCC-09-00213-f003

. This technique is based on the following Equation (

https://www.mdpi.com/2504-2289/9/8/213#FD1-BDCC-09-00213

S ^ t + 1 = S ^ t + r t ( I , S ^ t )

Here, the input consists of the current estimation of the face shape S ^ t and the input face image I. The facial shape is defined as S = P 1 , P 2 , … , P N ∈ R 2 N , where each element P i represents a specific facial fiducial point. We denote | S | = N = 68 facial fiducial points, and each point P i is represented by Cartesian coordinates P i ( x i , y i ) . The goal of Equation (

https://www.mdpi.com/2504-2289/9/8/213#FD1-BDCC-09-00213

) is to iteratively adjust the face shape until convergence, using the regression function r t ( ) , which takes as inputs S ^ t and I. This function is implemented as a cascade of decision trees trained using the gradient boosting method.

Following inspiration from previous works \[

https://www.mdpi.com/2504-2289/9/8/213#B16-BDCC-09-00213

\], the spatial representation of the input is achieved by computing all possible Euclidean distances between pairs of facial fiducial points (see Equation (

https://www.mdpi.com/2504-2289/9/8/213#FD2-BDCC-09-00213

)). For each frame of an image sequence, we have | S | = N = 68 facial fiducial points, resulting in n = 2278 possible distances, as shown in Equation (

https://www.mdpi.com/2504-2289/9/8/213#FD3-BDCC-09-00213

D E u c l i d e a n ( P a , P b ) = ( x a − x b ) 2 + ( y a − y b ) 2

n = N × ( N − 1 ) 2

As noted earlier, an image sequence consists of a variable number of frames, denoted as m. Thus, we must extract | V s | = m feature vectors, with each vector corresponding to a specific frame in the image sequence (see

https://www.mdpi.com/2504-2289/9/8/213#fig\_body\_display\_BDCC-09-00213-f004

). The spatial representation can be defined as V s = v s 1 , v s 2 , … , v s m , where v s i = D 1 i , D 2 i , … , D n i is the descriptor vector for the i t h frame, with i = 1 , 2 , … , m . Each vector v s i contains all the possible Euclidean distances represented by D j i , corresponding to the j t h distance, where j = 1 , 2 , … , n = 2278 . This representation is inspired by FACS \[

https://www.mdpi.com/2504-2289/9/8/213#B4-BDCC-09-00213

\], but instead of using specific distances corresponding to Action Units (AUs), we compute all possible distances.

Spatio-temporal representation of the input.

While the spatial representation may suffice for recognition, as demonstrated in \[

https://www.mdpi.com/2504-2289/9/8/213#B16-BDCC-09-00213

\], it still faces challenges, particularly the variable number of frames in each image sequence. This requires sequence normalization to apply a supervised machine learning technique effectively. Even after normalization, this approach remains computationally expensive in terms of time and resources. To address this issue, we propose a new representation to capture the temporal variations of each Euclidean distance D j i using statistical metrics. As shown in

https://www.mdpi.com/2504-2289/9/8/213#fig\_body\_display\_BDCC-09-00213-f004

, the spatio-temporal representation is defined as V s t = v s t 1 , v s t 2 , … , v s t n , where each vector v s t j contains a triplet of statistical metrics that represent the temporal variation of the j t h Euclidean distance. The statistical metrics are as follows: variance (Equation (

https://www.mdpi.com/2504-2289/9/8/213#FD4-BDCC-09-00213

)), skewness (Equation (

https://www.mdpi.com/2504-2289/9/8/213#FD5-BDCC-09-00213

)), and kurtosis (Equation (

https://www.mdpi.com/2504-2289/9/8/213#FD6-BDCC-09-00213

V j = σ 2 ( D j ) = ∑ i = 1 m ( D j i − D ¯ j ) 2 m

S j = γ 1 ( D j ) = ∑ i = 1 m ( D j i − D ¯ j ) 3 m σ 3 ( D j )

K j = γ 2 ( D j ) = ∑ i = 1 m ( D j i − D ¯ j ) 4 m σ 4 ( D j )

Finally, the resulting spatio-temporal representation of the input is defined by the feature vector V s t . This descriptor vector has | V s t | = 3 × n = 6834 distinct attributes.

## Feature Selection

As previously defined, the size of the obtained spatio-temporal representation is estimated at | V s t | = 6834 . However, it is well-known that a high number of attributes can lead to several issues, such as overfitting, which arises from redundant or noisy attributes; an increase in training time due to the larger feature space; and a potential accuracy reduction since some attributes may be misleading or irrelevant when constructing the model. To address these challenges, we introduce a feature selection stage (see

https://www.mdpi.com/2504-2289/9/8/213#fig\_body\_display\_BDCC-09-00213-f002

) aimed at reducing the size of the spatio-temporal representation.

Several feature selection techniques have been proposed in the literature. Among them, Principal Component Analysis (PCA) \[

https://www.mdpi.com/2504-2289/9/8/213#B19-BDCC-09-00213

\] remains one of the most common approaches. PCA is a statistical procedure that applies an orthogonal transformation to convert a set of potentially correlated attributes into a set of linearly uncorrelated variables known as principal components. This transformation improves the discriminatory power of the features by maximizing the variance captured in the selected components. Another approach involves ranking attributes by their importance. In this method, each attribute is assigned a score, and the higher the score, the more important the attribute is deemed. Based on these scores, a threshold is applied to select the most relevant attributes, determining the percentage of features to retain.

For our approach, we utilize the ExtRa-Trees technique, which is a variant of Random Forests \[

https://www.mdpi.com/2504-2289/9/8/213#B41-BDCC-09-00213

\]. As described in \[

https://www.mdpi.com/2504-2289/9/8/213#B42-BDCC-09-00213

\], the ExtRa-Trees algorithm constructs an ensemble of unpruned decision or regression trees using a classical top-down procedure. The key differences between ExtRa-Trees and other tree-based ensemble methods are that node splits are chosen completely at random, and the entire learning sample is used to grow the trees, rather than relying on a bootstrap replica.

In our case, we propose using the ExtRa-Trees technique along with the Gini index as the impurity measure. In a supervised manner, the feature vectors, along with their corresponding labels, are employed to build the ExtRa-Trees model. Subsequently, the feature importance is determined by generating score values for each attribute. The attributes are then ranked in descending order of importance. As illustrated in

https://www.mdpi.com/2504-2289/9/8/213#fig\_body\_display\_BDCC-09-00213-f002

, a threshold is set to select a specific percentage of the most important features. This threshold is incrementally adjusted until the model's accuracy reaches convergence.

## Classification

Classification represents the final component of the dynamic AFER approach, enabling the identification of various facial expressions. It relies on a supervised machine learning technique, requiring a training or learning phase with labeled samples. Furthermore, machine learning techniques are often sensitive to the value range of feature vectors. To improve accuracy, we propose applying a value normalization technique. We employ min-max normalization, which transforms the data into a predefined range, as shown in Equation (

https://www.mdpi.com/2504-2289/9/8/213#FD7-BDCC-09-00213

v n o r m = v − V min V max − V min × R max − R min + R min

Each element of the original feature vector is represented by v, with its current value range defined by \[ V min , V max \] . The new range for the normalized feature vector is \[ R min , R max \] , where we set R min = 0 and R max = 1 . While various machine learning techniques can be explored, we focus on two specific ones: k-NN and SVM, also testing other methods for an objective comparison of recognition rates.

We evaluated several commonly used classifiers in the field, prioritizing those with optimized implementations that are suitable for deployment in resource-constrained environments. Based on preliminary experiments, we shortlisted four classifiers—SVM, k-NN, DT, and MLP. For each technique, hyperparameters were carefully tuned to achieve the best possible performance within our experimental framework.

### SVM Classifier

The Support Vector Machine (SVM) classifier is a supervised machine learning technique introduced by Cortes and Vapnik \[

https://www.mdpi.com/2504-2289/9/8/213#B43-BDCC-09-00213

\]. The algorithm constructs a hyperplane designed to optimally separate two distinct classes. Thus, SVM is a binary classifier, as it distinguishes between two classes. For linearly separable datasets, multiple hyperplanes can be used to separate the classes. However, the best choice is the hyperplane that maximizes the margin to the nearest data points, known as the maximum-margin hyperplane. As defined in \[

https://www.mdpi.com/2504-2289/9/8/213#B44-BDCC-09-00213

\], a basic linear SVM classifier is represented by (see Equation (

https://www.mdpi.com/2504-2289/9/8/213#FD8-BDCC-09-00213

y i = sign ( 〈 w , x i 〉 + b )

where ( w , b ) represent the maximum-margin hyperplane, x i ∈ R D are the feature vectors, and y i ∈ ± 1 are the labels. The SVM algorithm can also handle nonlinearly separable datasets using the kernel trick, which maps the data into a transformed feature space to find the maximum-margin hyperplane.

In our case, we employed a linear SVM classifier due to its robustness and generalization capabilities. However, we face a multi-class classification problem, as we need to distinguish between M facial expressions. Fortunately, this limitation can be overcome by combining multiple SVM classifiers. Two strategies are commonly used: (1) One-Against-One, where an SVM classifier is trained for each possible pair of classes, and (2) One-Against-All, where an SVM classifier is built for each class. For the proposed dynamic AFER approach, we chose the One-Against-All strategy, as it requires training fewer classifiers. Additionally, the best performance in terms of accuracy was achieved with the cost variable set to C = 1 .

5.3.2. k-NN Classifier

The k-NN classifier is one of the simplest machine learning techniques and belongs to the category of instance-based methods \[

https://www.mdpi.com/2504-2289/9/8/213#B45-BDCC-09-00213

\]. The learning phase involves storing the training samples, and the prediction of an unlabeled instance is made by finding the closest neighbors in the training set. Its main advantage over other methods lies in its simplicity and interpretability, as it does not generate a black-box model. To construct a k-NN classifier, two parameters must be defined: (1) k, the number of neighbors to consider for classification, and (2) ρ , the distance metric used to compute the distance between training instances and the one to classify. The k-NN classification is determined by the majority label among y π i ( x ) : i ≤ k , where y are the labels, π i ( x ) is the reordering of training set instances based on the distance ρ ( x , x i ) , and k is the number of nearest neighbors considered.

In our case, we employed the k-NN classifier as presented in \[

https://www.mdpi.com/2504-2289/9/8/213#B16-BDCC-09-00213

\]. The number of neighbors was set to k = 1 , and the chosen distance metric ρ is the Cosine distance (see Equation (

https://www.mdpi.com/2504-2289/9/8/213#FD9-BDCC-09-00213

)). In , several other distances such as Euclidean and Manhattan were compared, but the best performance was achieved using Cosine distance:

D C o s i n e ( V a , V b ) = ∑ i = 1 n V a \[ i \] × V b \[ i \] ∑ i = 1 n V a \[ i \] 2 × ∑ i = 1 n V b \[ i \] 2

D C o s i n e is computed between two feature vectors | V a | = n and | V b | = n .

### Other Classifiers

To provide an objective comparison in terms of accuracy, we also tested two other widely-used classification techniques. The first is the Decision Tree (DT) classifier using the

algorithm with the Gini index as the impurity measure. The second technique is the Multi-Layer Perceptron (MLP), which utilizes the well-known backpropagation algorithm during the learning phase.

6. Experimentation & Evaluation

This section presents the validation protocol and experimental results obtained for the proposed dynamic AFER approach. We first describe the benchmark datasets used in our evaluation. Next, we detail the adopted validation strategy, followed by a thorough analysis of classification performance based on various evaluation metrics.

## Benchmark Datasets

To evaluate the effectiveness and generalizability of our method, we used three publicly available and widely recognized benchmark datasets. Each dataset consists of facial expression image sequences that capture the temporal evolution of expressions.

https://www.mdpi.com/2504-2289/9/8/213#table\_body\_display\_BDCC-09-00213-t001

summarizes their characteristics.

Benchmark facial expression datasets.

The Extended Cohn-Kanade (CK+) dataset \[

https://www.mdpi.com/2504-2289/9/8/213#B10-BDCC-09-00213

\] contains 593 video sequences from 123 different subjects, aged between 18 and 50 years, with diverse gender identities and ethnic backgrounds. Each video sequence captures the transition from a neutral expression to a peak facial expression, recorded at 30 frames per second with resolutions of 640 × 490 pixels. Among the 593 sequences, 327 are annotated with one of seven basic emotions: anger (AN), contempt (CO), disgust (DI), fear (FE), happiness (HA), sadness (SA), or surprise (SU). The demographic diversity and high-quality annotations make CK+ one of the most widely used and reliable datasets for benchmarking facial expression recognition systems under controlled conditions.

The MMI Facial Expression Database \[

https://www.mdpi.com/2504-2289/9/8/213#B12-BDCC-09-00213

\] includes over 2900 videos and 1500 high-resolution static images from 75 subjects, offering rich annotations of facial action units (AUs), both at the event level and, partially, at the frame level (neutral, onset, apex, offset). The dataset covers the six basic emotions and includes a small portion of audio-visual laughter data. It offers substantial variation in head pose and expression dynamics, making it suitable for evaluating robustness in dynamic conditions. The participant pool includes subjects from different genders and ethnic backgrounds, enhancing its relevance for cross-cultural studies in expression analysis.

The Multimedia Understanding Group (MUG) dataset \[

https://www.mdpi.com/2504-2289/9/8/213#B11-BDCC-09-00213

\] comprises 931 video sequences collected from 86 participants—51 men (with or without beards) and 35 women—all of Caucasian origin and aged between 20 and 35 years. The dataset is notable for its high-resolution sequences and the gradual, smooth transitions from neutral to expressive states, making it highly appropriate for studying temporal dynamics in facial expression recognition. Although ethnically homogeneous, the dataset provides useful intra-group variability in facial features, grooming, and expression intensity.

## Validation Strategy

We adopted a ten-fold stratified cross-validation strategy to ensure reliable and unbiased evaluation. In this setup, each dataset is partitioned into ten folds, maintaining the class distribution across all subsets. The training and evaluation process is repeated over ten iterations, where in each iteration, nine folds are used to train the model and the remaining one for testing. All experiments were conducted on an HP ProBook equipped with an Intel Core i7 processor and 8 GB of RAM, providing a balanced environment for performance assessment without relying on high-performance computing resources.

The implementation was carried out using Python 3.12 and relied on several widely-used open-source libraries, including scikit-learn for machine learning, scikit-image for image processing, and dlib for facial landmark detection. This software stack ensured reproducibility, flexibility, and compatibility with the proposed dynamic AFER approach.

The final recognition performance is computed by averaging the accuracy obtained across all folds. This validation strategy minimizes the effects of random partitioning and ensures that every data point is used for both training and evaluation.

#### Our experimental evaluation was conducted in the following stages:

#### Classifier Evaluation:

We compared several classification techniques under the same feature extraction pipeline. These included SVM, k-NN, DT, and MLP, allowing us to identify the most effective learning model for our dynamic AFER approach.

Comparison with

State-of-the-Art\*\*:\*\* We benchmarked the performance of our approach against existing methods in the literature using the same datasets and validation setup. This comparison aimed to demonstrate the competitiveness of our method in terms of recognition accuracy.

#### Detailed Metric Analysis:

In addition to accuracy, we also report precision, recall, and F1-score to provide a more comprehensive evaluation of classification performance, especially in the presence of class imbalance.

7. Results & Discussion

This section presents the experimental results and provides a detailed analysis. Each aspect of the evaluation is not only reported but also discussed and interpreted, with particular attention given to the classification performance across different datasets and classifiers, as well as a comparative analysis with state-of-the-art methods.

## Performance of Classifiers

https://www.mdpi.com/2504-2289/9/8/213#fig\_body\_display\_BDCC-09-00213-f005

illustrates the classification accuracy of the proposed dynamic AFER approach using four machine learning classifiers: SVM, k-NN, MLP, and DT. The evaluation was carried out on three benchmark datasets: CK+, MMI, and MUG. As observed, multi-class SVM and k-NN consistently outperform MLP and DT across all datasets, making them the most suitable classifiers for our approach.

Accuracy of the proposed dynamic AFER using different classifiers.

These results can be explained by the nature of the data and the characteristics of each classifier. The multi-class SVM achieves the highest performance across all datasets, likely due to its strong ability to handle non-linear decision boundaries, which are common in spatio-temporal facial features \[

https://www.mdpi.com/2504-2289/9/8/213#B46-BDCC-09-00213

\]. Similarly, k-NN yields competitive results, particularly because of an optimal choice of hyperparameters—namely, the distance metric and the value of k—which align well with the distribution of our geometric descriptors.

In contrast, the DT and MLP classifiers exhibit weaker performance. This can be attributed to their limitations in capturing non-linear relationships effectively in this context, especially without deep architectures or ensemble strategies. Additionally, the relatively high dimensionality of the feature vectors may affect their performance adversely. For DT, large input vectors can lead to overfitting or poor generalization, while for shallow MLPs, the absence of sufficient depth and representational power may hinder learning complex spatio-temporal patterns.

## CK+ Dataset (Six Basic Emotions)

https://www.mdpi.com/2504-2289/9/8/213#table\_body\_display\_BDCC-09-00213-t002

presents the confusion matrix obtained on the CK+ dataset for six emotion classes. The results are overall very good. Recognition rates are close to 100 % for SU, HA, and DI, which is expected due to their distinctive facial muscle activations, making their spatio-temporal patterns easier to discriminate.

Confusion matrix using

(six classes) dataset.

In contrast, slightly lower performance is observed for FE, AN, and SA, with accuracy ranging between 82.14 % and 86.67 % . This drop can be attributed to confusion between these emotions, whose dynamic facial expressions are more subtle and similar. In the case of CK+, this affects the model's ability to fully separate their spatio-temporal trajectories.

These findings confirm the model's ability to effectively distinguish the most expressive emotions, while also highlighting the challenges associated with more ambiguous ones.

https://www.mdpi.com/2504-2289/9/8/213#table\_body\_display\_BDCC-09-00213-t003

presents a comparison of recognition rates for each individual emotion, evaluated against four recent works published between 2019 and 2023. The results are consistent with our findings: all four studies report lower recognition rates for FE, AN, and SA. This convergence reinforces the validity of our results and underlines a common challenge in the field—these particular emotions remain more difficult to classify accurately, indicating that further work is needed to improve performance in these categories.

Recognition rate comparison by emotion with state-of-the-art methods (

https://www.mdpi.com/2504-2289/9/8/213#table\_body\_display\_BDCC-09-00213-t004

compares our proposed method with nine recent state-of-the-art approaches, published between 2019 and 2023, all evaluated using the same six-class setup on CK+. The compared methods span both traditional techniques and deep learning-based models. Our approach, particularly when using the multi-class SVM classifier, achieves the highest recognition accuracy among all tested methods. Only two methods—those proposed by Shahid et al. \[

https://www.mdpi.com/2504-2289/9/8/213#B7-BDCC-09-00213

\] and Singh et al. \[

https://www.mdpi.com/2504-2289/9/8/213#B24-BDCC-09-00213

\]—come close in terms of performance; however, both rely on deep neural networks, which typically require substantial computational resources. In contrast, our method is lightweight and designed to operate efficiently in resource-constrained environments, making its competitive performance particularly noteworthy.

Comparing with state-of-the-art methods (

## MMI Dataset

https://www.mdpi.com/2504-2289/9/8/213#table\_body\_display\_BDCC-09-00213-t005

presents the confusion matrix for the MMI dataset, which is inherently more challenging than CK+ due to greater variability in head pose and lighting conditions. Consequently, we observe a drop in overall recognition performance compared to CK+. Most emotions achieve accuracy rates above 70 % , with HA reaching a notably high accuracy of 95.24 % . However, the FE class exhibits a significant performance decline to 42.86 % , largely due to confusion with SU and SA. This difficulty in distinguishing certain emotions on MMI is a known challenge not unique to our method; many existing and recent approaches face similar limitations when evaluated on this dataset. Further improvements will be needed to better handle these challenging cases.

Confusion matrix using

https://www.mdpi.com/2504-2289/9/8/213#table\_body\_display\_BDCC-09-00213-t006

presents a comparison of recognition rates for each emotion against four recent studies (2020–2023). The results align well with ours, as all four studies report a noticeable drop in performance for the FE emotion. Notably, two methods by Pham et al. \[

https://www.mdpi.com/2504-2289/9/8/213#B20-BDCC-09-00213

\] and Samadiani et al. \[

https://www.mdpi.com/2504-2289/9/8/213#B30-BDCC-09-00213

\] show recognition rates as low as 31 % and 33.5 % respectively for FE. Aside from this, our method demonstrates a more balanced distribution of recognition accuracy across the remaining five emotions.

Recognition rate comparison by emotion with state-of-the-art methods (

As shown in

https://www.mdpi.com/2504-2289/9/8/213#table\_body\_display\_BDCC-09-00213-t007

, we compared our method with eight existing approaches published between 2019 and 2024. Our method consistently achieves the highest accuracy, particularly when using the multi-class SVM classifier. The only exception is a method by Yang et al. \[

https://www.mdpi.com/2504-2289/9/8/213#B23-BDCC-09-00213

\], which employs deep CNNs and outperforms ours by less than 1 % . It is also worth noting that, in this dataset, there is a larger performance gap of about 10 % between our multi-class SVM and k-NN classifiers, whereas on the CK+ dataset this difference was closer to 5 % . These results further confirm the strong generalization capabilities of our approach across datasets with varying acquisition conditions and subject variability.

Comparing with state-of-the-art methods (

## MUG Dataset

https://www.mdpi.com/2504-2289/9/8/213#table\_body\_display\_BDCC-09-00213-t008

presents the confusion matrix obtained on the MUG dataset. Overall, the results are excellent, with all emotions being recognized with an accuracy above 90 % . Notably, the model achieves near-perfect recognition for certain expressions such as disgust and happiness. The only exception is FE, which is recognized with an accuracy of 86.61 % and is mainly confused with SU. Compared to the other datasets, MUG yields the highest overall performance. This can be attributed to its high-resolution sequences, smooth and natural expression transitions, as well as a larger and more balanced number of samples across all emotion classes.

Confusion matrix using

https://www.mdpi.com/2504-2289/9/8/213#table\_body\_display\_BDCC-09-00213-t009

presents a comparison of emotion-wise recognition rates between our method and four recent studies (2019–2024). The results show a strong alignment with ours, particularly regarding the emotion FE, which remains challenging across all methods. Reported accuracies for FE range from 63.60 % (Kartheek et al. \[

https://www.mdpi.com/2504-2289/9/8/213#B22-BDCC-09-00213

\]) to 87.50 % (Shahid et al. \[

https://www.mdpi.com/2504-2289/9/8/213#B7-BDCC-09-00213

\]), showing less than a 1 % difference from our results. For the remaining emotions, performance is more balanced. Notably, our method achieves superior recognition rates for DI and SA compared to all four referenced approaches.

Recognition rate comparison by emotion with state-of-the-art methods (

As shown in

https://www.mdpi.com/2504-2289/9/8/213#table\_body\_display\_BDCC-09-00213-t010

, we compared our method with nine existing approaches published between 2019 and 2024. Our method consistently achieves the highest accuracy, particularly when using the multi-class SVM classifier. The only two approaches with comparable performance are those proposed by Shahid et al. \[

https://www.mdpi.com/2504-2289/9/8/213#B7-BDCC-09-00213

\] ( 92.57 % ) and Kumar Tataji et al. \[

https://www.mdpi.com/2504-2289/9/8/213#B26-BDCC-09-00213

\] ( 93.46 % ), both relying on deep neural networks. In contrast, our method avoids the use of deep learning to maintain a lightweight and resource-efficient architecture. Interestingly, the performance gap between k-NN and multi-class SVM is the smallest on this dataset—less than 3 % —which highlights the effectiveness of k-NN in this case. This can be attributed to the balanced distribution and the relatively large number of samples in the dataset, which favor instance-based learning.

Comparing with state-of-the-art methods (

## CK+ Dataset (Seven Classes Including Contempt)

To further assess the scalability of our method, we extended the CK+ dataset by including a seventh emotion category: CO. As shown in

https://www.mdpi.com/2504-2289/9/8/213#table\_body\_display\_BDCC-09-00213-t011

, the addition of this new class led to a slight drop in overall accuracy, from 91.65 % to 88.41 % . This decrease is mainly due to increased confusion between SA and CO, with the recognition rate for SA falling from 82.14 % to 75 % . Interestingly, contempt itself is recognized with a slightly higher accuracy of 77.78 % , indicating that although it is a challenging emotion to classify, the model is still able to distinguish it reasonably well.

Confusion matrix using

(seven classes) dataset.

## Detailed Metric Analysis

https://www.mdpi.com/2504-2289/9/8/213#table\_body\_display\_BDCC-09-00213-t012

presents a comprehensive evaluation of the proposed approach using five key performance metrics: F1-Score, Recall, Precision, Accuracy, and ∑ Attributes, which denotes the total number of attributes used for classification. These metrics provide detailed insights into both the predictive performance and the efficiency of the method.

Evaluation using various metrics.

From the table, it can be observed that the F1-score and recall are closely aligned with the overall accuracy, while the precision is slightly higher. This indicates a lower false positive rate, which is a favorable outcome for our method. Across all three benchmark datasets, the difference between accuracy and precision remains consistently just above 1 % , highlighting the robustness of the model.

In terms of feature vector size, the goal was to significantly reduce the number of attributes while maintaining strong recognition performance. Starting from an initial feature vector of 6834 dimensions, the dimensionality was reduced to 724 for the MUG dataset, 806 for MMI, and 1114 for CK+ (six-emotion configuration). For CK+ with seven emotions, the reduction was slightly less effective but still achieved a 70.9 % reduction relative to the original spatio-temporal representation. These results clearly demonstrate the effectiveness of our feature selection strategy, both in enhancing computational efficiency and preserving classification accuracy.

https://www.mdpi.com/2504-2289/9/8/213#table\_body\_display\_BDCC-09-00213-t013

provides an evaluation of the computational efficiency of the proposed method, focusing on both the training and prediction phases. As expected, there is little variation in prediction time across datasets, since the classification involves processing a single image sequence at a time. However, a clear difference emerges between the classifiers: the multi-class SVM consistently outperforms the k-NN in terms of prediction speed, achieving an average of 0.02 s per sequence, while k-NN requires between 0.14 and 0.17 s. This slower performance is due to the fact that k-NN must scan, reorganize, and compare the input to the entire training set before making a decision.

Measure of the run-time during training and prediction.

In contrast, during the training phase, dataset size plays a more significant role. Larger datasets naturally require more time to process. The multi-class SVM, being a model-based approach, requires between 6.28 and 10.15 s to train, depending on the dataset. On the other hand, k-NN—as an instance-based learning method—does not involve explicit model training, resulting in negligible training time. This highlights the trade-off between training and inference efficiency depending on the chosen classifier.

8. Conclusions & Future Work

In this paper, we introduced a novel dynamic approach to AFER. Unlike traditional static methods that analyze isolated images, dynamic methods capture the temporal evolution of facial expressions by leveraging the transitional phases— onset, apex, and offset. To this end, we proposed a method that constructs a compact spatio-temporal representation from image sequences, allowing for a richer and more informative characterization of facial dynamics.

We evaluated our approach using three widely adopted benchmark datasets: CK+, MMI, and MUG. The experimental analysis was carried out in several stages. First, we assessed different classifiers and observed that SVM and k-NN consistently yielded the best performance. We then compared our method against recent state-of-the-art techniques. The results confirm that our sequence-based dynamic approach, particularly when coupled with SVM, achieves superior classification accuracy.

Beyond accuracy, our method also demonstrates excellent computational efficiency. It operates with a significantly reduced feature set while maintaining high performance and competitive training and inference times. This makes it suitable for deployment in real-time or resource-constrained environments.

Despite these promising results, the proposed approach has certain limitations. Most notably, it is currently restricted to frontal-view image sequences captured in controlled environments. While this was appropriate given the objectives and scope of the present study, it does not reflect the variability of real-world (“ in-the-wild”) conditions, such as diverse poses, occlusions, and lighting. Extending our approach to handle multi-view or pose-invariant scenarios is therefore a compelling direction for future research. Such an extension would improve the applicability of our method in more unconstrained and practical settings.

Additionally, the recognition rates for more subtle emotions like sadness and fear remain relatively low, which may stem from the limited expressiveness of their geometric signatures and the exclusive use of landmark-based features in our pipeline. Integrating appearance-based or deep-learned descriptors could potentially address this gap and improve robustness across all emotion categories.

Finally, the overall performance of our system is closely tied to the accuracy of facial landmark detection. Errors in fiducial point localization can significantly impact the quality of the extracted features and the final classification. Strengthening this preprocessing step is essential to enhance the reliability of the full recognition pipeline.

Moreover, while our method shows strong comparative results, we acknowledge the absence of formal statistical significance testing in our evaluation. This limitation is partly due to the lack of access to individual run results or multiple evaluation splits for the compared methods, which prevents meaningful hypothesis testing. Performance differences—although often small—have thus not been statistically validated. We plan to incorporate appropriate statistical tests (e.g., paired t-tests or Wilcoxon tests) in future work to better assess the robustness of our comparative results when such data becomes available.

In summary, the proposed dynamic AFER framework provides a solid foundation for temporally aware and computationally efficient facial expression recognition. While it has proven effective in controlled scenarios, future work will aim to broaden its scope toward more realistic, “ in-the-wild” applications, making it a more versatile tool for affective computing in everyday contexts.

This research received no external funding.

Data Availability Statement

Data supporting the reported results are based on publicly available reference datasets widely used in the field, which can be accessed upon request by signing a data usage agreement. These datasets are not owned by the author but were made available through formal access requests according to the specified instructions.

Acknowledgments

The authors would like to acknowledge the use of ChatGPT (OpenAI, GPT-4, accessed April 2025) for assistance in correcting grammar, spelling, and improving the overall clarity and formulation of the text during the preparation of this manuscript. The authors have reviewed and edited the generated content and take full responsibility for the final version of the publication. We would also like to express our gratitude to all individuals and organizations that provided the benchmark facial expression datasets—CK+ \[

https://www.mdpi.com/2504-2289/9/8/213#B10-BDCC-09-00213

https://www.mdpi.com/2504-2289/9/8/213#B12-BDCC-09-00213

\], and MUG \[

https://www.mdpi.com/2504-2289/9/8/213#B11-BDCC-09-00213

\]—which were instrumental in validating our approach.

Conflicts of Interest

The author declares no conflicts of interest.

Abbreviations

#### The following abbreviations are used in this manuscript:

Ambient Assisted Living

Automatic Facial Expression Recognition

Facial Expression Recognition

k-Nearest Neighbors

Action Unit

Extended Cohn-Kanade

Multimedia Understanding Group

Support Vector Machine

Scale-Invariant Feature Transform

Information and Communication Technologies

Human–Computer Interaction

Facial Action Coding System

Extra-Trees

Extremely Randomized Trees

Active Shape Model

Active Appearance Model

Discrete Wavelet Transform

Local Binary Pattern

Convolutional Neural Network

Deep Belief Network

universal Gaussian Mixture Model Mean Interval Kernel

Directed Acyclic Graph SVM

Long short-term memory

Windmill Graph-based Feature Descriptors

Completed Local Binary Patterns

Cyclopentane Feature Descriptor

Cross-Connected Convolutional Neural Network

Cross-Centroid Ripple Pattern

Deep Cross Feature Adaptive Convolutional Neural Network

Feature Transfer Learning

Local Binary Pattern on Three Orthogonal Planes

Directed Graph Neural Network

Gated Linear Units

Principal Component Analysis

Decision Tree

Multi-Layer Perceptron

Transfer Learning

Mehrabian, A. Communication without words. Psychol. Today

, 2, 51–52. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Communication+without+words&author=Mehrabian,+A.&publication\_year=1968&journal=Psychol.+Today&volume=2&pages=51%E2%80%9352

Yaddaden, Y.; Adda, M.; Bouzouane, A.; Gaboury, S.; Bouchard, B. User action and facial expression recognition for error detection system in an ambient assisted environment. Expert Syst. Appl.

, 112, 173–189. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=User+action+and+facial+expression+recognition+for+error+detection+system+in+an+ambient+assisted+environment&author=Yaddaden,+Y.&author=Adda,+M.&author=Bouzouane,+A.&author=Gaboury,+S.&author=Bouchard,+B.&publication\_year=2018&journal=Expert+Syst.+Appl.&volume=112&pages=173%E2%80%93189&doi=10.1016/j.eswa.2018.06.033

https://doi.org/10.1016/j.eswa.2018.06.033

Ekman, P.; Friesen, W.V. Constants across cultures in the face and emotion. J. Personal. Soc. Psychol.

, 17, 124–129. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Constants+across+cultures+in+the+face+and+emotion&author=Ekman,+P.&author=Friesen,+W.V.&publication\_year=1971&journal=J.+Personal.+Soc.+Psychol.&volume=17&pages=124%E2%80%93129&doi=10.1037/h0030377

https://doi.org/10.1037/h0030377

Ekman, P.; Rosenberg, E.L. What the Face Reveals Basic and Applied Studies of Spontaneous Expression Using the Facial Action Coding System (FACS); Oxford University Press: Oxford, UK, 2005. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=What+the+Face+Reveals+Basic+and+Applied+Studies+of+Spontaneous+Expression+Using+the+Facial+Action+Coding+System+(FACS)&author=Ekman,+P.&author=Rosenberg,+E.L.&publication\_year=2005

https://doi.org/10.1093/acprof:oso/9780195179644.001.0001

Perveen, N.; Roy, D.; Chalavadi, K.M. Facial expression recognition in videos using dynamic kernels. IEEE Trans. Image Process.

, 29, 8316–8325. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Facial+expression+recognition+in+videos+using+dynamic+kernels&author=Perveen,+N.&author=Roy,+D.&author=Chalavadi,+K.M.&publication\_year=2020&journal=IEEE+Trans.+Image+Process.&volume=29&pages=8316%E2%80%938325&doi=10.1109/TIP.2020.3011846&pmid=32746249

https://doi.org/10.1109/TIP.2020.3011846

https://www.ncbi.nlm.nih.gov/pubmed/32746249

Lopez-Gil, J.M.; Garay-Vitoria, N. Photogram classification-based emotion recognition. IEEE Access

, 9, 136974–136984. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Photogram+classification-based+emotion+recognition&author=Lopez-Gil,+J.M.&author=Garay-Vitoria,+N.&publication\_year=2021&journal=IEEE+Access&volume=9&pages=136974%E2%80%93136984&doi=10.1109/ACCESS.2021.3117253

https://doi.org/10.1109/ACCESS.2021.3117253

Shahid, A.R.; Khan, S.; Yan, H. Contour and region harmonic features for sub-local facial expression recognition. J. Vis. Commun. Image Represent.

, 73, 102949. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Contour+and+region+harmonic+features+for+sub-local+facial+expression+recognition&author=Shahid,+A.R.&author=Khan,+S.&author=Yan,+H.&publication\_year=2020&journal=J.+Vis.+Commun.+Image+Represent.&volume=73&pages=102949&doi=10.1016/j.jvcir.2020.102949

https://doi.org/10.1016/j.jvcir.2020.102949

Ngoc, Q.T.; Lee, S.; Song, B.C. Facial landmark-based emotion recognition via directed graph neural network. Electronics

, 9, 764. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Facial+landmark-based+emotion+recognition+via+directed+graph+neural+network&author=Ngoc,+Q.T.&author=Lee,+S.&author=Song,+B.C.&publication\_year=2020&journal=Electronics&volume=9&pages=764&doi=10.3390/electronics9050764

https://doi.org/10.3390/electronics9050764

Aghamaleki, J.A.; Ashkani Chenarlogh, V. Multi-stream CNN for facial expression recognition in limited training data. Multimed. Tools Appl.

, 78, 22861–22882. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Multi-stream+CNN+for+facial+expression+recognition+in+limited+training+data&author=Aghamaleki,+J.A.&author=Ashkani+Chenarlogh,+V.&publication\_year=2019&journal=Multimed.+Tools+Appl.&volume=78&pages=22861%E2%80%9322882&doi=10.1007/s11042-019-7530-7

https://doi.org/10.1007/s11042-019-7530-7

Kanade, T.; Cohn, J.F.; Tian, Y. Comprehensive database for facial expression analysis. In Proceedings of the 4th IEEE International Conference on Automatic Face and Gesture Recognition, Grenoble, France, 28–30 March 2000; pp. 46–53. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Comprehensive+database+for+facial+expression+analysis&conference=Proceedings+of+the+4th+IEEE+International+Conference+on+Automatic+Face+and+Gesture+Recognition&author=Kanade,+T.&author=Cohn,+J.F.&author=Tian,+Y.&publication\_year=2000&pages=46%E2%80%9353&doi=10.1109/AFGR.2000.840611

https://doi.org/10.1109/AFGR.2000.840611

Aifanti, N.; Papachristou, C.; Delopoulos, A. The MUG facial expression database. In Proceedings of the 11th International Workshop on Image Analysis for Multimedia Interactive Services, Desenzano del Garda, Italy, 12–14 April 2010; pp. 1–4. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=The+MUG+facial+expression+database&conference=Proceedings+of+the+11th+International+Workshop+on+Image+Analysis+for+Multimedia+Interactive+Services&author=Aifanti,+N.&author=Papachristou,+C.&author=Delopoulos,+A.&publication\_year=2010&pages=1%E2%80%934

Pantic, M.; Valstar, M.; Rademaker, R.; Maat, L. Web-based database for facial expression analysis. In Proceedings of the IEEE International Conference on Multimedia and Expo, Amsterdam, The Netherlands, 6 July 2005. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Web-based+database+for+facial+expression+analysis&conference=Proceedings+of+the+IEEE+International+Conference+on+Multimedia+and+Expo&author=Pantic,+M.&author=Valstar,+M.&author=Rademaker,+R.&author=Maat,+L.&publication\_year=2005&doi=10.1109/ICME.2005.1521424

https://doi.org/10.1109/ICME.2005.1521424

Konar, A.; Halder, A.; Chakraborty, A. Introduction to Emotion Recognition. In Emotion Recognition; John Wiley & Sons, Inc.: Hoboken, NJ, USA, 2015; pp. 1–45. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Introduction+to+Emotion+Recognition&author=Konar,+A.&author=Halder,+A.&author=Chakraborty,+A.&publication\_year=2015&pages=1%E2%80%9345

https://doi.org/10.1002/9781118910566.ch1

Yaddaden, Y.; Adda, M.; Bouzouane, A.; Gaboury, S.; Bouchard, B. One-class and bi-class SVM classifier comparison for automatic facial expression recognition. In Proceedings of the 2018 International Conference on Applied Smart Systems (ICASS), Medea, Algeria, 24–25 November 2018; pp. 1–6. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=One-class+and+bi-class+SVM+classifier+comparison+for+automatic+facial+expression+recognition&conference=Proceedings+of+the+2018+International+Conference+on+Applied+Smart+Systems+(ICASS)&author=Yaddaden,+Y.&author=Adda,+M.&author=Bouzouane,+A.&author=Gaboury,+S.&author=Bouchard,+B.&publication\_year=2018&pages=1%E2%80%936&doi=10.1109/ICASS.2018.8651969

https://doi.org/10.1109/ICASS.2018.8651969

Zhang, S.; Pan, X.; Cui, Y.; Zhao, X.; Liu, L. Learning affective video features for facial expression recognition via hybrid deep learning. IEEE Access

, 7, 32297–32304. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Learning+affective+video+features+for+facial+expression+recognition+via+hybrid+deep+learning&author=Zhang,+S.&author=Pan,+X.&author=Cui,+Y.&author=Zhao,+X.&author=Liu,+L.&publication\_year=2019&journal=IEEE+Access&volume=7&pages=32297%E2%80%9332304&doi=10.1109/ACCESS.2019.2901521

https://doi.org/10.1109/ACCESS.2019.2901521

Yaddaden, Y.; Adda, M.; Bouzouane, A.; Gaboury, S.; Bouchard, B. Facial Expression Recognition from Video using Geometric Features. In Proceedings of the 8th International Conference on Pattern Recognition Systems, Madrid, Spain, 11–13 July 2017; pp. 1–6. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Facial+Expression+Recognition+from+Video+using+Geometric+Features&conference=Proceedings+of+the+8th+International+Conference+on+Pattern+Recognition+Systems&author=Yaddaden,+Y.&author=Adda,+M.&author=Bouzouane,+A.&author=Gaboury,+S.&author=Bouchard,+B.&publication\_year=2017&pages=1%E2%80%936&doi=10.1049/cp.2017.0133

https://doi.org/10.1049/cp.2017.0133

Sen, D.; Datta, S.; Balasubramanian, R. Facial emotion classification using concatenated geometric and textural features. Multimed. Tools Appl.

, 78, 10287–10323. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Facial+emotion+classification+using+concatenated+geometric+and+textural+features&author=Sen,+D.&author=Datta,+S.&author=Balasubramanian,+R.&publication\_year=2019&journal=Multimed.+Tools+Appl.&volume=78&pages=10287%E2%80%9310323&doi=10.1007/s11042-018-6537-9

https://doi.org/10.1007/s11042-018-6537-9

Yaddaden, Y.; Adda, M.; Bouzouane, A.; Gaboury, S.; Bouchard, B. Hybrid-based facial expression recognition approach for human-computer interaction. In Proceedings of the 2018 IEEE 20th International Workshop on Multimedia Signal Processing (MMSP), Vancouver, BC, Canada, 29–31 August 2018; pp. 1–6. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Hybrid-based+facial+expression+recognition+approach+for+human-computer+interaction&conference=Proceedings+of+the+2018+IEEE+20th+International+Workshop+on+Multimedia+Signal+Processing+(MMSP)&author=Yaddaden,+Y.&author=Adda,+M.&author=Bouzouane,+A.&author=Gaboury,+S.&author=Bouchard,+B.&publication\_year=2018&pages=1%E2%80%936&doi=10.1109/MMSP.2018.8547081

https://doi.org/10.1109/MMSP.2018.8547081

Yaddaden, Y. An efficient facial expression recognition system with appearance-based fused descriptors. Intell. Syst. Appl.

, 17, 200166. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=An+efficient+facial+expression+recognition+system+with+appearance-based+fused+descriptors&author=Yaddaden,+Y.&publication\_year=2023&journal=Intell.+Syst.+Appl.&volume=17&pages=200166&doi=10.1016/j.iswa.2022.200166

https://doi.org/10.1016/j.iswa.2022.200166

Pham, T.D.; Duong, M.T.; Ho, Q.T.; Lee, S.; Hong, M.C. CNN-based facial expression recognition with simultaneous consideration of inter-class and intra-class variations. Sensors

, 23, 9658. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=CNN-based+facial+expression+recognition+with+simultaneous+consideration+of+inter-class+and+intra-class+variations&author=Pham,+T.D.&author=Duong,+M.T.&author=Ho,+Q.T.&author=Lee,+S.&author=Hong,+M.C.&publication\_year=2023&journal=Sensors&volume=23&pages=9658&doi=10.3390/s23249658

https://doi.org/10.3390/s23249658

Vaijayanthi, S.; Arunnehru, J. Dense SIFT-based facial expression recognition using machine learning techniques. In Proceedings of the 6th International Conference on Advance Computing and Intelligent Engineering: ICACIE 2021, Bhubaneswar, India, 23–24 December 2021; Springer: Singapore, 2022; pp. 301–310. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Dense+SIFT-based+facial+expression+recognition+using+machine+learning+techniques&conference=Proceedings+of+the+6th+International+Conference+on+Advance+Computing+and+Intelligent+Engineering:+ICACIE+2021&author=Vaijayanthi,+S.&author=Arunnehru,+J.&publication\_year=2022&pages=301%E2%80%93310&doi=10.1007/978-981-19-2225-1\_27

https://doi.org/10.1007/978-981-19-2225-1\_27

Kartheek, M.N.; Prasad, M.V.; Bhukya, R. Windmill graph based feature descriptors for facial expression recognition. Optik

, 260, 169053. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Windmill+graph+based+feature+descriptors+for+facial+expression+recognition&author=Kartheek,+M.N.&author=Prasad,+M.V.&author=Bhukya,+R.&publication\_year=2022&journal=Optik&volume=260&pages=169053&doi=10.1016/j.ijleo.2022.169053

https://doi.org/10.1016/j.ijleo.2022.169053

Yang, B.; Li, Z.; Cao, E. Facial expression recognition based on multi-dataset neural network. Radioengineering

, 29, 259–266. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Facial+expression+recognition+based+on+multi-dataset+neural+network&author=Yang,+B.&author=Li,+Z.&author=Cao,+E.&publication\_year=2020&journal=Radioengineering&volume=29&pages=259%E2%80%93266&doi=10.13164/re.2020.0259

https://doi.org/10.13164/re.2020.0259

Singh, R.; Saurav, S.; Kumar, T.; Saini, R.; Vohra, A.; Singh, S. Facial expression recognition in videos using hybrid CNN & ConvLSTM. Int. J. Inf. Technol.

, 15, 1819–1830. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Facial+expression+recognition+in+videos+using+hybrid+CNN+%2526+ConvLSTM&author=Singh,+R.&author=Saurav,+S.&author=Kumar,+T.&author=Saini,+R.&author=Vohra,+A.&author=Singh,+S.&publication\_year=2023&journal=Int.+J.+Inf.+Technol.&volume=15&pages=1819%E2%80%931830&doi=10.1007/s41870-023-01183-0

https://doi.org/10.1007/s41870-023-01183-0

Mukhopadhyay, M.; Dey, A.; Kahali, S. A deep-learning-based facial expression recognition method using textural features. Neural Comput. Appl.

, 35, 6499–6514. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=A+deep-learning-based+facial+expression+recognition+method+using+textural+features&author=Mukhopadhyay,+M.&author=Dey,+A.&author=Kahali,+S.&publication\_year=2023&journal=Neural+Comput.+Appl.&volume=35&pages=6499%E2%80%936514&doi=10.1007/s00521-022-08005-7

https://doi.org/10.1007/s00521-022-08005-7

Kumar Tataji, K.N.; Kartheek, M.N.; Prasad, M.V. CC-CNN: A cross connected convolutional neural network using feature level fusion for facial expression recognition. Multimed. Tools Appl.

, 83, 27619–27645. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=CC-CNN:+A+cross+connected+convolutional+neural+network+using+feature+level+fusion+for+facial+expression+recognition&author=Kumar+Tataji,+K.N.&author=Kartheek,+M.N.&author=Prasad,+M.V.&publication\_year=2024&journal=Multimed.+Tools+Appl.&volume=83&pages=27619%E2%80%9327645&doi=10.1007/s11042-023-16433-3

https://doi.org/10.1007/s11042-023-16433-3

Verma, M.; Vipparthi, S.K. Cross-centroid ripple pattern for facial expression recognition. Multimed. Tools Appl.

, 84, 11707–11727. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Cross-centroid+ripple+pattern+for+facial+expression+recognition&author=Verma,+M.&author=Vipparthi,+S.K.&publication\_year=2025&journal=Multimed.+Tools+Appl.&volume=84&pages=11707%E2%80%9311727&doi=10.1007/s11042-024-19364-9

https://doi.org/10.1007/s11042-024-19364-9

Reddy, A.H.; Kolli, K.; Kiran, Y.L. Deep cross feature adaptive network for facial emotion classification. Signal Image Video Process.

, 16, 369–376. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Deep+cross+feature+adaptive+network+for+facial+emotion+classification&author=Reddy,+A.H.&author=Kolli,+K.&author=Kiran,+Y.L.&publication\_year=2022&journal=Signal+Image+Video+Process.&volume=16&pages=369%E2%80%93376&doi=10.1007/s11760-021-01941-2

https://doi.org/10.1007/s11760-021-01941-2

Li, J.; Huang, S.; Zhang, X.; Fu, X.; Chang, C.C.; Tang, Z.; Luo, Z. Facial expression recognition by transfer learning for small datasets. In Security with Intelligent Computing and Big-data Services, Proceedings of the Second International Conference on Security with Intelligent Computing and Big Data Services (SICBS-2018), Guilin, China, 14–16 December 2018; Springer: Cham, Switzerland, 2020; pp. 756–770. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Facial+expression+recognition+by+transfer+learning+for+small+datasets&author=Li,+J.&author=Huang,+S.&author=Zhang,+X.&author=Fu,+X.&author=Chang,+C.C.&author=Tang,+Z.&author=Luo,+Z.&publication\_year=2020&pages=756%E2%80%93770

https://doi.org/10.1007/978-3-030-16946-6\_62

Samadiani, N.; Huang, G.; Luo, W.; Chi, C.H.; Shu, Y.; Wang, R.; Kocaturk, T. A multiple feature fusion framework for video emotion recognition in the wild. Concurr. Comput. Pract. Exp.

, 34, e5764. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=A+multiple+feature+fusion+framework+for+video+emotion+recognition+in+the+wild&author=Samadiani,+N.&author=Huang,+G.&author=Luo,+W.&author=Chi,+C.H.&author=Shu,+Y.&author=Wang,+R.&author=Kocaturk,+T.&publication\_year=2022&journal=Concurr.+Comput.+Pract.+Exp.&volume=34&pages=e5764&doi=10.1002/cpe.5764

https://doi.org/10.1002/cpe.5764

Mao, J.; Xu, R.; Yin, X.; Chang, Y.; Nie, B.; Huang, A.; Wang, Y. Poster++: A simpler and stronger facial expression recognition network. Pattern Recognit.

, 157, 110951. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Poster++:+A+simpler+and+stronger+facial+expression+recognition+network&author=Mao,+J.&author=Xu,+R.&author=Yin,+X.&author=Chang,+Y.&author=Nie,+B.&author=Huang,+A.&author=Wang,+Y.&publication\_year=2025&journal=Pattern+Recognit.&volume=157&pages=110951&doi=10.1016/j.patcog.2024.110951

https://doi.org/10.1016/j.patcog.2024.110951

Liao, L.; Wu, S.; Song, C.; Fu, J. RS-Xception: A lightweight network for facial expression recognition. Electronics

, 13, 3217. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=RS-Xception:+A+lightweight+network+for+facial+expression+recognition&author=Liao,+L.&author=Wu,+S.&author=Song,+C.&author=Fu,+J.&publication\_year=2024&journal=Electronics&volume=13&pages=3217&doi=10.3390/electronics13163217

https://doi.org/10.3390/electronics13163217

Grover, R.; Bansal, S. Enhancing facial expression recognition in uncontrolled environment: A lightweight CNN approach with pre-processing. Neural Comput. Appl.

, 37, 7363–7378. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Enhancing+facial+expression+recognition+in+uncontrolled+environment:+A+lightweight+CNN+approach+with+pre-processing&author=Grover,+R.&author=Bansal,+S.&publication\_year=2025&journal=Neural+Comput.+Appl.&volume=37&pages=7363%E2%80%937378&doi=10.1007/s00521-025-10974-4

https://doi.org/10.1007/s00521-025-10974-4

Zhao, Z.; Li, Y.; Yang, J.; Ma, Y. A lightweight facial expression recognition model for automated engagement detection. Signal Image Video Process.

, 18, 3553–3563. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=A+lightweight+facial+expression+recognition+model+for+automated+engagement+detection&author=Zhao,+Z.&author=Li,+Y.&author=Yang,+J.&author=Ma,+Y.&publication\_year=2024&journal=Signal+Image+Video+Process.&volume=18&pages=3553%E2%80%933563&doi=10.1007/s11760-024-03020-8

https://doi.org/10.1007/s11760-024-03020-8

Wang, K.; Yu, W.; Yamauchi, T. MVT-CEAM: A lightweight MobileViT with channel expansion and attention mechanism for facial expression recognition. Signal Image Video Process.

, 18, 6853–6865. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=MVT-CEAM:+A+lightweight+MobileViT+with+channel+expansion+and+attention+mechanism+for+facial+expression+recognition&author=Wang,+K.&author=Yu,+W.&author=Yamauchi,+T.&publication\_year=2024&journal=Signal+Image+Video+Process.&volume=18&pages=6853%E2%80%936865&doi=10.1007/s11760-024-03356-1

https://doi.org/10.1007/s11760-024-03356-1

Kopalidis, T.; Solachidis, V.; Vretos, N.; Daras, P. Advances in facial expression recognition: A survey of methods, benchmarks, models, and datasets. Information

, 15, 135. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Advances+in+facial+expression+recognition:+A+survey+of+methods,+benchmarks,+models,+and+datasets&author=Kopalidis,+T.&author=Solachidis,+V.&author=Vretos,+N.&author=Daras,+P.&publication\_year=2024&journal=Information&volume=15&pages=135&doi=10.3390/info15030135

https://doi.org/10.3390/info15030135

Tagmatova, Z.; Umirzakova, S.; Kutlimuratov, A.; Abdusalomov, A.; Im Cho, Y. A Hyper-Attentive Multimodal Transformer for Real-Time and Robust Facial Expression Recognition. Appl. Sci.

, 15, 7100. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=A+Hyper-Attentive+Multimodal+Transformer+for+Real-Time+and+Robust+Facial+Expression+Recognition&author=Tagmatova,+Z.&author=Umirzakova,+S.&author=Kutlimuratov,+A.&author=Abdusalomov,+A.&author=Im+Cho,+Y.&publication\_year=2025&journal=Appl.+Sci.&volume=15&pages=7100&doi=10.3390/app15137100

https://doi.org/10.3390/app15137100

Khelifa, A.; Ghazouani, H.; Barhoumi, W. Rank-aware LDL hybrid MetaFormer for Compound Facial Expression Recognition in-the-wild. Inf. Fusion

, 126, 103525. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Rank-aware+LDL+hybrid+MetaFormer+for+Compound+Facial+Expression+Recognition+in-the-wild&author=Khelifa,+A.&author=Ghazouani,+H.&author=Barhoumi,+W.&publication\_year=2025&journal=Inf.+Fusion&volume=126&pages=103525&doi=10.1016/j.inffus.2025.103525

https://doi.org/10.1016/j.inffus.2025.103525

Viola, P.; Jones, M. Rapid object detection using a boosted cascade of simple features. In Proceedings of the IEEE Conference on Computer Vision and Pattern Recognition, Kauai, HI, USA, 8–14 December 2001; Volume 1, pp. I–I. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Rapid+object+detection+using+a+boosted+cascade+of+simple+features&conference=Proceedings+of+the+IEEE+Conference+on+Computer+Vision+and+Pattern+Recognition&author=Viola,+P.&author=Jones,+M.&publication\_year=2001&pages=I%E2%80%93I&doi=10.1109/CVPR.2001.990517

https://doi.org/10.1109/CVPR.2001.990517

Kazemi, V.; Sullivan, J. One millisecond face alignment with an ensemble of regression trees. In Proceedings of the IEEE Conference on Computer Vision and Pattern Recognition, Columbus, OH, USA, 23–28 June 2014; pp. 1867–1874. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=One+millisecond+face+alignment+with+an+ensemble+of+regression+trees&conference=Proceedings+of+the+IEEE+Conference+on+Computer+Vision+and+Pattern+Recognition&author=Kazemi,+V.&author=Sullivan,+J.&publication\_year=2014&pages=1867%E2%80%931874&doi=10.1109/CVPR.2014.241

https://doi.org/10.1109/CVPR.2014.241

Breiman, L. Random forests. Mach. Learn.

, 45, 5–32. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Random+forests&author=Breiman,+L.&publication\_year=2001&journal=Mach.+Learn.&volume=45&pages=5%E2%80%9332&doi=10.1023/A:1010933404324

https://doi.org/10.1023/A:1010933404324

Geurts, P.; Ernst, D.; Wehenkel, L. Extremely randomized trees. Mach. Learn.

, 63, 3–42. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Extremely+randomized+trees&author=Geurts,+P.&author=Ernst,+D.&author=Wehenkel,+L.&publication\_year=2006&journal=Mach.+Learn.&volume=63&pages=3%E2%80%9342&doi=10.1007/s10994-006-6226-1

https://doi.org/10.1007/s10994-006-6226-1

Cortes, C.; Vapnik, V. Support-vector networks. Mach. Learn.

, 20, 273–297. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Support-vector+networks&author=Cortes,+C.&author=Vapnik,+V.&publication\_year=1995&journal=Mach.+Learn.&volume=20&pages=273%E2%80%93297&doi=10.1023/A:1022627411411

https://doi.org/10.1023/A:1022627411411

Shalev-Shwartz, S.; Ben-David, S. Understanding Machine Learning: From Theory to Algorithms; Cambridge University Press: London, UK, 2014. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Understanding+Machine+Learning:+From+Theory+to+Algorithms&author=Shalev-Shwartz,+S.&author=Ben-David,+S.&publication\_year=2014

https://doi.org/10.1017/CBO9781107298019

Aha, D.W.; Kibler, D.; Albert, M.K. Instance-based learning algorithms. Mach. Learn.

, 6, 37–66. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Instance-based+learning+algorithms&author=Aha,+D.W.&author=Kibler,+D.&author=Albert,+M.K.&publication\_year=1991&journal=Mach.+Learn.&volume=6&pages=37%E2%80%9366&doi=10.1023/A:1022689900470

https://doi.org/10.1023/A:1022689900470

Lamouchi, D.; Yaddaden, Y.; Parent, J.; Cherif, R. Efficient Driver Drowsiness Detection Using Spatiotemporal Features with Support Vector Machine. Int. J. Intell. Transp. Syst. Res.

, 23, 720–732. \[

Google Scholar

https://scholar.google.com/scholar\_lookup?title=Efficient+Driver+Drowsiness+Detection+Using+Spatiotemporal+Features+with+Support+Vector+Machine&author=Lamouchi,+D.&author=Yaddaden,+Y.&author=Parent,+J.&author=Cherif,+R.&publication\_year=2025&journal=Int.+J.+Intell.+Transp.+Syst.+Res.&volume=23&pages=720%E2%80%93732&doi=10.1007/s13177-025-00478-9

https://doi.org/10.1007/s13177-025-00478-9

Basic building blocks of a common AFER system.

Overview of our dynamic AFER approach.

Overview of the pre-processing steps.

Spatio-temporal representation of the input.

Accuracy of the proposed dynamic AFER using different classifiers.

Benchmark facial expression datasets.

https://www.mdpi.com/2504-2289/9/8/213#B10-BDCC-09-00213

https://www.mdpi.com/2504-2289/9/8/213#B12-BDCC-09-00213

https://www.mdpi.com/2504-2289/9/8/213#B11-BDCC-09-00213

Onset-Apex-Offset

Onset-Apex-Offset

Confusion matrix using

(six classes) dataset.

O v e r a l l = 91.65 %

Recognition rate comparison by emotion with state-of-the-art methods (

Shahid et al. (2020) \[

https://www.mdpi.com/2504-2289/9/8/213#B7-BDCC-09-00213

Sen et al. (2019) \[

https://www.mdpi.com/2504-2289/9/8/213#B17-BDCC-09-00213

Kartheek et al. (2022) \[

https://www.mdpi.com/2504-2289/9/8/213#B22-BDCC-09-00213

Mukhopadhyay et al. (2023) \[

https://www.mdpi.com/2504-2289/9/8/213#B25-BDCC-09-00213

Comparing with state-of-the-art methods (

Aghamaleki & Ashkani Chenarlogh (2019) \[

https://www.mdpi.com/2504-2289/9/8/213#B9-BDCC-09-00213

CNN (VGG-16) + TL

Shahid et al. (2020) \[

https://www.mdpi.com/2504-2289/9/8/213#B7-BDCC-09-00213

CNN + multi-class SVM

Sen et al. (2019) \[

https://www.mdpi.com/2504-2289/9/8/213#B17-BDCC-09-00213

Kartheek et al. (2022) \[

https://www.mdpi.com/2504-2289/9/8/213#B22-BDCC-09-00213

multi-class SVM

Lopez-Gil & Garay-Vitoria (2021) \[

https://www.mdpi.com/2504-2289/9/8/213#B6-BDCC-09-00213

Ensemble of classifiers

Pham et al. (2023) \[

https://www.mdpi.com/2504-2289/9/8/213#B20-BDCC-09-00213

CNN (MobileNet-V3)

Singh et al. (2023) \[

https://www.mdpi.com/2504-2289/9/8/213#B24-BDCC-09-00213

3D-CNN + ConvLSTM

Mukhopadhyay et al. (2023) \[

https://www.mdpi.com/2504-2289/9/8/213#B25-BDCC-09-00213

Reddy et al. (2022) \[

https://www.mdpi.com/2504-2289/9/8/213#B28-BDCC-09-00213

multi-class

Confusion matrix using

O v e r a l l = 73.56 %

Recognition rate comparison by emotion with state-of-the-art methods (

Pham et al. (2023) \[

https://www.mdpi.com/2504-2289/9/8/213#B20-BDCC-09-00213

Yang et al. (2020) \[

https://www.mdpi.com/2504-2289/9/8/213#B23-BDCC-09-00213

Li et al. (2020) \[

https://www.mdpi.com/2504-2289/9/8/213#B29-BDCC-09-00213

Samadiani et al. (2022) \[

https://www.mdpi.com/2504-2289/9/8/213#B30-BDCC-09-00213

Comparing with state-of-the-art methods (

Pham et al. (2023) \[

https://www.mdpi.com/2504-2289/9/8/213#B20-BDCC-09-00213

CNN (MobileNet-V3)

Perveen et al. (2020) \[

https://www.mdpi.com/2504-2289/9/8/213#B5-BDCC-09-00213

Kernel-based classifier

Zhang et al. (2019) \[

https://www.mdpi.com/2504-2289/9/8/213#B15-BDCC-09-00213

Yang et al. (2020) \[

https://www.mdpi.com/2504-2289/9/8/213#B23-BDCC-09-00213

CNN with multi-source loss

Verma & Vipparthi (2024) \[

https://www.mdpi.com/2504-2289/9/8/213#B27-BDCC-09-00213

CRIP + multi-class SVM

Li et al. (2020) \[

https://www.mdpi.com/2504-2289/9/8/213#B29-BDCC-09-00213

CNN with feature transfer

Samadiani et al. (2022) \[

https://www.mdpi.com/2504-2289/9/8/213#B30-BDCC-09-00213

LBP-TOP + LUF + SR

Ngoc et al. (2020) \[

https://www.mdpi.com/2504-2289/9/8/213#B8-BDCC-09-00213

multi-class

Confusion matrix using

O v e r a l l = 93.65 %

Recognition rate comparison by emotion with state-of-the-art methods (

Shahid et al. (2020) \[

https://www.mdpi.com/2504-2289/9/8/213#B7-BDCC-09-00213

Sen et al. (2019) \[

https://www.mdpi.com/2504-2289/9/8/213#B17-BDCC-09-00213

Kartheek et al. (2022) \[

https://www.mdpi.com/2504-2289/9/8/213#B22-BDCC-09-00213

Kumar Tataji et al. (2024) \[

https://www.mdpi.com/2504-2289/9/8/213#B26-BDCC-09-00213

Comparing with state-of-the-art methods (

Aghamaleki & Ashkani Chenarlogh (2019) \[

https://www.mdpi.com/2504-2289/9/8/213#B9-BDCC-09-00213

CNN (VGG-16) + TL

Shahid et al. (2020) \[

https://www.mdpi.com/2504-2289/9/8/213#B7-BDCC-09-00213

CNN + multi-class SVM

Sen et al. (2019) \[

https://www.mdpi.com/2504-2289/9/8/213#B17-BDCC-09-00213

Kartheek et al. \[

https://www.mdpi.com/2504-2289/9/8/213#B22-BDCC-09-00213

multi-class SVM

Vaijayanthi & Arunnehru (2022) \[

https://www.mdpi.com/2504-2289/9/8/213#B21-BDCC-09-00213

Lopez-Gil & Garay-Vitoria (2021) \[

https://www.mdpi.com/2504-2289/9/8/213#B6-BDCC-09-00213

Ensemble of classifiers

Kumar Tataji et al. (2024) \[

https://www.mdpi.com/2504-2289/9/8/213#B26-BDCC-09-00213

Cross-Connected CNN

Verma & Vipparthi (2024) \[

https://www.mdpi.com/2504-2289/9/8/213#B27-BDCC-09-00213

CRIP + multi-class SVM

Reddy et al. (2022) \[

https://www.mdpi.com/2504-2289/9/8/213#B28-BDCC-09-00213

multi-class

Confusion matrix using

(seven classes) dataset.

O v e r a l l = 88.41 %

Evaluation using various metrics.

∑ Attributes

Measure of the run-time during training and prediction.

| Dataset | Classifier | Computational time ( s) ||

| ^^ | ^^ | Training | Predicting |

| --- | --- | --- | --- |

| SVM | 6.74 | 0.02 |

| ^^ | k-NN | 0.31 | 0.16 |

| SVM | 6.28 | 0.02 |

| ^^ | k-NN | 0.31 | 0.17 |

| SVM | 8.33 | 0.02 |

| ^^ | k-NN | 0.31 | 0.17 |

| SVM | 10.15 | 0.02 |

| ^^ | k-NN | 0.29 | 0.14 |

#### Disclaimer/Publisher's Note:

The statements, opinions and data contained in all publications are solely those of the individual author(s) and contributor(s) and not of MDPI and/or the editor(s). MDPI and/or the editor(s) disclaim responsibility for any injury to people or property resulting from any ideas, methods, instructions or products referred to in the content.

© 2025 by the author. Licensee MDPI, Basel, Switzerland. This article is an open access article distributed under the terms and conditions of the Creative Commons Attribution (CC BY) license (

https://creativecommons.org/licenses/by/4.0/

https://creativecommons.org/licenses/by/4.0/

Share and Cite

mailto:?&subject=From%20MDPI%3A%20%22Efficient%20Dynamic%20Emotion%20Recognition%20from%20Facial%20Expressions%20Using%20Statistical%20Spatio-Temporal%20Geometric%20Features"&body=https://www.mdpi.com/3456048%3A%0A%0AEfficient%20Dynamic%20Emotion%20Recognition%20from%20Facial%20Expressions%20Using%20Statistical%20Spatio-Temporal%20Geometric%20Features%0A%0AAbstract%3A%20Automatic%20Facial%20Expression%20Recognition%20%28AFER%29%20is%20a%20key%20component%20of%20affective%20computing%2C%20enabling%20machines%20to%20recognize%20and%20interpret%20human%20emotions%20across%20various%20applications%20such%20as%20human%26ndash%3Bcomputer%20interaction%2C%20healthcare%2C%20entertainment%2C%20and%20social%20robotics.%20Dynamic%20AFER%20systems%2C%20which%20exploit%20image%20sequences%2C%20can%20capture%20the%20temporal%20evolution%20of%20facial%20expressions%20but%20often%20suffer%20from%20high%20computational%20costs%2C%20limiting%20their%20suitability%20for%20real-time%20use.%20In%20this%20paper%2C%20we%20propose%20an%20efficient%20dynamic%20AFER%20approach%20based%20on%20a%20novel%20spatio-temporal%20representation.%20Facial%20landmarks%20are%20extracted%2C%20and%20all%20possible%20Euclidean%20distances%20are%20computed%20to%20model%20the%20spatial%20structure.%20To%20capture%20temporal%20variations%2C%20three%20statistical%20metrics%20are%20applied%20to%20each%20distance%20sequence.%20A%20feature%20selection%20stage%20based%20on%20the%20Extremely%20Randomized%20Trees%20%28ExtRa-Trees%29%20algorithm%20is%20then%20performed%20to%20reduce%20dimensionality%20and%20enhance%20classification%20performance.%20Finally%2C%20the%20emotions%20are%20classified%20using%20a%20linear%20multi-class%20Support%20Vector%20Machine%20%28SVM%29%20and%20compared%20against%20the%20k-Nearest%20Neighbors%20%28k-NN%29%20method.%20The%20proposed%20approach%20is%20evaluated%20on%20three%20benchmark%20datasets%3A%20CK%2B%2C%20MUG%2C%20and\[...\]

https://x.com/intent/tweet?text=Efficient+Dynamic+Emotion+Recognition+from+Facial+Expressions+Using+Statistical+Spatio-Temporal+Geometric+Features&hashtags=mdpiBDCC&url=https%3A%2F%2Fwww.mdpi.com%2F3456048&via=BDCC\_MDPI

http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fwww.mdpi.com%2F3456048&title=Efficient%20Dynamic%20Emotion%20Recognition%20from%20Facial%20Expressions%20Using%20Statistical%20Spatio-Temporal%20Geometric%20Features%26source%3Dhttps%3A%2F%2Fwww.mdpi.com%26summary%3DAutomatic%20Facial%20Expression%20Recognition%20%28AFER%29%20is%20a%20key%20component%20of%20affective%20computing%2C%20enabling%20machines%20to%20recognize%20and%20interpret%20human%20emotions%20across%20various%20applications%20such%20as%20human%E2%80%93computer%20interaction%2C%20healthcare%2C%20entertainment%2C%20and%20%5B...%5D

http://www.facebook.com/sharer.php?u=https://www.mdpi.com/3456048

javascript:void(0);

http://www.reddit.com/submit?url=https://www.mdpi.com/3456048

http://www.mendeley.com/import/?url=https://www.mdpi.com/3456048

MDPI and ACS Style

Yaddaden, Y. Efficient Dynamic Emotion Recognition from Facial Expressions Using Statistical Spatio-Temporal Geometric Features.

Big Data Cogn. Comput.

, 213. https://doi.org/10.3390/bdcc9080213

Yaddaden Y. Efficient Dynamic Emotion Recognition from Facial Expressions Using Statistical Spatio-Temporal Geometric Features.

Big Data and Cognitive Computing

. 2025; 9(8):213. https://doi.org/10.3390/bdcc9080213

Chicago/Turabian Style

Yaddaden, Yacine. 2025. "Efficient Dynamic Emotion Recognition from Facial Expressions Using Statistical Spatio-Temporal Geometric Features"

Big Data and Cognitive Computing

9, no. 8: 213. https://doi.org/10.3390/bdcc9080213

Yaddaden, Y. (2025). Efficient Dynamic Emotion Recognition from Facial Expressions Using Statistical Spatio-Temporal Geometric Features.

Big Data and Cognitive Computing

(8), 213. https://doi.org/10.3390/bdcc9080213

Article Metrics

https://www.scopus.com/inward/citedby.uri?partnerID=HzOxMe3b&scp=105014376671&origin=inward

Web of Science

https://www.webofscience.com/api/gateway?GWVersion=2&SrcApp=PARTNER\_APP&SrcAuth=LinksAMR&KeyUT=WOS:001557858100001&DestLinkType=FullRecord&DestApp=ALL\_WOS&UsrCustomerID=7e717b028bc90856e7c55c7029afc773

Google Scholar

\[click to view\]

https://scholar.google.com/scholar\_lookup?title=Efficient+Dynamic+Emotion+Recognition+from+Facial+Expressions+Using+Statistical+Spatio-Temporal+Geometric+Features&volume=9&doi=10.3390%2Fbdcc9080213&journal=Big+Data+and+Cognitive+Computing&publication\_year=2025&author=Yacine+Yaddaden

Article Access Statistics

Created with Highcharts 4.0.4 Article access statistics Article Views 7. Jan 8. Jan 9. Jan 10. Jan 11. Jan 12. Jan 13. Jan 14. Jan 15. Jan 16. Jan 17. Jan 18. Jan 19. Jan 20. Jan 21. Jan 22. Jan 23. Jan 24. Jan 25. Jan 26. Jan 27. Jan 28. Jan 29. Jan 30. Jan 31. Jan 1. Feb 2. Feb 3. Feb 4. Feb 5. Feb 6. Feb 7. Feb 8. Feb 9. Feb 10. Feb 11. Feb 12. Feb 13. Feb 14. Feb 15. Feb 16. Feb 17. Feb 18. Feb 19. Feb 20. Feb 21. Feb 22. Feb 23. Feb 24. Feb 25. Feb 26. Feb 27. Feb 28. Feb 1. Mar 2. Mar 3. Mar 4. Mar 5. Mar 6. Mar 7. Mar 8. Mar 9. Mar 10. Mar 11. Mar 12. Mar 13. Mar 14. Mar 15. Mar 16. Mar 17. Mar 18. Mar 19. Mar 20. Mar 21. Mar 22. Mar 23. Mar 24. Mar 25. Mar 26. Mar 27. Mar 28. Mar 29. Mar 30. Mar 31. Mar 1. Apr 2. Apr 3. Apr 4. Apr 5. Apr 6. Apr 0 500 1000 1500 2000 2500 3000

For more information on the journal statistics, click

https://www.mdpi.com/journal/BDCC/stats

Multiple requests from the same IP address are counted as one view.

https://www.mdpi.com/2504-2289/9/8/213

https://www.mdpi.com/2504-2289/9/8/213

https://www.mdpi.com/2504-2289/9/8/213

https://www.mdpi.com/2504-2289/9/8/213

https://www.mdpi.com/2504-2289/9/8/213

https://www.mdpi.com/2504-2289/9/8/213

Previous Scene

https://www.mdpi.com/2504-2289/9/8/213

https://www.mdpi.com/2504-2289/9/8/213

#### Export citation file:

javascript:window.document.forms\['export-bibtex'\].submit()

javascript:window.document.forms\['export-endnote'\].submit()

javascript:window.document.forms\['export-ris'\].submit()

MDPI and ACS Style

Yaddaden, Y. Efficient Dynamic Emotion Recognition from Facial Expressions Using Statistical Spatio-Temporal Geometric Features.

Big Data Cogn. Comput.

, 213. https://doi.org/10.3390/bdcc9080213

Yaddaden Y. Efficient Dynamic Emotion Recognition from Facial Expressions Using Statistical Spatio-Temporal Geometric Features.

Big Data and Cognitive Computing

. 2025; 9(8):213. https://doi.org/10.3390/bdcc9080213

Chicago/Turabian Style

Yaddaden, Yacine. 2025. "Efficient Dynamic Emotion Recognition from Facial Expressions Using Statistical Spatio-Temporal Geometric Features"

Big Data and Cognitive Computing

9, no. 8: 213. https://doi.org/10.3390/bdcc9080213

Yaddaden, Y. (2025). Efficient Dynamic Emotion Recognition from Facial Expressions Using Statistical Spatio-Temporal Geometric Features.

Big Data and Cognitive Computing

(8), 213. https://doi.org/10.3390/bdcc9080213

https://www.mdpi.com/2504-2289/9/8/213

Big Data Cogn. Comput.

, EISSN 2504-2289, Published by MDPI

https://www.mdpi.com/rss/journal/BDCC

Content Alert

https://www.mdpi.com/journal/BDCC/toc-alert

Further Information

Article Processing Charges

https://www.mdpi.com/apc

Pay an Invoice

https://www.mdpi.com/about/payment

Open Access Policy

https://www.mdpi.com/openaccess

Contact MDPI

https://www.mdpi.com/about/contact

Jobs at MDPI

https://careers.mdpi.com/

For Authors

https://www.mdpi.com/authors

For Reviewers

https://www.mdpi.com/reviewers

For Editors

https://www.mdpi.com/editors

For Librarians

https://www.mdpi.com/librarians

For Publishers

https://www.mdpi.com/publishing\_services

For Societies

https://www.mdpi.com/societies

For Conference Organizers

https://www.mdpi.com/conference\_organizers

MDPI Initiatives

https://sciforum.net/

https://www.mdpi.com/books

Preprints.org

https://www.preprints.org/

https://www.scilit.com/

SciProfiles

https://sciprofiles.com?utm\_source=mpdi.com&utm\_medium=bottom\_menu&utm\_campaign=initiative

Encyclopedia

https://encyclopedia.pub/

https://jams.pub/

Proceedings Series

https://www.mdpi.com/about/proceedings

Follow MDPI

https://www.linkedin.com/company/mdpi

https://www.facebook.com/MDPIOpenAccessPublishing

https://x.com/MDPIOpenAccess

Subscribe to receive issue release notifications and newsletters from MDPI journals

Accounting and Auditing

Acta Microbiologica Hellenica

Administrative Sciences

Adolescents

Advances in Respiratory Medicine

Aerobiology

Agriculture

AgriEngineering

Agrochemicals

AI Chemistry

AI for Engineering

AI in Education

AI in Medicine

AI Materials

Anesthesia Research

Antibiotics

Antioxidants

Applied Biosciences

Applied Mechanics

Applied Microbiology

Applied Nano

Applied Sciences

Applied System Innovation

AppliedChem

AppliedMath

AppliedPhys

Aquaculture Journal

Architecture

Astronautics

Audiology Research

Behavioral Sciences

Big Data and Cognitive Computing

Bioengineering

Biology and Life Sciences Forum

Biomechanics

Biomedicines

BioMedInformatics

Biomimetics

Biomolecules

Bioresources and Bioproducts

Blockchains

Brain Sciences

Cardiogenetics

Cardiovascular Medicine

ChemEngineering

Chemistry Proceedings

Chemosensors

Clean Technologies

Clinical and Translational Neuroscience

Clinical Bioenergetics

Clinics and Practice

Clocks & Sleep

Colloids and Interfaces

Commodities

Complexities

Complications

Computation

Computer Sciences & Mathematics Forum

Condensed Matter

Conservation

Construction Materials

Corrosion and Materials Degradation

Craniomaxillofacial Trauma & Reconstruction

Cryptography

Current Issues in Molecular Biology

Current Oncology

Dentistry Journal

Dermatopathology

Diabetology

Diagnostics

Disabilities

Drugs and Drug Candidates

Econometrics

Education Sciences

Electricity

Electrochem

Electronic Materials

Electronics

Emergency Care and Medicine

Encyclopedia

Energy Storage and Applications

Engineering Proceedings

Entropic and Disordered Matter

Environmental and Earth Sciences Proceedings

Environmental Remediation

Environments

Epidemiologia

European Burn Journal

European Journal of Investigation in Health, Psychology and Education

Family Sciences

Fermentation

Forecasting

Forensic Sciences

Fossil Studies

Foundations

Fractal and Fractional

Future Internet

Future Pharmacology

Future Transportation

Gastroenterology Insights

Gastrointestinal Disorders

Geographies

Geosciences

Geotechnics

Gout, Urate, and Crystal Deposition Disease

Green Health

Hematology Reports

Horticulturae

Hydrobiology

Infectious Disease Reports

Informatics

Information

Infrastructures

Instruments

Intelligent Infrastructure and Construction

International Journal of Cognitive Sciences

International Journal of Environmental Medicine

International Journal of Environmental Research and Public Health

International Journal of Financial Studies

International Journal of Molecular Sciences

International Journal of Neonatal Screening

International Journal of Orofacial Myology and Myofunctional Therapy

International Journal of Plant Biology

International Journal of Topology

International Journal of Translational Medicine

International Journal of Turbomachinery, Propulsion and Power

International Medical Education

ISPRS International Journal of Geo-Information

Journal of Aesthetic Medicine

Journal of Ageing and Longevity

Journal of CardioRenal Medicine

Journal of Cardiovascular Development and Disease

Journal of Clinical & Translational Ophthalmology

Journal of Clinical Medicine

Journal of Composites Science

Journal of Cybersecurity and Privacy

Journal of Dementia and Alzheimer's Disease

Journal of Developmental Biology

Journal of Experimental and Theoretical Analyses

Journal of Eye Movement Research

Journal of Functional Biomaterials

Journal of Functional Morphology and Kinesiology

Journal of Fungi

Journal of Genome Biotechnology and Genetics

Journal of Gerontology and Geriatrics

Journal of Imaging

Journal of Innovation

Journal of Intelligence

Journal of Interdisciplinary Research Applied to Medicine

Journal of Low Power Electronics and Applications

Journal of Manufacturing and Materials Processing

Journal of Marine Science and Engineering

Journal of Market Access & Health Policy

Journal of Mind and Medical Sciences

Journal of Molecular Pathology

Journal of Nanotheranostics

Journal of Nuclear Engineering

Journal of Otorhinolaryngology, Hearing and Balance Medicine

Journal of Parks

Journal of Personalized Medicine

Journal of Pharmaceutical and BioTech Industry

Journal of Phytomedicine

Journal of Respiration

Journal of Risk and Financial Management

Journal of Sensor and Actuator Networks

Journal of Superintelligence

Journal of the American Podiatric Medical Association

Journal of the Oman Medical Association

Journal of Theoretical and Applied Electronic Commerce Research

Journal of Vascular Diseases

Journal of Xenobiotics

Journal of Zoological and Botanical Gardens

Journalism and Media

Kidney and Dialysis

Kinases and Phosphatases

Laboratories

Limnological Review

Low-Altitude Economy

Machine Learning and Knowledge Extraction

Magnetochemistry

Marine Drugs

Materials Proceedings

Mathematical and Computational Applications

Mathematics

Medical Sciences

Medical Sciences Forum

Metabolites

Meteorology

Methods and Protocols

Microbiology Research

Microelectronics

Micromachines

Microorganisms

Microplastics

Modern Mathematical Physics

Multimodal Technologies and Interaction

Nanoenergy Advances

Nanomanufacturing

Nanomaterials

Neuroimaging

Neurology International

Non-Coding RNA

Nursing Reports

Nutraceuticals

Occupational Health

Parasitologia

Pathophysiology

Peace Studies

Pediatric Reports

Pharmaceuticals

Pharmaceutics

Pharmacoepidemiology

Philosophies

Physical Sciences Forum

Physiologia

Polysaccharides

Populations

Precision Oncology

Primary and Hospital Care

Proceedings

Psychiatry International

Psychoactives

Psychology International

Publications

Purification

Quantum Beam Science

Quantum Reports

Real Estate

Regional Science and Environmental Economics

Remote Sensing

Reproductive Medicine

Romanian Journal of Preventive Medicine

Scientia Pharmaceutica

Semiconductors and Heterogeneous Integration

Separations

Smart Cities

Social Sciences

Société Internationale d'Urologie Journal

Soil Systems

Spectroscopy Journal

Stratigraphy and Sedimentology

Surgical Techniques Development

Sustainability

Sustainable Chemistry

Swiss Archives of Neurology, Psychiatry and Psychotherapy

Technologies

Thalassemia Reports

Theoretical and Applied Ergonomics

Therapeutics

Time and Space

Tourism and Hospitality

Transplantology

Trauma Care

Trends in Higher Education

Trends in Public Health

Tropical Medicine and Infectious Disease

Urban Science

Venereology

Veterinary Sciences

Virtual Worlds

World Electric Vehicle Journal

Zoonotic Diseases

Select options

\[-\] accountaudit

Accounting and Auditing

\[-\] acoustics

Acta Microbiologica Hellenica

\[-\] actuators

\[-\] adhesives

Administrative Sciences

\[-\] adolescents

Adolescents

Advances in Respiratory Medicine

\[-\] aerobiology

Aerobiology

\[-\] aerospace

\[-\] agriculture

Agriculture

\[-\] agriengineering

AgriEngineering

\[-\] agrochemicals

Agrochemicals

\[-\] agronomy

AI Chemistry

AI for Engineering

AI in Education

AI in Medicine

\[-\] aimater

AI Materials

\[-\] algorithms

\[-\] allergies

\[-\] analytica

\[-\] analytics

\[-\] anatomia

\[-\] anesthres

Anesthesia Research

\[-\] animals

\[-\] antibiotics

Antibiotics

\[-\] antibodies

\[-\] antioxidants

Antioxidants

\[-\] applbiosci

Applied Biosciences

\[-\] applmech

Applied Mechanics

\[-\] applmicrobiol

Applied Microbiology

\[-\] applnano

Applied Nano

\[-\] applsci

Applied Sciences

Applied System Innovation

\[-\] appliedchem

AppliedChem

\[-\] appliedmath

AppliedMath

\[-\] appliedphys

AppliedPhys

Aquaculture Journal

\[-\] architecture

Architecture

\[-\] arthropoda

\[-\] astronautics

Astronautics

\[-\] astronomy

\[-\] atmosphere

\[-\] audiolres

Audiology Research

\[-\] automation

\[-\] bacteria

\[-\] batteries

\[-\] behavsci

Behavioral Sciences

\[-\] beverages

Big Data and Cognitive Computing

\[-\] biochem

\[-\] bioengineering

Bioengineering

\[-\] biologics

\[-\] biology

Biology and Life Sciences Forum

\[-\] biomass

\[-\] biomechanics

Biomechanics

\[-\] biomedicines

Biomedicines

\[-\] biomedinformatics

BioMedInformatics

\[-\] biomimetics

Biomimetics

\[-\] biomolecules

Biomolecules

\[-\] biophysica

\[-\] bioresourbioprod

Bioresources and Bioproducts

\[-\] biosensors

\[-\] biosphere

\[-\] biotech

\[-\] blockchains

Blockchains

\[-\] brainsci

Brain Sciences

\[-\] buildings

\[-\] businesses

\[-\] cancers

\[-\] cardiogenetics

Cardiogenetics

\[-\] cardiovascmed

Cardiovascular Medicine

\[-\] catalysts

\[-\] ceramics

\[-\] challenges

\[-\] ChemEngineering

ChemEngineering

\[-\] chemistry

\[-\] chemproc

Chemistry Proceedings

\[-\] chemosensors

Chemosensors

\[-\] children

\[-\] civileng

\[-\] cleantechnol

Clean Technologies

\[-\] climate

Clinical and Translational Neuroscience

\[-\] clinbioenerg

Clinical Bioenergetics

\[-\] clinpract

Clinics and Practice

\[-\] clockssleep

Clocks & Sleep

\[-\] coatings

\[-\] colloids

Colloids and Interfaces

\[-\] colorants

\[-\] commodities

Commodities

\[-\] complexities

Complexities

\[-\] complications

Complications

\[-\] compounds

\[-\] computation

Computation

Computer Sciences & Mathematics Forum

\[-\] computers

\[-\] condensedmatter

Condensed Matter

\[-\] conservation

Conservation

\[-\] constrmater

Construction Materials

Corrosion and Materials Degradation

\[-\] cosmetics

Craniomaxillofacial Trauma & Reconstruction

\[-\] cryptography

Cryptography

\[-\] crystals

\[-\] culture

Current Issues in Molecular Biology

\[-\] curroncol

Current Oncology

\[-\] dentistry

Dentistry Journal

\[-\] dermato

\[-\] dermatopathology

Dermatopathology

\[-\] designs

\[-\] diabetology

Diabetology

\[-\] diagnostics

Diagnostics

\[-\] dietetics

\[-\] digital

\[-\] disabilities

Disabilities

\[-\] diseases

\[-\] diversity

Drugs and Drug Candidates

\[-\] dynamics

\[-\] ecologies

\[-\] econometrics

Econometrics

\[-\] economies

\[-\] education

Education Sciences

\[-\] electricity

Electricity

\[-\] electrochem

Electrochem

\[-\] electronicmat

Electronic Materials

\[-\] electronics

Electronics

Emergency Care and Medicine

\[-\] encyclopedia

Encyclopedia

\[-\] endocrines

\[-\] energies

Energy Storage and Applications

\[-\] engproc

Engineering Proceedings

Entropic and Disordered Matter

\[-\] entropy

Environmental and Earth Sciences Proceedings

\[-\] environremediat

Environmental Remediation

\[-\] environments

Environments

\[-\] epidemiologia

Epidemiologia

\[-\] epigenomes

European Burn Journal

European Journal of Investigation in Health, Psychology and Education

Family Sciences

\[-\] fermentation

Fermentation

\[-\] fintech

\[-\] forecasting

Forecasting

\[-\] forensicsci

Forensic Sciences

\[-\] forests

\[-\] fossstud

Fossil Studies

\[-\] foundations

Foundations

\[-\] fractalfract

Fractal and Fractional

\[-\] futureinternet

Future Internet

\[-\] futurepharmacol

Future Pharmacology

\[-\] futuretransp

Future Transportation

\[-\] galaxies

\[-\] gastroent

Gastroenterology Insights

\[-\] gastrointestdisord

Gastrointestinal Disorders

\[-\] gastronomy

\[-\] genealogy

\[-\] geographies

Geographies

\[-\] geohazards

\[-\] geomatics

\[-\] geometry

\[-\] geosciences

Geosciences

\[-\] geotechnics

Geotechnics

\[-\] geriatrics

\[-\] glacies

Gout, Urate, and Crystal Deposition Disease

\[-\] grasses

\[-\] greenhealth

Green Health

\[-\] hardware

\[-\] healthcare

\[-\] hematolrep

Hematology Reports

\[-\] heritage

\[-\] histories

\[-\] horticulturae

Horticulturae

\[-\] hospitals

\[-\] humanities

\[-\] hydrobiology

Hydrobiology

\[-\] hydrogen

\[-\] hydrology

\[-\] hydropower

\[-\] hygiene

\[-\] industries

Infectious Disease Reports

\[-\] informatics

Informatics

\[-\] information

Information

\[-\] infrastructures

Infrastructures

\[-\] inorganics

\[-\] insects

\[-\] instruments

Instruments

Intelligent Infrastructure and Construction

International Journal of Cognitive Sciences

International Journal of Environmental Medicine

International Journal of Environmental Research and Public Health

International Journal of Financial Studies

International Journal of Molecular Sciences

International Journal of Neonatal Screening

International Journal of Orofacial Myology and Myofunctional Therapy

International Journal of Plant Biology

International Journal of Topology

International Journal of Translational Medicine

International Journal of Turbomachinery, Propulsion and Power

International Medical Education

\[-\] inventions

ISPRS International Journal of Geo-Information

\[-\] jaestheticmed

Journal of Aesthetic Medicine

Journal of Ageing and Longevity

Journal of CardioRenal Medicine

Journal of Cardiovascular Development and Disease

Journal of Clinical & Translational Ophthalmology

Journal of Clinical Medicine

Journal of Composites Science

Journal of Cybersecurity and Privacy

Journal of Dementia and Alzheimer's Disease

Journal of Developmental Biology

Journal of Experimental and Theoretical Analyses

Journal of Eye Movement Research

Journal of Functional Biomaterials

Journal of Functional Morphology and Kinesiology

Journal of Fungi

Journal of Genome Biotechnology and Genetics

Journal of Gerontology and Geriatrics

\[-\] jimaging

Journal of Imaging

Journal of Innovation

\[-\] jintelligence

Journal of Intelligence

Journal of Interdisciplinary Research Applied to Medicine

Journal of Low Power Electronics and Applications

Journal of Manufacturing and Materials Processing

Journal of Marine Science and Engineering

Journal of Market Access & Health Policy

Journal of Mind and Medical Sciences

Journal of Molecular Pathology

Journal of Nanotheranostics

Journal of Nuclear Engineering

Journal of Otorhinolaryngology, Hearing and Balance Medicine

Journal of Parks

Journal of Personalized Medicine

Journal of Pharmaceutical and BioTech Industry

\[-\] jphytomed

Journal of Phytomedicine

Journal of Respiration

Journal of Risk and Financial Management

Journal of Sensor and Actuator Networks

\[-\] superintelligence

Journal of Superintelligence

Journal of the American Podiatric Medical Association

Journal of the Oman Medical Association

Journal of Theoretical and Applied Electronic Commerce Research

Journal of Vascular Diseases

Journal of Xenobiotics

Journal of Zoological and Botanical Gardens

\[-\] journalmedia

Journalism and Media

\[-\] kidneydial

Kidney and Dialysis

\[-\] kinasesphosphatases

Kinases and Phosphatases

\[-\] knowledge

\[-\] laboratories

Laboratories

\[-\] languages

\[-\] limnolrev

Limnological Review

\[-\] lipidology

\[-\] liquids

\[-\] literature

\[-\] logistics

Low-Altitude Economy

\[-\] lubricants

\[-\] lymphatics

Machine Learning and Knowledge Extraction

\[-\] machines

\[-\] macromol

\[-\] magnetism

\[-\] magnetochemistry

Magnetochemistry

\[-\] marinedrugs

Marine Drugs

\[-\] materials

\[-\] materproc

Materials Proceedings

Mathematical and Computational Applications

\[-\] mathematics

Mathematics

Medical Sciences

Medical Sciences Forum

\[-\] medicina

\[-\] medicines

\[-\] membranes

\[-\] metabolites

Metabolites

\[-\] meteorology

Meteorology

\[-\] methane

Methods and Protocols

\[-\] metrics

\[-\] metrology

\[-\] microbiolres

Microbiology Research

\[-\] microelectronics

Microelectronics

\[-\] micromachines

Micromachines

\[-\] microorganisms

Microorganisms

\[-\] microplastics

Microplastics

\[-\] microwave

\[-\] minerals

\[-\] modelling

Modern Mathematical Physics

\[-\] molbank

\[-\] molecules

\[-\] multimedia

Multimodal Technologies and Interaction

\[-\] muscles

\[-\] nanoenergyadv

Nanoenergy Advances

\[-\] nanomanufacturing

Nanomanufacturing

\[-\] nanomaterials

Nanomaterials

\[-\] network

\[-\] neuroglia

\[-\] neuroimaging

Neuroimaging

\[-\] neurolint

Neurology International

\[-\] neurosci

\[-\] nitrogen

Non-Coding RNA

\[-\] nursrep

Nursing Reports

\[-\] nutraceuticals

Nutraceuticals

\[-\] nutrients

\[-\] obesities

\[-\] occuphealth

Occupational Health

\[-\] organics

\[-\] organoids

\[-\] osteology

\[-\] pandemics

\[-\] parasitologia

Parasitologia

\[-\] particles

\[-\] pathogens

\[-\] pathophysiology

Pathophysiology

\[-\] peacestud

Peace Studies

\[-\] pediatrrep

Pediatric Reports

\[-\] pharmaceuticals

Pharmaceuticals

\[-\] pharmaceutics

Pharmaceutics

\[-\] pharmacoepidemiology

Pharmacoepidemiology

\[-\] pharmacy

\[-\] philosophies

Philosophies

\[-\] photochem

\[-\] photonics

\[-\] phycology

\[-\] physchem

Physical Sciences Forum

\[-\] physics

\[-\] physiologia

Physiologia

\[-\] platforms

\[-\] pollutants

\[-\] polymers

\[-\] polysaccharides

Polysaccharides

\[-\] populations

Populations

\[-\] poultry

\[-\] powders

\[-\] precisoncol

Precision Oncology

Primary and Hospital Care

\[-\] proceedings

Proceedings

\[-\] processes

\[-\] prosthesis

\[-\] proteomes

\[-\] psychiatryint

Psychiatry International

\[-\] psychoactives

Psychoactives

\[-\] psycholint

Psychology International

\[-\] publications

Publications

\[-\] purification

Purification

Quantum Beam Science

\[-\] quantumrep

Quantum Reports

\[-\] quaternary

\[-\] radiation

\[-\] reactions

\[-\] realestate

Real Estate

\[-\] receptors

\[-\] recycling

Regional Science and Environmental Economics

\[-\] religions

\[-\] remotesensing

Remote Sensing

\[-\] reports

\[-\] reprodmed

Reproductive Medicine

\[-\] resources

\[-\] rheumato

\[-\] robotics

Romanian Journal of Preventive Medicine

\[-\] ruminants

\[-\] scipharm

Scientia Pharmaceutica

\[-\] sclerosis

Semiconductors and Heterogeneous Integration

\[-\] sensors

\[-\] separations

Separations

\[-\] signals

\[-\] sinusitis

\[-\] smartcities

Smart Cities

Social Sciences

Société Internationale d'Urologie Journal

\[-\] societies

\[-\] software

\[-\] soilsystems

Soil Systems

\[-\] spectroscj

Spectroscopy Journal

\[-\] standards

\[-\] stratsediment

Stratigraphy and Sedimentology

\[-\] stresses

\[-\] surfaces

\[-\] surgeries

Surgical Techniques Development

\[-\] sustainability

Sustainability

\[-\] suschem

Sustainable Chemistry

Swiss Archives of Neurology, Psychiatry and Psychotherapy

\[-\] symmetry

\[-\] systems

\[-\] targets

\[-\] taxonomy

\[-\] technologies

Technologies

\[-\] telecom

\[-\] textiles

\[-\] thalassrep

Thalassemia Reports

Theoretical and Applied Ergonomics

\[-\] therapeutics

Therapeutics

\[-\] timespace

Time and Space

\[-\] tomography

\[-\] tourismhosp

Tourism and Hospitality

\[-\] transplantology

Transplantology

\[-\] traumacare

Trauma Care

\[-\] higheredu

Trends in Higher Education

Trends in Public Health

\[-\] tropicalmed

Tropical Medicine and Infectious Disease

\[-\] universe

\[-\] urbansci

Urban Science

\[-\] vaccines

\[-\] vehicles

\[-\] venereology

Venereology

Veterinary Sciences

\[-\] vibration

\[-\] virtualworlds

Virtual Worlds

\[-\] viruses

World Electric Vehicle Journal

\[-\] zoonoticdis

Zoonotic Diseases

© 1996-2026 MDPI (Basel, Switzerland) unless otherwise stated

https://www.mdpi.com/2504-2289/9/8/213

Disclaimer/Publisher's Note: The statements, opinions and data contained in all publications are solely those of the individual author(s) and contributor(s) and not of MDPI and/or the editor(s). MDPI and/or the editor(s) disclaim responsibility for any injury to people or property resulting from any ideas, methods, instructions or products referred to in the content.

Terms and Conditions

https://www.mdpi.com/about/terms-and-conditions

Privacy Policy

https://www.mdpi.com/about/privacy

We use cookies on our website to ensure you get the best experience.

Read more about our cookies

https://www.mdpi.com/about/privacy

https://www.mdpi.com/accept\_cookies

mailto:?&subject=From%20MDPI%3A%20%22Efficient%20Dynamic%20Emotion%20Recognition%20from%20Facial%20Expressions%20Using%20Statistical%20Spatio-Temporal%20Geometric%20Features"&body=https://www.mdpi.com/3456048%3A%0A%0AEfficient%20Dynamic%20Emotion%20Recognition%20from%20Facial%20Expressions%20Using%20Statistical%20Spatio-Temporal%20Geometric%20FeaturesAutomatic%20Facial%20Expression%20Recognition%20%28AFER%29%20is%20a%20key%20component%20of%20affective%20computing%2C%20enabling%20machines%20to%20recognize%20and%20interpret%20human%20emotions%20across%20various%20applications%20such%20as%20human%E2%80%93computer%20interaction%2C%20healthcare%2C%20entertainment%2C%20and%20social%20robotics.%20Dynamic%20AFER%20systems%2C%20which%20exploit%20image%20sequences%2C%20can%20capture%20the%20temporal%20evolution%20of%20facial%20expressions%20but%20often%20suffer%20from%20high%20computational%20costs%2C%20limiting%20their%20suitability%20for%20real-time%20use.%20In%20this%20paper%2C%20we%20propose%20an%20efficient%20dynamic%20AFER%20approach%20based%20on%20a%20novel%20spatio-temporal%20representation.%20Facial%20landmarks%20are%20extracted%2C%20and%20all%20possible%20Euclidean%20distances%20are%20computed%20to%20model%20the%20spatial%20structure.%20To%20capture%20temporal%20variations%2C%20three%20statistical%20metrics%20are%20applied%20to%20each%20distance%20sequence.%20A%20feature%20selection%20stage%20based%20on%20the%20Extremely%20Randomized%20Trees%20%28ExtRa-Trees%29%20algorithm%20is%20then%20performed%20to%20reduce%20dimensionality%20and%20enhance%20classification%20performance.%20Finally%2C%20the%20emotions%20are%20classified%20using%20a%20linear%20multi-class%20Support%20Vector%20Machine%20%28SVM%29%20and%20compared%20against%20the%20k-Nearest%20Neighbors%20%28k-NN%29%20method.%20The%20proposed%20approach%20is%20evaluated%20on%20three%20benchmark%20datasets%3A%20CK%2B%2C%20MUG%2C%20and%20MMI%2C%20achieving\[...\]

https://x.com/intent/tweet?text=Efficient+Dynamic+Emotion+Recognition+from+Facial+Expressions+Using+Statistical+Spatio-Temporal+Geometric+Features&hashtags=mdpiBDCC&url=https%3A%2F%2Fwww.mdpi.com%2F3456048&via=BDCC\_MDPI

http://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fwww.mdpi.com%2F3456048&title=Efficient%20Dynamic%20Emotion%20Recognition%20from%20Facial%20Expressions%20Using%20Statistical%20Spatio-Temporal%20Geometric%20Features%26source%3Dhttps%3A%2F%2Fwww.mdpi.com%26summary%3DAutomatic%20Facial%20Expression%20Recognition%20%28AFER%29%20is%20a%20key%20component%20of%20affective%20computing%2C%20enabling%20machines%20to%20recognize%20and%20interpret%20human%20emotions%20across%20various%20applications%20such%20as%20human%E2%80%93computer%20interaction%2C%20healthcare%2C%20entertainment%2C%20and%20%5B...%5D

http://www.facebook.com/sharer.php?u=https://www.mdpi.com/3456048

javascript:void(0);

http://www.reddit.com/submit?url=https://www.mdpi.com/3456048

http://www.mendeley.com/import/?url=https://www.mdpi.com/3456048

http://www.citeulike.org/posturl?url=https://www.mdpi.com/3456048

https://www.mdpi.com/3456048

https://www.mdpi.com/2504-2289/9/8/213

https://www.mdpi.com/2504-2289/9/8/213

https://www.mdpi.com/3456048

https://www.mdpi.com/2504-2289/9/8/213

Back to Top Top

https://www.mdpi.com/2504-2289/9/8/213

All MDPI websites use third-party website tracking technologies to provide and continually improve our services. I agree and may revoke or change my consent at any time with effect for the future.

https://www.mdpi.com/about/privacy

https://www.mdpi.com/about/terms-and-conditions

More Information

https://www.mdpi.com/2504-2289/9/8/213

Powered by Usercentrics Consent Management

https://www.usercentrics.com/consent-management-platform-powered-by-usercentrics/?utm\_source=banner\_uc&utm\_medium=referral&utm\_content=v3

