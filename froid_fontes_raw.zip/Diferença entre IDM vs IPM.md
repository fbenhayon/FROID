# Diferença entre IDM vs IPM

### 1. Diferença Fundamental

Métrica

Significado

O que mede?

Analogia Clínica

\*\*IPM\*\*

\*\*Índice de Potência Motivacional\*\*

Mede a \*\*INTENSIDADE\*\* ou \*\*ENERGIA\*\* global da voz. Indica o nível de ativação, engajamento e "combustível" emocional disponível no momento.

É como o \*\*velocímetro\*\* ou o \*\*tacômetro\*\* do carro. Mostra quão rápido o motor está girando (alta energia vs. embotamento).

\*\*IDM\*\*

\*\*Índice de Desvio Multimodal\*\*

Mede a \*\*DIREÇÃO\*\* e o \*\*DESEQUILÍBRIO\*\* da energia em zonas específicas. Indica se a energia está fluindo para padrões adaptativos (positivos) ou desadaptativos (negativos/conflito).

É como a \*\*bússola\*\* ou o \*\*alinhamento das rodas\*\*. Mostra se o carro está indo na direção certa ou se está derrapando para o lado errado.

### 2. Utilidade Prática Conjunta (Matriz de Interpretação)

A potência do FROID está em cruzar esses dois dados. Veja os 4 cenários clínicos possíveis:

Cenário

IPM (Energia)

IDM (Direção/Zona)

Interpretação Clínica

Ação Sugerida

\*\*A. Fluxo Saudável\*\*

Alto/Médio

Positivo (Verde/Azul)

Paciente engajado e resolvendo conflitos. Energia fluindo para recursos positivos.

Reforçar, validar e aprofundar o insight.

\*\*B. Sofrimento Ativo\*\*

Alto/Médio

Negativo Extremo (Vermelho)

Paciente em crise, raiva explosiva, choro intenso ou ansiedade aguda. Há energia, mas está direcionada ao conflito.

Conter, acolher a emoção, reduzir a ativação antes de interpretar.

\*\*C. Embotamento/Defesa\*\*

Baixo (Queda brusca)

Neutro ou Levemente Negativo

Paciente "desligou". Dissociação, shutdown ou resistência passiva. A energia colapsou.

Estimular suavemente, checar conexão terapêutica, não forçar conteúdo.

\*\*D. Falsa Calma\*\*

Baixo

Negativo Profundo (Latente)

Perigoso. Paciente parece calmo, mas o IDM mostra conflito profundo reprimido (somatização).

Investigar resistências, pois a energia está "presa" internamente.

### 3. Como isso aparece no Gráfico Mapa Zonal?

\* \*\*Linha Central (DR):\*\* Representa o ponto de equilíbrio (Zero).

\* \*\*Barras (IDM):\*\* O tamanho e a cor da barra mostram \*onde\* e \*quanto\* o paciente está desviado do equilíbrio (Conflito vs. Recurso).

\* \*\*Contexto (IPM):\*\* O valor do IPM (exibido no topo como "Base Line: XX.X") diz \*quanta força\* está sendo usada nesse desvio.

  \* \*Exemplo:\* Um IDM de -0.20 com IPM baixo pode ser apenas uma tristeza pensativa. O mesmo IDM de -0.20 com IPM altíssimo indica uma crise depressiva ativa ou luto agudo.