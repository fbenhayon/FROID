# MFCC7: Biomarcador Espectral para Diagnóstico de Depressão no FROID

O Coeficiente Cepstral de Frequência Mel 7 (MFCC7) atua como um biomarcador espectral avançado de extrema importância na análise vocal, desempenhando o papel de um preditor quantitativo e objetivo da gravidade da depressão \[1, 2\]. 

Na acústica da fala, os MFCCs (Mel-Frequency Cepstral Coefficients) são utilizados para modelar o formato e as propriedades de ressonância do trato vocal, capturando de forma minuciosa as mudanças sutis na tensão muscular e na coordenação articulatória do paciente \[1, 3\]. Como quadros depressivos frequentemente afetam o sistema nervoso autônomo e induzem fadiga e tensão muscular, a dinâmica dos articuladores da fala é alterada, impactando as frequências do som que passam pelas cordas vocais e pelo trato vocal \[4\]. O MFCC7, especificamente, capta essas microalterações fonéticas que são imperceptíveis à audição clínica humana subjetiva \[5\].

Clinicamente, o papel do MFCC7 divide-se nas seguintes frentes:

\*\*1. Predição de Risco Depressivo (Escala PHQ-9):\*\*
O MFCC7 apresenta uma forte correlação positiva e direta com a severidade dos sintomas depressivos \[6, 7\]. Estudos demonstraram que ele atua como um biomarcador capaz de prever matematicamente a pontuação global do paciente no \*Patient Health Questionnaire\* (PHQ-9), a principal escala de rastreamento de depressão maior \[1, 6\]. 

\*\*2. Especificidade em Verbalizações Negativas:\*\*
O poder preditivo do MFCC7 é maximizado quando o coeficiente é extraído durante tarefas de leitura ou verbalização de conteúdos com emoção ou valência negativa (situação mapeada clinicamente como "MFCC7-negativo") \[6, 8\]. Enquanto outros coeficientes podem variar mais dependendo da tarefa, o MFCC7 extraído em contextos negativos provou, via regressão linear, prever com precisão o nível de depressão do indivíduo \[6, 8\].

\*\*3. Discriminação Diagnóstica:\*\*
O MFCC7 também demonstrou possuir alta capacidade discriminatória para distinguir pessoas clinicamente saudáveis de pessoas com depressão, mostrando-se um indicador estável independentemente do idioma \[2, 9, 10\]. 

Na arquitetura do sistema FROID, o MFCC7 é extraído em tempo real pelo motor de processamento de borda (Edge AI) e utilizado para alimentar os algoritmos de predição clínica \[5\]. Ao isolar este coeficiente junto ao MFCC9 (que prevê ansiedade somática), o FROID não se limita a avaliar o conteúdo semântico do que o paciente diz, mas executa uma verdadeira biópsia espectral de sua exaustão neurológica e afetiva \[1, 11\].