# Backup Consolidado: Arquitetura Tecnológica e Estratégica FROID

# Backup Consolidado: Arquitetura Tecnológica e Estratégica FROID

### 1. Visão Geral e Propósito do Sistema
O sistema FROID é uma plataforma de \*\*Amplificação da Percepção Clínica\*\*, desenvolvida para prover a psicólogos e psiquiatras uma camada de inteligência analítica sobreposta à intuição profissional. O núcleo do sistema reside no processamento de \*Real-Time Inputs\* para detectar biomarcadores de condições psíquicas que frequentemente escapam à observação humana desassistida.

\*\*Pilares Estratégicos:\*\*
\*   \*\*Percepção Multimodal de Alta Fidelidade:\*\* Sincronização de análise prosódica (voz) e microexpressões faciais (vídeo).
\*   \*\*Inteligência de Diagnóstico Longitudinal:\*\* Monitoramento de evolução clínica através de séries temporais e comparação de baselines.
\*   \*\*Conformidade Bioética e Administrativa:\*\* Automação de prontuários estruturados sob rigoroso controle de consentimento granular (LGPD).

---

### 2. Arquitetura de Software e Infraestrutura (Monorepo)
A infraestrutura é organizada em um monorepo para garantir consistência entre o núcleo de identidade e os motores de análise biométrica. \*\*Nota Crítica de Arquitetura:\*\* O ambiente deve operar estritamente sob \*\*Python 3.11\*\*. Testes em ambiente de desenvolvimento confirmaram que a versão 3.13 causa falhas críticas de build em dependências essenciais como \`parselmouth\` e \`googleads\`.

| Módulo | Tecnologia Base | Porta | IP de Dependência (WSL) | Função Principal |
| :--- | :--- | :--- | :--- | :--- |
| \`identity-vault\` | NestJS / Prisma / TS | 3001 | 172.21.208.107 (DB) | Gestão de Usuários, Consentimentos e Auditoria. |
| \`froid-voice\` | \*\*Python 3.11\*\* / FastAPI | 3002 | 172.21.208.107 (Redis) | Extração de biomarcadores vocais e scoring clínico. |
| \`froid-face\` | \*\*Python 3.11\*\* / FastAPI | 3003 | 172.21.208.107 (Redis) | Análise de FACS, landmarks e microexpressões. |

\*   \*\*Persistência:\*\* PostgreSQL (Porta 5432) e Redis (Porta 6379) para Pub/Sub de eventos de baixa latência.

---

### 3. Orquestração de Sessão e Fluxo de Dados (Session Orchestrator)
O \`SessionOrchestrator\` governa o ciclo de vida das consultas, operando como o gatekeeper de privacidade.

1.  \*\*Inicialização (\`startSession\`):\*\* Validação de escopos via \`PolicyEngine\`.
2.  \*\*Snapshot de Consentimento:\*\* Criação do \`SessionConsentSnapshot\`, um registro imutável dos termos aceitos no momento exato do início.
3.  \*\*Gestão de Estados:\*\*
    \*   \*\*Active:\*\* Processamento liberado conforme escopos (\`audio\_recording\`, \`facial\_analysis\`).
    \*   \*\*Blocked:\*\* Suspensão automática caso o \`PolicyEngine\` detecte ausência de consentimento válido.
    \*   \*\*Ended:\*\* Encerramento com geração de \`LegalEvent\` (tipo \`SESSION\_ENDED\`) vinculado ao \`system\_policy\`.
4.  \*\*Auditoria:\*\* Registro de cada transição no \*\*Hash Chain\*\*, garantindo integridade forense aos logs.

---

### 4. Módulo FROID-Voice: Análise de Voz e Prosódia
Diferente de sistemas de transcrição comuns, o motor FROID foca na decomposição subconsciente da fala.

\*   \*\*Processamento de Sinal:\*\* Uso de \`openSMILE 3.0\` (eGeMAPS) e \`praat-parselmouth\`.
\*   \*\*VAD e Suavização:\*\* Implementação de \*\*VAD (Voice Activity Detection)\*\* agressividade 3 e \*\*EMA (Exponential Moving Average)\*\* para filtragem de ruído e estabilidade dos dados.
\*   \*\*Calibração Basal:\*\* Protocolo obrigatório de \*\*60 segundos iniciais\*\* para estabelecer a linha de base acústica individual.
\*   \*\*Ajuste por Sexo Biológico:\*\* Aplicação do fator de inversão de \*\*-0.85\*\* (baseado em Kaczmarek-Majer et al., 2024) para normalizar parâmetros de F0 e fluxo espectral em vozes femininas.
\*   \*\*Correlatos Neurológicos:\*\*
    \*   \*\*12 Zonas FROID:\*\* Dicotomias psíquicas mapeadas por energia zonal.
    \*   \*\*7 Bandas Espectrais:\*\* Foco no "janelamento humano" (85-2000 Hz) para detecção de ativação do sistema autônomo.
    \*   \*\*Sub-harmônicos (5-20 Hz):\*\* Detecção de tremores imperceptíveis ligados ao estresse agudo.
\*   \*\*Outputs Clínicos (Construct Scores):\*\* Geração de métricas normalizadas (0-1) para \`depression\_risk\`, \`mania\_activation\` e \`stress\_cognitive\`.

---

### 5. Módulo FROID-Face: Análise de Expressões e Microexpressões
A análise visual utiliza visão computacional avançada para isolar movimentos musculares involuntários.

\*   \*\*Geometria Facial:\*\* \`MediaPipe Face Mesh\` (468 landmarks 3D).
\*   \*\*FACS (Facial Action Coding System):\*\* Mapeamento de \*\*46 Action Units (AUs)\*\* com escala de intensidade de \*\*A a E\*\*.
\*   \*\*Lógica Temporal (HMM):\*\* Implementação de \*\*Modelo Oculto de Markov de 4 estados com decodificação Viterbi\*\*, exigindo a detecção da fase de "apex" para validar uma microexpressão e eliminar falsos positivos.
\*   \*\*Análise de Assimetria (D-face/S-face):\*\* Comparação entre hemisférios faciais para detecção de indicadores de desprezo ou paralisias neurogênicas leves.
\*   \*\*Genuineness Score:\*\* Métrica de autenticidade baseada na co-ativação de músculos confiáveis (involuntários) vs. voluntários.

---

### 6. Conformidade Legal, Ética e LGPD
O sistema atende integralmente às resoluções do CFP 13/2022 e 9/2024.

| Requisito Legal | Implementação Tecnológica FROID |
| :--- | :--- |
| \*\*Consentimento Informado\*\* | \`ConsentService\` com aceitação granular e vinculação via \`legalTextId\`. |
| \*\*Sigilo e Sigilo Profissional\*\* | \`Identity Vault\` com isolamento de PII (Personally Identifiable Information). |
| \*\*Transparência e Auditoria\*\* | Registro de \`LegalEvent\` vinculado a \`system\_policy\` e \`privacy\_policy\`. |
| \*\*Rastreabilidade de Dados\*\* | \`HashChain\` imutável para todos os eventos de ciclo de vida da sessão. |

---

### 7. Modelo de Negócio e Estratégia Financeira
A viabilidade econômica é sustentada por uma taxa de câmbio fixada em \*\*R$ 5,00 por USD\*\*.

1.  \*\*Plano Essencial:\*\* 100% processamento local (Open-source). Foco em volume e clínicas de entrada.
2.  \*\*Plano Profissional:\*\* Modelo híbrido. Análise local em tempo real e análise profunda via \*\*Hume AI em modo Batch\*\* (pós-sessão) para otimização de custos.
3.  \*\*Plano Premium:\*\* \*\*Full Streaming\*\* com Hume AI (48 dimensões emocionais) e teleconsulta avançada para psiquiatria de alto padrão.

---

### 8. Protocolos de Comunicação e Streaming
A escolha tecnológica prioriza a estabilidade e a confiança no deploy inicial.

\*   \*\*Modo Piloto (WebSocket):\*\* Escolhido para o lançamento inicial por evitar a complexidade de sinalização STUN/TURN do WebRTC, garantindo 95% de confiança na estabilidade de rede local/WSL.
\*   \*\*Modo Teleconsulta (WebRTC/LiveKit):\*\* Interceptação de stream para análise em tempo real em consultas remotas.
\*   \*\*Formatos de Dados:\*\*
    \*   \*\*JSON:\*\* Metadados e respostas REST.
    \*   \*\*Protobuf:\*\* Streaming de alta frequência a \*\*30 FPS\*\* para reduzir latência e overhead de banda.

---

### 9. Guia de Manutenção e Testes (Runbook E4A/E4B)
O sistema possui 47 cenários de teste automatizados que devem ser executados após qualquer alteração no núcleo de orquestração.

\*\*Procedimento de Reinicialização de Ambiente (Ordem de Operações):\*\*

1.  \*\*Sincronização de Banco (Vault):\*\*
    \`\`\`bash
    cd packages/identity-vault
    npx prisma generate --schema=src/prisma/schema.prisma
    npx prisma db push --schema=src/prisma/schema.prisma
    \`\`\`
2.  \*\*População de Dados (Seeds):\*\*
    \`\`\`bash
    node cleanup-e4a.js
    npx ts-node src/seed/legal-texts.ts  # Obrigatório para FK de system\_policy
    node seed-e4a.js
    \`\`\`
3.  \*\*Inicialização dos Motores Python (Utilizar py -3.11):\*\*
    \`\`\`bash
    # Em terminais separados
    py -3.11 -m pip install praat-parselmouth webrtcvad-wheels
    py -3.11 -m uvicorn src.main:app --host 0.0.0.0 --port 3002
    py -3.11 -m uvicorn src.main:app --host 0.0.0.0 --port 3003
    \`\`\`
4.  \*\*Execução da Suíte de Testes:\*\*
    \`\`\`bash
    pnpm run start:dev
    node test-e4a.js  # Verificar \[PASS\] para todos os 47 cenários
    \`\`\`