---
sourceFile: "FACS (Facial Action Coding System)"
exportedBy: "Kortex"
exportDate: "2026-06-29T01:00:27.837Z"
---

# FACS (Facial Action Coding System)

806dcb09-7e17-4a19-84d0-18484c449e10

FACS (Facial Action Coding System)

2c68d370-391d-4fe6-87fa-7b76ceeb9dd7

https://www.cs.cmu.edu/~face/facs.htm

FACS (Facial Action Coding System)

FACS - Facial Action Coding System (2002 Revision is

http://face-and-emotion.com/dataface/facs/new\_version.jsp

http://www.paulekman.com/

and Friesen 1978)

Description

Facial muscle

Example image

Inner Brow Raiser

Frontalis, pars medialis

Outer Brow Raiser

Frontalis, pars lateralis

Brow Lowerer

Corrugator supercilii, Depressor supercilii

Upper Lid Raiser

Levator palpebrae superioris

Cheek Raiser

Orbicularis oculi, pars orbitalis

Lid Tightener

Orbicularis oculi, pars palpebralis

Nose Wrinkler

Levator labii superioris alaquae nasi

Upper Lip Raiser

Levator labii superioris

Nasolabial Deepener

Zygomaticus minor

Lip Corner Puller

Zygomaticus major

Cheek Puffer

Levator anguli oris (a.k.a. Caninus)

Lip Corner Depressor

Depressor anguli oris (a.k.a. Triangularis)

Lower Lip Depressor

Depressor labii inferioris

Chin Raiser

Lip Puckerer

Incisivii labii superioris and Incisivii labii inferioris

Lip stretcher

Risorius w/ platysma

Lip Funneler

Orbicularis oris

Lip Tightener

Orbicularis oris

Lip Pressor

Orbicularis oris

Lips part\*\*

Depressor labii inferioris or relaxation of Mentalis, or Orbicularis oris

Masseter, relaxed Temporalis and internal Pterygoid

Mouth Stretch

Pterygoids, Digastric

Orbicularis oris

Lid droop\*\*

Relaxation of Levator palpebrae superioris

Orbicularis oculi

Eyes Closed

Relaxation of Levator palpebrae superioris; Orbicularis oculi, pars palpebralis

Orbicularis oculi, pars palpebralis

Relaxation of Levator palpebrae superioris; Orbicularis oculi, pars palpebralis

Relaxation of Levator palpebrae superioris; Orbicularis oculi, pars palpebralis

Head turn left

Head turn right

Head tilt left

Head tilt right

Head forward

Eyes turn left

Eyes turn right

AUs (Action Units) underlined bold are currently recognizable by AFA System when occurring alone or cooccurring.

\*\* The criteria has changed for this AU, that is, AU 25, 26 and 27 are now coded according to criteria of intensity (25A-E) and also AU 41, 42 and 43 are now coded according to criteria of intensity

