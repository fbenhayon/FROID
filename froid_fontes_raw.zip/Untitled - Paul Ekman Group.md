---
sourceFile: "Untitled - Paul Ekman Group"
exportedBy: "Kortex"
exportDate: "2026-06-29T01:00:28.816Z"
---

# Untitled - Paul Ekman Group

72fd6df9-d42e-4cc4-b839-5e8096e2dd80

Untitled - Paul Ekman Group

62304599-6df9-47a9-abb6-2c19755e8f11

https://www.paulekman.com/wp-content/uploads/2013/07/Classifying-Facial-Action.pdf

https://lh3.googleusercontent.com/notebooklm/AKXwDQE84AKyueoRMxDdnW4m4atzy2Nv7PD03ixsHtPoEDancF4GKeJe0CkzIa4N35I6hq\_IvjmA6f-R\_9OM7oqSa3\_D2\_gZS76LbGLE0P42gq7nljPBxcP\_NNU0O\_0BNLfdstAP\_yDa=w883-h1111-v0

0718b3f5-80a0-433a-84b3-7e9ff23a6287

https://lh3.googleusercontent.com/notebooklm/AKXwDQHjQZ9XKJ3jLJZ5L91zkglq3ag5KymmE0o3Rm69USU--R\_NfiSWmM5OOLOJZ5Z2ugLfJZaqG4PQRZrljyCzeoMHAJG3H1OePBovq8hGeoM5omu2Iba0L7mBulwJtVMvgd2Xja6M=w883-h1111-v0

49f4fb84-9af6-4ec9-b82f-da2e36996b68

https://lh3.googleusercontent.com/notebooklm/AKXwDQHQVwZcuUlUYaaMC7\_KKODZ7CHLbfxkO-cDxFaWV-WcFE3moj1GjOjMYs2DqW-WYJN-WoAfVKDZqsCHdyrutiSplO43hTpTbY4Yl99B8ATVVfTwqIoaThxtH7RrI8rgyVUuzmvo=w883-h1115-v0

ac7fc1d6-750c-40b6-9b23-88628f98c2ef

https://lh3.googleusercontent.com/notebooklm/AKXwDQHh8mXbHbaSBbYT1VG4gzGStCKFPQJW\_ke27dn6Mha1358eAdrC9G4NcKFPFN4iJ3ni7c\_YBH5UekxXld-\_7hgDQVjvvzG6YF\_2ICTxt8jLs6XofK2YyGv1bx59jetEyYVvHHlYhQ=w883-h1115-v0

10ccd8c4-b113-42fd-bf94-3fdd88feb6ea

https://lh3.googleusercontent.com/notebooklm/AKXwDQHf5ArNO-IYtlshgqwUzipNpodVq\_a9C1KdH9OUQQ1e534Oz9KeOb0LA7hKGUBU1JhKjn3TiEYKu84XyC0QHvqb5aD8StkjoTFv3gIAAQ6RtKFQAMW0aqCtX3fBJWAf5Hfk7wxo=w883-h1115-v0

485b5e54-bc33-4a8b-8226-b8729c1a693b

https://lh3.googleusercontent.com/notebooklm/AKXwDQEMSRvZ8KSmRrwJ0gjxxHjKkZD6RiWT37ol4RFWBpW8IAaXRiiYzbglZYtulcdIW6lIsU-fQmkFLn2Fcdjd\_uec73YncmXES-6rMfJC434LD-TvA3e88x5AsyTScx\_K9VUBdI4jDw=w883-h1115-v0

0601d2d9-8a66-43c5-bf29-bd741b059c77

https://lh3.googleusercontent.com/notebooklm/AKXwDQHWgBTsb0zNANWF9ySatphK3uTIJq\_pTHmQZEq73HjtdcHgEHvp6FgQ6kQ9nMh1M-SQwCyt3OkKK49XwurX\_yAffk7AyicgrzoQehoNlO1WjE993Kh5B6yINp0BoA0uL77BNvNMVA=w883-h1115-v0

57f54b53-1e7e-4ab1-9240-0693d3eabed6

https://lh3.googleusercontent.com/notebooklm/AKXwDQHrDJ3HalGEEF\_3gH\_qZfT5uj\_-5YF9RrRd5HnwfhU0ujYSrRNzPjabhHVANjk6NqKF9E9CtOa9HW3KS8EglbGeg9c7UD0zAI3BS9TcXzHGBOG5bPYLDCRbTvKRCcGFVElKYZdu=w883-h1115-v0

9a6872b3-46e0-41e8-bc41-899f97469620

