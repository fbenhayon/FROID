---
sourceFile: "Classifying Facial Actions - PMC - NIH"
exportedBy: "Kortex"
exportDate: "2026-06-29T01:00:27.716Z"
---

# Classifying Facial Actions - PMC - NIH

c2e97c8f-53c3-4c13-85be-dd6fc6a17db2

Classifying Facial Actions - PMC - NIH

ba199cae-beab-4864-8424-79fb943b775c

https://pmc.ncbi.nlm.nih.gov/articles/PMC3008166/

Checking your browser - reCAPTCHA

Checking your browser before accessing pmc.ncbi.nlm.nih.gov ...

https://www.google.com/recaptcha/challengepage/

if you are not automatically redirected after 5 seconds.

Try again later

Your computer or network may be sending automated queries. To protect our users, we can't process your request right now. For more details visit

our help page

https://support.google.com/websearch/answer/86640

