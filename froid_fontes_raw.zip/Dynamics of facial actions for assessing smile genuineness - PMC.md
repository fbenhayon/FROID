---
sourceFile: "Dynamics of facial actions for assessing smile genuineness - PMC"
exportedBy: "Kortex"
exportDate: "2026-06-29T01:00:27.764Z"
---

# Dynamics of facial actions for assessing smile genuineness - PMC

0e192af4-7acb-427a-af70-dfb6a0f512bc

Dynamics of facial actions for assessing smile genuineness - PMC

6bca9a6c-477d-4d3a-9454-0902e6119987

https://pmc.ncbi.nlm.nih.gov/articles/PMC7785114/

Checking your browser - reCAPTCHA

Checking your browser before accessing pmc.ncbi.nlm.nih.gov ...

https://www.google.com/recaptcha/challengepage/

if you are not automatically redirected after 5 seconds.

Try again later

Your computer or network may be sending automated queries. To protect our users, we can't process your request right now. For more details visit

our help page

https://support.google.com/websearch/answer/86640

