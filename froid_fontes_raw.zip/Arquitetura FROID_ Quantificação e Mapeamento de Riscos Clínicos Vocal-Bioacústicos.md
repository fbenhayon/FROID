# Arquitetura FROID: Quantificação e Mapeamento de Riscos Clínicos Vocal-Bioacústicos

Para substanciar a arquitetura do FROID com a precisão exigida pelos profissionais mais habilidosos do planeta, a quantificação dos riscos clínicos não opera com base em suposições, mas em uma extração matemática rigorosa cruzada com as escalas psiquiátricas padrão-ouro. O sistema traduz o estado fisiológico do paciente em um painel de monitoramento visual através do processamento exato de seis indicadores de risco.

Os indicadores de risco clínico mapeados na arquitetura do FROID são: \*\*Depressão, Mania, Estresse, Ansiedade, Dissociação e Trauma\*\* \[1\].

### A Matemática da Transformação (Como são calculados)

A inteligência de borda (Edge AI) do FROID atua em duas camadas para gerar o percentual exibido na tela do profissional:

\*\*1. O Motor de Inferência Backend (Score de 0 a 1):\*\*
O motor bioacústico do sistema analisa as características vocais (FFT, Coeficientes Cepstrais Mel e dinâmica temporal) e extrai \*scores\* normalizados entre 0.0 e 1.0 para cada constructo \[2\]. Estes escores não são aleatórios; eles são calculados através de coeficientes de regressão linear baseados em biomarcadores validados em estudos científicos \[2\].

\*\*2. A Equação Frontend (O Percentual de 0% a 100%):\*\*
Para que o dashboard exiba uma métrica visualmente acionável, o código do FROID recebe o valor bruto (v) e aplica a seguinte fórmula de conversão algorítmica:
\`Percentual = Math.max(0, Math.round((v - 0.5) \* 200))\` \[1\].
Isso significa que um \*score\* basal ou neutro avaliado em 0.5 pela IA equivale a 0% de risco na tela (o limite inferior garantido pela função matemática) \[1\]. À medida que o \*score\* bruto supera 0.5, o valor é multiplicado de forma a acelerar o percentual, culminando em 100% quando a IA emite um alerta máximo de 1.0.

### Fontes Clínicas e Extração dos Biomarcadores

Cada um dos seis percentuais provém do cruzamento espectral de biomarcadores específicos em relação a escalas psiquiátricas validadas:

\*\*1. Risco de Depressão (Depression Risk):\*\*
Deriva diretamente da predição matemática da escala \*\*PHQ-9\*\* (\*Patient Health Questionnaire-9\*) \[3, 4\]. O algoritmo isola o biomarcador MFCC7 (\*Mel-Frequency Cepstral Coefficient 7\*) durante a verbalização de conteúdos com valência semântica negativa \[3, 5\]. Quando este coeficiente se eleva acusticamente junto a marcadores de retardo psicomotor (como aumento da Taxa de Cruzamento por Zero - ZCR, prolongamento de pausas na fala e menor variação da frequência fundamental F0), o percentual de risco depressivo escala \[6, 7\].

\*\*2. Risco de Ansiedade Somática (Anxiety Risk):\*\*
O FROID mapeia esse risco espelhando as subescalas de ansiedade e somatização da escala \*\*HAMD\*\* (\*Escala de Depressão de Hamilton\*) \[3, 8, 9\]. O cálculo concentra-se de maneira diametralmente oposta: o sistema busca o coeficiente MFCC9 em momentos de discurso puramente "neutro" \[3, 8\]. O MFCC9 tem correlação inversa com a ansiedade, significando que quedas nos valores brutos acústicos evidenciam severa tensão autônoma latente represada nas pregas vocais, elevando o percentual de risco no sistema \[8\].

\*\*3. Ativação de Mania (Mania Activation):\*\*
Baseia-se nos preditores vocais avaliados para a escala \*\*YMRS\*\* (\*Young Mania Rating Scale\*) \[10\]. O sistema monitora ativamente se o paciente apresenta aumento drástico no tom de voz (pitch/F0 elevado), elevação na intensidade/energia (loudness), taxa acelerada de fala (sílabas por segundo) e fluxo espectral mais incisivo ("sharper voice") \[11-14\]. Esses marcadores acusticamente correlacionados à hiperativação disparam o percentual desta barra.

\*\*4. Estresse Cognitivo (Stress Cognitive):\*\*
Este percentual é um reflexo do \*workload\* (esforço mental contínuo) do cérebro. É detectado algoritmicamente através das microperturbações irregulares ciclo a ciclo na laringe, monitorando aumentos sustentados de frequência (F0) e alterações significativas no Jitter (perturbação de frequência) e Shimmer (perturbação de amplitude) \[15, 16\].

\*\*5 e 6. Risco de Dissociação e Trauma:\*\*
Esses percentuais são originados pela mais sofisticada capacidade do FROID: o cruzamento de frequências do Infrassom Vocal com a expressão muscular FACS. O sistema examina a energia sub-harmônica (na faixa imperceptível de 5 a 12 Hz), que rastreia os tremores oriundos do Sistema Nervoso Autônomo \[17\]. O risco aumenta instantaneamente quando há "picos" nesses sub-harmônicos aliados a indicadores de dor e angústia facial profunda, como ativações acentuadas do músculo depressor do ângulo da boca (AU15) e o estiramento horizontal dos lábios (AU20), tudo sob uma tensão vocal simultânea na base (85-165 Hz) \[17\]. Esta combinação alerta o psiquiatra sobre \*flooding\* (sobrecarga autonômica ou retraumatização) \[17\].

### Colorimetria Clínica

Para conferir uma rápida percepção ao profissional sem distraí-lo da interação humana, o algoritmo de interface traduz matematicamente esses percentuais de risco em um esquema de cores evolutivas \[18\]:

\*   \*\*Percentual ≤ 0%:\*\* Cinza escuro (Nenhum risco detectado / Linha de base) \[18\].
\*   \*\*Percentual < 15%:\*\* Verde escuro (Risco residual normal) \[18\].
\*   \*\*Percentual < 30%:\*\* Verde (Baixo risco) \[18\].
\*   \*\*Percentual < 50%:\*\* Amarelo (Risco Moderado/Atenção) \[18\].
\*   \*\*Percentual < 70%:\*\* Laranja (Risco Elevado) \[18\].
\*   \*\*Percentual ≥ 70%:\*\* Vermelho (Risco Extremo ou Crise Ativa) \[18\].