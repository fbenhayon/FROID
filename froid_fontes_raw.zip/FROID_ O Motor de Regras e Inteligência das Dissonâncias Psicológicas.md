# FROID: O Motor de Regras e Inteligência das Dissonâncias Psicológicas

O \*\*Motor de Regras de avaliação das Dissonâncias\*\* do FROID é o núcleo de inteligência que distingue a plataforma de qualquer sistema de prontuário eletrônico convencional, operando como um sensor radiográfico do subconsciente humano \[1, 2\]. Para que o sistema atinja a precisão inquestionável exigida pela nossa arquitetura de elite, ele não analisa canais de comunicação isolados; em vez disso, ele processa a \*\*conjunção multimodal\*\* de sinais a cada 500 milissegundos, comparando a intenção consciente (sistema piramidal) com o vazamento biológico involuntário (sistema extrapiramidal) \[3-5\].

Abaixo, detalho minuciosamente o funcionamento técnico, as conjunções de gatilho e a lógica matemática que acionam este Motor de Regras:

### 1. O Fundamento Matemático: O Multiplicador $M\_{fac}$
O acionamento das regras de dissonância culmina na fórmula mestre do \*\*Índice de Desvio Multimodal (IDM)\*\* \[3\]. O sistema calcula o desvio energético basal da voz ($D\_{energia}$) e aplica o \*\*Multiplicador Facial de Dissonância ($M\_{fac}$)\*\* \[6, 7\]. 
\*   \*\*Congruência:\*\* Se a face e a voz confirmam a mesma emoção, $M\_{fac} = 1.0$.
\*   \*\*Dissonância:\*\* Sempre que uma das cinco regras abaixo é detectada, o multiplicador assume o valor de \*\*2.5\*\*, fazendo o score de desvio "explodir" graficamente no dashboard para as zonas Amarela ou Vermelha, sinalizando uma resistência psicológica severa \[3, 7, 8\].

---

### 2. As 5 Conjunções do Motor de Regras

O FROID está codificado para identificar discrepâncias específicas através do cruzamento de Unidades de Ação (AUs), bandas de frequência vocal e análise semântica \[9, 10\]:

#### A. Regra 1: O Sorriso Falso (Falsa Calma)
Esta regra detecta quando o paciente utiliza um sorriso como máscara social para encobrir sofrimento interno \[11, 12\].
\*   \*\*Gatilho Vocal:\*\* O sistema detecta alta tensão ou picos de energia em zonas de conflito (como a \*\*Zona 7 - Raiva\*\* ou \*\*Zona 3 - Tristeza\*\*) \[11, 12\].
\*   \*\*Gatilho Facial:\*\* A IA identifica a ativação da \*\*AU 12\*\* (\*Lip Corner Puller\*), mas confirma a \*\*ausência total da AU 6\*\* (\*Cheek Raiser\*) \[9, 13\].
\*   \*\*Diferencial Clínico:\*\* Sem a contração involuntária da porção orbital do olho (AU 6 - Marcador de Duchenne), o sorriso é classificado como puramente voluntário e contraditório à energia vocal \[14, 15\].

#### B. Regra 2: Raiva Contida
Identifica a agressividade reprimida que não chega a ser verbalizada ou expressa em macroexpressões \[9, 12\].
\*   \*\*Gatilho Vocal:\*\* Picos de energia extrema na \*\*Zona 7 (F#)\*\*, que mapeia a dicotomia entre raiva e aceitação da mudança \[16, 17\].
\*   \*\*Gatilho Facial:\*\* A face principal pode parecer neutra, mas o motor detecta a contração isolada e tensa das \*\*AUs 23\*\* (\*Lip Tightener\*) ou \*\*AU 24\*\* (\*Lip Pressor\*) \[9, 11\].
\*   \*\*Lógica de Incoerência:\*\* O esforço muscular para comprimir os lábios (AU 24) serve para "frear" fisicamente a fala ou o grito que a energia vocal da Zona 7 está pressionando para liberar \[18, 19\].

#### C. Regra 3: Tristeza Mascarada
Mapeia o vazamento da dor profunda durante discursos de aparente bem-estar \[9, 12\].
\*   \*\*Gatilho Semântico:\*\* O processamento de linguagem natural (NLP) identifica valência positiva ou neutra (ex: o paciente diz que "está tudo bem") \[9\].
\*   \*\*Gatilho Vocal:\*\* Queda abrupta de energia na \*\*Zona 3 (D)\*\*, associada à depressão e luto \[17, 20\].
\*   \*\*Gatilho Facial:\*\* Detecção pelo classificador temporal do combo neuromuscular involutivo \*\*{AU 1 + 4 + 15}\*\* (sobrancelhas internas elevadas e aproximadas com cantos da boca para baixo) \[9, 21, 22\].

#### D. Regra 4: Microexpressão Contraditória
Capta verdades emocionais que "vazam" em intervalos quase imperceptíveis ao olho humano \[9, 23\].
\*   \*\*Gatilho Temporal:\*\* Vazamentos emocionais que duram entre \*\*40 e 200 milissegundos\*\* \[14, 23, 24\].
\*   \*\*Conjunção de Gatilho:\*\* O paciente mantém uma máscara de neutralidade (\*\*AU 0\*\*), mas o sistema detecta o frame de ápice (\*\*Apex\*\*) de uma emoção antagônica (medo ou nojo) antes que o controle cortical consiga suprimi-la totalmente \[19, 25\].
\*   \*\*Validação:\*\* A regra só é acionada se a confiança do ápice ($Apex\_Confidence$) for superior a 0.75 \[26\].

#### E. Regra 5: Desprezo Unilateral
Identifica sentimentos subconscientes de superioridade ou desdém \[9, 13\].
\*   \*\*Gatilho de Assimetria:\*\* Ativação estritamente unilateral (apenas no lado direito ou esquerdo) da \*\*AU 12\*\* (\*Lip Corner Puller\*) ou \*\*AU 14\*\* (\*Dimpler\*) \[13, 27\].
\*   \*\*Conjunção Contextual:\*\* Ocorre frequentemente enquanto o paciente relata fatos sobre terceiros ou descreve situações de conflito interpessoal, invalidando discursos de neutralidade ou cooperação \[9, 19\].

---

### 3. O Ápice da Inteligência: Risco Clínico e Flooding Autonômico
O Motor de Regras atinge sua complexidade máxima ao cruzar frequências inaudíveis com morfodinâmica facial para prever o colapso psíquico \[12, 22\]. O sistema emite um \*\*Alerta Vermelho de Risco Extremo\*\* quando detecta a conjunção de três vetores simultâneos:
1.  \*\*Vocal:\*\* Tremores autonômicos no infrassom vocal (\*\*5-12 Hz\*\*) \[22, 28, 29\].
2.  \*\*Facial:\*\* Contrações síncronas de pânico e dor profunda (\*\*AU 15 + AU 20\*\*) \[12, 22, 28\].
3.  \*\*Tensão de Base:\*\* Alta energia represada na banda de \*\*85-165 Hz\*\* \[28, 29\].

Esta conjunção sinaliza retraumatização iminente (\*flooding\*) ou um desligamento dissociativo (\*shutdown\*), permitindo que o profissional interrompa a abordagem antes da desregulação biológica do paciente \[12, 22, 29\].