---
sourceFile: "FROID_Premissas_Sistema_v1.docx"
exportedBy: "Kortex"
exportDate: "2026-06-29T01:00:27.956Z"
---

# FROID_Premissas_Sistema_v1.docx

f175eac3-f581-451d-9617-37dc7f9071d3

FROID\_Premissas\_Sistema\_v1.docx

297f4c61-02c6-49c2-8c49-13206d534319

Frequency Recognition of Internal Dynamics

Documento de Premissas e Especificações do Sistema

#### Documento Confidencial

1. Visão Geral do Sistema
1.1 Definição

O FROID (Frequency Recognition of Internal Dynamics) é um software voltado para profissionais da psicologia e psiquiatria, projetado para ampliar a percepção clínica durante sessões terapêuticas. O sistema captura, analisa e apresenta em tempo real indicadores psicoacústicos da voz e padrões de expressões faciais dos pacientes, fornecendo ao profissional uma camada adicional de dados objetivos para complementar sua avaliação clínica subjetiva.

1.2 Propósito e Justificativa

A prática clínica em saúde mental depende fortemente da capacidade do profissional de perceber nuances emocionais e comportamentais em seus pacientes. O FROID não substitui essa expertise, mas a potencializa ao oferecer:

Dados quantitativos sobre variações vocais em zonas de frequência específicas, inspirado no modelo de análise do sistema EVOX

Mapeamento contínuo de micro e macroexpressões faciais durante a sessão

Correlação temporal entre conteúdo verbal, tonalidade vocal e expressão facial

Histórico longitudinal para acompanhamento da evolução do paciente ao longo do tratamento

Relatórios pós-sessão com síntese dos pontos mais relevantes e índices médios

1.3 Público-Alvo

Psicólogos clínicos (todas as abordagens terapêuticas)

Psiquiatras em atendimento ambulatorial

Clínicas e centros de saúde mental

Instituições de pesquisa em saúde mental

Programas de formação e supervisão clínica

2. Arquitetura e Módulos do Sistema

O FROID é estruturado em dois eixos principais — Clínico e Administrativo — com módulos interdependentes que cobrem todo o ciclo de atendimento.

Função Principal

Análise Vocal (Voice Spectrum)

Captura e análise de frequências vocais em tempo real

Análise Facial (Face Map)

Reconhecimento e classificação de expressões faciais

Dashboard em Tempo Real

Visualização gráfica unificada durante a sessão

Relatórios e Histórico

Geração de relatórios pós-sessão e longitudinais

Gravação de Sessões

Registro em áudio/vídeo das consultas

Administrativo

Calendário e Agenda

Gestão de horários, pacientes e tipos de consulta

Administrativo

Padrões de Consulta

Configuração de templates para tipos de atendimento

Administrativo

Controle de cobranças, pacotes de sessões e faturamento

Administrativo

Compartilhamento

Envio controlado de relatórios por sessão (modelo pago)

3. Módulo de Análise Vocal — Voice Spectrum
3.1 Fundamento Teórico

O módulo Voice Spectrum baseia-se no princípio de que a voz humana carrega informações emocionais e psicológicas além do conteúdo semântico. Variações em frequência fundamental (F0), harmônicos, formantes, jitter, shimmer e taxa de fala podem indicar estados emocionais como ansiedade, depressão, raiva contida, dissimulação e engajamento autêntico. A abordagem é inspirada no modelo de zonas energéticas utilizado pelo sistema EVOX, adaptada para o contexto clínico.

3.2 Zonas de Energia Vocal

O sistema mapeia a voz do paciente em zonas de energia, cada uma correlacionada a estados psicoemocionais específicos. A seguir, a definição de cada zona:

Faixa de Frequência

Correlação Emocional

Indicadores Clínicos

85–165 Hz (base)

Raiva, frustração, assertividade intensa

Tensão muscular vocal, ativação simpática

Ansiedade, nervosismo, agitação

Elevação de pitch, instabilidade vocal

Engajamento cognitivo, atenção

Clareza articulatória, ritmo regular

Equilíbrio, serenidade, abertura

Voz ressonante, respiração regular

Expressão emocional, vulnerabilidade

Variação melódica, pausas reflexivas

Azul Escuro

900–1200 Hz

Introspecção, retração, tristeza

Volume reduzido, monotonia vocal

1200–2000 Hz (harmônicos)

Criatividade, insight, resolução

Entonação complexa, riqueza harmônica

3.3 Parâmetros de Análise em Tempo Real

O motor de análise vocal processa continuamente os seguintes parâmetros, apresentados ao profissional em gráficos dinâmicos:

Frequência Fundamental (F0): pitch médio, variação e contorno ao longo do tempo

Jitter e Shimmer: indicadores de instabilidade vocal associados a estresse e fadiga

Harmônicos-para-Ruído (HNR): qualidade vocal geral; valores baixos sugerem tensão ou patologia

Taxa de Fala (sílabas/segundo): aceleração pode indicar ansiedade; desaceleração pode indicar depressão

Pausas e Silêncios: duração, frequência e posição no discurso — marcadores de hesitação ou reflexão

Distribuição Espectral: proporção de energia em cada zona, atualizada a cada 500ms

Coerência Emocional: índice que compara o conteúdo semântico (via NLP) com o padrão vocal detectado

3.4 Visualização no Dashboard

#### A interface de análise vocal apresenta ao profissional:

Gráfico circular de zonas (estilo EVOX): disco colorido mostrando a distribuição de energia vocal por zona, atualizado em tempo real

Gráfico de linha temporal: evolução da zona dominante ao longo da sessão

Indicadores instantâneos: barras laterais com F0, jitter, shimmer e HNR com código de cores (verde = normal, amarelo = atenção, vermelho = alerta)

Marcação de eventos: o profissional pode inserir marcos temporais (ex: “paciente mencionou divórcio”) para correlação posterior

4. Módulo de Análise Facial — Face Map
4.1 Fundamento Teórico

O módulo Face Map utiliza tecnologia de visão computacional para mapear as unidades de ação facial (Action Units — AU), conforme o Facial Action Coding System (FACS) desenvolvido por Paul Ekman. O sistema identifica combinações de AUs para classificar emoções e detectar incoerências entre expressão facial e discurso verbal.

4.2 Emoções Mapeadas

Action Units (FACS)

Relevância Clínica

AU6 + AU12 (sorriso genuíno de Duchenne)

Diferenciação entre alegria autêntica e social

AU1 + AU4 + AU15

Indicador de humor depressivo

AU4 + AU5 + AU7 + AU23

Hostilidade contida ou expressa

AU1 + AU2 + AU4 + AU5 + AU20

Ansiedade, trauma, fóbica

AU9 + AU15 + AU16

Rejeição, aversão a temas específicos

AU1 + AU2 + AU5 + AU26

Reação a insights ou revelações

AU12R ou AU14R (unilateral)

Atitude de superioridade ou dissônancia

Neutra/Flat Affect

Ausência prolongada de AUs

Embotamento afetivo, dissociação

4.3 Análises Avançadas

Microexpressões: detecção de expressões de duração inferior a 500ms, frequentemente associadas a emoções reprimidas

Dissônancia Expressiva: índice que mede a incongruência entre expressão facial e conteúdo verbal/vocal

Assimetria Facial: indicação de emoção não genuína ou conflito interno

Frequência de piscadas: taxa elevada pode indicar estresse; taxa muito baixa pode indicar dissociação

Direção do olhar: padrões de evitação visual, desvio durante temas sensíveis

4.4 Visualização no Dashboard

#### O painel de análise facial apresenta:

Mapa facial esquemático: exibição do rosto com destaque nas áreas ativas (sobrancelhas, olhos, boca, maçãs do rosto)

Gráfico de emoções (radar): distribuição proporcional das emoções detectadas nos últimos 30 segundos

Timeline emocional: evolução das emoções ao longo da sessão, sincronizada com a análise vocal

Indicador de coerência voz-face: semáforo que indica se a expressão facial é coerente com a análise vocal

5. Dashboard Integrado em Tempo Real
5.1 Layout da Tela Principal

O dashboard é projetado para ser discreto e não intrusivo, podendo ser exibido em um segundo monitor ou em uma área lateral da tela principal. O layout consiste em:

Área superior: disco de zonas vocais (estilo EVOX) com atualização a cada 500ms

Área central: timeline dual — linha superior mostrando zona vocal dominante, linha inferior mostrando emoção facial dominante

Área lateral direita: indicadores numéricos instantâneos (F0, HNR, jitter, índice de coerência)

Área inferior: barra de ferramentas com botões de marcação de evento, anotação rápida e controles de gravação

Alertas visuais: pulsos sutis de cor quando detectados picos de incoerência ou transições emocionais abruptas

5.2 Índice de Percepção Móvel (IPM)

O IPM é o indicador central do FROID. Trata-se de um índice composto que integra os dados vocais e faciais em um único score contínuo (0–100), calculado a cada 5 segundos. O IPM reflete:

Estabilidade emocional: quanto menor a variância entre zonas vocais e emoções faciais, maior o índice

Coerência multimodal: alinhamento entre voz, face e conteúdo verbal

Intensidade emocional: magnitude das ativações detectadas

O IPM é exibido como um gráfico de área colorida (verde = equilíbrio, amarelo = atenção, vermelho = alerta) que acompanha toda a sessão.

6. Relatórios e Análise Longitudinal
6.1 Relatório Pós-Sessão

#### Ao final de cada sessão, o sistema gera automaticamente um relatório contendo:

Resumo executivo: duração, IPM médio, zona vocal predominante e emoção facial predominante

Gráfico temporal completo: evolução do IPM, zonas vocais e emoções ao longo da sessão

Momentos críticos: lista dos picos e vales de IPM com timestamp e contexto (marcadores do profissional)

Análise de coerência: percentual de tempo em coerência vs. dissonância entre voz e face

Temas abordados: identificação automática de tópicos via NLP com correlação de impacto emocional

Notas do profissional: anotações inseridas durante a sessão

6.2 Análise Longitudinal

O sistema permite ao profissional acompanhar a evolução do paciente ao longo do tempo:

Comparação entre sessões: sobreposição de gráficos de IPM de diferentes sessões

Evolução de indicadores: tendências de F0 médio, distribuição de zonas, emoções predominantes

Padrões recorrentes: identificação automática de temas que consistentemente provocam alterações

Médias móveis: IPM médio por período (semanal, mensal, trimestral)

Definição de baselines: o profissional pode marcar sessões de referência para comparar evolução

6.3 Padrões de Comportamento

O FROID permite ao profissional definir e monitorar padrões de comportamento específicos:

Triggers emocionais: associação de temas específicos a padrões de ativação consistentes

Perfis de sessão: categorização automática de sessões por padrão emocional dominante

Alertas de regressão: notificação quando indicadores voltam a padrões anteriores ao tratamento

Predição de tendências: modelos estatísticos para projeção de trajetória terapêutica

7. Gravação e Armazenamento de Sessões
7.1 Modalidades de Gravação

Áudio integral: gravação contínua do áudio da sessão para análise posterior

Vídeo (opcional): captura de vídeo para referência de expressões faciais

Dados analíticos: stream de dados brutos de análise vocal e facial

Transcrição automática: conversão speech-to-text para indexação e busca

7.2 Consentimento e Conformidade

Toda gravação requer consentimento explícito do paciente, documentado digitalmente no sistema. O FROID implementa:

Termo de consentimento digital com assinatura eletrônica do paciente

Opção de consentimento granular: o paciente pode autorizar áudio, vídeo e/ou dados analíticos separadamente

Possibilidade de revogação de consentimento a qualquer momento com exclusão dos dados

Conformidade com LGPD, HIPAA e regulamentações locais de saúde mental

Criptografia end-to-end para todos os dados armazenados e em trânsito

Política de retenção configurável pelo profissional

8. Eixo Administrativo
8.1 Calendário e Agenda

#### Módulo completo de gestão de agenda integrado ao fluxo clínico:

Visão diária, semanal e mensal com arraste de consultas

Tipos de consulta configuráveis: primeira consulta, retorno, sessão de crise, avaliação, supervisão

Lembretes automáticos via SMS, e-mail ou WhatsApp para pacientes

Gestão de lista de espera e cancelamentos

Integração com Google Calendar e Outlook

Bloqueio de horários para atividades não clínicas (supervisão, estudo, etc.)

8.2 Padrões de Consulta

#### O profissional pode definir templates de consulta que determinam:

Duração padrão (30, 45, 50, 60 minutos ou personalizado)

Protocolo de análise: quais módulos ativar (vocal, facial, ambos)

Checklist de início de sessão (consentimento, atualização cadastral, etc.)

Estrutura de relatório: campos obrigatórios e opcionais no relatório pós-sessão

Categorização temática: tags para organizar sessões por tema ou fase do tratamento

8.3 Módulo Financeiro

#### Gestão financeira integrada ao fluxo de atendimento:

Tabela de preços por tipo de consulta e convênio

Pacotes de sessões: definição de planos com número fixo de sessões e valores diferenciados

Controle de pagamentos: registro de pagamentos, parcelas e inadimplência

Emissão de recibos e notas fiscais (integração com sistemas contábeis)

Relatórios financeiros: faturamento mensal, média por paciente, taxa de cancelamento

Conciliação com convênios e planos de saúde

8.4 Compartilhamento de Sessões

#### O sistema permite o compartilhamento controlado de dados de sessões:

Compartilhamento por sessão individual, nunca em lote (proteção do paciente)

Destinatários autorizados: outros profissionais de saúde, supervisionadores, o próprio paciente

Níveis de acesso: relatório completo, relatório resumido ou apenas indicadores

Rastreabilidade: log de todos os compartilhamentos com data, destinatário e escopo

Modelo de cobrança: o compartilhamento pode ser vinculado ao plano de sessões contratado

Expiração automática: links de compartilhamento expiram após período configurável

9. Modelo de Negócios e Licenciamento
9.1 Planos de Assinatura

Professional

Sessões/mês

Análise Vocal

Básica (3 zonas)

Completa (7 zonas)

Completa + NLP

Completa + NLP + IA

Análise Facial

Não inclusa

6 emoções básicas

8 emoções + micro

Completa + predição

Básico pós-sessão

Completo + longitudinal

Completo + padrões

Custom + API

Somente áudio

Áudio + vídeo

Completa + transcrição

Completa + IA summ.

Armazenamento

Completo + NF

ERP integrado

Compartilhamento

Não incluso

Ilimitado + API

Chat + E-mail

Prioritário

Dedicado + SLA

9.2 Modelo de Sessões Adicionais

Além da assinatura base, o profissional pode adquirir créditos adicionais de sessões, compartilhamentos e armazenamento. O sistema opera com um modelo de créditos flexível onde cada operação consume um número específico de créditos conforme a complexidade (análise básica = 1 crédito, análise completa = 2, compartilhamento = 0,5 crédito).

10. Requisitos Técnicos
10.1 Infraestrutura

Cloud-native: deployável em AWS, Azure ou GCP

Processamento de áudio: latência máxima de 200ms para análise vocal em tempo real

Processamento de vídeo: mínimo de 15 fps para análise facial contínua

Banco de dados: PostgreSQL para dados estruturados, S3/Blob para mídia

API RESTful e WebSocket para comunicação em tempo real

Criptografia AES-256 para dados em repouso e TLS 1.3 para dados em trânsito

10.2 Plataformas

Web App: navegador Chrome, Firefox, Edge, Safari (versões atuais)

Desktop: aplicativo nativo para Windows 10+ e macOS 12+

Tablet: iPad e Android tablets (uso em consultório)

Mobile: app para iOS e Android (acesso a relatórios e agenda; análise não disponível)

10.3 Tecnologias de Análise

Análise Vocal: bibliotecas de DSP (librosa/Praat), modelos de ML treinados para classificação emocional vocal

Análise Facial: MediaPipe Face Mesh (468 pontos) + modelo customizado de classificação de AU

NLP: modelos de linguagem para identificação de temas e análise de sentimento

Machine Learning: modelos de série temporal para detecção de padrões e anomalias

11. Segurança, Privacidade e Ética
11.1 Proteção de Dados

Conformidade com LGPD (Brasil), HIPAA (EUA) e GDPR (Europa)

Anonimização de dados para uso em pesquisa (opt-in do paciente e profissional)

Auditoria completa: log imutável de todos os acessos e operações

Direito ao esquecimento: exclusão completa de dados sob solicitação

Data residency: dados armazenados no país de origem do profissional

11.2 Diretrizes Éticas

#### O FROID adota as seguintes diretrizes inegociáveis:

O sistema é uma ferramenta de apoio, nunca de diagnóstico autônomo

Nenhum dado é utilizado para treinamento de IA sem consentimento explícito e anônimo

O profissional mantém total autonomia sobre as interpretações clínicas

Alertas do sistema são sugestões, não determinações

Transparência algorítmica: documentação aberta sobre como os índices são calculados

Comitê de ética: revisão periódica por profissionais de saúde mental e especialistas em ética de IA

12. Roadmap de Desenvolvimento

Entregas Principais

Prazo Estimado

Análise vocal básica (3 zonas) + dashboard + relatório simples

Prova de conceito funcional para testes com profissionais

7 zonas vocais + análise facial básica + agenda + financeiro básico

Produto viável para comercialização

NLP integrado + microexpressões + longitudinal + compartilhamento

Produto completo com diferencial competitivo

IA preditiva + integrações ERP + API aberta + pesquisa

Plataforma enterprise e ecossistema

FROID — Frequency Recognition of Internal Dynamics

Documento de Premissas v1.0 — Abril 2026

