# A Bússola da Psique: Guia do Índice de Desvio Multimodal

O Índice de Desvio Multimodal (IDM) é uma métrica central na arquitetura diagnóstica do sistema FROID, projetada para medir a \*\*direção\*\* e o \*\*grau de desequilíbrio\*\* da energia de um paciente nas 12 zonas específicas de percepção psíquica \[1, 2\]. Enquanto o Índice de Potência Motivacional (IPM) atua como o "velocímetro" ou "tacômetro" que mede a intensidade global e a quantidade de energia (combustível) emocional disponível no momento, o IDM funciona como a "bússola" ou o "alinhamento das rodas" da psique, revelando com precisão se a energia do paciente está fluindo de forma saudável para padrões adaptativos (positivos) ou se está sendo arrastada para padrões desadaptativos (negativos e de conflito) \[1-4\].

\*\*Cálculo e a Matemática Multimodal\*\*
Diferente das tecnologias corporativas concorrentes (como o EVOX) que ocultam suas fórmulas analíticas, o algoritmo do IDM no FROID é fundamentado em um cruzamento biométrico transparente. O cálculo base inicia-se medindo o desvio quantitativo da energia acústica extraída da voz em relação à Linha de Base Dinâmica (a média de repouso extraída nos primeiros 60 segundos da sessão). 

No entanto, o grande salto de inteligência reside no "multiplicador multimodal": o IDM não avalia a voz de forma isolada. Se a câmera do sistema, que realiza a leitura pelo \*Facial Action Coding System\* (FACS), flagrar uma microexpressão que contradiga o que a voz está emitindo (por exemplo, um pico de energia vocal de raiva abafado no rosto por uma compressão labial forçada — AUs 23/24 —, ou uma tristeza mascarada por um sorriso social mecânico — AU 12 sem AU 6), o motor do FROID aplica matematicamente um \*\*multiplicador de gravidade\*\* sobre esse desvio. Quando o rosto tenta encobrir a verdade da voz, o escore de desvio do IDM explode, sinalizando instantaneamente para a faixa Amarela ou Vermelha. 

\*\*Representação Gráfica e Colorimetria no Dashboard\*\*
No painel de atendimento do profissional, o IDM é renderizado no Gráfico de Mapa Zonal. A linha central contínua (DR) representa a linha de base ou o ponto de equilíbrio perfeito (Zero) \[5, 6\]. A partir desse centro, as barras do IDM crescem mostrando exatamente \*onde\* e \*quanto\* o subconsciente do paciente está desviado do equilíbrio \[5, 6\]. A colorimetria do IDM traduz a severidade do cenário:
\*   \*\*Branco:\*\* Áreas com queda extrema de energia, indicando compensação ou ausência de estímulo.
\*   \*\*Azul:\*\* Faixa de baixo nível de desequilíbrio.
\*   \*\*Verde:\*\* Nível médio de desequilíbrio.
\*   \*\*Amarelo:\*\* Alto nível de desequilíbrio, evidenciando uma zona de preocupação ou resistência psicológica significativa.
\*   \*\*Vermelho:\*\* Desequilíbrio extremo. Onde os conflitos subconscientes estão em estágio mais crítico.

\*\*Matriz de Interpretação Clínica (O Cruzamento IDM x IPM)\*\*
Na prática terapêutica diária, o IDM atinge sua utilidade máxima ao ser cruzado com a potência do IPM, desenhando quatro cenários precisos de abordagem para o psicólogo ou psiquiatra \[3, 4\]:

1.  \*\*Fluxo Saudável:\*\* Quando o paciente exibe um IPM Alto/Médio (muita energia) associado a um IDM Positivo (cores Verde ou Azul). O paciente está profundamente engajado e resolvendo seus conflitos de forma produtiva \[3, 4\].
    \*   \*Ação Clínica:\* O terapeuta deve reforçar, validar e aprofundar as descobertas e \*insights\* \[3, 4\].
2.  \*\*Sofrimento Ativo:\*\* O paciente possui um IPM Alto/Médio, mas o IDM mergulha num estado Negativo Extremo (Vermelho). Este é o sinal de crise: choro intenso, raiva explosiva ou ansiedade aguda, apontando que toda a potência emocional está voltada e alimentando o conflito psíquico \[3, 4, 7, 8\].
    \*   \*Ação Clínica:\* A prioridade não é a interpretação analítica. O terapeuta deve conter a crise, acolher a emoção e promover a regulação autonômica do paciente antes de prosseguir \[7, 8\].
3.  \*\*Embotamento/Defesa:\*\* O IPM despenca (baixa energia) e o IDM permanece Neutro ou Levemente Negativo. Isso espelha a dissociação: o paciente entrou em \*shutdown\* psíquico ou resistência passiva \[7, 8\].
    \*   \*Ação Clínica:\* Não forçar a exposição de traumas ou conteúdos densos. Estimular e resgatar suavemente a conexão terapêutica e ancoragem \[7, 8\].
4.  \*\*Falsa Calma:\*\* O cenário de maior alerta diagnóstico. O IPM é Baixo (parecendo que há calma superficial e relaxamento), porém o IDM atinge marcadores Negativos Profundos e Latentes. O corpo físico não manifesta muita agitação externa, mas o algoritmo revela uma carga de conflito reprimida violentamente no subconsciente \[5-8\].
    \*   \*Ação Clínica:\* Trata-se de um forte risco de somatização clínica. É preciso investigar as defesas e resistências, pois a energia agressiva do paciente encontra-se perigosamente aprisionada contra si mesmo \[5, 6\].