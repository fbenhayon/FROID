---
sourceFile: "Facial Action Coding System (FACS) Cheat Sheet"
exportedBy: "Kortex"
exportDate: "2026-06-29T01:00:28.012Z"
---

# Facial Action Coding System (FACS) Cheat Sheet

2190f61f-a258-4a7e-9f24-5e649fc0119d

Facial Action Coding System (FACS) Cheat Sheet

2f2c1578-0de0-43a4-a731-75e441fb6dd7

https://melindaozel.com/facs-cheat-sheet/

Facial Action Coding System (FACS) Cheat Sheet

Skip to content

https://melindaozel.com/facs-cheat-sheet/#content

Member Links

Premium Member Access

https://melindaozel.com/premium-resources/

https://melindaozel.com/login/

Subscribe :)

https://melindaozel.com/subscription-options/

Recorded Lecture Access

https://melindaozel.com/recorded-lectures/

FACS Cram Session

https://melindaozel.com/facs-cram-session/

All About Lipsync

https://melindaozel.com/all-about-lipsync-lecture-videos/

https://melindaozel.com/login/

Login Issues?

https://melindaozel.com/login-issues/

Face the FACS | Facial Expressions in Animation, AI, & Behavior

https://melindaozel.com/

Learning Hub

https://melindaozel.com/learning-hub/

FACS Cheat Sheet

https://melindaozel.com/facs-cheat-sheet/

Viseme Cheat Sheet

https://melindaozel.com/viseme-cheat-sheet/

All Free Resources

https://melindaozel.com/free-resources/

🔒 Premium Resources

https://melindaozel.com/premium-resources/

https://melindaozel.com/faqs/

https://melindaozel.com/online-lectures/

FACS Cram Session

https://melindaozel.com/services/lectures-training/facs-cram-session/

All About Lipsync

https://melindaozel.com/all-about-lipsync-course/

Full Site Access

https://melindaozel.com/subscription-options/

Membership Options

https://melindaozel.com/subscription-options/

https://melindaozel.com/services/

FACS Lectures & Training

https://melindaozel.com/services/lectures-training/

https://melindaozel.com/services/consulting/

https://melindaozel.com/who-is-melinda-ozel/

https://melindaozel.com/who-is-melinda-ozel/

Cite My Work

https://melindaozel.com/how-to-cite-my-work-use-my-visuals/

https://melindaozel.com/who-is-melinda-ozel/contact-me/

https://melindaozel.com/who-is-melinda-ozel/contact-me/

Facial Action Coding System (FACS) – Cheat Sheet

Melinda Ozel

https://www.linkedin.com/in/melindaozel/

Published: Feb. 20, 2020

Updated: Mar. 15, 2026

The FACS Cheat Sheet is a visual guide for the Facial Action Coding System (FACS) and beyond. Here you will find action unit (AU) references and the facial muscles they map to. You will also find references and descriptions for anatomically-based facial movements that do not exist in FACS; these additional breakdowns serve to supplement areas where FACS is deficient. All actions are performed by the

, FACS-certified with 14 years of experience in facial muscle isolation.

More Reference Guides

#### Quick FACS reference sheet with photos only:

FACS Lite: Photos

https://melindaozel.com/facs-lite-still-fast/

https://melindaozel.com/facs-lite-still-fast/

#### Comprehensive FACS guide with stills + GIFs:

FACS Study Guide

https://melindaozel.com/facs-study-guide/

https://melindaozel.com/facs-study-guide/

#### Viseme and phoneme reference sheet:

Viseme Cheat Sheet

https://melindaozel.com/viseme-cheat-sheet/

https://melindaozel.com/viseme-cheat-sheet/

#### ARKit to FACS translation sheet:

ARKit to FACS Cheat Sheet

https://melindaozel.com/arkit-to-facs-cheat-sheet/

https://melindaozel.com/arkit-to-facs-cheat-sheet/

FACS Course On-Demand

https://melindaozel.com/services/lectures-training/facs-cram-session/

FACS Course On-Demand

https://melindaozel.com/services/lectures-training/facs-cram-session/

FACS Action Unit References

FOREHEAD AREA & EARS

AU1 - inner brow raiser

frontalis muscle

https://melindaozel.com/frontalis-variation/

(the medial portion)

#### AU1 ACTION:

Inner brow raiser

lifts the medial brow and forehead area.

NOTE 1: Inner brow raiser is variable in wrinkle formation and range. This variability is due to a number of factors, a prominent factor being

frontalis muscle variability

https://melindaozel.com/frontalis-variation/

NOTE 2: Further reading on inner brow raiser – 1)

Inner Brow Raiser Deep Dive

https://melindaozel.com/inner-brow-raiser-deep-dive/

The Secret Life of Inner Brow Raiser.

https://melindaozel.com/the-secret-life-of-inner-brow-raiser/

AU2 - outer brow raiser

frontalis muscle

https://melindaozel.com/frontalis-variation/

(the lateral portion)

#### AU2 ACTION:

Outer brow raiser

lifts the lateral brow and forehead areas.

NOTE: As mentioned with inner brow raiser, outer brow raiser is also variable in wrinkle formation and range. This variability is due to a number of factors, a prominent factor being

frontalis muscle variability

https://melindaozel.com/frontalis-variation/

AU4 - brow lowerer

corrugator supercilii, depressor supercilii, and/or procerus muscles

#### AU4 ACTION:

Brow lowerer

knits (corrugator supercilii) and lowers (procerus, depressor supercilii, and parts of corrugator supercilii) the brow area and lower central forehead. \*\*Read NOTE below for important considerations.

NOTE: Brow lowerer can be performed by any or all of the above listed muscles. Though FACS lumps together the actions of all three of these muscles,

when I teach facial anatomy and FACS

https://melindaozel.com/services/lectures-training/

, I separate out the movements.

See more in the FACS Study Guide

https://melindaozel.com/facs-study-guide/

#notFACS indicates actions I have identified and coined that do not exist in FACS. Due to FACS's original purpose as a facial behavior identification system, FACS lacks documentation for some finer, more nuanced facial movements. To fill this void, I have further defined my own nonFACS movements such as: vertical lip tightener, y-axis dimpler, open-eye blink, etc. If you work on lipsync technology or photoreal characters, these distinctions will be particularly useful.

ears up & back

auricular muscles (see notes below)

#### EARS UP & BACK ACTION:

Ears up & back

lifts the ears and pushes them back.

NOTE1: This is not a FACS action. I have included this ear movement in the

FACS Cheat Sheet,

because I observe it happening relatively frequently.

NOTE 2: There are multiple auricular muscles. The superior auricular moves the ears up. The posterior auricular moves the ears back. The anterior auricular the moves ears forward. At present, I cannot separate these movements. The reference here shows posterior auricular + superior auricular movement.

EYE & CHEEK AREA

AU5 - upper lid raiser

levator palpebrae superioris muscle

#### AU5 ACTION:

Upper lid raiser

pulls the top eyelid up and back to widen the eyes.

NOTE: For more on upper lid raiser: (1A) – If you are a subscriber, view

All About Upper Lid Raiser

https://melindaozel.com/all-about-upper-lid-raiser-au5/

– or – (1B) View

Stylized Facial Expression Design

https://melindaozel.com/stylized-facial-expression-design/

. (2) If you are not a subscriber, you can view the

preview post of All About Upper Lid Raiser here

https://melindaozel.com/all-about-upper-lid-raiser-preview/

AU6 - cheek raiser

orbicularis oculi muscle (the orbital portion)

#### AU6 ACTION:

Cheek raiser

tightens the outer rings of the eye orbit and squeezes the lateral eye corners.

NOTE: For help differentiating cheek raiser from lid tightener, see

Cheek Raiser vs. Lid Tightener

https://melindaozel.com/cheek-raiser-vs-lid-tightener/

AU7 - lid tightener

orbicularis oculi muscle (the pre-septal portion of the palpebral area)

#### AU7 ACTION:

Lid tightener

tightens the rings around the eyelids and pushes the lower eyelid skin toward the inner eye corners.

NOTE: For help differentiating cheek raiser from lid tightener, see

Cheek Raiser vs. Lid Tightener

https://melindaozel.com/cheek-raiser-vs-lid-tightener/

open-eyed blink

orbicularis oculi muscle (the pretarsal portion of the palpebral area)

#### OPEN-EYED BLINK ACTION:

Open-eyed blink

tightens the innermost rings around the eyelids in a circular motion toward the inner eye corners.

NOTE: The pretarsal area is the portion of our orbicularis oculi muscle that is involved with blinking.

See more breakdowns here

https://twitter.com/MelindaOzel/status/1572634393319030784?s=20&t=w4NEhsPE7sojcQyR10r\_xw

AU45 - blink

orbicularis oculi muscle (the pretarsal portion of the palpebral area)\*\*

#### AU45 ACTION:

closes and opens the eyes in a swift, fluid manner.

NOTE: Beyond pretarsal activation,

also often consists of: (1) relaxation of levator palpebrae superioris and/or (2) forced closure from the preseptal portion of orbicularis oculi.

AU46 - wink

orbicularis oculi muscle

#### AU46 ACTION:

closes one eye, usually with some compression.

NOTE: Unless you are a facial coder conducting behavioral research (and even then, the official FACS Manual lists AU46 – wink as “optional”), the FACS shape for wink is not the most useful. I have included it because other FACS lists include it; however, I find it to be a clunky, unnecessary addition to most shape sets. That being said, orbicularis oculi does deserve better functional breakdowns beyond cheek raiser, blink, and lid tightener – but wink is not the way to go. In the near future, I will post a functional breakdown of orbicularis oculi.

Sign up for monthly post updates to keep tabs on the latest content and breakdowns

https://melindaozel.com/post-updates/

MIDDLE FACE & NASOLABIAL AREA

AU9 - nose wrinkler

levator labii superioris alaeque nasi (+ usually depressor supercilii and/or procerus) muscle(s)

#### AU9 ACTION:

Nose wrinkler

lifts the sides of the nose, nostrils, and central upper lip area.

NOTE: The brow lowering you see in

nose wrinkler

is not directly caused by the levator labii superioris alaeque nasi (LLSAN) muscle. Rather, it is caused by the brow lowering muscles often paired with

nose wrinkler

: depressor supercilii and procerus. There is variable interconnectivity between these muscles and the LLSAN.

AU10 - upper lip raiser

levator labii superioris muscle

#### AU10 ACTION:

Upper lip raiser

lifts top lip in a manner more lateral than

nose wrinkler

but more medial than

nasolabial furrow deepener

NOTE: For help differentiating between upper lip raiser and nasolabial furrow deepener: (1) If you are a subscriber view:

Upper Lip Raiser vs. Nasolabial Furrow Deepener

https://melindaozel.com/facial-actions-in-context/

. (2) If you are not a subscriber, you can view the

preview post of Upper Lip Raiser vs. Nasolabial Furrow Deepener here

https://melindaozel.com/levator-labii-superioris-vs-zygomaticus-minor/

AU11 - nasolabial furrow deepener

zygomaticus minor muscle

#### AU11 ACTION:

Nasolabial furrow deepener

lifts and stretches the top lip (in a more lateral and oblique manner than

nose wrinkler

or \* upper lip raiser\*).

NOTE: For help differentiating between upper lip raiser and nasolabial furrow deepener: (1) If you are a subscriber view:

Upper Lip Raiser vs. Nasolabial Furrow Deepener

https://melindaozel.com/facs-cheat-sheet/

. (2) a subscriber, you can view the

preview post of Upper Lip Raiser vs. Nasolabial Furrow Deepener here

https://melindaozel.com/facs-cheat-sheet/

AU38 - nostril dilator

dilator naris (alar portion of nasalis) muscle

#### AU38 ACTION:

Nostril dilator

expands / widens the nostril wings allowing for deeper air intake.

AU39 - nostril compressor

compressor naris (tranverse portion of nasalis)+ depressor septi muscles

#### AU39 ACTION:

Nostril compressor

narrows the nostril wings while also often lowering the nose tip.

LIP CORNER MOVERS

AU12 - lip corner puller

zygomaticus major muscle

#### AU12 ACTION:

Lip corner puller

draws the lip corners up, back, and laterally.

AU13 - sharp lip puller

levator anguli oris muscle

#### AU13 ACTION:

Sharp lip puller

(formerly known as

cheek puffer

) draws the lip corners upward.

AU14 - dimpler

partially #notFACS

See “NOTE” below.

buccinator muscle

y-axis type

(superior + inferior portions of buccinator)

z-axis type

(posterior portion of buccinator)

y-axis type + z-axis type

(inferior + superior + posterior portions of buccinator)

#### AU14-y ACTION:

of the y-axis type pinches the lip corners against each other on a vertical plane.

#### AU14-z ACTION:

of the z-axis type draws the lip corners back against the teeth.

NOTE: y-axis and z-axis dimplers are not FACS-official terms. Classic FACS describes

as the y+z-axis combo type.

Learn why I've coined y and z distinctions here

https://melindaozel.com/facs-study-guide/

AU15 - lip corner depressor

depressor anguli oris muscle

#### AU15 ACTION:

Lip corner depressor

draws the lip corners downward.

AU18 - lip pucker

incisivus labii inferioris & incisivus labii superioris muscles

#### AU18 ACTION:

draws the lip corners medially causing the fleshy part of the lips to collect toward the midline of the face and protrude.

NOTE 1: Incisivus labii superioris and incisivus labii inferioris are considered accessory muscles to orbicularis oris.

typically co-activates

vertical lip tightener

(as seen in this example). Learn more about \* vertical lip tightener\* under the “ORBICULARIS ORIS ACTIONS” section below.

AU20 - lip stretcher

risorius muscle

#### AU20 ACTION:

Lip stretcher

draws the lip corners laterally, stretching the fleshy part of the lips.

NOTE1: Not to be confused with

mouth stretch

Mouth stretch

refers to forced (not due to relaxation) jaw lowering (see “JAW ACTIONS” section below).

NOTE2: Risorius is one of the most variable facial muscles in humans. Depending on the study, it has been reported missing in anywhere from 1-94% of research subjects. Risorius is narrow and difficult to locate; so it is possible that this discrepancy in statistics is partly inflated due to methodological study errors.

For more on anatomical variation, book a studio lecture on facial muscle diversity

https://melindaozel.com/services/lectures-training/

LOWER LIP & CHIN AREA

AU16 - lower lip depressor

depressor labii inferioris muscle

#### AU16 ACTION:

Lower lip depressor

draws the lower lip downward and laterally.

AU17 - chin raiser

mentalis muscle

#### AU17 ACTION:

Chin raiser

pushes the up lower lip and chin area.

NOTE: The lower lip may protrude to a degree in some instances of

chin raiser

; however, if you are seeing significant protrusion in a person attempting

chin raiser

, they are likely triggering non-target orbicularis oris actions as well.

ORBICULARIS ORIS ACTIONS

AU8 - lips toward each other

orbicularis oris muscle

#### AU8 ACTION:

Lips toward each other

brings the upper and lower lips toward each other by lowering the top lip and raising the bottom lip.

Lips toward each other

functions as a way to bring the lips back together from actions that may separate the lips. In the above reference, AU26 –

is the cause of separated lips, and AU8 is used to close the lips while allowing the jaw to remain open. In tools like ARKit and Android XR, AU8 is solely used to counteract the lip opening caused by AU26; however, on real faces, AU8 is not limited to counteracting jaw opening. In fact, AU8 can be used to counteract anything that causes the lips to separate. For instance, if a strong AU9 causes the lips to part, the action of AU8 can bring the lips together while retaining other aspects of AU9.

AU22 - lip funneler

orbicularis oris muscle (peripheral portion)

#### AU22 ACTION:

Lip funneler

projects the lips forward and fans them outward.

AU23 - lip tightener

partially #notFACS

See “NOTE” below.

orbicularis oris (marginal portion)

horizontal type

#### AU23 ACTION (horizontal type):

Lip tightener

thins the lips. Think of it as the top lip and the bottom lip each collapsing upon itself.

vertical type

(thinking of calling it

lip cincher

#### AU23 ACTION (vertical type):

Lip cincher

constricts the lips toward the midline of the face.

NOTE: This 2-type distinction is a deviation from official FACS. Only “horizontal type” qualifies as

lip tightener

in original FACS. I have chosen to divide lip tightener into two types, because the lips tighten in distinct manners. The muscle behind both movements, orbicularis oris, possesses rich variation in fiber directionality; such directional variation yields more potential actions for orbicularis oris than have thus far been documented. The distinction of horizontal vs. vertical lip tightening proves especially useful when breaking down speech.

For speech references, visit the Viseme Cheat Sheet

https://melindaozel.com/viseme-cheat-sheet/

AU24 - lip presser (or, "lip pressor")

orbicularis oris muscle (marginal portion)

#### AU24 ACTION:

Lip presser

involves the top and bottom lip pressing against each other.

NOTE: You may see

lip presser

spelled as “lip pressor” in many sources. This widespread variation in spelling can be attributed to Paul Ekman's inconsistent documentation. In the

FACS Investigator's

from 1978, there is one instance (on page 6, a page ripe with many differently-spelled FACS actions such as “lip tightner” for

lip tightener,

“lip puckerer” for

lip pucker,

“cheek puffer” for

sharp lip puller,

“lip suck” for \* lips suck\*, etc.), where

lip presser

is spelled “lip pressor.” In the official 2002

FACS Manual

lip presser

is solely referred to as “lip presser.” To further ail the prescriptivist mind, Ekman's post-2002 writings (e.g.

What the Face Reveals

, 2005) revert back to the 1978 “pressor” spelling. Circa 2020, I asked Ekman's protégé, Erika Rosenberg, whether “presser” or “pressor” was the canon spelling; her answer was that the spelling didn't matter so much as the attribution of the AU number. Unfortunately, it seems the jury is still out on the official spelling. I suppose we'll have to wait at the edge of our seats until the next release of the \* FACS Manual\* to solve this

FURTHER READING: Read about

lip presser

asymmetries in speech here:

M-B-P Bilabial Visemes

https://melindaozel.com/m-b-p-bilabial-visemes/

. (Useful for those working on lipsync and automated speech solutions.)

AU28 - lips suck

orbicularis oris muscle (marginal and peripheral portions)

#### AU28 ACTION:

draws the lips into the mouth opening and wraps them around the teeth.

NOTE 1: AU17 –

chin raiser

appears during the in-between steps. I cannot perform this action without assistance from AU17 during the transition to the final pose. Mentalis appearance during lips suck is likely the case for many others as well.

is almost always required for

JAW ACTIONS

AU26 - jaw drop

relaxation of masseter, temporalis, and medial pterygoid muscles

#### AU26 ACTION:

lowers the lower mandible (jaw) in a relaxed (unforced) manner.

AU27 - mouth stretch

lateral pterygoid and the suprahyoid (anterior digastric, geniohyoid, and mylohyoid) muscles

#### AU27 ACTION:

Mouth stretch

forcefully lowers the lower mandible (jaw). Unlike AU26, the action of AU27 is not due to relaxation.

NOTE: Because the word “mouth” is quite ambiguous and can colloquially refer to either the lips and/or jaw,

mouth stretch

can be easily confused with similarly-named actions like

lip stretcher

. Be aware of the nuances in naming when working with toolkits such as ARKit and ICT-FaceKit, both of which have renamed AU20 –

lip stretcher

mouth stretch

mouth stretch

in ARKit and ICT-FaceKit is not the same as the official and original

mouth stretch

from FACS. It is both unfortunate and confusing that

mouth stretch

(1) was named so poorly to begin with, and (2) that ARKit and ICT-FaceKit have exacerbated the confusion with name swapping.

Mouth stretch

would have been better suited with a more pointed name like “jaw stretch.” Ultimately, it is what it is; so be careful out there.

AD29 - jaw thrust

medial & lateral pterygoid muscles and some masseter

#### AD29 ACTION:

pushes the lower mandible (jaw) forward.

NOTE: “AD” refers to “action descriptor.” An action descriptor is basically a less fleshed out action unit (AU). ADs differ in that they function more as event descriptors.

AD 30 - jaw sideways

medial & lateral pterygoid muscles and temporalis

#### AD30 ACTION:

Jaw sideways

moves the lower mandible (jaw) to the side (either left or right).

AU31 - jaw clencher

temporalis, masseter, and medial pterygoid muscles

#### AU31 ACTION:

Jaw clencher

brings the lower mandible (jaw) upward causing it to press against the upper mandible.

MISCELLANEOUS ACTIONS

AU21 - neck tightener

platysma muscle

NOTE: You may see some AU20 –

lip stretcher

in the AU21 –

neck tightener

example and vice versa. This concurrence is due to a close relationship between the risorius and platysma muscles.

AU25 - lips part

it depends\*\*

NOTE: In FACS, AU25 –

refers to the state of the lips being parted. This parting can be caused by any action that separates the lips – e.g. relaxation of mentalis, relaxation of orbicularis oris, contraction of other muscles, etc.

ACTION DESCRIPTORS

“AD” refers to “action descriptor.” An action descriptor is basically a less fleshed out action unit (AU). ADs differ in that they function more as event descriptors.

AD19 - tongue show

it depends\*\*

AD32 - bite

it depends\*\*

AUD33 - blow

it depends\*\*

AD34 - puff

it depends\*\*

AD35 - suck

it depends\*\*

AD36 - bulge

it depends\*\*

AD36 - lip wipe

it depends\*\*

How to Cite This Page

To ensure this citation is tracked correctly, please refer to the

official record on Google Scholar

https://scholar.google.com/citations?view\_op=view\_citation&hl=en&user=P205y6YAAAAJ&citation\_for\_view=P205y6YAAAAJ:IjCSPb-OGe4C

Ozel, M. (2020, February).

FACS Cheat Sheet

. Face the FACS.

https://melindaozel.com/facs-cheat-sheet/

https://melindaozel.com/facs-cheat-sheet/

@misc{ozel2020facs,
  author = {Ozel, Melinda},
  title = {FACS Cheat Sheet},
  year = {2020},
  month = feb,
  howpublished = {\url{https://melindaozel.com/facs-cheat-sheet/}}
}

References & Further Reading

Carl-Herman Hjortsjö. (1970).

Man's face and mimic language.

Studentlitteratur.

de Sanctis Pecora, C. (2020).

One21: A Novel, Customizable Injection Protocol for Treatment of the Forehead with IncobotulinumtoxinA

https://pubmed.ncbi.nlm.nih.gov/32104039/

Clinical, Cosmetic and Investigational Dermatology

https://doi.org/10.2147/ccid.s237519

https://doi.org/10.2147/ccid.s237519

Ekman, P., Friesen, W. V., & Hager, J. C. (2002).

Facial action coding system

. Research Nexus.

Netter, F. H. (2019).

Atlas of Human Anatomy

(7th ed.). Elsevier.

Standring, S., & Tubbs, S. R. (2025).

Gray's Anatomy

https://www.us.elsevierhealth.com/grays-anatomy-9780443124785.html?srsltid=AfmBOopwtcHXfQnT6lSQlUND1y40SUV8AC9l4N6luGi6xpzp32D3wwAN

. Elsevier.

More free reference guides!

https://melindaozel.com/

I'm a Facial Systems Expert specializing in the Facial Action Coding System (FACS) and facial anatomy. My work spans

expression tracking

https://patents.justia.com/inventor/melinda-ozel

, facial animation, and

AI-driven lipsync

http://linkedin.com/in/melindaozel

. Recent work includes contributions to the de-aging of Tom Hanks and other actors in the

Zemeckis film, Here

Learn more about

my background

https://melindaozel.com/melinda-who-zel/

Courses & Workshops

FACS Cram Session

https://melindaozel.com/services/lectures-training/facs-cram-session/

All About Lipsync

https://melindaozel.com/all-about-lipsync-course/

All Training Services

https://melindaozel.com/services/lectures-training/

Melinda Ozel's resources on face anatomy, motion, and FACS are industry standard. During my time working on The Last of Us Part II (and other unannounced Playstation titles) I referred to it almost exclusively on a regular basis. The free material is great but the pay material is worth the cost.

Eric Drobile | Technical Animator

For most people learning traditional FACS is not feasible. It requires very costly specialized degrees and years long commitment. And the half century old research with fuzzy photos was not made for artists. What Melinda has done for our industry is take the dense scientific information and streamlined it into very easy to digest entries and videos catered to artists.

Paul Liaw | Principal Character Artist

I've been working as a Facial Blendshape Artist across film and gaming and have watched the quality of my work improve exponentially since I've had access to this wealth of knowledge that Melinda has so thoughtfully put together. Her documentation is clear, appealing, and comprehensive. If Paul Ekman is the father of FACS, Melinda has become the cool aunt.

Ioana Alexandra Pirvu | Lead Artist: Blendshapes @ Rockstar Games

Face the FACS in my opinion is bar-none, the best resource out there for any artist and company dealing with facial animation. The way in which Melinda delivers knowledge is detailed, but fun and compelling enough to make you want to keep learning. For a topic that could have easily been boring, she inspired me to keep learning.

Giovanni Nakpil | Senior Creative 3D Evangelist @ Adobe

If you're doing AU's (action units), this is the site you're going to need to bookmark. Melinda has gone above and beyond to create what I feel is the ultimate resource guide for AU's. Each AU explained, annotated and demonstrated with extreme clarity. You'll experience plenty of "aha!!" moments using Melinda's work as your guide!

Frank Gravatt

| Facial Modeler @ Cloud Chamber

Connect with me <3

https://instagram.com/manicexpression

https://linkedin.com/in/melindaozel

https://x.com/melindaozel

Terms & Conditions

https://melindaozel.com/terms-conditions/

Copyright © 2020-2026

Melinda Ozel

. All rights reserved.

Learn how to

cite my work here

https://melindaozel.com/how-to-cite-my-work-use-my-visuals/

https://melindaozel.com/es/facs-cheat-sheet/

https://melindaozel.com/fr/facs-cheat-sheet/

https://melindaozel.com/es\_ve/facs-cheat-sheet/

https://melindaozel.com/es\_cl/facs-cheat-sheet/

https://melindaozel.com/es\_gt/facs-cheat-sheet/

https://melindaozel.com/pt/facs-cheat-sheet/

https://melindaozel.com/zh/facs-cheat-sheet/

https://melindaozel.com/zh\_tw/facs-cheat-sheet/

https://melindaozel.com/zh\_hk/facs-cheat-sheet/

https://melindaozel.com/ja/facs-cheat-sheet/

https://melindaozel.com/hi/facs-cheat-sheet/

https://melindaozel.com/de/facs-cheat-sheet/

https://melindaozel.com/de\_de/facs-cheat-sheet/

https://melindaozel.com/ru/facs-cheat-sheet/

https://melindaozel.com/pl/facs-cheat-sheet/

https://melindaozel.com/cs/facs-cheat-sheet/

https://melindaozel.com/vi/facs-cheat-sheet/

https://melindaozel.com/it/facs-cheat-sheet/

https://melindaozel.com/sv/facs-cheat-sheet/

https://melindaozel.com/sr/facs-cheat-sheet/

https://melindaozel.com/ar/facs-cheat-sheet/

https://melindaozel.com/ms/facs-cheat-sheet/

https://melindaozel.com/fi/facs-cheat-sheet/

https://melindaozel.com/es\_mx/facs-cheat-sheet/

https://melindaozel.com/ko/facs-cheat-sheet/

https://melindaozel.com/tr/facs-cheat-sheet/

https://melindaozel.com/is/facs-cheat-sheet/

https://melindaozel.com/nl/facs-cheat-sheet/

https://melindaozel.com/nl\_nl/facs-cheat-sheet/

https://melindaozel.com/es\_ar/facs-cheat-sheet/

https://melindaozel.com/uk/facs-cheat-sheet/

