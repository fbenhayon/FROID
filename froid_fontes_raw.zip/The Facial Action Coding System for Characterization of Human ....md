---
sourceFile: "The Facial Action Coding System for Characterization of Human ..."
exportedBy: "Kortex"
exportDate: "2026-06-29T01:00:28.736Z"
---

# The Facial Action Coding System for Characterization of Human ...

3e38d937-a517-4547-9df8-f464a256e4e9

The Facial Action Coding System for Characterization of Human ...

b63629ee-6f44-45ea-a253-1a9a89ca4d5a

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full

Frontiers | The Facial Action Coding System for Characterization of Human Affective Response to Consumer Product-Based Stimuli: A Systematic Review

https://www.frontiersin.org/

Frontiers in Psychology

https://www.frontiersin.org/journals/psychology

Mission and values

https://www.frontiersin.org/about/mission

https://www.frontiersin.org/about/history

https://www.frontiersin.org/about/leadership

https://www.frontiersin.org/about/awards

Impact and progress

Frontiers' impact

https://www.frontiersin.org/about/impact

Our annual reports

https://www.frontiersin.org/about/annual-reports

Thought leadership

https://www.frontiersin.org/about/thought-leadership

Publishing model

How we publish

https://www.frontiersin.org/about/how-we-publish

Open access

https://www.frontiersin.org/about/open-access

Peer review

https://www.frontiersin.org/about/peer-review

Research integrity

https://www.frontiersin.org/about/research-integrity

Research Topics

https://www.frontiersin.org/about/research-topics

FAIR² Data Management

https://www.frontiersin.org/about/fair-data-management

https://www.frontiersin.org/about/fee-policy

https://publishingpartnerships.frontiersin.org/

National consortia

https://www.frontiersin.org/open-access-agreements/consortia

Institutional partnerships

https://www.frontiersin.org/about/open-access-agreements

Collaborators

https://www.frontiersin.org/about/collaborators

More from Frontiers

Frontiers Forum

https://forum.frontiersin.org/

Frontiers Planet Prize

https://www.frontiersin.org/about/frontiers-planet-prize

Press office

https://pressoffice.frontiersin.org/

Sustainability

https://www.frontiersin.org/about/sustainability

Career opportunities

https://careers.frontiersin.org/

https://www.frontiersin.org/about/contact

All journals

https://www.frontiersin.org/journals

All articles

https://www.frontiersin.org/articles

Submit your research

https://www.frontiersin.org/submission/submit?domainid=1&fieldid=69&specialtyid=0&entitytype=2&entityid=36

https://www.frontiersin.org/search?tab=top-results&origin=https%3A%2F%2Fwww.frontiersin.org%2Fjournals%2Fpsychology%2Farticles%2F10.3389%2Ffpsyg.2020.00920%2Ffull

https://www.frontiersin.org/people/login?returnUrl=https%3A%2F%2Fwww.frontiersin.org%2Fjournals%2Fpsychology%2Farticles%2F10.3389%2Ffpsyg.2020.00920%2Ffull

https://www.frontiersin.org/

Frontiers in Psychology

https://www.frontiersin.org/journals/psychology

Addictive Behaviors

https://www.frontiersin.org/journals/psychology/sections/addictive-behaviors

Auditory Cognitive Neuroscience

https://www.frontiersin.org/journals/psychology/sections/auditory-cognitive-neuroscience

https://www.frontiersin.org/journals/psychology/sections/cognition

Cognitive Science

https://www.frontiersin.org/journals/psychology/sections/cognitive-science

Comparative Psychology

https://www.frontiersin.org/journals/psychology/sections/comparative-psychology

Consciousness Research and Mindfulness

https://www.frontiersin.org/journals/psychology/sections/consciousness-research-and-mindfulness

Cultural Psychology

https://www.frontiersin.org/journals/psychology/sections/cultural-psychology

Decision Neuroscience

https://www.frontiersin.org/journals/psychology/sections/decision-neuroscience

Eating Behavior

https://www.frontiersin.org/journals/psychology/sections/eating-behavior

Educational Psychology

https://www.frontiersin.org/journals/psychology/sections/educational-psychology

Emotion Science

https://www.frontiersin.org/journals/psychology/sections/emotion-science

Environmental Psychology

https://www.frontiersin.org/journals/psychology/sections/environmental-psychology

Evolutionary Psychology

https://www.frontiersin.org/journals/psychology/sections/evolutionary-psychology

Forensic and Legal Psychology

https://www.frontiersin.org/journals/psychology/sections/forensic-and-legal-psychology

Health Psychology

https://www.frontiersin.org/journals/psychology/sections/health-psychology

Human Developmental Psychology

https://www.frontiersin.org/journals/psychology/sections/human-developmental-psychology

Media Psychology

https://www.frontiersin.org/journals/psychology/sections/media-psychology

Movement Science

https://www.frontiersin.org/journals/psychology/sections/movement-science

Neuropsychology

https://www.frontiersin.org/journals/psychology/sections/neuropsychology

Organizational Psychology

https://www.frontiersin.org/journals/psychology/sections/organizational-psychology

Pediatric Psychology

https://www.frontiersin.org/journals/psychology/sections/pediatric-psychology

Perception Science

https://www.frontiersin.org/journals/psychology/sections/perception-science

Performance Science

https://www.frontiersin.org/journals/psychology/sections/performance-science

Personality and Social Psychology

https://www.frontiersin.org/journals/psychology/sections/personality-and-social-psychology

Positive Psychology

https://www.frontiersin.org/journals/psychology/sections/positive-psychology

Psycho-Oncology

https://www.frontiersin.org/journals/psychology/sections/psycho-oncology

Psychology for Clinical Settings

https://www.frontiersin.org/journals/psychology/sections/psychology-for-clinical-settings

Psychology of Aging

https://www.frontiersin.org/journals/psychology/sections/psychology-of-aging

Psychology of Language

https://www.frontiersin.org/journals/psychology/sections/psychology-of-language

Psychopathology

https://www.frontiersin.org/journals/psychology/sections/psychopathology

Quantitative Psychology and Measurement

https://www.frontiersin.org/journals/psychology/sections/quantitative-psychology-and-measurement

Sport Psychology

https://www.frontiersin.org/journals/psychology/sections/sport-psychology

Theoretical and Philosophical Psychology

https://www.frontiersin.org/journals/psychology/sections/theoretical-and-philosophical-psychology

https://www.frontiersin.org/journals/psychology/articles

Research Topics

https://www.frontiersin.org/journals/psychology/research-topics

Editorial board

https://www.frontiersin.org/journals/psychology/editors

About journal

About journal

Field chief editors

https://www.frontiersin.org/journals/psychology/about#about-editors

Mission & scope

https://www.frontiersin.org/journals/psychology/about#about-scope

https://www.frontiersin.org/journals/psychology/about#about-facts

Journal sections

https://www.frontiersin.org/journals/psychology/about#about-submission

Open access statement

https://www.frontiersin.org/journals/psychology/about#about-open

Copyright statement

https://www.frontiersin.org/journals/psychology/about#copyright-statement

https://www.frontiersin.org/journals/psychology/about#about-quality

For authors

Why submit?

https://www.frontiersin.org/journals/psychology/for-authors/why-submit

Article types

https://www.frontiersin.org/journals/psychology/for-authors/article-types

Author guidelines

https://www.frontiersin.org/journals/psychology/for-authors/author-guidelines

Editor guidelines

https://www.frontiersin.org/journals/psychology/for-authors/editor-guidelines

Publishing fees

https://www.frontiersin.org/journals/psychology/for-authors/publishing-fees

Submission checklist

https://www.frontiersin.org/journals/psychology/for-authors/submission-checklist

Contact editorial office

https://www.frontiersin.org/journals/psychology/for-authors/contact-editorial-office

Mission and values

https://www.frontiersin.org/about/mission

https://www.frontiersin.org/about/history

https://www.frontiersin.org/about/leadership

https://www.frontiersin.org/about/awards

Impact and progress

Frontiers' impact

https://www.frontiersin.org/about/impact

Our annual reports

https://www.frontiersin.org/about/annual-reports

Thought leadership

https://www.frontiersin.org/about/thought-leadership

Publishing model

How we publish

https://www.frontiersin.org/about/how-we-publish

Open access

https://www.frontiersin.org/about/open-access

Peer review

https://www.frontiersin.org/about/peer-review

Research integrity

https://www.frontiersin.org/about/research-integrity

Research Topics

https://www.frontiersin.org/about/research-topics

FAIR² Data Management

https://www.frontiersin.org/about/fair-data-management

https://www.frontiersin.org/about/fee-policy

https://publishingpartnerships.frontiersin.org/

National consortia

https://www.frontiersin.org/open-access-agreements/consortia

Institutional partnerships

https://www.frontiersin.org/about/open-access-agreements

Collaborators

https://www.frontiersin.org/about/collaborators

More from Frontiers

Frontiers Forum

https://forum.frontiersin.org/

Frontiers Planet Prize

https://www.frontiersin.org/about/frontiers-planet-prize

Press office

https://pressoffice.frontiersin.org/

Sustainability

https://www.frontiersin.org/about/sustainability

Career opportunities

https://careers.frontiersin.org/

https://www.frontiersin.org/about/contact

All journals

https://www.frontiersin.org/journals

All articles

https://www.frontiersin.org/articles

Submit your research

https://www.frontiersin.org/submission/submit?domainid=1&fieldid=69&specialtyid=0&entitytype=2&entityid=36

Frontiers in Psychology

https://www.frontiersin.org/journals/psychology

Addictive Behaviors

https://www.frontiersin.org/journals/psychology/sections/addictive-behaviors

Auditory Cognitive Neuroscience

https://www.frontiersin.org/journals/psychology/sections/auditory-cognitive-neuroscience

https://www.frontiersin.org/journals/psychology/sections/cognition

Cognitive Science

https://www.frontiersin.org/journals/psychology/sections/cognitive-science

Comparative Psychology

https://www.frontiersin.org/journals/psychology/sections/comparative-psychology

Consciousness Research and Mindfulness

https://www.frontiersin.org/journals/psychology/sections/consciousness-research-and-mindfulness

Cultural Psychology

https://www.frontiersin.org/journals/psychology/sections/cultural-psychology

Decision Neuroscience

https://www.frontiersin.org/journals/psychology/sections/decision-neuroscience

Eating Behavior

https://www.frontiersin.org/journals/psychology/sections/eating-behavior

Educational Psychology

https://www.frontiersin.org/journals/psychology/sections/educational-psychology

Emotion Science

https://www.frontiersin.org/journals/psychology/sections/emotion-science

Environmental Psychology

https://www.frontiersin.org/journals/psychology/sections/environmental-psychology

Evolutionary Psychology

https://www.frontiersin.org/journals/psychology/sections/evolutionary-psychology

Forensic and Legal Psychology

https://www.frontiersin.org/journals/psychology/sections/forensic-and-legal-psychology

Health Psychology

https://www.frontiersin.org/journals/psychology/sections/health-psychology

Human Developmental Psychology

https://www.frontiersin.org/journals/psychology/sections/human-developmental-psychology

Media Psychology

https://www.frontiersin.org/journals/psychology/sections/media-psychology

Movement Science

https://www.frontiersin.org/journals/psychology/sections/movement-science

Neuropsychology

https://www.frontiersin.org/journals/psychology/sections/neuropsychology

Organizational Psychology

https://www.frontiersin.org/journals/psychology/sections/organizational-psychology

Pediatric Psychology

https://www.frontiersin.org/journals/psychology/sections/pediatric-psychology

Perception Science

https://www.frontiersin.org/journals/psychology/sections/perception-science

Performance Science

https://www.frontiersin.org/journals/psychology/sections/performance-science

Personality and Social Psychology

https://www.frontiersin.org/journals/psychology/sections/personality-and-social-psychology

Positive Psychology

https://www.frontiersin.org/journals/psychology/sections/positive-psychology

Psycho-Oncology

https://www.frontiersin.org/journals/psychology/sections/psycho-oncology

Psychology for Clinical Settings

https://www.frontiersin.org/journals/psychology/sections/psychology-for-clinical-settings

Psychology of Aging

https://www.frontiersin.org/journals/psychology/sections/psychology-of-aging

Psychology of Language

https://www.frontiersin.org/journals/psychology/sections/psychology-of-language

Psychopathology

https://www.frontiersin.org/journals/psychology/sections/psychopathology

Quantitative Psychology and Measurement

https://www.frontiersin.org/journals/psychology/sections/quantitative-psychology-and-measurement

Sport Psychology

https://www.frontiersin.org/journals/psychology/sections/sport-psychology

Theoretical and Philosophical Psychology

https://www.frontiersin.org/journals/psychology/sections/theoretical-and-philosophical-psychology

https://www.frontiersin.org/journals/psychology/articles

Research Topics

https://www.frontiersin.org/journals/psychology/research-topics

Editorial board

https://www.frontiersin.org/journals/psychology/editors

About journal

About journal

Field chief editors

https://www.frontiersin.org/journals/psychology/about#about-editors

Mission & scope

https://www.frontiersin.org/journals/psychology/about#about-scope

https://www.frontiersin.org/journals/psychology/about#about-facts

Journal sections

https://www.frontiersin.org/journals/psychology/about#about-submission

Open access statement

https://www.frontiersin.org/journals/psychology/about#about-open

Copyright statement

https://www.frontiersin.org/journals/psychology/about#copyright-statement

https://www.frontiersin.org/journals/psychology/about#about-quality

For authors

Why submit?

https://www.frontiersin.org/journals/psychology/for-authors/why-submit

Article types

https://www.frontiersin.org/journals/psychology/for-authors/article-types

Author guidelines

https://www.frontiersin.org/journals/psychology/for-authors/author-guidelines

Editor guidelines

https://www.frontiersin.org/journals/psychology/for-authors/editor-guidelines

Publishing fees

https://www.frontiersin.org/journals/psychology/for-authors/publishing-fees

Submission checklist

https://www.frontiersin.org/journals/psychology/for-authors/submission-checklist

Contact editorial office

https://www.frontiersin.org/journals/psychology/for-authors/contact-editorial-office

https://www.frontiersin.org/

Frontiers in Psychology

https://www.frontiersin.org/journals/psychology

Addictive Behaviors

https://www.frontiersin.org/journals/psychology/sections/addictive-behaviors

Auditory Cognitive Neuroscience

https://www.frontiersin.org/journals/psychology/sections/auditory-cognitive-neuroscience

https://www.frontiersin.org/journals/psychology/sections/cognition

Cognitive Science

https://www.frontiersin.org/journals/psychology/sections/cognitive-science

Comparative Psychology

https://www.frontiersin.org/journals/psychology/sections/comparative-psychology

Consciousness Research and Mindfulness

https://www.frontiersin.org/journals/psychology/sections/consciousness-research-and-mindfulness

Cultural Psychology

https://www.frontiersin.org/journals/psychology/sections/cultural-psychology

Decision Neuroscience

https://www.frontiersin.org/journals/psychology/sections/decision-neuroscience

Eating Behavior

https://www.frontiersin.org/journals/psychology/sections/eating-behavior

Educational Psychology

https://www.frontiersin.org/journals/psychology/sections/educational-psychology

Emotion Science

https://www.frontiersin.org/journals/psychology/sections/emotion-science

Environmental Psychology

https://www.frontiersin.org/journals/psychology/sections/environmental-psychology

Evolutionary Psychology

https://www.frontiersin.org/journals/psychology/sections/evolutionary-psychology

Forensic and Legal Psychology

https://www.frontiersin.org/journals/psychology/sections/forensic-and-legal-psychology

Health Psychology

https://www.frontiersin.org/journals/psychology/sections/health-psychology

Human Developmental Psychology

https://www.frontiersin.org/journals/psychology/sections/human-developmental-psychology

Media Psychology

https://www.frontiersin.org/journals/psychology/sections/media-psychology

Movement Science

https://www.frontiersin.org/journals/psychology/sections/movement-science

Neuropsychology

https://www.frontiersin.org/journals/psychology/sections/neuropsychology

Organizational Psychology

https://www.frontiersin.org/journals/psychology/sections/organizational-psychology

Pediatric Psychology

https://www.frontiersin.org/journals/psychology/sections/pediatric-psychology

Perception Science

https://www.frontiersin.org/journals/psychology/sections/perception-science

Performance Science

https://www.frontiersin.org/journals/psychology/sections/performance-science

Personality and Social Psychology

https://www.frontiersin.org/journals/psychology/sections/personality-and-social-psychology

Positive Psychology

https://www.frontiersin.org/journals/psychology/sections/positive-psychology

Psycho-Oncology

https://www.frontiersin.org/journals/psychology/sections/psycho-oncology

Psychology for Clinical Settings

https://www.frontiersin.org/journals/psychology/sections/psychology-for-clinical-settings

Psychology of Aging

https://www.frontiersin.org/journals/psychology/sections/psychology-of-aging

Psychology of Language

https://www.frontiersin.org/journals/psychology/sections/psychology-of-language

Psychopathology

https://www.frontiersin.org/journals/psychology/sections/psychopathology

Quantitative Psychology and Measurement

https://www.frontiersin.org/journals/psychology/sections/quantitative-psychology-and-measurement

Sport Psychology

https://www.frontiersin.org/journals/psychology/sections/sport-psychology

Theoretical and Philosophical Psychology

https://www.frontiersin.org/journals/psychology/sections/theoretical-and-philosophical-psychology

https://www.frontiersin.org/journals/psychology/articles

Research Topics

https://www.frontiersin.org/journals/psychology/research-topics

Editorial board

https://www.frontiersin.org/journals/psychology/editors

About journal

About journal

Field chief editors

https://www.frontiersin.org/journals/psychology/about#about-editors

Mission & scope

https://www.frontiersin.org/journals/psychology/about#about-scope

https://www.frontiersin.org/journals/psychology/about#about-facts

Journal sections

https://www.frontiersin.org/journals/psychology/about#about-submission

Open access statement

https://www.frontiersin.org/journals/psychology/about#about-open

Copyright statement

https://www.frontiersin.org/journals/psychology/about#copyright-statement

https://www.frontiersin.org/journals/psychology/about#about-quality

For authors

Why submit?

https://www.frontiersin.org/journals/psychology/for-authors/why-submit

Article types

https://www.frontiersin.org/journals/psychology/for-authors/article-types

Author guidelines

https://www.frontiersin.org/journals/psychology/for-authors/author-guidelines

Editor guidelines

https://www.frontiersin.org/journals/psychology/for-authors/editor-guidelines

Publishing fees

https://www.frontiersin.org/journals/psychology/for-authors/publishing-fees

Submission checklist

https://www.frontiersin.org/journals/psychology/for-authors/submission-checklist

Contact editorial office

https://www.frontiersin.org/journals/psychology/for-authors/contact-editorial-office

Submit your research

https://www.frontiersin.org/submission/submit?domainid=1&fieldid=69&specialtyid=0&entitytype=2&entityid=36

https://www.frontiersin.org/search?tab=top-results&origin=https%3A%2F%2Fwww.frontiersin.org%2Fjournals%2Fpsychology%2Farticles%2F10.3389%2Ffpsyg.2020.00920%2Ffull

https://www.frontiersin.org/people/login?returnUrl=https%3A%2F%2Fwww.frontiersin.org%2Fjournals%2Fpsychology%2Farticles%2F10.3389%2Ffpsyg.2020.00920%2Ffull

SYSTEMATIC REVIEW article

Front. Psychol., 25 May 2020

Sec. Emotion Science

Volume 11 - 2020 |

https://doi.org/10.3389/fpsyg.2020.00920

https://doi.org/10.3389/fpsyg.2020.00920

SYSTEMATIC REVIEW article

Front. Psychol., 25 May 2020

Sec. Emotion Science

Volume 11 - 2020 |

https://doi.org/10.3389/fpsyg.2020.00920

https://doi.org/10.3389/fpsyg.2020.00920

The Facial Action Coding System for Characterization of Human Affective Response to Consumer Product-Based Stimuli: A Systematic Review

E A Elizabeth A. Clark \*

https://loop.frontiersin.org/people/835519

J K J'Nai Kessinger

S E Susan E. Duncan

https://loop.frontiersin.org/people/594948

M A Martha Ann Bell

https://loop.frontiersin.org/people/120807

J L Jacob Lahne

https://loop.frontiersin.org/people/872539

D L Daniel L. Gallagher

https://loop.frontiersin.org/people/944865

S F Sean F. O'Keefe

https://loop.frontiersin.org/people/944589

Virginia Polytechnic Institute and State University, Blacksburg, VA, United States

Article metrics

View details

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#metrics

To characterize human emotions, researchers have increasingly utilized Automatic Facial Expression Analysis (AFEA), which automates the Facial Action Coding System (FACS) and translates the facial muscular positioning into the basic universal emotions. There is broad interest in the application of FACS for assessing consumer expressions as an indication of emotions to consumer product-stimuli. However, the translation of FACS to characterization of emotions is elusive in the literature. The aim of this systematic review is to give an overview of how FACS has been used to investigate human emotional behavior to consumer product-based stimuli. The search was limited to studies published in English after 1978, conducted on humans, using FACS or its action units to investigate affect, where emotional response is elicited by consumer product-based stimuli evoking at least one of the five senses. The search resulted in an initial total of 1,935 records, of which 55 studies were extracted and categorized based on the outcomes of interest including (i) method of FACS implementation; (ii) purpose of study; (iii) consumer product-based stimuli used; and (iv) measures of affect validation. Most studies implemented FACS manually (73%) to develop products and/or software (20%) and used consumer product-based stimuli that had known and/or defined capacity to evoke a particular affective response, such as films and/or movie clips (20%); minimal attention was paid to consumer products with low levels of emotional competence or with unknown affective impact. The vast majority of studies (53%) did not validate FACS-determined affect and, of the validation measures that were used, most tended to be discontinuous in nature and only captured affect as it holistically related to an experience. This review illuminated some inconsistencies in how FACS is carried out as well as how emotional response is inferred from facial muscle activation. This may prompt researchers to consider measuring the total consumer experience by employing a variety of methodologies in addition to FACS and its emotion-based interpretation guide. Such strategies may better conceptualize consumers' experience with products of low, unknown, and/or undefined capacity to evoke an affective response such as product prototypes, line extensions, etc.

Introduction

A variety of methods exist to capture the human affectual experience in response to stimuli; however, the nature of emotions makes them difficult to measure and interpret. In recent years, there has been an expanding body of research investigating how specific affectual responses (i.e., emotional response) can systematically influence an individual's perceptions, judgments, and behaviors to products and environment (Lerner and Keltner,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B96

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B97

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B102

; Tiedens and Linton,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B142

; Garg et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B56

; Maheswaran and Chen,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B105

; Agrawal et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B2

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B1

; Han et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B68

; de Hooge et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B35

; Keltner and Lerner,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B85

). Emotions are short-term, complex, multidimensional behavioral responses (Smith and Ellsworth,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B138

; Lambie and Marcel,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B92

) that are aimed to promote adaptive strategies in a variety of contexts. Specific emotions are functions of a multitude of information-rich associations underlying the emotional experience (So et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B139

). Emotional appraisals (i.e., how these specific emotions are elicited and function to influence an individual's conscious and unconscious evaluations of events and situations) have been widely recognized to impact decision-making and other cognitive processes (Scherer,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B135

; Tiedens and Linton,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B142

; Herrald and Tomaka,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B74

; Maheswaran and Chen,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B105

; Raghunathan et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B121

; de Mello et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B36

; Kim et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B86

; Hill et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B76

; Wilcox et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B155

; Winterich and Haws,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B156

; Mirabella,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B109

Though there is no consensus on a definition for emotions, the range of effects that emotions have on facial expression is recognized as broad and diverse (Jack et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B80

). Emotions have been traditionally characterized dichotomously as either positive (e.g., joyful, content, passionate) or negative (e.g., disgust, worried, anxious) affective states (Plutchik,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B118

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B128

). Positive affect refers to the extent an individual feels enthusiastic, active, and pleasurably aroused whereas negative affect refers to the extent an individual feels upset, distressed, and unpleasantly aroused (Watson and Tellegen,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B153

). However, Lazarus (Novacek and Lazarus,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B116

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B93

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B94

) proposed a theory in which motivational processes played a central role in emotional expression. In this theory, emotions such as pride, love, or happiness would arise when a situation is regarded as beneficial and anger, anxiety, and sadness would arise when a situation is regarded as harmful. Davidson (

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B34

) proposed a similar model linked to frontal electroencephalogram (EEG) asymmetry in the brain during emotional states. He proposed that frontal asymmetry was not related to the valence of emotional stimulus but rather to the motivational system that is engaged by the stimulus. He concluded that emotion will be associated with a right or left asymmetry depending on the extent to which it is accompanied by approach or withdrawal behaviors (Davidson,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B34

). Recent work has supported distinguishing facially expressed emotions as approach or withdrawal based on the relationship between emotions and cognitive processes (Coan et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B21

; Alves et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B3

; van Peer et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B150

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B143

) defined the subjective experience of emotion as the feedback from facial muscular changes, and research by others has investigated how an individual's subjective experience of emotions influences performance of different muscular movements (Laird,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B91

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B79

; Tourangeau and Ellsworth,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B144

). From this research, Ekman et al. (

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B48

) hypothesized that the face may also influence other people's emotional experiences by providing signals about how an individual feels. In an effort to provide a sounder basis about what different facial actions might signify, Ekman and Friesen (

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B46

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B47

) developed a novel technique for measuring facial behavior, the Facial Action Coding System (FACS). FACS was primarily developed as a comprehensive system to distinguish all possible visible anatomically based facial movements (Ekman and Friesen,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B46

). FACS provides a common nomenclature for facial movement research, which allows for diverse application in a variety of fields. Following the work of Hjortsjö (

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B77

); Ekman and Friesen (

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B46

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B47

) identified and published a system of action units (AU) or fundamental actions of individual or group muscles. AUs are identified by a number, shorthand name, and include the anatomical basis for each action (

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#T1

) and are rated on a 5-point intensity scale (A = trace, B = slight, C = marked or pronounced, D = severe or extreme, E = maximum). Ekman et al. (

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B49

) later published a significant update to FACS. Although FACS itself includes no emotion-specified descriptors, it is commonly used to interpret non-verbal communicative signals, such as facial expressions related to emotion or other human states (Valstar and Pantic,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B147

); related resources such as EMFACS (emotional FACS), the FACS Investigators' Guide (Ekman et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B49

), as well as the FACS interpretive database (Ekman et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B51

) are used to make emotion-based inferences from single and/or combinations of AUs. A constraint of FACS is that it deals with

visible changes in facial movement and doesn't account for subtle visible changes such as changes in muscle tonus (Ekman and Friesen,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B46

). Another limitation of FACS is that it was developed to measure movement in the face, thus other facial phenomena (e.g., changes in skin coloration, sweating, tears, etc.) are excluded.

Name of action

Muscle(s) activated

Inner brow raiser

Frontalis (pars medialis)

Outer brow raiser

Frontalis (pars lateralis)

Brow lowerer

Depressor glabellae, depressor supercilii, corrugator supercilli

Upper lid raiser

Levator palpebrae superioris, superior tarsal muscle

Cheek raiser

Orbicularis oculi (pars orbitalis)

Lid tightener

Orbicularis oculi (pars palpebralis)

Lips toward each other

Orbicularis oris

Nose wrinkler

Levator labii superioris alaeque nasi

Upper lid raiser

Levator labii superioris, caput infraorbitalis

Nasolabial deepener

Zygomaticus minor

Lip corner puller

Zygomaticus major

Sharp lip puller

Levator anguli oris (i.e., caninus)

Buccinnator

Lip corner depressor

Depressor anguli oris (i.e., triangularis)

Lower lip depressor

Depressor labii inferioris

Chin raiser

Incisivii labii superioris and incisivii labii inferioris

Tongue Show

Lip stretcher

Risorius with platysma

Neck tightener

Lip funneler

Orbicularis oris

Lip tightener

Orbicularis oris

Lip pressor

Orbicularis oris

Depressor labii inferioris or relaxation of mentalis, or orbicularis oris

Masetter; relaxed temporalis and internal pterygoid

Mouth stretch

Pterygoids, digastric

Orbicularis oris

Relaxation of levator palpebrae superioris

Orbicularis oculi (pars palpebralis)

Eyes closed

Relaxation of levator palpebrae superioris, orbicularis oculi (pars palpebralis)

Orbicularis oculi (pars palpebralis)

Relaxation of levator palpebrae superioris, orbicularis oculi (pars palpebralis)

Relaxation of levator palpebrae superioris, orbicularis oculi (pars palpebralis)

Single action units in the facial action code Ekman et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B49

The coded numbers are arbitrary and do not correspond to any significant value

Although FACS was designed for manual application by trained and certified FACS coders, the subjectivity and time intensiveness of human-performed coding had led to the adoption of FACS into computer automated systems (Hamm et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B67

). Automated facial expression analysis (AFEA) was developed to reduce the challenges of manual FACS application. AFEA provides more rapid evaluation of facial expressions and subsequent classification of those expressions into discrete categories of basic emotions (happy, sad, disgusted, surprised, angry, scared, and neutral) on a scale from 0 (not expressed) to 1 (fully expressed) (Lewinski et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B99

). Additionally, software may assess AU activation, intensity, and duration. Several commercially available software systems can generate AFEA. As an example, the integration of FACS and emotional characterization approach for one software system (Noldus FaceReader™;

http://www.noldus.com

http://www.noldus.com/

; Noldus Information Technology,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B115

) is described. The face reading software functions by finding a person's face and subsequently creating a 3D Active Appearance Model (AAM) (Cootes and Taylor,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B28

) of the face. The AAM serves as a base for which all the universal emotional expressions, plus the neutral expression, can be identified via independent neural network classifiers trained with backpropagation—a method proven effective for pattern recognition tasks (Bishop,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B10

). The final expression judgement of a face image is then based on the network with the highest output. The automatic emotions expression classifiers used in Noldus FaceReader™ were trained on the “Karolinska Directed Emotional Faces” set containing 980 high quality facial images showing one of the universal emotional expressions or a neutral expression; 89% of all faces presented to the classifier is classified correctly which, at the time of its development, was promising as it was among the highest reported results on emotional expression classification from static images (van Kuilenburg et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B148

). Similarly, independent classifiers, which perform FACS scoring of a face, were trained on 858 appearance vectors of images from the Cohn-Kanade AU-Coded Facial Expression Database; AUs were detected with an average accuracy of 86%, which means that most classified faces will have one or more AUs scored incorrectly. More recently, Noldus FaceReader™ (version 6.0) has proven to be a reliable indicator of facial expressions of basic emotions, although it could stand to become more robust with respect to FACS coding (Lewinski et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B99

AFEA technology has been used in a variety of consumer-affective research and marketing studies (de Wijk et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B38

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B37

; He et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B69

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B72

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B70

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B71

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B73

; Garcia-Burgos and Zamora,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B55

; Lewinski et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B100

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B101

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B98

; Chavaglia and Filipe,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B20

; Crist et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B30

; Mozuriene et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B112

; Walsh et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B151

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B152

); however, these studies fail to characterize the role of FACS, specifically AUs, as it pertains to consumer emotional behavior and stimuli evaluation. Additional approaches exist, such as those from the field of neuromarketing, to understand how internal and external forces (e.g., an individual's internal emotional experience vs. emotional expression by entities outside of the individual) might shift consumers from one pattern of decisions to another (Breiter et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B15

). For example, functional magnetic resonance imaging (fMRI) is employed to map differences in brain region activity and, subsequently, to infer systematic variations in the engagement of emotions (Poldrack,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B119

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B120

). Likewise, facial electromyography (EMG) serves to measure and map the underlying electrical activity that is generated when muscles contract during discrete choice-making (Rasch et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B122

) while eye-tracking technology has been harnessed to study gaze behavior with respect to packaging, label and menu design, in-store consumer behavior, emotional responses, and eating disorders (Duerrschmid and Danner,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B43

). In fact, neuromarketing techniques are often used in conjunction with FACS to provide a more holistic picture of the consumer affective experience (Cohn et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B24

; Balzarotti et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B6

; Lagast et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B90

Given the aforementioned application of FACS to measure emotion in various scientific fields, the aim of this review is to understand how the facial action coding system (manual or automated) has been used to investigate human emotional behavior to consumer product-based stimuli. This review will outline the methods and purposes for using FACS to characterize human affective (i.e., emotional) responses elicited by consumer product-based stimuli and, additionally, will provide evidence for how FACS-measured affective responses are validated.

Study Design and Systematic Review Protocol

The search for articles was carried out between June 2018 and June 2019. The syntax was developed in line with common search strategies in consumer and sensory research (Booth,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B11

) and in line with studies on emotion in the field of psychology (Mauss and Robinson,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B107

). The search included an

limit for only human studies and restricted the publication year to studies published after 1978 since the defining work on the Facial Action Coding System was published in 1978 (Ekman and Friesen,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B47

). The search syntax was developed from key terms within the PICOS framework (

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#SM1

), which were combined using the Boolean operator “OR” and between elements using the Boolean operator “AND.” This resulted in the combination of the following keywords: (“facial action” OR “automatic facial expression analysis”) AND (consum

OR human OR participant OR customer OR client OR purchaser OR user OR buyer OR shopper OR patron OR vendee). Peer reviewed articles that investigated (i) method of FACS implementation, (ii) purpose of study, (iii) consumer product-based stimuli used, and (iv) measures of affect validation were obtained from the databases ABI/Inform, ISI Web of Science, PsychINFO, PubMed as well as Google Scholar. To be included in the systematic review, studies had to be published in English, used the FACS system or its AUs to evaluate facial response to purchasable consumer-based goods or products (stimuli) that evoke at least one of the five senses (sight, touch, smell, taste, hearing), and reported outcomes on emotion, mood, or arousal and outcomes on measures used to validate emotions, mood, or arousal. Studies were excluded if they were not full-text articles, written in a language other than English, conducted solely on animals, measured and/or characterized affective response to media-based messaging, webpages, or forums used to market and/or sell consumer products, did not use the facial action coding system and/or the facial action units of the facial action coding system to measure and/or characterize emotion, and if they included participants with eating disorders (i.e., anorexia nervosa, bulimia nervosa), neurologic, psychiatric, or physiological disorders. Inclusion and exclusion criteria are shown in

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#SM1

. This review focused on research studies that used FACS to measure human affective responses to consumer product-based stimuli with no limitation in setting. As this review aims to compare different methods of FACS implementation, no exclusions were made based on comparison.

Data Sources, Studies Sections, and Data Extraction

This search syntax was used in all databases (ABI/Inform, ISI Web of Science, PsychINFO, PubMed) as well as Google Scholar and database index terms or headings were checked for unique terms to add to the search. Additionally, known systematic reviews on the facial action coding system or facial expression of emotion were considered and both their cited and citing sources were reviewed for potential inclusion in this study. Included studies' reference lists and studies citing the included studies were also reviewed for inclusion.

All papers retrieved were subsequently imported into both a citation manager library (Zotero, version 5.0.55, Center for History and New Media at George Mason University, Fairfax, VA, USA) and a systematic review management database/software (Covidence, version 1052 cd18d6a1, Melbourne, Victoria, Australia) and duplicates were removed. Two researchers conducted the search independently, in accordance with the Preferred Reporting Items for Systematic Reviews and Meta-Analyses (PRISMA) Statement (Moher et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B111

), using the same databases and all findings were merged. If the researchers encountered conflicts in their independent assessments, they were discussed until a consensus was reached. The first step of the search was based on a title and abstract screening for existence of important key words related to the research question and for relevance of the studies based on the inclusion and exclusion criteria. In the second step, all relevant articles were subjected to an in-depth full-text critical review for eligibility.

The search resulted in an initial total of 1,935 records, of which 18 were found in ABI/Inform, 598 in PsychINFO, 799 in Web of Science, 305 in PubMed, and 206 in Google Scholar. Additionally, 9 studies were later included after reviewing reference lists and studies citing the included studies. A total of 638 duplicates were removed, resulting in 1,298 records to be screened. Based on title and abstract screening for existence of important keywords related to research question as well as inclusion and exclusion criteria, 1,026 were found to be irrelevant and 271 records were subject to a full-text review. After the full-text review, 216 articles were found not eligible for inclusion based on the following criteria: wrong outcomes (

= 134), wrong intervention (

= 58), full-text article not written in English (

= 9), wrong population (

= 12), full-text article not accessible (

= 3). A total 55 articles were selected for extraction and analysis. The search strategy for this systematic review can be found in

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#F1

, which is based on the PRISMA (Moher et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B111

Flow diagram of literature search and selection procedure employed to identify studies eligible for inclusion in the systematic review.

Data Analysis

To have a comprehensive understanding of the characteristics of the studies, a data extraction sheet was developed in Microsoft Excel (version 16.16.2., Microsoft Corporation, Redmond, WA, USA). Identifying information extracted from the studies including the title, author(s), publishing year, and Covidence number were placed into separate columns. Columns were also made for information extracted for each outcome of interest (i) method of FACS implementation (ii) purpose of study (iii) consumer product-based stimuli used and (iv) measures of affect validation; a “Notes” column was also made so further detail could be provided on each outcome of interest, if necessary (

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#SM1

). Method of FACS implementation consisted of three broad categories: manual, automatic, and “both” (a combination of manual as well as automatic). For purpose of study, typology-based categories were developed to structure the plethora of aims represented across the extracted studies (

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#SM1

). Likewise, typology-based categories were developed to structure the diversity of diversity of purchasable, consumer product-based stimuli that were represented across the extracted studies (

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#SM1

). If a study utilized multiple stimuli, then the “Multiple” category was chosen, and all stimuli were listed out in the “Notes” column of

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#SM1

. An variety of affect validation measures represented across the extracted studies (

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#SM1

). These categories are defined by the nature of the validation measures, which included externally-reported (i.e., non-self-reported) measures (implicit: affect-related activation and/or arousal occurring within the body; affect-related activation and/or arousal occurring within the body; explicit: affect-related activation and/or arousal that can be observed occurring on the outside of the body) and self-reported measures (vocalized: vocal communication of information pertaining to arousal and/or affective state; non-vocalized: information pertaining to arousal or affective state that is physically input, selected, or expressed). The category “None” was used to describe studies where no additional measure was used to validate FACS-measured affective response. For interpretations for key words and terms used throughout the review has been provided (

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#SM1

). If the researchers encountered conflicts in their independent assessments, they were discussed until a consensus was reached.

Additionally, all extracted studies were assessed for risk of bias using the Cochrane Risk of Bias Tool (Higgins and Green,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B75

). Bias was assessed in the following categories: selection bias (allocation concealment, sequence generation), performance bias (blinding of participants and personnel to all outcomes), detection bias (blinding of assessors to all outcomes), attrition bias (incomplete outcome data), reporting bias (selective outcome reporting), and other sources of bias. The two researchers conducted the risk of bias assessment independently and evaluated the extracted studies for selection, performance, detection, attrition, reporting, and other sources of bias, which was rated as being either low, high, or unclear. If the researchers encountered conflicts in their independent assessments, they were discussed until a consensus was reached.

Overview of the Selected Articles

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#T2

gives a summary of the final set of 55 articles with respect to their purpose, how FACS was implemented, the consumer product-based stimuli used, and measures utilized to validate FACS-determined affect (i.e., emotion). The data extraction sheet for this review, which outlines all selected article, outcomes of interest, and notes providing further detail about the outcomes has also been provided (

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#SM1

). More than half of these articles were published in the last 10 years (33 studies; 60%) of which a majority have been published in the last 5 years (19 studies; 35%). About 13 times more articles were published in the last 4 years than during the first 4 years (

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#F2

). This suggests that there is a growing interest in using FACS to measure human emotional behavior to consumer product-based stimuli. Most studies implemented FACS manually (40 studies; 73%), however studies published within the last 5 years (

= 19) have increasingly implemented FACS automatically (9 studies; 47%; automatic or both automatic and manual within last 5 years) to assess human affective response. Though the studies were performed for a variety of purposes, the most frequent purposes were to develop products & software (11 studies; 20%) as well as to assess behavior toward stimuli under a social and/or situational context (10 studies; 18%) and investigate human development and/or behavior (10 studies; 18%). Films and/or movie clips (11 studies; 20%) as well as comedies, jokes, or cartoons (10 studies; 18%) were used most often as the emotion-evoking consumer product-based stimuli; though several studies used multiple stimuli (9 studies; 16%).

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#F3

gives an overview of the consumer product-based stimuli that have been used to elicit an affective response. Most often, studies validated an individual's FACS-determined affective response with non-vocalized self-reported measures (12 studies; 22%) via questionnaires, scales, or surveys. However, it should be noted that the vast majority of studies (29 studies; 53%) did not use another measure to validate an individual's affective response as determined using FACS.

Purpose of study - stimuli (i.e., product) category

Validation method implicit externally-reported measures

Explicit externally-reported measures

Vocalized self-reported measures

Non-vocalized self-reported measures

Combination

#### Affective states during learning

- Tutoring program/system

Craig et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B29

Grafsgaard et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B58

Behavior toward stimuli under social and/or situational contexts

- Cigarettes

Sayette et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B133

- Comedy, joke, and/or cartoon

Sayette et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B132

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B127

; Lynch and Trivers,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B104

- Computer game

Mui et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B113

- Film and/or movie clip

Jakobs et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B81

Dale et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B31

- Physical game

Schneider and Josephs,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B136

#### Facial behavior and emotion expression

- Comedy, joke, and/or cartoon

Krumhuber and Manstead,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B89

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B126

- Film and/or movie clip

Ekman et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B45

; Dosmukhambetova and Manstead,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B42

; Namba et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B114

Frank et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B54

Catia et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B18

Soussignan and Schaal,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B140

#### Genetics and emotion expression

- Comedy, joke, and/or cartoon

Haase et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B65

Human development and/or behavior

- Cigarettes

Sayette and Hufford,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B130

; Griffin and Sayette,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B62

; Sayers and Sayette,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B129

- Comedy, joke, and/or cartoon

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B103

- Film and/or movie clip

Johnson et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B83

Forestell and Mennella,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B53

Sayette and Parrott,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B134

Soussignan et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B141

- Physical game

Unzner and Schneider,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B146

Cole et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B26

Human-computer interaction and emotion

- Computer game

Balzarotti et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B6

- Film and/or movie clip

Menne et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B108

Product and/or software development

- Tutoring program/system

Graesser et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B57

- Self-service checkout

Martin et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B106

Reliability Of FACS

Sayette et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B131

#### Sensory modalities and emotion

- Flavor and/or taste solutions

Bredie et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B14

Rosenstein and Oster,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B123

; Bezerra Alves et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B9

; Zacche Sa et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B158

Weiland et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B154

Greimel et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B61

Implicit externally-reported measures

Explicit externally-reported measures

Vocalized self-reported measures

Non-vocalized self-reported measures

Combination

#### Affective states during learning

- Tutoring program/system

Grafsgaard et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B59

Grafsgaard et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B60

- E-book and/or audio book

Hung et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B78

Behavior toward stimuli under social and/or situational contexts

- Computer game

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B124

Product and/or software development

Gurbuz and Toga,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B64

Brown et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B16

Tussyadiah and Park,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B145

Bartlett et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B8

Gunes et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B63

Espinosa-Aranda et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B52

#### Sensory modalities and emotion

- Flavor and/or taste solutions

Chapman et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B19

MANUAL+AUTOMATIC

Implicit externally-reported measures

Explicit externally-reported measures

Vocalized self-reported measures

Non-vocalized self-reported measures

Combination

#### Facial behavior and emotion expression

- Comedy, joke, and/or cartoon

Cohn et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B24

Product and/or software development

- Tutoring program/system

D'Mello and Graesser,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B40

- Film and/or movie clip

Kodra et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B88

Zhang et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B159

Overview of the studies included in the systematic review by outcome of interest including the Facial Action Coding System (FACS) application, purpose of study, products assessed, and validation method in the study.

Total number of publications included in this review (

= 55) as published over successive 4-years intervals from 1978 to 2019.

This is a 5 year interval to capture the year FACS was established \[1978\]

Frequency of validation methods used within 55 studies (C, Combination of methods; EER, Explicit externally-reported; IER, implicit externally-reported; NVSR, Non-vocalized self-reported; N, None or no validation measures used; U, Unsure if self-reported method was vocalized or non-vocalized; VSR, Vocalized self-reported).

Facial Action Coding System (FACS)

In most studies (40 out of 55; 73%), participants affective responses were exclusively coded manually using FACS. Only 11 studies (20%) exclusively coded FACS automatically, of which 4 studies utilized the Computer Expression Recognition Toolbox (CERT), 6 studies used a novel software developed by the researchers, and 1 study utilized Affdex for Market Research by Affectiva. A total of 4 studies combined manually coding FACS with another measure that automatically coded FACS to determine participants' affective responses. For all 55 studies in this review, facial expressions were coded from pre-recorded and/or live video recordings.

For the studies that exclusively coded FACS manually, a majority (26 out of 40; 65%) utilized two individual coders to determine the participants' affective responses. However, some studies used one (5 studies), three (6 studies), four (1 study), and even six people (1 study) to manually code FACS. In the study by Catia et al. (

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B18

), it was unclear how many individuals were utilized to code the human participants' facial responses. The purpose of these studies varied, but the majority investigated human development and/or behavior (10 studies; 25%). Though the stimuli of these studies were numerous, the majority of manually coded studies used comedies, jokes, and/or cartoons (7 studies; 18%) or film and/or movie clips (7 studies; 18%) to evoke an affective response from participants. Notably, the majority of these studies (22 out of 40; 55%) did not use another measure to validate FACS-determined affective response even though it has been suggested that there are many facets to evoking emotion and any single measure would fail to capture these facets in their totality (Lagast et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B90

; Kaneko et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B84

In most of the studies where FACS was exclusively coded automatically (6 out of 11; 55%), participants engaged with consumer product-based stimuli that were presented on a digital device (i.e., computer or computerized mobile device) including videos, online tutoring programs, computer games, and e-books. However, in three studies (27%), the consumer product-based stimuli themselves (e.g., robot or animatronic toy doll) contained the automatic FACS coding software. The purpose of some studies focused on product and/or software development (6 studies; 55%) whereas others investigated affective states during learning (3 studies), behavior toward stimuli under social and/or situations contexts (1 study), and relationship between sensory modalities and emotion (1 study). Similar to the manually coded studies, the majority of the automatically coded studies (8 out of 11; 73%) did not use another measure to validate FACS-determined affective response.

Of the studies that used both manual and automatic FACS coding, the majority (3 out of 4) focused on the development of products and/or software. Compared to studies that utilized manual or automatic coding alone to determine participant affective responses, all four of the studies that used both FACS applications validated FACS-determined affect with at least one and/or a combination of other methods. Though the methods varied, they encompassed all of the validation categories presented in this review (except “None”).

Purpose of Study

An expansive variety of purposes were present in the selected studies (

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#T2

). For this review these purposes were categorized into a total of 9 typology-based categories: affective states during learning, behavior toward stimuli under social and/or situational contexts, facial behavior & emotion expression, genetics & emotion expression, human development and/or behavior, product and/or software development, reliability of FACS, and sensory modalities & emotion. In general, the most common purpose was to investigate development of products and/or software (11 studies; 20%). As over half of studies (28 studies; 51%) focused on human behavior in some respect, including the ones that investigated behavior under social and/or situational contexts (10 studies), facial behavior & emotion expression (eight studies), and human development and/or behavior (10 studies), it can be deduced that using FACS is considered a valuable tool for comprehending the impact of emotions on human appraisal as well as action tendencies. Nevertheless, some of the reviewed studies investigated the underpinnings of emotion and their relationship to human physiological capacities. In two studies, Haase et al. (

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B65

) examined the effect of the short allele of the 5-HTTLPR polymorphism in the serotonin transporter gene on positive emotional expressions measured by objectively coded smiling and laughing behavior in response to cartoons as well as an amusing film. Cohn et al. (

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B24

) assessed individual differences in rates of positive expression and in specific configurations of facial action units while participants watched short films intended to elicit emotion, which showed strong evidence that individuals may be accurately recognized on the basis of their facial behavior suggesting that facial expression may be a valuable biometric. Participants in the study by Weiland et al. (

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B154

) were exposed to basic tastes (bitter, salty, sweet, sour, umami) as well as qualitatively different odors (banana, cinnamon, clove, coffee, fish, and garlic) while their taste- and odor- specific facial expressions were examined. Spontaneous facial expressions were also examined in response to distaste (Chapman et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B19

) and to investigate whether they would provide additional information as to the explicit measure of liking (de Wijk et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B38

) for basic tastes. As mentioned previously, FACS-measured facial responses were frequently utilized to develop various consumer products and/or software (11 studies; 20%). For a more detailed overview of the studies categorized by purpose and consumer product-based stimuli, see

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#SM1

. The type of purpose varied widely across consumer product-based stimuli; the greatest number of stimuli by purpose were for flavor and/or taste solutions (

= 7, sensory modalities and emotion). Given the aforementioned variety of purposes for affective response measurement, it appears that FACS can be applied within numerous scientific fields.

Consumer Product-Based Stimuli

A wide range of consumer product-based stimuli were used in the selected studies (

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#T2

). For this review, these products were categorized into a total of 18 product categories: amusement park ride; animal; cigarettes; comedies, jokes, and/or cartoons; computer games; e-book and/or audiobook; film and/or movie clip; flavor and/or taste solutions; food; gift/present; mobile application (app); multiple (i.e., more than one product-based stimuli); odor; physical game; robot; self-service checkout; toy; and tutoring program and/or system. A more detailed description of the stimuli used in each study can be found in the “Notes” column of

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#SM1

. Although it could be argued that flavor or odor themselves are not consumer product-based stimuli, the reviewers deemed them appropriate categories since flavor and odor are inherent properties of purchasable consumer-product based stimuli (e.g., diffusible scents such those found in essential oils, candles, room or fabric fresheners, line-extension flavor varieties, etc.) that can elicit an affective response by evoking at least one of the five senses (i.e., taste or smell), which is in accord with the inclusion criteria of this review. In general, the most used product categories were films and/or movie clips (10 studies of which 8 featured only film and/or movie clips and two featured film and/or movie clips and another stimulus category) and comedies, jokes, and/or cartoons (nine studies of which 8 featured only comedies, jokes, and/or cartoons and 1 featured comedies, jokes, and/or cartoons and another stimulus category). In this review, most studies focused on utilizing consumer product stimuli that are emotionally competent (i.e., have the known and/or defined capacity to evoke a particular affective response) in nature, such as film clips and comedies. Similarly, flavor and/or taste solutions (seven studies) and odors (six studies) were also used as the single stimulus or one of multiple affect-evoking stimuli since certain tastes are emotionally competent, such as bitter, which elicits disgust motivated by withdrawal from products that may be harmful if consumed (Rozin et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B125

Nevertheless, some of the reviewed studies investigated product categories with low, unknown, or undefined emotional competence. Some articles (three studies) used computer games to evoke adults' (Rossi,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B124

; Balzarotti et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B6

) as well as children's (Mui et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B113

) affective responses in order to investigate their behavior under social and/or situational contexts. Tutoring programs/software were used in several studies to evoke an affective response in order to study affective states during learning (four studies) or to develop products and/or software (two studies). Grafsgaard et al. (

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B58

), Grafsgaard et al. (

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B60

), Grafsgaard et al. (

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B59

) used either manual or automatic FACS coding to determine students' affective responses, while being tutored through an online program, because affective states often influence progress on learning tasks, resulting in positive or negative cycles of affect that impact learning outcomes (Woolf et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B157

; Baker et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B5

; D'Mello and Graesser,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B41

). Participants of studies conducted by Sayette and Hufford (

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B130

), Sayette and Parrott (

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B134

), Sayette et al. (

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B131

), Sayette et al. (

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B132

), Griffin and Sayette (

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B62

) and Sayers and Sayette (

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B129

) underwent smoking cue exposure with cigarette and rolled-paper stimuli to better understand the relationship between affect and human behaviors including craving and urge. Children's facial expressions of affect were also manually coded in response to physical games to better understand human psychological development (Unzner and Schneider,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B146

; Schneider and Josephs,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B136

). Although food, used in studies by Forestell and Mennella (

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B53

) as well as Gurbuz and Toga (

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B64

), is recognized as emotional stimuli, researchers debate whether the nature of specific foods have the capacity to elicit intense emotional responses (Desmet and Schifferstein,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B39

; Walsh et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B151

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B152

As such, studies with multiple stimuli seem to utilize products of known and/or high emotional competence alone or in combination with products of low, unknown, and/or undefined emotional competence in combination. For studies where multiple products were utilized, the number of stimuli varied widely: studies that analyzed pre-existing or pre-recorded video clips (of participants engaging with a consumer product-based stimulus) typically used between 2 and 5 stimuli whereas studies that presented products for participants to physically engage with in the present varied between 2 and 10 stimuli. Studies using multiple stimuli also featured some of the most underrepresented (≤ 2 studies) product categories in this review including amusement park rides, animals, e-books and/or audio books, gift/present, and mobile application (app). Though the study by Brown et al. (

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B16

) was marked as having multiple stimuli, it was marked as such because it was unclear if the stimulus used is an actual e-book or a mobile application (app) featuring an e-book. Based on previous suggestions for emotional research by King and Meiselman (

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B87

) the number of products tested for emotional measurement is important because it can increase the number of statistically significant differences in measured emotions.

Validation of Emotion

Method Type

Though method of affect validation was an outcome of interest in the review, more than half of the included articles (29 out of 55 studies; 53%) did not employ additional methodology to validate FACS-determined affect. Non-vocalized self-reported methods were most commonly applied and appeared in a total of 14 articles (25%) as either the sole validation method (11 studies) or in combination with other methods (four studies). In

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#T2

, all studies are categorized by type of method used to measure emotion. Following the typology (see

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#SM1

), the methods are further classified by type of measure/instrument used to validate FACS-determined affect. A more detailed description of the validation measures used in each study can be used in each study can be found in the “Notes” column of

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#SM1

. For the explicit externally-reported method, five type of measures were found: manual FACS coding, gross body movements, vocal quality cues, and subjective human judgment of emotion. Also, seven measure categories for the implicit externally-reported method were listed: skin conductance/electro dermal activity, heart rate (HR), electrocardiogram (ECG), facial electromyography (EMG), EEG, respiratory sinus arrhythmia, respiratory rate (RR), and blood pressure (BP). For the non-vocalized self-reported method, five types of measures were identified: dial reporting, Likert-type scales for emotion and emotion intensity rating, positive and negative affect schedule (PANAS) questionnaires, mood state questionnaires, and Likert scales for pleasantness. Also, two measure categories for the vocalized self-reported method were recognized: vocalized/vocal report of emotion and vocalized/vocal report of pleasantness. For the studies that combined validation methods, five categories were identified: explicit externally-reported & vocalized self-reported, implicit externally-reported & vocalized self-reported, explicit non-vocalized self-reported, implicit externally-reported & non-vocalized self-reported, and explicit & implicit externally-reported.

Explicit Externally-Reported Measures (Nine Incidences Reported)

Of the 55 studies included in this review, only eight studies (15%) reported use of explicit externally-reported methodology: four articles where the method was the only validation method and 4 articles where the method was used in combination with other methods. Explicit externally-reported measures of affect validation were most frequently applied through subjective judgement of emotion (four studies) and tracking of gross body movements (three studies), both of which were performed by a human individual that was neither the subject nor the study's principle investigators. For articles where the subjective human judgement of emotion was employed (four studies), FACS was coded manually (three studies) or automatically (one study) and it was always combined with another method and/or measure. Of the studies using gross body movements to validate affective responses, FACS was automatically coded (one study), manually coded (one study), as well as coded both manually and automatically (1 study). Vocal quality cues, coded by individuals trained to use the maximally discriminative facial movements coding system (MAX), were another explicit externally-reported measure used in combination for affect validation (1 study). Bartlett et al. (

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B8

) used subjective judgement by observers using the turn dial technique to rate amount of happiness shown by the subject. Notably, one study by Bredie et al. (

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B14

) manually coded facial expressions using FACS and utilized manually coded facial expressions from a previous study by the same group to validate the affective responses they measured. In most studies, the timing of the explicit externally-reported validation measurement took place concurrently (five studies) or after (three studies) facial expressions had been coded using FACS.

Implicit Externally-Reported Measures (15 Incidences Reported)

Of the 55 studies reviewed, only seven studies (13%) used implicit-externally reported methods: 1 article where the method was the only validation method and six articles where the method was used in combination with other methods. The registration of HR (five studies) was most popular and occurred in studies where implicit-externally reported measures were the exclusive validation method (1 study) as well as when this method was combined with other methods (four studies); in this review, heart rate was usually accompanied by another implicit-externally reported measure (five studies) such as skin conductance, blood pressure, etc. For studies that used implicit-externally reported methods, facial expressions were mostly coded manually using FACS (4 studies) but were also coded automatically (1 study) or by using both manual and automatic coding (two studies). Only two studies exclusively used a single implicit externally-reported measure (Facial EMG = 1 study, EEG = 1 study) whereas five studies employed at least 2 or more implicit externally-reported measures including HR (5 studies), ECG (1 study), skin conductance/electrodermal activity (three studies), RR (two studies), respiratory sinus arrhythmia (1 study), and BP (1 study) to validate FACS-determined affect. In these studies, facial expressions occurred concurrently with the measurement of implicit-externally reported methods.

Vocalized Self-Reported (4 Incidences Reported)

Of the 55 studies reviewed, only five studies used vocalized self-reported methods, either vocalized report of emotion or vocalized report of pleasantness. Verbal/vocal report of emotion was most common (four studies) and was used exclusively as the affect validation measure (1 study) or in combination with another method (three studies) and was utilized only when facial expressions were manually coded with FACS. Vocalized report of pleasantness (1 study) was only reported once in this review and was the only measure used to validate manually coded, FACS-determined affect in that study. In studies that used vocalized self-reported methods, facial expressions occurred concurrently (three studies) or before (two studies) the vocalized self-report validation method.

Non-vocalized Self-Reported (16 Incidences Reported)

Of the 55 studies reviewed, only 14 studies (25%) used non-vocalized self-reported methods: 10 articles where the method was the only validation method and four articles where the method was used in combination with other methods. The rating of affect and its intensity on rating scales (eight studies) was most popular in the non-vocalized self-reported validation method, which occurred most often in the form of 9-point (3 studies), 7-point (3 studies), and 5-point (2 studies) Likert-like scales; however, in Jakobs et al. (

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B81

), subjects rated intensity of nine emotional feelings (interest, happiness, boredom, surprise, contentment, irritation, excitement, amusement, and disgust) on 100-millimeter rating scales numbered at each centimeter, in which 0 = not at all and 100 = extremely. Mood (1 study) or affective state (two studies) questionnaires were also utilized by subjects to indicate the “state” they were in while engaging with a stimulus. Two studies used the PANAS questionnaire which consists of a number of words that describe different feelings and emotions where subjects indicate to what extent they have felt in the present moment or over a particular period of time (e.g., the past week). In another (1 study) by Soussignan and Schaal (

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B140

), subjects' hedonic ratings were assessed using five differently colored cards, each bearing a label describing a hedonic tone (from 1 = very unpleasant to 5 = very pleasant) and subjects were asked to point to the card that best fit with their assessment of how pleasant the stimuli were. However, it should be noted that these questionnaires, scales, and rating measures are discontinuous and only capture affect as it holistically relates to an experience. Additionally, a few articles (two studies) utilized dial reporting—a more continuous measure where subjects are asked to turn a hardware dial to quantify valence throughout their engagement with a stimulus; e.g., on a 0–100 dial range, subjects are typically told that 0 is disinterest, 50 is neutral, and 100 is interest in the stimulus. For the studies that utilized non-vocalized self-reported validation methods, the majority (12 studies) coded facial expressions manually using FACS whereas the minority (two studies) used both manual and automatic coding.

Studies Combining Validation Methods

Of the eight studies (15%) that combined validation methods and used multiple validation measures, the combinations fell into the following categories: explicit externally-reported & vocalized self-reported (two studies); explicit externally-reported & non-vocalized self-reported (1 study); implicit externally-reported & non-vocalized self-reported (1 study); explicit externally-reported & implicit externally-reported (1 study); implicit externally-reported, vocalized self-reported, & and non-vocalized self-reported (1 study); and explicit externally-reported, implicit externally-reported, and non-vocalized self-reported (1 study). The study by Cohn et al. (

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B24

) combined the implicit externally-reported method (measure= Facial EMG) with a self-report of emotion; however it was unclear if the self-report was vocalized or non-vocalized. Likewise, it was also unclear if subjects' facial expressions occurred concurrently or before the self-report of emotion. For the studies that utilized a combination of validation methods, the majority (6 studies) coded facial expressions manually using FACS whereas the minority used both manual and automatic coding (two studies).

Risk of Bias

Of the 55 studies included in this review, 11 studies (20%) were determined to have high risk of bias in one or more of the following categories: selection bias (allocation concealment, sequence generation), performance bias (blinding of participants and personnel to all outcomes), detection bias (blinding of assessors to all outcomes), attrition bias (incomplete outcome data), reporting bias (selective outcome reporting), and other sources of bias. One study was identified as being at risk of selection bias because the videos the experimenters used were shown in the same order and it was unclear if the conditions (solitary or social interactions) were randomized (Frank et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B54

). The risk of performance bias was judged to be minimal since blinding of participants and personnel was determined to be low (38 studies) or unclear (17 studies). Detection bias was a concern for a few studies (five studies) as the accessors were not blinded to all study outcomes. In the study by Brown et al. (

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B16

), it appears that the evaluation of experimental treatments/stimuli were performed by the prototype developers (i.e., the authors). Similar circumstances were presented in the study by D'Mello and Graesser (

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B40

) where the two FACS coders “had considerable experience interacting with AutoTutor. Hence, their emotion judgments were based on contextual dialogue information as well as the FACS system.” Likewise, three studies identified that the FACS coder(s) was one of the principle investigators of that study and, therefore, was aware of the study's aims (Lynch,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B103

; Lynch and Trivers,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B104

; Martin et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B106

). Attrition bias was also a concern for a few studies (four studies) as there was incomplete outcome data. In the study by Brown et al. (

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B16

), the authors did not clearly state their outcomes of interest and, though they discussed some of the main areas of work they performed, the criteria they evaluated the prototype for was not well-defined or discussed. The study by Cohn et al. (

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B24

) listed comparisons of facial behavior with self-reported emotion, but no methodology is outlined for how self-reported emotion was measured nor for any statistical analysis being performed; although the experimenters later reported correlations between self-reported emotion and zygomatic major activity, no comparisons were made for self-reported emotions and AUs. Similarly, Frank et al. (

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B54

) rating dial and subject self-report data was not included in the study's results or discussion. Additionally, Tussyadiah and Park (

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B145

) reported using the Emotion Facial Action Coding System (EMFACS) to score emotion expressions (joy, anger, surprise, fear, contempt, sadness, and disgust) but no scores were presented for each emotion in the results; only percent occurrence of the emotional expression was discussed and graphically depicted. Reporting bias was a concern for a few studies (six studies) as there was selective outcome reporting. For four studies, the outcomes listed in the methods section of the article could not be compared with those whose results were reported (Frank et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B54

; Cohn et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B24

; Bezerra Alves et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B9

; Brown et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B16

). Also, in the study by Catia et al. (

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B18

), the authors compared the human videos coded with FACS to the established literature instead of a within-study control for reliability, which could lead to selection of literature that supports their findings instead of collectively reporting on the entire body of evidence that exists. In the study by Gurbuz and Toga (

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B64

), the researchers cited that the automatic FACS coding software they developed scored basic emotions (anger, contempt, disgust, fear, happiness, neutral, sadness, and surprise) from 0 to 1 but only reported that the expression happiness was a significant predictor of gender; no emotion scores were reported. Other sources of bias were found in three separate studies. Brown et al. (

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B16

) made several conclusions about their e-books abilities that were not supported by the data presented, which could lead to conclusions that are not realistic or substantiated by the data. In the videos selected by Catia et al. (

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B18

), there is no justification or verification of the subjects' emotional experience; therefore, the authors may be speculating that a particular emotion is being expressed when it really is not. In which case, their authors' basis for the specific emotional competency of each stimuli may be false and subsequent interpretations of the data may be invalid. Additionally, Frank et al. (

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B54

) utilized data from a previously conducted study, which may contribute to other potential sources of bias, and also mentioned the removal of outlier data—a practice generally considered to be unethical.

This is the first study that systematically reviews the purpose and validation of (manual, automatic, and a combination of both manual and automatic) FACS implementation for the measurement of human emotional behavior to different types of consumer product-based stimuli.

It provides a comprehensive overview on 55 peer-reviewed articles published between 1978 and June 2019 and builds on the increased interest in the relationship between emotions and consumer-based products, which goes beyond sensory liking, by indicating trends of capturing and validating affective responses with FACS. The main observations were: (1) The vast majority of studies neglected to employ additional methodology to validate FACS-determined affect (29 out of 55 studies; 53%); (2) Of the validation measures that were used, most tended to be discontinuous in nature and only captured affect as it holistically related to an experience; (3) As described in the articles' methodologies, researchers typically utilized consumer product-based stimuli that had known and/or defined capacity to evoke a particular affective response, and a lack of attention was paid to consumer products with low levels of emotional competence or with unknown affective impact. Additionally, this review illuminated some inconsistencies in how FACS is carried out as well as how affective (i.e., emotional) response is inferred from AU activation—these inconsistencies will be outlined and recommendations will be suggested to enhance the interpretation of emotion as it pertains to consumer product-based stimuli.

Neglecting to Validate FACS-Determined Affect

Emotions are considered to be important drivers of consumer product-related perceptions such as liking and preference. Valid, reliable, and sensitive instruments that assess consumer product-elicited emotions are therefore valuable for fundamental and applied research, developing new products, and advocating for a healthy lifestyle and/or behavior. As mentioned in the results, the fact that at least half of the studies in this review failed to employ an additional validation measure makes it evident that researchers assume that FACS is an accurate and reliable approach for assessing product-evoked emotions. FACS has been used to verify the physiological presence of emotion in a number of studies, with high (over 75%) agreement (Bartlett et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B8

), and good to excellent reliability for the occurrence, intensity, and timing of individual action units and for corresponding measures of more global emotion-specified combinations (Sayette et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B131

). Although FACS is an ideal system for the behavioral analysis of facial action patterns and humans can be trained to code reliably the morphology of facial expressions (which muscles are active), it is very difficult for them to code the dynamics of the expression (the activation and movement patterns of the muscles as a function of time) (Bartlett et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B8

). Additionally, human emotion is a multifaceted construct linked to physiological, behavioral, and cognitive processes, and we may not assume to find a single measure that covers the full range, although there is a general agreement that all measures are relevant (Ruch,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B126

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B127

). Thus, it can be concluded that emotions (i.e., an affective response) evoked by consumer product-based stimuli can only be fully-understood by integrating data from multiple modalities (e.g., facial expressions, physiological responses, self-report).

Tendency Toward Discontinuous Validation Measures

Of the 19 validation measures reported, there were 14 instances of non-vocalized self-reported, 15 instances of implicit externally-reported, 10 instances of explicit externally-reported, and 4 instances of vocalized self-reported measures. Regarding these incidences, the non-vocalized self-reported measure was by far used in the most articles (14 studies) with 10 of those studies using the method as the only measure of validation. As previously mentioned, the majority (more than 86%) of measures used in the non-vocalized self-reported method are discontinuous measures of affect such as questionnaires, scales, and rating procedures; the only continuous measure reported was the dial reporting method. Discontinuous measures existed in other methods as well-including subjective human judgement of emotion (explicit-externally reported), vocalized/vocal report of emotion (vocalized self-report), and vocalized/vocal report of pleasantness (vocalized self-report). There are two important comments to be made here. First, report of product engagement can vary over time in emotional response due to perceptual variability, changing expectations, and preceding contexts. Most studies, especially when self-reported methods were used, measured emotion after engagement with a consumer product-based stimulus. As such the method does not continuously measure emotional response alongside facial expressions, which can account for inconsistencies between the two reported affective states (Kodra et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B88

). Externally-reported methods (implicit and explicit) can provide a measure of affect that is not encumbered by issues associated with self-reported methodology. Explicit externally-reported methods in this review were exclusively applied/measured by another human being including gross body movements, vocal quality cues, and subjective human judgement of emotion. While the latter is a discontinuous measure as it was performed after the initial product-engagement session, the former measures offer a more continuous report of affect as they occurred concurrently with facial expression of emotions. However, Graesser et al. (

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B57

) noted that the humans applying these methods have varying levels of accuracy in their judgements, which were dependent upon the degree of training they had received and were subject to bias from human cognitive processes. Implicit externally-reported methods apply continuous monitoring of emotion measurement using instrumentation, which avoid the limitations of self-report and explicit externally-reported methods. In this review, the use of an implicit externally-reported measure (8 measures; 15 reported incidences) was mostly the result of interdisciplinary research as techniques from psychology and medical science were applied. FACS was developed by psychologists Ekman and Friesen (

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B46

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B47

) because their research supported that the face may also influence a person's emotional experience by providing signals to others about how the person feels and; thus, FACS is frequently used in the field of psychology. Similarly, the measurements of autonomic nervous system (ANS) responses (such as heart rate) and neurophysiological responses (such as brain activity) originate from psychophysiology and have only recently been applied in consumer and sensory research (Bradley,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B12

; Bradley et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B13

; Codispoti et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B22

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B23

). According to Zhang et al. (

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B159

), research has also shown a correlation between the physiological state to the emotional state of individuals. Based on the studies in this review that incorporated implicit measures to validate FACS-determined affect, results indicate that the combined use of implicit measures can yield super additive effects for interpretations of some affective states but redundant and inhibitory effects for others.

Researchers' Proclivity for Emotionally-Competent Stimuli

Although authors report FACS and affective data evoked by a variety of consumer product-based stimuli, these are frequently of a category and/or include a stimulus that has a known and/or defined capacity to evoke a particular affective response: films and/or movie clips, comedies, jokes, and/or cartoons, and flavor/taste solutions dominated as the stimuli of choice in the reviewed studies. It seems that this is a result of the nature of the reviewed studies as the majority (28 studies; 51%) investigated human behavior in some context including: affect in human development & behavior (10 studies;18%), behavior toward stimuli under social and/or situational contexts (10 studies; 15%), as well as facial behavior & emotion expression (8 studies; 15%). In these cases, the researchers desired to induce a particular affective state or elicit a specific emotion from subjects so they could understand its impact on their behavior. The existing body of literature suggests that emotional and motor processes are strongly interrelated, but attempts to assess whether emotionally-competent stimuli (i.e., stimuli with known and/or defined capacity to evoke a particular affective response) modulate action readiness (i.e., the ease with which an action may be initiated given the pre-action state an individual) has yielded contradictory results due to differences in experimental design (Avenanti et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B4

; Coombes et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B27

; Hajcak et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B66

; Schutter et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B137

; van Loon et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B149

). To overcome these contradictions, Mirabella (

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B110

) devised a new version of an emotional go/no-go task to directly compare equivalent decision-making processes underlying actions cued by emotional stimuli of differing valence. In their work, it was demonstrated that only when the emotional content of the stimuli was relevant for the task did it impact the generation of actions (Mirabella,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B110

). As such, if task-relevance is a crucial factor, then consumer response to an emotionally-competent stimulus would not be directly related to the stimulus itself; rather it would be contingent on the cognitive state of the consumer.

Several studies referenced or characterized the relationships between flavors, odors, and the specific affective responses they evoke (Rosenstein and Oster,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B123

; Greimel et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B61

; Weiland et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B154

; Bezerra Alves et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B9

; Bredie et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B14

; Zacche Sa et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B158

; Chapman et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B19

). Notably, only two in this review sought to use FACS to assess consumer engagement for the purpose of understanding preference for (1 study) or acceptability of (1 study) a consumer-based product (Lynch,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B103

; Forestell and Mennella,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B53

). The scientific need to better conceptualize consumers' experience with products of low or unknown/undefined capacity to evoke an affective response (such as product prototypes, line extensions, etc.) has led to an increased interest in integrating emotions into consumer and sensory research. Several articles (11 studies) in this review utilized FACS for the purpose of product and/or software development, however, the majority (six studies) were focused on developing and/or validating software or consumer-based products that contained software for automatic recognition of facial expressions of affect; only three studies were truly using FACS to assess consumer affective response to product-based stimuli that were being developed including self-service checkouts and robots (Martin et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B106

; Tussyadiah and Park,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B145

; Gunes et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B63

). In recent years, there has been a particular focus on the relationship between food and emotions for the sake of understanding food-evoked affect on acceptability, intention to purchase, food choice, attitudes, or behavior, which has led to the introduction of many methods and measures to capture consumers' emotions elicited by food (Lagast et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B90

; Kaneko et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B84

). Much like traditional sensory methods already in use by the industry for acceptance or preference, explicit methods of emotion measurement rely on participant cognition of and ability to recognize affective \[emotional\] response. However, a lack of emotion term understanding as well as pre-existing attitudes and stereotypes for products causes high panelist-to-panelist variation and within-panelist inconsistency (Leitch et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B95

; Walsh et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B152

). Likewise, the complexity and lack of specificity of implicit methods makes emotion interpretation incredibly challenging. Although research suggests that implicit measures are likely sensitive enough for consumer products with intensely polarized (very high or very low) liking, some studies have even concluded that implicit measures such as ANS responses and facial expressions cannot reliably differentiate sensory effects and changes in emotional valence (de Wijk et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B38

; Danner et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B32

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B33

; Walsh et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B151

). It has also been suggested that context can be an important and influential source of information when inferring emotional meaning in a facial configurations (Carroll and Russell,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B17

). As such, it can be deduced that the emotions elicited by products are often undefined and researchers should increasingly implement a variety of affective \[emotion\] measurement methods and integrate it with contextual data to provide a more comprehensive understanding of consumers' preferences and drivers of product-related choices.

Procedure for Utilization of FACS

FACS is the most comprehensive, psychometrically rigorous, and widely used system to describe facial activity in terms of visually observable facial muscle actions (i.e., AUs). Because of its descriptive power, FACS is regarded by many as the standard measure for facial behavior and is used widely in diverse fields such as neuroscience, computer vision, computer graphics and animation, facial encoding for digital signal processing, behavioral science, and psychology (Cohn et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B25

). This review shows that there are many inconsistencies with how researchers utilized FACS, both manually and automatically, to measure emotion. The main areas of inconsistency pertained to participant awareness of their facial expressions being video recorded, training of the coder and/or coding system, and validation of coder or automatic coding system's ability.

Whether manually or automatically applying FACS, video-recorded facial behavior must be captured and exhaustively analyzed frame-by-frame. For studies in this review, 55% (30 studies) reported participants being aware of the camera and/or that they were being video recorded, 25% (14 studies) were unaware because of camera concealment (8 studies) or because the participants were infants (six studies), and 20% (11 studies) did not identify or make clear whether or not participants were cognizant of being video recorded. Most often, participants were made aware of the video recording as part of the informed consent process and, depending on the transparency level, this process may have informed participants that the recordings would be used to analyze their facial expressions. Consequently, any resulting data and interpretations could be negatively influenced by subject reactivity bias; participants are cognizant that their actions and reactions are being closely observed, which may cause them to exaggerate or moderated facial expressions (Weiland et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B154

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B82

). To reduce the potential for subject reactivity bias, researchers should employ a consent process that informs panelists that the experiment will be continuously video recorded but should not disclose that their facial expressions would be analyzed.

As previously mentioned, this review illuminated inconsistencies related to coder (manual and automatic) training and validation. For studies that employed manual coding (44 total; 40 used manual only, 4 used manual in combination with automatic coding), 67% (29 studies) identified that the coders were certified-trained in FACS while 34% (15 studies) failed to identify if one or all coders were FACS certified-trained. Barrett et al. (

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B7

) maintain that people's capacity to reliably perceive emotions in the “common view” expressive configurations depends on how participants are asked to report or register their inferences. Likewise, there appears to be important cultural variation in whether emotions are perceived as situated actions or as mental states that cause actions (Barrett et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B7

). Although FACS is widely considered to be an ideal system for the behavioral analysis of facial action patterns, the process of manually applying FACS to videotaped behavior has been identified as a major obstacle (Bartlett et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B8

). To become FACS certified-trained, one must become intimately familiar with the content of the 597-page self-instructional text (also available on compact disk, CD), as well as the 197-page Investigator's Guide; at the time this review was published, FACS preparation materials are priced at $350 (Paul Ekman Group LLC,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B117

). The time required to learn FACS is variable, depending on a number of factors including number of hours per week that can be devoted to training, the availability of expert trainers, and individual differences among trainees. Cohn et al. (

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B25

) approximate that it would take 3 months to become proficient so as to demonstrate mastery on the FACS Final Test, which is a 34-question video-based exam priced at $50 (Paul Ekman Group LLC,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B117

). It then takes, on average, over 2 h to comprehensively code 1 min of video. Furthermore, although humans can be trained to reliably code the morphology of facial expressions it is very difficult for them to code the expression dynamics (i.e., movement patterns of the muscles as a function of time) as well as the occurrence of micro expressions, which occur at very high frequencies (1/15th−1/25th of a s) (Bartlett et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B8

)—even FACS certified-trained individuals need to undergo a separate specific training to reliably code micro expressions. Without rigors of becoming FACS certified trained, researchers attempting to use FACS may do so with varying levels of reliability. Likewise, researchers have a higher likelihood of success when one or more of their coders has demonstrated validated reliability via their FACS Final Test (following submission of the test scores, a trainee receives a reliability measure of their score compared with those of experts in FACS scoring) and/or by calculating interrater reliability (e.g., Cohen's Kappa).

For studies that employed automatic coding (15 total; 11 use automatic only, 4 used automatic in combination with manual coding), 73% (11 studies) identified that the coding system was trained and validated while only 27% (four studies) failed to identify if the system had been trained and/or validated. Similar to manual coders, automatic coding systems require training to ensure reliable coding of AUs. This training is performed by having the system evaluate still images and/or videos from a database where the facial AUs being activated (and emotions being expressed) are fully coded and comparing the system's determinations with the database. Based on this review, the automatic systems used for analysis were trained on a variety of databases including those that contained still images of posed facial expressions (e.g., Pictures of Facial Affect, POFA; Psychological Image Collection at Stirling University, PICS; MMI-Facial Expression Database; Cohn-Kanade DFAT-504) as well as those that contained videos depicting spontaneous facial behavior (e.g., Cohn-Kanade AU-Coded Expression Database, CK+; Rutgers and University of California San Diego FACS database, RU-FACS; Binghamton-Pittsburgh 3D Dynamic Spontaneous Facial Expression Database, BP4D). Although most automatic systems were trained on a spontaneous expression database, several did not identify how their system was trained (D'Mello and Graesser,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B40

; Hung et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B78

; Gurbuz and Toga,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B64

; Tussyadiah and Park,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B145

) or were solely trained on posed still image databases (Brown et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B16

; Gunes et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B63

), which may put their interpretations of participant emotion responses to consumer product-based stimuli at risk. Spontaneous facial expressions differ substantially from posed expressions; subjects often contract different facial muscles when asked to pose an emotion such as fear (subjects perform AUs 1+2), vs. when they are actually experiencing fear (spontaneous fear reliably elicits AUs 1+2+4) (Ekman,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B44

). Additionally, spontaneous expressions have a dynamically fast and smooth onset in which muscle contractions in different parts of the face peak at the same time. In contrast, posed expressions tends to be slow and jerky, and the muscle contractions typically do not peak simultaneously (Bartlett et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B8

). Thus, researchers attempting to use the automatic FACS coding may do so with varying levels of reliability unless their system has been trained and validated against at least one, if not more, spontaneous expression databases.

Relationship Between Action Units and Emotion Expression

Although FACS itself is descriptive and includes no emotion-specified descriptors, it is commonly used to interpret non-vocalized communicative signals, such as facial expressions related to emotion or other human states (Valstar and Pantic,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B147

). Using FACS, human observers can uniquely break down a facial expression into one or more of AUs that comprise the expression in question including: nine action units in the upper face and 18 in the lower face. In addition, there are 14 head positions and movements, nine eye positions and movements, five miscellaneous action units, nine action descriptors (i.e., movements for which the anatomical basis is unspecified), nine gross behaviors, and five visibility codes (Ekman et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B49

). If one wishes to make emotion-based inferences from single and/or combinations of AUs, a variety of related resources exist such as EMFACS and the FACS Investigators' Guide (Ekman et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B49

), the FACS interpretive database (Ekman et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B51

), and a large body of empirical research (Ekman and Rosenberg,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B50

). With respect to the studies in this review, there were inconsistencies with how affective (i.e., emotional) response is inferred from AU activation (

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#SM1

). Specifically, there were instances where AUs as well as emotion-based inferences were not used in agreement with FACS.

Of the 55 studies in this review, the majority (49 studies; 85%) reported coding AUs as they are defined in the FACS system (e.g., AU 12 = lip corner puller,

Zygomaticus major

). However, there were 2 studies (Rosenstein and Oster,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B123

; Brown et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B16

) where it was unclear if the AUs were coded as defined in the FACS system and 4 studies (Soussignan et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B141

; Bezerra Alves et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B9

; Kodra et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B88

; Zacche Sa et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B158

) that reported coding/defining the AUs in a manner that diverged from FACS. AU's were not identified in 4 studies in which the automatic emotion coding software was being developed/piloted to measure emotions in response to consumer products (Brown et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B16

; Espinosa-Aranda et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B52

; Gurbuz and Toga,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B64

; Tussyadiah and Park,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B145

). As suggested in the FACS Investigators' Guide (Ekman et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B49

), it is possible to map AUs onto the basic emotion categories using a finite number of rules (

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#T3

). When researchers deviate from these rules and define AUs and emotions by their own criteria (e.g., AU12 = smile, lateral lip corner pull without AU04 or AU09), such as in the study by Kodra et al. (

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B88

), their emotional interpretation has a higher chance of being faulty unless substantiated by a large body of empirical research. There are iterations of FACS, such as the Baby FACS, which are supported by existing literature. A few studies in this review reported using Baby FACS to code the facial expressions of affect in infants (Soussignan et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B141

; Bezerra Alves et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B9

; Zacche Sa et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B158

). Rosenstein and Oster (

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B123

) also reported using Baby FACS but the AUs they reported were more consistent with the adult FACS. Baby FACS is an anatomically based coding system adapted from Ekman et al. (

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B49

) adult FACS that consists of the following action units: A1 = no distinct mouth action or sucking on the face; A2 = A1 with a negative expression on the mid-face; A3 = A1 with a negative expression on the mid-face and brows; B1 = pursing mouth; B2 is B1 with a negative expression on the mid-face; B3 = B1 with a negative expression on the mid-face and brows; C1 = mouth-gaping action; C2 = C1 with a negative expression on the mid-face; C3 = C1 with a negative expression on the mid-face and brows. Unless researchers are seeking to contextualize facial expressions of novel or undefined emotions, attitudes, or moods, such as when Grafsgaard and others were investigating facial expression of confusion, they should utilize the AU-specific rules outlined for the basic emotions as outlined in in the FACS Investigators' Guide.

4+5+7+10+22+23+25/26

4+5+7+10+23+25/26

4+5+7+17+23/24

4+5+7+23/24

9/10+16+25/26

1+2+4+5+20+25/26/27

1+2+4+5+25/26/27

1+2+5+25/26/27

5+20+25/26/27

1+2+5+26/27

Rules for mapping Action Units to emotions, according to the FACS investigators guide. A/B means “either A or B”.

Additionally, it should be mentioned that recent research refutes the common view that facial configurations are “fingerprints” or diagnostic displays that reliably and specifically signal particular emotional states regardless of context, person, and culture (Barrett et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B7

). Instead, when facial movements do express emotional states, they are considerably more variable—rich in the variety with which people spontaneously move their faces to express emotions in everyday life. As such, it has been suggested that technology that applies facial expression nomenclatures & mapping constructs \[such as the FACS and its AUs\] fail to reliably interpret facial expressions of emotion.

Limitations

Although this systematic review aimed to give an overview of how FACS has been used to investigate human emotional behavior to consumer product-based stimuli, the inclusion and exclusion criteria narrowed the search down to studies that reported using FACS and/or the AUs of FACS to measure and/or characterize emotion. As such, studies that utilized measures that were derived from and/or engaged FACS in their analysis of facial expressions, such as automatic facial expression analysis (AFEA) software but neglected to identify whether the AUs measured and/or characterized emotion were excluded. In the initial search, several studies used AFEA instruments that have the capacity to measure and output data on AU activation and intensity (e.g., FaceReader™) but they only reported emotion based on the software's algorithm-determined output. Because such studies were excluded from this review, there could be a variety of consumer product-based applications of FACS that went unaccounted.

Conclusions

This review aimed to present how the facial action coding system has been used to investigate human emotional behavior to consumer product-based stimuli. While this field of research is rapidly growing, this systematic review offers a comprehensive overview of the purposes, applications, and methods of validating FACS-determined affective responses for different types of consumer product-based stimuli. Given the aforementioned variety of purposes for affective response measurement, it appears that FACS can be applied within numerous scientific fields. This review may prompt researchers to consider measuring the total consumer experience by employing a variety of methodology, in addition to FACS, to better conceptualize consumers' experience with products of low, unknown, and/or undefined capacity to evoke and affective response such as product prototypes, line extensions, etc. It must be noted that there are many more compounding factors that work to influence consumer choice and buying behavior in the market such as culture, geographical location, income, and individual experiences. However, utilizing a combination of measures, such as those that capture continuous as well as discrete emotional responses in both implicit as well as explicit contexts, is progressive step to better predict an individual's actual decision-making and affective response. Future research could review the results generated by the different FACS applications and validation measures in order to compare and evaluate them by consumer product type.

Data availability statement

All datasets generated for this study are included in the article/

Supplementary Material

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#s9

Author contributions

EC put forward the review idea, developed the inclusion & exclusion criteria, organized the article structure, and wrote the draft manuscript. EC and J'NK selected the databases to be searched, developed the search string, searched the relevant literature, read the literature, and identified the articles included in this review. SD assisted in conceptualizing the original question, reviewed and edited the drafted manuscript and provided critical guidance for integrating the introduction, results, and discussion topics. J'NK, MB, JL, DG, and SO'K contributed to identification of discussion topics for improving the interpretation of the observations from the systematic review, reviewed, and edited the manuscript.

Acknowledgments

We would like to thank the University Libraries at Virginia Tech for their guidance on conducting systematic reviews as well as their assistance acquiring various articles and books.

Conflict of interest

The authors declare that the research was conducted in the absence of any commercial or financial relationships that could be construed as a potential conflict of interest.

Supplementary material

#### The Supplementary Material for this article can be found online at:

https://www.frontiersin.org/articles/10.3389/fpsyg.2020.00920/full#supplementary-material

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#supplementary-material

Supplementary Materials

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#SM1

of this manuscript include:

Tables S1-S6

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#SM1

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#SM1

contains the inclusion and exclusion criteria used for article selection.

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#SM1

outlines the application of the PICO (S, T) framework for this review.

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#SM1

depicts the data extraction sheet layout and contains all the extracted data for this systematic review.

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#SM1

outlines the typology for the purpose, stimuli, and validation method categories used in this review.

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#SM1

contains the definitions and interpretations of key words and frequently used terms in this systematic review.

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#SM1

outlines the AUs investigated and/or reported on and their identified emotional interpretation by study.

1 Agrawal N. Han D. Duhachek A. ( 2013). Emotional agency appraisals influence responses to preference inconsistent information.

Organ. Behav. Hum. Decis. Process.

120, 87– 97. 10.1016/j.obhdp.2012.10.001

https://doi.org/10.1016/j.obhdp.2012.10.001

Google Scholar

http://scholar.google.com/scholar\_lookup?author=N..%2BAgrawal&author=D..%2BHan&author=A..%2BDuhachek&publication\_year=2013&title=Emotional%2Bagency%2Bappraisals%2Binfluence%2Bresponses%2Bto%2Bpreference%2Binconsistent%2Binformation&journal=Organ.+Behav.+Hum.+Decis.+Process.&volume=120&pages=87-97

2 Agrawal N. Menon G. Aaker J. L. ( 2007). Getting emotional about health.

J. Mark. Res.

44, 100– 113. 10.1509/jmkr.44.1.100

https://doi.org/10.1509/jmkr.44.1.100

Google Scholar

http://scholar.google.com/scholar\_lookup?author=N..%2BAgrawal&author=G..%2BMenon&author=J.%2BL..%2BAaker&publication\_year=2007&title=Getting%2Bemotional%2Babout%2Bhealth&journal=J.+Mark.+Res.&volume=44&pages=100-113

3 Alves N. T. Aznar-Casanova J. A. Fukusima S. S. ( 2009). Patterns of brain asymmetry in the perception of positive and negative facial expressions.

Laterality14

, 256– 272. 10.1080/13576500802362927

Pubmed Abstract

https://pubmed.ncbi.nlm.nih.gov/18942002

https://doi.org/10.1080/13576500802362927

Google Scholar

http://scholar.google.com/scholar\_lookup?author=N.%2BT..%2BAlves&author=J.%2BA..%2BAznar-Casanova&author=S.%2BS..%2BFukusima&publication\_year=2009&title=Patterns%2Bof%2Bbrain%2Basymmetry%2Bin%2Bthe%2Bperception%2Bof%2Bpositive%2Band%2Bnegative%2Bfacial%2Bexpressions&journal=Laterality&volume=14&pages=256-272

4 Avenanti A. Bueti D. Galati G. Aglioti S. M. ( 2005). Transcranial magnetic stimulation highlights the sensorimotor side of empathy for pain.

Nat. Neurosci.

8, 955– 960. 10.1038/nn1481

Pubmed Abstract

https://pubmed.ncbi.nlm.nih.gov/15937484

https://doi.org/10.1038/nn1481

Google Scholar

http://scholar.google.com/scholar\_lookup?author=A..%2BAvenanti&author=D..%2BBueti&author=G..%2BGalati&author=S.%2BM..%2BAglioti&publication\_year=2005&title=Transcranial%2Bmagnetic%2Bstimulation%2Bhighlights%2Bthe%2Bsensorimotor%2Bside%2Bof%2Bempathy%2Bfor%2Bpain&journal=Nat.+Neurosci.&volume=8&pages=955-960

5 Baker J. K. Haltigan J. D. Messinger D. S. ( 2010). Non-expert ratings of infant and parent emotion: Concordance with expert coding and relevance to early autism risk.

Int. J. Behav. Dev.

34, 88– 95. 10.1177/0165025409350365

Pubmed Abstract

https://pubmed.ncbi.nlm.nih.gov/20436947

https://doi.org/10.1177/0165025409350365

Google Scholar

http://scholar.google.com/scholar\_lookup?author=J.%2BK..%2BBaker&author=J.%2BD..%2BHaltigan&author=D.%2BS..%2BMessinger&publication\_year=2010&title=Non-expert%2Bratings%2Bof%2Binfant%2Band%2Bparent%2Bemotion%3A%2BConcordance%2Bwith%2Bexpert%2Bcoding%2Band%2Brelevance%2Bto%2Bearly%2Bautism%2Brisk&journal=Int.+J.+Behav.+Dev.&volume=34&pages=88-95

6 Balzarotti S. Piccini L. Andreoni G. Ciceri R. ( 2014). “I know that you know how I feel”: Behavioral and physiological signals demonstrate emotional attunement while interacting with a computer simulating emotional intelligence.

J. Nonverbal. Behav.

38, 283– 299. 10.1007/s10919-014-0180-6

https://doi.org/10.1007/s10919-014-0180-6

Google Scholar

http://scholar.google.com/scholar\_lookup?author=S..%2BBalzarotti&author=L..%2BPiccini&author=G..%2BAndreoni&author=R..%2BCiceri&publication\_year=2014&title=%E2%80%9CI%2Bknow%2Bthat%2Byou%2Bknow%2Bhow%2BI%2Bfeel%E2%80%9D%3A%2BBehavioral%2Band%2Bphysiological%2Bsignals%2Bdemonstrate%2Bemotional%2Battunement%2Bwhile%2Binteracting%2Bwith%2Ba%2Bcomputer%2Bsimulating%2Bemotional%2Bintelligence&journal=J.+Nonverbal.+Behav.&volume=38&pages=283-299

7 Barrett L. F. Adolphs R. Marsella S. Martinez A. M. Pollak S. D. ( 2019). Emotional expressions reconsidered: challenges to inferring emotion from human facial movements.

Psychol. Sci. Public Interest

20, 1– 68. 10.1177/1529100619832930

Pubmed Abstract

https://pubmed.ncbi.nlm.nih.gov/31313636

https://doi.org/10.1177/1529100619832930

Google Scholar

http://scholar.google.com/scholar\_lookup?author=L.%2BF..%2BBarrett&author=R..%2BAdolphs&author=S..%2BMarsella&author=A.%2BM..%2BMartinez&author=S.%2BD..%2BPollak&publication\_year=2019&title=Emotional%2Bexpressions%2Breconsidered%3A%2Bchallenges%2Bto%2Binferring%2Bemotion%2Bfrom%2Bhuman%2Bfacial%2Bmovements&journal=Psychol.+Sci.+Public+Interes&volume=20&pages=1-68

8 Bartlett M. S. Movellan J. R. Littlewort G. Braathen B. Frank M. G. ( 2005). Toward automatic recognition of spontaneous facial actions, in

What the Face Reveals: Basic and Applied Studies of Spontaneous Expression Using the Facial Action Coding System (FACS), 2nd Edn

, ed Ekman P. ( New York, NY: Oxford University Press), 393– 426.

Google Scholar

http://scholar.google.com/scholar\_lookup?author=M.%2BS..%2BBartlett&author=J.%2BR..%2BMovellan&author=G..%2BLittlewort&author=B..%2BBraathen&author=M.%2BG..%2BFrank&publication\_year=2005&title=Toward%2Bautomatic%2Brecognition%2Bof%2Bspontaneous%2Bfacial%2Bactions&journal=What+the+Face+Reveals%3A+Basic+and+Applied+Studies+of+Spontaneous+Expression+Using+the+Facial+Action+Coding+System+%28FACS%29%2C+2nd+Edn&pages=393-426

9 Bezerra Alves J. G. Russo P. C. Alves G. V. ( 2013). Facial responses to basic tastes in breastfeeding and formula-feeding infants.

Breastfeed. Med.

8, 235– 236. 10.1089/bfm.2012.0092

Pubmed Abstract

https://pubmed.ncbi.nlm.nih.gov/23390990

https://doi.org/10.1089/bfm.2012.0092

Google Scholar

http://scholar.google.com/scholar\_lookup?author=J.%2BG..%2BBezerra%2BAlves&author=P.%2BC..%2BRusso&author=G.%2BV..%2BAlves&publication\_year=2013&title=Facial%2Bresponses%2Bto%2Bbasic%2Btastes%2Bin%2Bbreastfeeding%2Band%2Bformula-feeding%2Binfants&journal=Breastfeed.+Med.&volume=8&pages=235-236

10 Bishop C. M. ( 1995).

Neural Networks for Pattern Recognition

. New York, NY: Oxford University Press.

Google Scholar

http://scholar.google.com/scholar\_lookup?author=C.%2BM..%2BBishop&publication\_year=1995&journal=Neural+Networks+for+Pattern+Recognition

11 Booth D. A. ( 2014). Measuring sensory and marketing influences on consumers' choices among food and beverage product brands.

Trends Food Sci. Technol.

35, 129– 137. 10.1016/j.tifs.2013.11.002

https://doi.org/10.1016/j.tifs.2013.11.002

Google Scholar

http://scholar.google.com/scholar\_lookup?author=D.%2BA..%2BBooth&publication\_year=2014&title=Measuring%2Bsensory%2Band%2Bmarketing%2Binfluences%2Bon%2Bconsumers%27%2Bchoices%2Bamong%2Bfood%2Band%2Bbeverage%2Bproduct%2Bbrands&journal=Trends+Food+Sci.+Technol.&volume=35&pages=129-137

12 Bradley M. M. ( 2000). Emotion and motivation, in

Handbook of Psychophysiology

, eds, Cacioppo J. T. Tassinary L. G. Berntson G. G. ( New York, NY: Cambridge University Press), 602– 642

Google Scholar

http://scholar.google.com/scholar\_lookup?author=M.%2BM..%2BBradley&publication\_year=2000&title=Emotion%2Band%2Bmotivation&journal=Handbook+of+Psychophysiology&pages=602-642

13 Bradley M. M. Codispoti M. Cuthbert B. N. Lang P. J. ( 2001). Emotion and motivation I: defensive an appetitive reactions in picture processing.

, 276– 298. 10.1037/1528-3542.1.3.276

https://doi.org/10.1037/1528-3542.1.3.276

Google Scholar

http://scholar.google.com/scholar\_lookup?author=M.%2BM..%2BBradley&author=M..%2BCodispoti&author=B.%2BN..%2BCuthbert&author=P.%2BJ..%2BLang&publication\_year=2001&title=Emotion%2Band%2Bmotivation%2BI%3A%2Bdefensive%2Ban%2Bappetitive%2Breactions%2Bin%2Bpicture%2Bprocessing&journal=Emotion&volume=1&pages=276-298

14 Bredie W. L. P. Tan H. S. G. Wendin K. ( 2014). A comparative study on facially expressed emotions in response to basic tastes.

Chemosens. Percept.

7, 1– 9. 10.1007/s12078-014-9163-6

https://doi.org/10.1007/s12078-014-9163-6

Google Scholar

http://scholar.google.com/scholar\_lookup?author=W.%2BL.%2BP..%2BBredie&author=H.%2BS.%2BG..%2BTan&author=K..%2BWendin&publication\_year=2014&title=A%2Bcomparative%2Bstudy%2Bon%2Bfacially%2Bexpressed%2Bemotions%2Bin%2Bresponse%2Bto%2Bbasic%2Btastes&journal=Chemosens.+Percept.&volume=7&pages=1-9

15 Breiter H. C. Block M. Blood A. J. Calder B. Chamberlain L. Lee N. et al. ( 2015). Redefining neuromarketing as an integrated science of influence.

Front. Hum. Neurosci.

8: 1073. 10.3389/fnhum.2014.01073

Pubmed Abstract

https://pubmed.ncbi.nlm.nih.gov/25709573

https://doi.org/10.3389/fnhum.2014.01073

Google Scholar

http://scholar.google.com/scholar\_lookup?author=H.%2BC..%2BBreiter&author=M..%2BBlock&author=A.%2BJ..%2BBlood&author=B..%2BCalder&author=L..%2BChamberlain&author=N..%2BLee&publication\_year=2015&title=Redefining%2Bneuromarketing%2Bas%2Ban%2Bintegrated%2Bscience%2Bof%2Binfluence&journal=Front.+Hum.+Neurosci.&volume=8

16 Brown W. Liu C. John R. M. Ford P. ( 2014). Developing an eBook-integrated high-fidelity mobile app prototype for promoting child motor skills and taxonomically assessing children's emotional responses using face and sound topology.

AMIA Annu. Symp. Proc. AMIA. Symp.

2014, 333– 342.

Pubmed Abstract

https://pubmed.ncbi.nlm.nih.gov/25954336

Google Scholar

http://scholar.google.com/scholar\_lookup?author=W..%2BBrown&author=C..%2BLiu&author=R.%2BM..%2BJohn&author=P..%2BFord&publication\_year=2014&title=Developing%2Ban%2BeBook-integrated%2Bhigh-fidelity%2Bmobile%2Bapp%2Bprototype%2Bfor%2Bpromoting%2Bchild%2Bmotor%2Bskills%2Band%2Btaxonomically%2Bassessing%2Bchildren%27s%2Bemotional%2Bresponses%2Busing%2Bface%2Band%2Bsound%2Btopology&journal=AMIA+Annu.+Symp.+Proc.+AMIA.+Symp.&volume=2014&pages=333-342

17 Carroll J. M. Russell J. A. ( 1996). Do facial expressions express specific emotions? Judging emotion from the face in context.

J. Pers. Soc. Psychol.

70, 205– 218.

Pubmed Abstract

https://pubmed.ncbi.nlm.nih.gov/8636880

Google Scholar

http://scholar.google.com/scholar\_lookup?author=J.%2BM..%2BCarroll&author=J.%2BA..%2BRussell&publication\_year=1996&title=Do%2Bfacial%2Bexpressions%2Bexpress%2Bspecific%2Bemotions%3F%2BJudging%2Bemotion%2Bfrom%2Bthe%2Bface%2Bin%2Bcontext&journal=J.+Pers.+Soc.+Psychol.&volume=70&pages=205-218

18 Catia C. Kun G. Daniel M. ( 2017). Dogs and humans respond to emotionally competent stimuli by producing different facial actions.

7: 15525. 10.1038/s41598-017-15091-4

https://doi.org/10.1038/s41598-017-15091-4

Google Scholar

http://scholar.google.com/scholar\_lookup?author=C..%2BCatia&author=G..%2BKun&author=M..%2BDaniel&publication\_year=2017&title=Dogs%2Band%2Bhumans%2Brespond%2Bto%2Bemotionally%2Bcompetent%2Bstimuli%2Bby%2Bproducing%2Bdifferent%2Bfacial%2Bactions&journal=Sci.+Rep.&volume=7

19 Chapman H. A. Lee D. H. Susskind J. M. Bartlett M. S. Anderson A. K. ( 2017). The face of distaste: a preliminary study.

42: 457– 463. 10.1093/chemse/bjx024

Pubmed Abstract

https://pubmed.ncbi.nlm.nih.gov/28486601

https://doi.org/10.1093/chemse/bjx024

Google Scholar

http://scholar.google.com/scholar\_lookup?author=H.%2BA..%2BChapman&author=D.%2BH..%2BLee&author=J.%2BM..%2BSusskind&author=M.%2BS..%2BBartlett&author=A.%2BK..%2BAnderson&publication\_year=2017&title=The%2Bface%2Bof%2Bdistaste%3A%2Ba%2Bpreliminary%2Bstudy&journal=Chem+Sens.&volume=42&pages=457-463

20 Chavaglia N. J. Filipe J. A. ( 2015). Consumers economic behavior and emotions: the case of iphone 6 in neuromarketing.

Int. J. Latest Trends Finance Econ. Sci.

5: 1041– 1047. 10.2047/ijltfesvol5iss4-1041-1047

https://doi.org/10.2047/ijltfesvol5iss4-1041-1047

Google Scholar

http://scholar.google.com/scholar\_lookup?author=N.%2BJ..%2BChavaglia&author=J.%2BA..%2BFilipe&publication\_year=2015&title=Consumers%2Beconomic%2Bbehavior%2Band%2Bemotions%3A%2Bthe%2Bcase%2Bof%2Biphone%2B6%2Bin%2Bneuromarketing&journal=Int.+J.+Latest+Trends+Finance+Econ.+Sci.&volume=5&pages=1041-1047

21 Coan J. A. Allen J. J. B. Harmon-Jones E. ( 2001). Voluntary facial expression and hemispheric asymmetry over the frontal cortex.

Psychophysiology38

, 912– 925. 10.1111/1469-8986.3860912

Pubmed Abstract

https://pubmed.ncbi.nlm.nih.gov/12240668

https://doi.org/10.1111/1469-8986.3860912

Google Scholar

http://scholar.google.com/scholar\_lookup?author=J.%2BA..%2BCoan&author=J.%2BJ.%2BB..%2BAllen&author=E..%2BHarmon-Jones&publication\_year=2001&title=Voluntary%2Bfacial%2Bexpression%2Band%2Bhemispheric%2Basymmetry%2Bover%2Bthe%2Bfrontal%2Bcortex&journal=Psychophysiology&volume=38&pages=912-925

22 Codispoti M. Ferrari V. Bradley M. M. ( 2006). Repetitive picture processing: autonomoic and cortical correlates.

213– 220. 10.1016/j.brainres.2005.11.009

Pubmed Abstract

https://pubmed.ncbi.nlm.nih.gov/16403475

https://doi.org/10.1016/j.brainres.2005.11.009

Google Scholar

http://scholar.google.com/scholar\_lookup?author=M..%2BCodispoti&author=V..%2BFerrari&author=M.%2BM..%2BBradley&publication\_year=2006&title=Repetitive%2Bpicture%2Bprocessing%3A%2Bautonomoic%2Band%2Bcortical%2Bcorrelates&journal=Brain+Res.&pages=213-220

23 Codispoti M. Mazzetti M. Bradley M. M. ( 2009). Unmasking emotion: exposure duration and emotional engagement.

Psychophysiology46

, 731– 738. 10.1111/j.1469-8986.2009.00804.x

Pubmed Abstract

https://pubmed.ncbi.nlm.nih.gov/19386053

https://doi.org/10.1111/j.1469-8986.2009.00804.x

Google Scholar

http://scholar.google.com/scholar\_lookup?author=M..%2BCodispoti&author=M..%2BMazzetti&author=M.%2BM..%2BBradley&publication\_year=2009&title=Unmasking%2Bemotion%3A%2Bexposure%2Bduration%2Band%2Bemotional%2Bengagement&journal=Psychophysiology&volume=46&pages=731-738

24 Cohn J. Schmidt K. Gross R. Ekman P. ( 2002). Individual differences in facial expression: stability over time, relation to self-reported emotion, and ability to inform person identification, in Fourth

IEEE International Conference on Multimodal Interfaces

( Pittsburgh, PA), 491– 496.

Google Scholar

http://scholar.google.com/scholar\_lookup?author=J..%2BCohn&author=K..%2BSchmidt&author=R..%2BGross&author=P..%2BEkman&publication\_year=2002&title=Individual%2Bdifferences%2Bin%2Bfacial%2Bexpression%3A%2Bstability%2Bover%2Btime%2C%2Brelation%2Bto%2Bself-reported%2Bemotion%2C%2Band%2Bability%2Bto%2Binform%2Bperson%2Bidentification&journal=IEEE+International+Conference+on+Multimodal+Interfaces&pages=491-496

25 Cohn J. F. Ambadar Z. Ekman P. ( 2007). Observer-based measurement of facial expression with the facial action coding system, in

Handbook of Emotion Elicitation and Assessment

, eds Coan A. Allen J. J. B. ( New York, NY: Oxford University Press), 203– 221.

Google Scholar

http://scholar.google.com/scholar\_lookup?author=J.%2BF..%2BCohn&author=Z..%2BAmbadar&author=P..%2BEkman&publication\_year=2007&title=Observer-based%2Bmeasurement%2Bof%2Bfacial%2Bexpression%2Bwith%2Bthe%2Bfacial%2Baction%2Bcoding%2Bsystem&journal=Handbook+of+Emotion+Elicitation+and+Assessment&pages=203-221

26 Cole P. M. Zahn-Waxler C. Smith K. D. ( 1994). Expressive control during a disappointment: variations related to preschoolers' behavior problems.

Dev. Psychol.

30, 835– 846. 10.1037/0012-1649.30.6.835

https://doi.org/10.1037/0012-1649.30.6.835

Google Scholar

http://scholar.google.com/scholar\_lookup?author=P.%2BM..%2BCole&author=C..%2BZahn-Waxler&author=K.%2BD..%2BSmith&publication\_year=1994&title=Expressive%2Bcontrol%2Bduring%2Ba%2Bdisappointment%3A%2Bvariations%2Brelated%2Bto%2Bpreschoolers%27%2Bbehavior%2Bproblems&journal=Dev.+Psychol.&volume=30&pages=835-846

27 Coombes S. A. Janelle C. M. Duley A. R. ( 2005). Emotion and motor control: movement attributes following affective picture processing.

J. Mot. Behav.

37, 425– 436. 10.3200/JMBR.37.6.425-436

Pubmed Abstract

https://pubmed.ncbi.nlm.nih.gov/16280313

https://doi.org/10.3200/JMBR.37.6.425-436

Google Scholar

http://scholar.google.com/scholar\_lookup?author=S.%2BA..%2BCoombes&author=C.%2BM..%2BJanelle&author=A.%2BR..%2BDuley&publication\_year=2005&title=Emotion%2Band%2Bmotor%2Bcontrol%3A%2Bmovement%2Battributes%2Bfollowing%2Baffective%2Bpicture%2Bprocessing&journal=J.+Mot.+Behav.&volume=37&pages=425-436

28 Cootes T. Taylor C. ( 2000).

Statistical models of appearance for Computer Vision

. Manchester : Wolfson Image Analysis Unit, Imaging Science and Biomedical Engineering, University of Manchester.

Pubmed Abstract

https://pubmed.ncbi.nlm.nih.gov/9304693

Google Scholar

http://scholar.google.com/scholar\_lookup?author=T..%2BCootes&author=C..%2BTaylor&publication\_year=2000&journal=Statistical+models+of+appearance+for+Computer+Vision

29 Craig S. D. D'Mello S. Witherspoon A. Graesser A. ( 2008). Emote aloud during learning with autotutor: applying the facial action coding system to cognitive-affective states during learning.

Cogn. Emot.

22, 777– 788. 10.1080/02699930701516759

https://doi.org/10.1080/02699930701516759

Google Scholar

http://scholar.google.com/scholar\_lookup?author=S.%2BD..%2BCraig&author=S..%2BD%27Mello&author=A..%2BWitherspoon&author=A..%2BGraesser&publication\_year=2008&title=Emote%2Baloud%2Bduring%2Blearning%2Bwith%2Bautotutor%3A%2Bapplying%2Bthe%2Bfacial%2Baction%2Bcoding%2Bsystem%2Bto%2Bcognitive-affective%2Bstates%2Bduring%2Blearning&journal=Cogn.+Emot.&volume=22&pages=777-788

30 Crist C. A. Duncan S. E. Gallagher D. L. ( 2016). Protocol for data collection and analysis applied to automated facial expression analysis technology and temporal analysis for sensory evaluation.

J. Vis. Exp

. 26: 54046. 10.3791/54046

Pubmed Abstract

https://pubmed.ncbi.nlm.nih.gov/27685862

https://doi.org/10.3791/54046

Google Scholar

http://scholar.google.com/scholar\_lookup?author=C.%2BA..%2BCrist&author=S.%2BE..%2BDuncan&author=D.%2BL..%2BGallagher&publication\_year=2016&title=Protocol%2Bfor%2Bdata%2Bcollection%2Band%2Banalysis%2Bapplied%2Bto%2Bautomated%2Bfacial%2Bexpression%2Banalysis%2Btechnology%2Band%2Btemporal%2Banalysis%2Bfor%2Bsensory%2Bevaluation&journal=J.+Vis.+Exp&volume=26

31 Dale J. A. Hudak M. A. Wasikowski P. ( 1991). Effects of dyadic participation and awareness of being monitored on facial action during exposure to humor.

Percept. Mot. Skills73

, 984– 986. 10.2466/PMS.73.7.984-986

https://doi.org/10.2466/PMS.73.7.984-986

Google Scholar

http://scholar.google.com/scholar\_lookup?author=J.%2BA..%2BDale&author=M.%2BA..%2BHudak&author=P..%2BWasikowski&publication\_year=1991&title=Effects%2Bof%2Bdyadic%2Bparticipation%2Band%2Bawareness%2Bof%2Bbeing%2Bmonitored%2Bon%2Bfacial%2Baction%2Bduring%2Bexposure%2Bto%2Bhumor&journal=Percept.+Mot.+Skills&volume=73&pages=984-986

32 Danner L. Haindl S. Joechl M. Duerrschmid K. ( 2014a). Facial expressions and autonomous nervous system responses elicited by tasting different juices.

Food Res. Int.

64, 81– 90. 10.1016/j.foodres.2014.06.003

Pubmed Abstract

https://pubmed.ncbi.nlm.nih.gov/30011719

https://doi.org/10.1016/j.foodres.2014.06.003

Google Scholar

http://scholar.google.com/scholar\_lookup?author=L..%2BDanner&author=S..%2BHaindl&author=M..%2BJoechl&author=K..%2BDuerrschmid&publication\_year=2014a&title=Facial%2Bexpressions%2Band%2Bautonomous%2Bnervous%2Bsystem%2Bresponses%2Belicited%2Bby%2Btasting%2Bdifferent%2Bjuices&journal=Food+Res.+Int.&volume=64&pages=81-90

33 Danner L. Sidorkina L. Joechl M. Duerrschmid K. ( 2014b). Make a face! Implicit and explicit measurement of facial expressions elicited by orange juices using face reading technology.

Food Qual. Prefer.

32, 167– 172. 10.1016/j.foodqual.2013.01.004

https://doi.org/10.1016/j.foodqual.2013.01.004

Google Scholar

http://scholar.google.com/scholar\_lookup?author=L..%2BDanner&author=L..%2BSidorkina&author=M..%2BJoechl&author=K..%2BDuerrschmid&publication\_year=2014b&title=Make%2Ba%2Bface%21%2BImplicit%2Band%2Bexplicit%2Bmeasurement%2Bof%2Bfacial%2Bexpressions%2Belicited%2Bby%2Borange%2Bjuices%2Busing%2Bface%2Breading%2Btechnology&journal=Food+Qual.+Prefer.&volume=32&pages=167-172

34 Davidson R. J. ( 1984). Affect, cognition, and hemispheric specialization, in

Emotions, Cognitions, and Behaviors

, eds Izard C. E. Kagan J. Zajonc R. B. ( New York, NY: Cambridge University Press), 320– 365.

Google Scholar

http://scholar.google.com/scholar\_lookup?author=R.%2BJ..%2BDavidson&publication\_year=1984&title=Affect%2C%2Bcognition%2C%2Band%2Bhemispheric%2Bspecialization&journal=Emotions%2C+Cognitions%2C+and+Behaviors&pages=320-365

35 de Hooge I. E. Breugelmans S. M. Zeelenberg M. ( 2008). Not so ugly after all: when shame acts as a commitment device.

J. Pers. Soc. Psychol.

95, 933– 943. 10.1037/a0011991

Pubmed Abstract

https://pubmed.ncbi.nlm.nih.gov/18808269

https://doi.org/10.1037/a0011991

Google Scholar

http://scholar.google.com/scholar\_lookup?author=I.%2BE..%2Bde%2BHooge&author=S.%2BM..%2BBreugelmans&author=M..%2BZeelenberg&publication\_year=2008&title=Not%2Bso%2Bugly%2Bafter%2Ball%3A%2Bwhen%2Bshame%2Bacts%2Bas%2Ba%2Bcommitment%2Bdevice&journal=J.+Pers.+Soc.+Psychol.&volume=95&pages=933-943

36 de Mello G. MacInnis D. J. Stewart D. W. ( 2007). Threats to hope: effects on reasoning about product information.

J. Consum. Res.

34, 153– 161. 10.1086/519144

Pubmed Abstract

https://pubmed.ncbi.nlm.nih.gov/27409075

https://doi.org/10.1086/519144

Google Scholar

http://scholar.google.com/scholar\_lookup?author=G..%2Bde%2BMello&author=D.%2BJ..%2BMacInnis&author=D.%2BW..%2BStewart&publication\_year=2007&title=Threats%2Bto%2Bhope%3A%2Beffects%2Bon%2Breasoning%2Babout%2Bproduct%2Binformation&journal=J.+Consum.+Res.&volume=34&pages=153-161

37 de Wijk R. A. He W. Mensink M. G. J. Verhoeven R. H. G. de Graaf C. Matsunami H. ( 2014). ANS responses and facial expressions differentiate between the taste of commercial breakfast drinks.

: e93823. 10.1371/journal.pone.0093823

Pubmed Abstract

https://pubmed.ncbi.nlm.nih.gov/24714107

https://doi.org/10.1371/journal.pone.0093823

Google Scholar

http://scholar.google.com/scholar\_lookup?author=R.%2BA..%2Bde%2BWijk&author=W..%2BHe&author=M.%2BG.%2BJ..%2BMensink&author=R.%2BH.%2BG..%2BVerhoeven&author=C..%2Bde%2BGraaf&author=H..%2BMatsunami&publication\_year=2014&title=ANS%2Bresponses%2Band%2Bfacial%2Bexpressions%2Bdifferentiate%2Bbetween%2Bthe%2Btaste%2Bof%2Bcommercial%2Bbreakfast%2Bdrinks&journal=PLoS+ONE&volume=9

38 de Wijk R. A. Kooijman V. Verhoeven R. H. G. Holthuysen N. T. E. de Graaf C. ( 2012). Autonomic nervous system responses on and facial expressions to the sight, smell, and taste of liked and disliked foods.

Food Qual. Prefer.

26, 196– 203. 10.1016/j.foodqual.2012.04.015

https://doi.org/10.1016/j.foodqual.2012.04.015

Google Scholar

http://scholar.google.com/scholar\_lookup?author=R.%2BA..%2Bde%2BWijk&author=V..%2BKooijman&author=R.%2BH.%2BG..%2BVerhoeven&author=N.%2BT.%2BE..%2BHolthuysen&author=C..%2Bde%2BGraaf&publication\_year=2012&title=Autonomic%2Bnervous%2Bsystem%2Bresponses%2Bon%2Band%2Bfacial%2Bexpressions%2Bto%2Bthe%2Bsight%2C%2Bsmell%2C%2Band%2Btaste%2Bof%2Bliked%2Band%2Bdisliked%2Bfoods&journal=Food+Qual.+Prefer.&volume=26&pages=196-203

39 Desmet P. M. A. Schifferstein H. N. J. ( 2008). Sources of positive and negative emotions in food experience.

, 290– 301. 10.1016/j.appet.2007.08.003

Pubmed Abstract

https://pubmed.ncbi.nlm.nih.gov/17945385

https://doi.org/10.1016/j.appet.2007.08.003

Google Scholar

http://scholar.google.com/scholar\_lookup?author=P.%2BM.%2BA..%2BDesmet&author=H.%2BN.%2BJ..%2BSchifferstein&publication\_year=2008&title=Sources%2Bof%2Bpositive%2Band%2Bnegative%2Bemotions%2Bin%2Bfood%2Bexperience&journal=Appetite&volume=50&pages=290-301

40 D'Mello S. K. Graesser A. ( 2010). Multimodal semi-automated affect detection from conversational cues, gross body language, and facial features.

User Model User Adapt. Interact.

20, 147– 187. 10.1007/s11257-010-9074-4

https://doi.org/10.1007/s11257-010-9074-4

Google Scholar

http://scholar.google.com/scholar\_lookup?author=S.%2BK..%2BD%27Mello&author=A..%2BGraesser&publication\_year=2010&title=Multimodal%2Bsemi-automated%2Baffect%2Bdetection%2Bfrom%2Bconversational%2Bcues%2C%2Bgross%2Bbody%2Blanguage%2C%2Band%2Bfacial%2Bfeatures&journal=User+Model+User+Adapt.+Interact.&volume=20&pages=147-187

41 D'Mello S. K. raesser A. C. ( 2014). Confusion, in

International Handbook of Emotions in Education

, eds Pekrun R. Linnenbrink-Garcia L. ( New York, NY: Routledge; Taylor & Francis Group), 289– 310.

Google Scholar

http://scholar.google.com/scholar\_lookup?author=S.%2BK..%2BD%27Mello&author=A.%2BC..%2Braesser&publication\_year=2014&title=Confusion&journal=International+Handbook+of+Emotions+in+Education&pages=289-310

42 Dosmukhambetova D. Manstead A. S. R. ( 2012). Fear attenuated and affection augmented: Male self-presentation in a romantic context.

J. Nonverbal. Behav.

36, 135– 147. 10.1007/s10919-011-0126-1

https://doi.org/10.1007/s10919-011-0126-1

Google Scholar

http://scholar.google.com/scholar\_lookup?author=D..%2BDosmukhambetova&author=A.%2BS.%2BR..%2BManstead&publication\_year=2012&title=Fear%2Battenuated%2Band%2Baffection%2Baugmented%3A%2BMale%2Bself-presentation%2Bin%2Ba%2Bromantic%2Bcontext&journal=J.+Nonverbal.+Behav.&volume=36&pages=135-147

43 Duerrschmid K. Danner L. ( 2018). Eye tracking in consumer research, in eds Ares G. Varela P.

Methods in Consumer Research, Vol. 2

( Elsevier), 279– 318. 10.1016/C2015-0-06109-3

Pubmed Abstract

https://pubmed.ncbi.nlm.nih.gov/29580530

https://doi.org/10.1016/C2015-0-06109-3

Google Scholar

http://scholar.google.com/scholar\_lookup?author=K..%2BDuerrschmid&author=L..%2BDanner&publication\_year=2018&title=Eye%2Btracking%2Bin%2Bconsumer%2Bresearch&journal=Methods+in+Consumer+Research%2C+Vol.+2&pages=279-318

44 Ekman P. ( 2009). Telling Lies: Clues to Deceit in the Marketplace, Politics, and Marriage, 4th Edn. New York, NY: W.W. Norton.

Google Scholar

http://scholar.google.com/scholar\_lookup?author=P..%2BEkman&publication\_year=2009&title=Telling%2BLies%3A%2BClues%2Bto%2BDeceit%2Bin%2Bthe%2BMarketplace%2C%2BPolitics%2C%2Band%2BMarriage

45 Ekman P. Freisen W. V. Ancoli S. ( 1980). Facial signs of emotional experience.

J. Pers. Soc. Psychol.

39, 1125– 1134. 10.1037/h0077722

https://doi.org/10.1037/h0077722

Google Scholar

http://scholar.google.com/scholar\_lookup?author=P..%2BEkman&author=W.%2BV..%2BFreisen&author=S..%2BAncoli&publication\_year=1980&title=Facial%2Bsigns%2Bof%2Bemotional%2Bexperience&journal=J.+Pers.+Soc.+Psychol.&volume=39&pages=1125-1134

46 Ekman P. Friesen W. V. ( 1976). Measuring facial movement.

Environ. Psychol. Nonverbal. Behav.

1, 56– 75. 10.1007/BF01115465

https://doi.org/10.1007/BF01115465

Google Scholar

http://scholar.google.com/scholar\_lookup?author=P..%2BEkman&author=W.%2BV..%2BFriesen&publication\_year=1976&title=Measuring%2Bfacial%2Bmovement&journal=Environ.+Psychol.+Nonverbal.+Behav.&volume=1&pages=56-75

47 Ekman P. Friesen W. V. ( 1978).

Facial Action Coding System: A Technique for the Measurement of Facial Movement

. California, CA: Consulting Psychologists Press, Palo Alto.

Pubmed Abstract

https://pubmed.ncbi.nlm.nih.gov/10194972

Google Scholar

http://scholar.google.com/scholar\_lookup?author=P..%2BEkman&author=W.%2BV..%2BFriesen&publication\_year=1978&journal=Facial+Action+Coding+System%3A+A+Technique+for+the+Measurement+of+Facial+Movement

48 Ekman P. Friesen W. V. Ellsworth P. ( 1972).

Emotion in the Human face: Guide-Lines for Research and an Integration of Findings

. Pergamon Press, New York, NY

Google Scholar

http://scholar.google.com/scholar\_lookup?author=P..%2BEkman&author=W.%2BV..%2BFriesen&author=P..%2BEllsworth&publication\_year=1972&journal=Emotion+in+the+Human+face%3A+Guide-Lines+for+Research+and+an+Integration+of+Findings

49 Ekman P. Friesen W. V. Hager J. C. ( 2002).

The Facial Action Coding System: A Technique for the Measurement of Facial Movement

. San Francisco, CA: Consulting Psychologists Press.

Pubmed Abstract

https://pubmed.ncbi.nlm.nih.gov/10194972

Google Scholar

http://scholar.google.com/scholar\_lookup?author=P..%2BEkman&author=W.%2BV..%2BFriesen&author=J.%2BC..%2BHager&publication\_year=2002&journal=The+Facial+Action+Coding+System%3A+A+Technique+for+the+Measurement+of+Facial+Movement

50 Ekman P. Rosenberg E. L. ( 2005). What the Face Reveals: Basic and Applied Studies of Spontaneous Expression Using the Facial Action Coding System (FACS), 2nd Edn. New York, NY: Oxford University Press.

Google Scholar

http://scholar.google.com/scholar\_lookup?author=P..%2BEkman&author=E.%2BL..%2BRosenberg&publication\_year=2005&title=What%2Bthe%2BFace%2BReveals%3A%2BBasic%2Band%2BApplied%2BStudies%2Bof%2BSpontaneous%2BExpression%2BUsing%2Bthe%2BFacial%2BAction%2BCoding%2BSystem%2B%28FACS%29

51 Ekman P. Rosenberg E. L. Hager J. C. ( 1998).

Facial Action Coding System Interpretive Database (FACSAID).

San Francisco, CA: Unpubl Manuscr Univ Calif San Franc Hum Interact Lab.

Google Scholar

http://scholar.google.com/scholar\_lookup?author=P..%2BEkman&author=E.%2BL..%2BRosenberg&author=J.%2BC..%2BHager&publication\_year=1998&journal=Facial+Action+Coding+System+Interpretive+Database+%28FACSAID%29.

52 Espinosa-Aranda J. Vallez N. Rico-Saavedra J. Parra-Patino J. Bueno G. ( 2018). Smart doll: emotion recognition using embedded deep learning.

: 387. 10.3390/sym10090387

https://doi.org/10.3390/sym10090387

Google Scholar

http://scholar.google.com/scholar\_lookup?author=J..%2BEspinosa-Aranda&author=N..%2BVallez&author=J..%2BRico-Saavedra&author=J..%2BParra-Patino&author=G..%2BBueno&publication\_year=2018&title=Smart%2Bdoll%3A%2Bemotion%2Brecognition%2Busing%2Bembedded%2Bdeep%2Blearning&journal=Symmetry&volume=10

53 Forestell C. A. Mennella J. A. ( 2012). More than just a pretty face. The relationship between infant's temperament, food acceptance, and mothers' perceptions of their enjoyment of food.

, 1136– 1142. 10.1016/j.appet.2012.03.005

Pubmed Abstract

https://pubmed.ncbi.nlm.nih.gov/22407135

https://doi.org/10.1016/j.appet.2012.03.005

Google Scholar

http://scholar.google.com/scholar\_lookup?author=C.%2BA..%2BForestell&author=J.%2BA..%2BMennella&publication\_year=2012&title=More%2Bthan%2Bjust%2Ba%2Bpretty%2Bface.%2BThe%2Brelationship%2Bbetween%2Binfant%27s%2Btemperament%2C%2Bfood%2Bacceptance%2C%2Band%2Bmothers%27%2Bperceptions%2Bof%2Btheir%2Benjoyment%2Bof%2Bfood&journal=Appetite&volume=58&pages=1136-1142

54 Frank M. G. Ekman P. Friesen W. V. ( 1997). Behavioral Markers and Recognizability of the Smile of Enjoyment. New York, NY: Oxford University Press.

Pubmed Abstract

https://pubmed.ncbi.nlm.nih.gov/8421253

Google Scholar

http://scholar.google.com/scholar\_lookup?author=M.%2BG..%2BFrank&author=P..%2BEkman&author=W.%2BV..%2BFriesen&publication\_year=1997&title=Behavioral%2BMarkers%2Band%2BRecognizability%2Bof%2Bthe%2BSmile%2Bof%2BEnjoyment

55 Garcia-Burgos D. Zamora M. C. ( 2013). Facial affective reactions to bitter-tasting foods and body mass index in adults.

, 178– 186. 10.1016/j.appet.2013.08.013

Pubmed Abstract

https://pubmed.ncbi.nlm.nih.gov/23994505

https://doi.org/10.1016/j.appet.2013.08.013

Google Scholar

http://scholar.google.com/scholar\_lookup?author=D..%2BGarcia-Burgos&author=M.%2BC..%2BZamora&publication\_year=2013&title=Facial%2Baffective%2Breactions%2Bto%2Bbitter-tasting%2Bfoods%2Band%2Bbody%2Bmass%2Bindex%2Bin%2Badults&journal=Appetite&volume=71&pages=178-186

56 Garg N. Inman J. J. Mittal V. ( 2005). Incidental and task-related affect: a re-inquiry and extension of the influence of affect on choice.

J. Consum. Res.

32, 154– 159. 10.1086/426624

https://doi.org/10.1086/426624

Google Scholar

http://scholar.google.com/scholar\_lookup?author=N..%2BGarg&author=J.%2BJ..%2BInman&author=V..%2BMittal&publication\_year=2005&title=Incidental%2Band%2Btask-related%2Baffect%3A%2Ba%2Bre-inquiry%2Band%2Bextension%2Bof%2Bthe%2Binfluence%2Bof%2Baffect%2Bon%2Bchoice&journal=J.+Consum.+Res.&volume=32&pages=154-159

57 Graesser A. McDaniel B. Witherspoon A. M. ( 2006). Detection of Emotions during Learning with AutoTutor.

https://www.bing.com/search?q=detection+of+emotions+during+learning+with+autotutor&form=EDGTCT&qs=PF&cvid=ae4f4277bb6b4635b3a68df071463f66&refig=040b2af9572d48dda32b988afccd2fbc&cc=IN&setlang=en-US&DAF0=1&plvar=0

https://www.bing.com/search?q=detection+of+emotions+during+learning+with+autotutor&form=EDGTCT&qs=PF&cvid=ae4f4277bb6b4635b3a68df071463f66&refig=040b2af9572d48dda32b988afccd2fbc&cc=IN&setlang=en-US&DAF0=1&plvar=0

Google Scholar

http://scholar.google.com/scholar\_lookup?author=A..%2BGraesser&author=B..%2BMcDaniel&author=A.%2BM..%2BWitherspoon&publication\_year=2006&title=Detection%2Bof%2BEmotions%2Bduring%2BLearning%2Bwith%2BAutoTutor

58 Grafsgaard J. F. Boyer K. E. Phillips R. Lester J. C. ( 2011) Modeling confusion: facial expression, task, discourse in task-oriented tutorial dialogue, in

Artificial Intelligence in Education. AIED 2011. Lecture Notes in Computer Science

, eds Biswas G. Bull S. Kay J. Mitrovic A. ( Springer, Berlin, Heidelberg), 122– 129.

Google Scholar

http://scholar.google.com/scholar\_lookup?author=J.%2BF..%2BGrafsgaard&author=K.%2BE..%2BBoyer&author=R..%2BPhillips&author=J.%2BC..%2BLester&publication\_year=2011&title=Modeling%2Bconfusion%3A%2Bfacial%2Bexpression%2C%2Btask%2C%2Bdiscourse%2Bin%2Btask-oriented%2Btutorial%2Bdialogue&journal=Artificial+Intelligence+in+Education.+AIED+2011.+Lecture+Notes+in+Computer+Science&pages=122-129

59 Grafsgaard J. Wiggins J. Boyer K. Wiebe E. N. Lester J. C. ( 2014). Predicting learning and affect from multimodal data streams in task-oriented tutorial dialogue, in

Proceedings of the 7th International Conference on Educational Data Mining

, 122– 129.

Google Scholar

http://scholar.google.com/scholar\_lookup?author=J..%2BGrafsgaard&author=J..%2BWiggins&author=K..%2BBoyer&author=E.%2BN..%2BWiebe&author=J.%2BC..%2BLester&publication\_year=2014&title=Predicting%2Blearning%2Band%2Baffect%2Bfrom%2Bmultimodal%2Bdata%2Bstreams%2Bin%2Btask-oriented%2Btutorial%2Bdialogue&journal=Proceedings+of+the+7th+International+Conference+on+Educational+Data+Mining&pages=122-129

60 Grafsgaard J. F. Wiggins J. B. Boyer K. E. Wiebe E. N. Lester J. C. ( 2013). Automatically recognizing facial indicators of frustration: a learning-centric analysis, in

2013 Hum Assoc Conf Affect Comput Intell Interact ACIISE Int Conf Affect Comput Intell Nteraction

, 159– 165.

Google Scholar

http://scholar.google.com/scholar\_lookup?author=J.%2BF..%2BGrafsgaard&author=J.%2BB..%2BWiggins&author=K.%2BE..%2BBoyer&author=E.%2BN..%2BWiebe&author=J.%2BC..%2BLester&publication\_year=2013&title=Automatically%2Brecognizing%2Bfacial%2Bindicators%2Bof%2Bfrustration%3A%2Ba%2Blearning-centric%2Banalysis&journal=2013+Hum+Assoc+Conf+Affect+Comput+Intell+Interact+ACIISE+Int+Conf+Affect+Comput+Intell+Nteraction&pages=159-165

61 Greimel E. Macht M. Krumhuber E. Ellgring H. ( 2006). Facial and affective reactions to tastes and their modulation by sadness and joy.

Physiol. Behav.

89, 261– 269. 10.1016/j.physbeh.2006.06.002

Pubmed Abstract

https://pubmed.ncbi.nlm.nih.gov/16857218

https://doi.org/10.1016/j.physbeh.2006.06.002

Google Scholar

http://scholar.google.com/scholar\_lookup?author=E..%2BGreimel&author=M..%2BMacht&author=E..%2BKrumhuber&author=H..%2BEllgring&publication\_year=2006&title=Facial%2Band%2Baffective%2Breactions%2Bto%2Btastes%2Band%2Btheir%2Bmodulation%2Bby%2Bsadness%2Band%2Bjoy&journal=Physiol.+Behav.&volume=89&pages=261-269

62 Griffin K. M. Sayette M. A. ( 2008). Facial reactions to smoking cues relate to ambivalence about smoking.

Psychol. Addict. Behav. J.

22, 551– 556. 10.1037/0893-164X.22.4.551

Pubmed Abstract

https://pubmed.ncbi.nlm.nih.gov/19071980

https://doi.org/10.1037/0893-164X.22.4.551

Google Scholar

http://scholar.google.com/scholar\_lookup?author=K.%2BM..%2BGriffin&author=M.%2BA..%2BSayette&publication\_year=2008&title=Facial%2Breactions%2Bto%2Bsmoking%2Bcues%2Brelate%2Bto%2Bambivalence%2Babout%2Bsmoking&journal=Psychol.+Addict.+Behav.+J.&volume=22&pages=551-556

63 Gunes H. Celiktutan O. Sariyanidi E. ( 2019). Live human-robot interactive public demonstrations with automatic emotion and personality prediction.

Philos. Trans. R. Soc. Lond. B Biol. Sci.

374: 20180026. 10.1098/rstb.2018.0026

Pubmed Abstract

https://pubmed.ncbi.nlm.nih.gov/30853000

https://doi.org/10.1098/rstb.2018.0026

Google Scholar

http://scholar.google.com/scholar\_lookup?author=H..%2BGunes&author=O..%2BCeliktutan&author=E..%2BSariyanidi&publication\_year=2019&title=Live%2Bhuman-robot%2Binteractive%2Bpublic%2Bdemonstrations%2Bwith%2Bautomatic%2Bemotion%2Band%2Bpersonality%2Bprediction&journal=Philos.+Trans.+R.+Soc.+Lond.+B+Biol.+Sci.&volume=374

64 Gurbuz F. Toga G. ( 2018).

Usage of the Facial Action Coding System to Predict Costumer Gender Profile: A Neuro Marketing Application in TURKEY.

Google Scholar

http://scholar.google.com/scholar\_lookup?author=F..%2BGurbuz&author=G..%2BToga&publication\_year=2018&journal=Usage+of+the+Facial+Action+Coding+System+to+Predict+Costumer+Gender+Profile%3A+A+Neuro+Marketing+Application+in+TURKEY.&volume=IEEE&pages=1-4

65 Haase C. M. Beermann U. Saslow L. R. Shiota M. N. Saturn S. R. Lwi S. J. et al. ( 2015). Short alleles, bigger smiles? The effect of 5-HTTLPR on positive emotional expressions.

: 438– 448. 10.1037/emo0000074

Pubmed Abstract

https://pubmed.ncbi.nlm.nih.gov/26029940

https://doi.org/10.1037/emo0000074

Google Scholar

http://scholar.google.com/scholar\_lookup?author=C.%2BM..%2BHaase&author=U..%2BBeermann&author=L.%2BR..%2BSaslow&author=M.%2BN..%2BShiota&author=S.%2BR..%2BSaturn&author=S.%2BJ..%2BLwi&publication\_year=2015&title=Short%2Balleles%2C%2Bbigger%2Bsmiles%3F%2BThe%2Beffect%2Bof%2B5-HTTLPR%2Bon%2Bpositive%2Bemotional%2Bexpressions&journal=Emotion&volume=15&pages=438-448

66 Hajcak G. Molnar C. George M. S. Bolger K. Koola J. Nahas Z. ( 2007). Emotion facilitates action: A transcranial magnetic stimulation study of motor cortex excitability during picture viewing.

Psychophysiology44

, 91– 97. 10.1111/j.1469-8986.2006.00487.x

Pubmed Abstract

https://pubmed.ncbi.nlm.nih.gov/17241144

https://doi.org/10.1111/j.1469-8986.2006.00487.x

Google Scholar

http://scholar.google.com/scholar\_lookup?author=G..%2BHajcak&author=C..%2BMolnar&author=M.%2BS..%2BGeorge&author=K..%2BBolger&author=J..%2BKoola&author=Z..%2BNahas&publication\_year=2007&title=Emotion%2Bfacilitates%2Baction%3A%2BA%2Btranscranial%2Bmagnetic%2Bstimulation%2Bstudy%2Bof%2Bmotor%2Bcortex%2Bexcitability%2Bduring%2Bpicture%2Bviewing&journal=Psychophysiology&volume=44&pages=91-97

67 Hamm J. Kohler C. G. Gur R. C. Verma R. ( 2011). Automated Facial Action Coding System for dynamic analysis of facial expressions in neuropsychiatric disorders.

J. Neurosci. Methods200

, 237– 256. 10.1016/j.jneumeth.2011.06.023

Pubmed Abstract

https://pubmed.ncbi.nlm.nih.gov/21741407

https://doi.org/10.1016/j.jneumeth.2011.06.023

Google Scholar

http://scholar.google.com/scholar\_lookup?author=J..%2BHamm&author=C.%2BG..%2BKohler&author=R.%2BC..%2BGur&author=R..%2BVerma&publication\_year=2011&title=Automated%2BFacial%2BAction%2BCoding%2BSystem%2Bfor%2Bdynamic%2Banalysis%2Bof%2Bfacial%2Bexpressions%2Bin%2Bneuropsychiatric%2Bdisorders&journal=J.+Neurosci.+Methods&volume=200&pages=237-256

68 Han S. Lerner J. S. Keltner D. ( 2007). Feelings and consumer decision making: the appraisal-tendency framework.

J. Consum. Psychol.

17, 158– 168. 10.1080/10577400701389706

https://doi.org/10.1080/10577400701389706

Google Scholar

http://scholar.google.com/scholar\_lookup?author=S..%2BHan&author=J.%2BS..%2BLerner&author=D..%2BKeltner&publication\_year=2007&title=Feelings%2Band%2Bconsumer%2Bdecision%2Bmaking%3A%2Bthe%2Bappraisal-tendency%2Bframework&journal=J.+Consum.+Psychol.&volume=17&pages=158-168

69 He W. Boesveldt S. de Graaf C. de Wijk R. A. ( 2012a). Behavioural and physiological responses to two food odours.

: 628. 10.1016/j.appet.2012.05.071

https://doi.org/10.1016/j.appet.2012.05.071

Google Scholar

http://scholar.google.com/scholar\_lookup?author=W..%2BHe&author=S..%2BBoesveldt&author=C..%2Bde%2BGraaf&author=R.%2BA..%2Bde%2BWijk&publication\_year=2012a&title=Behavioural%2Band%2Bphysiological%2Bresponses%2Bto%2Btwo%2Bfood%2Bodours&journal=Appetite&volume=59

70 He W. Boesveldt S. de Graaf C. de Wijk R. A. ( 2014). Dynamics of autonomic nervous system responses and facial expressions to odors.

Front. Psychol.

5: 110. 10.3389/fpsyg.2014.00110

Pubmed Abstract

https://pubmed.ncbi.nlm.nih.gov/24592246

https://doi.org/10.3389/fpsyg.2014.00110

Google Scholar

http://scholar.google.com/scholar\_lookup?author=W..%2BHe&author=S..%2BBoesveldt&author=C..%2Bde%2BGraaf&author=R.%2BA..%2Bde%2BWijk&publication\_year=2014&title=Dynamics%2Bof%2Bautonomic%2Bnervous%2Bsystem%2Bresponses%2Band%2Bfacial%2Bexpressions%2Bto%2Bodors&journal=Front.+Psychol.&volume=5

71 He W. Boesveldt S. de Graaf C. de Wijk R. A. ( 2016). The relation between continuous and discrete emotional responses to food odors with facial expressions and non-verbal reports.

Food Qual. Prefer.

48, 130– 137. 10.1016/j.foodqual.2015.09.003

https://doi.org/10.1016/j.foodqual.2015.09.003

Google Scholar

http://scholar.google.com/scholar\_lookup?author=W..%2BHe&author=S..%2BBoesveldt&author=C..%2Bde%2BGraaf&author=R.%2BA..%2Bde%2BWijk&publication\_year=2016&title=The%2Brelation%2Bbetween%2Bcontinuous%2Band%2Bdiscrete%2Bemotional%2Bresponses%2Bto%2Bfood%2Bodors%2Bwith%2Bfacial%2Bexpressions%2Band%2Bnon-verbal%2Breports&journal=Food+Qual.+Prefer.&volume=48&pages=130-137

72 He W. Boesveldt S. de Graaf K. de Wijk R. A. ( 2012b). The effect of positive and negative food odours on human behavioural and physiological responses, in

Proc. 5th Eur. Conf. Sens. Consum. Res

OP-1 ( Brighton).

Google Scholar

http://scholar.google.com/scholar\_lookup?author=W..%2BHe&author=S..%2BBoesveldt&author=K..%2Bde%2BGraaf&author=R.%2BA..%2Bde%2BWijk&publication\_year=2012b&title=The%2Beffect%2Bof%2Bpositive%2Band%2Bnegative%2Bfood%2Bodours%2Bon%2Bhuman%2Bbehavioural%2Band%2Bphysiological%2Bresponses&journal=Proc.+5th+Eur.+Conf.+Sens.+Consum.+Res

73 He W. Boesveldt S. Delplanque S. de Graaf C. de Wijk R. A. ( 2017). Sensory-specific satiety: added insights from autonomic nervous system responses and facial expressions.

Physiol. Behav.

170, 12– 18. 10.1016/j.physbeh.2016.12.012

Pubmed Abstract

https://pubmed.ncbi.nlm.nih.gov/27988247

https://doi.org/10.1016/j.physbeh.2016.12.012

Google Scholar

http://scholar.google.com/scholar\_lookup?author=W..%2BHe&author=S..%2BBoesveldt&author=S..%2BDelplanque&author=C..%2Bde%2BGraaf&author=R.%2BA..%2Bde%2BWijk&publication\_year=2017&title=Sensory-specific%2Bsatiety%3A%2Badded%2Binsights%2Bfrom%2Bautonomic%2Bnervous%2Bsystem%2Bresponses%2Band%2Bfacial%2Bexpressions&journal=Physiol.+Behav.&volume=170&pages=12-18

74 Herrald M. M. Tomaka J. ( 2002). Patterns of emotion-specific appraisal, coping, and cardiovascular reactivity during an ongoing emotional episode.

J. Pers. Soc. Psychol.

83, 434– 450. 10.1037/0022-3514.83.2.434

Pubmed Abstract

https://pubmed.ncbi.nlm.nih.gov/12150239

https://doi.org/10.1037/0022-3514.83.2.434

Google Scholar

http://scholar.google.com/scholar\_lookup?author=M.%2BM..%2BHerrald&author=J..%2BTomaka&publication\_year=2002&title=Patterns%2Bof%2Bemotion-specific%2Bappraisal%2C%2Bcoping%2C%2Band%2Bcardiovascular%2Breactivity%2Bduring%2Ban%2Bongoing%2Bemotional%2Bepisode&journal=J.+Pers.+Soc.+Psychol.&volume=83&pages=434-450

75 Higgins J. Green S. (eds). ( 2011).

Cochrane Handbook for Systematic Reviews of Interventions Version 5.11.0 \[updated March 2011\]

. The Cochrane Collaboration.

Google Scholar

http://scholar.google.com/scholar\_lookup?publication\_year=2011&journal=Cochrane+Handbook+for+Systematic+Reviews+of+Interventions+Version+5.11.0+%5Bupdated+March+2011%5D

76 Hill S. E. DelPriore D. J. Vaughan P. W. ( 2011). The cognitive consequences of envy: attention, memory, and self-regulatory depletion.

J. Pers. Soc. Psychol.

101, 653– 666. 10.1037/a0023904

Pubmed Abstract

https://pubmed.ncbi.nlm.nih.gov/21639650

https://doi.org/10.1037/a0023904

Google Scholar

http://scholar.google.com/scholar\_lookup?author=S.%2BE..%2BHill&author=D.%2BJ..%2BDelPriore&author=P.%2BW..%2BVaughan&publication\_year=2011&title=The%2Bcognitive%2Bconsequences%2Bof%2Benvy%3A%2Battention%2C%2Bmemory%2C%2Band%2Bself-regulatory%2Bdepletion&journal=J.+Pers.+Soc.+Psychol.&volume=101&pages=653-666

77 Hjortsjö C. H. ( 1970).

Man's Face and Mimic Language.

Studen Literature, 111.

Google Scholar

http://scholar.google.com/scholar\_lookup?author=C.%2BH..%2BHjortsj%C3%B6&publication\_year=1970&journal=Man%27s+Face+and+Mimic+Language.

78 Hung J. Chiang K. Huang Y. Lin K. ( 2017). Augmenting teacher-student interaction in digital learning through affective computing.

Multimed. Tools. Appl.

76, 18361– 386. 10.1007/s11042-016-4101-z

https://doi.org/10.1007/s11042-016-4101-z

Google Scholar

http://scholar.google.com/scholar\_lookup?author=J..%2BHung&author=K..%2BChiang&author=Y..%2BHuang&author=K..%2BLin&publication\_year=2017&title=Augmenting%2Bteacher-student%2Binteraction%2Bin%2Bdigital%2Blearning%2Bthrough%2Baffective%2Bcomputing&journal=Multimed.+Tools.+Appl.&volume=76&pages=18361-386

79 Izard C. E. ( 1977).

Human Emotions

. Boston, MA: Springer

Google Scholar

http://scholar.google.com/scholar\_lookup?author=C.%2BE..%2BIzard&publication\_year=1977&journal=Human+Emotions

80 Jack R. E. Garrod O. G. B. Yu H. Caldara R. Schyns P. G. ( 2012). Facial expressions of emotion are not culturally universal.

Proc. Natl. Acad. Sci. U.S.A

109: 7241– 7244. 10.1073/pnas.1200155109

Pubmed Abstract

https://pubmed.ncbi.nlm.nih.gov/22509011

https://doi.org/10.1073/pnas.1200155109

Google Scholar

http://scholar.google.com/scholar\_lookup?author=R.%2BE..%2BJack&author=O.%2BG.%2BB..%2BGarrod&author=H..%2BYu&author=R..%2BCaldara&author=P.%2BG..%2BSchyns&publication\_year=2012&title=Facial%2Bexpressions%2Bof%2Bemotion%2Bare%2Bnot%2Bculturally%2Buniversal&journal=Proc.+Natl.+Acad.+Sci.+U.S.A&volume=109&pages=7241-7244

81 Jakobs E. Manstead A. Fischer A. ( 1999). Social motives and emotional feelings as determinants of facial displays: The case of smiling.

Pers. Soc. Psychol. Bull.

25: 424– 435.

Google Scholar

http://scholar.google.com/scholar\_lookup?author=E..%2BJakobs&author=A..%2BManstead&author=A..%2BFischer&publication\_year=1999&title=Social%2Bmotives%2Band%2Bemotional%2Bfeelings%2Bas%2Bdeterminants%2Bof%2Bfacial%2Bdisplays%3A%2BThe%2Bcase%2Bof%2Bsmiling&journal=Pers.+Soc.+Psychol.+Bull.&volume=25&pages=424-435

82 Jewitt C. ( 2012).

An Introduction To Using Video for Research

. NCRM Working Paper. NCRM. Available online at:

http://eprints.ncrm.ac.uk/2256/

http://eprints.ncrm.ac.uk/2256/

Google Scholar

http://scholar.google.com/scholar\_lookup?author=C..%2BJewitt&publication\_year=2012&journal=An+Introduction+To+Using+Video+for+Research

83 Johnson S. L. Haase C. M. Beermann U. Sanchez A. H. Tharp J. A. ( 2017). Positive urgency and emotional reactivity: Evidence for altered responding to positive stimuli.

, 442– 449. 10.1037/emo0000240

Pubmed Abstract

https://pubmed.ncbi.nlm.nih.gov/27819449

https://doi.org/10.1037/emo0000240

Google Scholar

http://scholar.google.com/scholar\_lookup?author=S.%2BL..%2BJohnson&author=C.%2BM..%2BHaase&author=U..%2BBeermann&author=A.%2BH..%2BSanchez&author=J.%2BA..%2BTharp&publication\_year=2017&title=Positive%2Burgency%2Band%2Bemotional%2Breactivity%3A%2BEvidence%2Bfor%2Baltered%2Bresponding%2Bto%2Bpositive%2Bstimuli&journal=Emotion&volume=17&pages=442-449

84 Kaneko D. Toet A. Brouwer A.-M. Kallen V. van Erp J. B. F. ( 2018). Methods for evaluating emotions evoked by food experiences: a literature review.

Front. Psychol.

9: 911. 10.3389/fpsyg.2018.00911

Pubmed Abstract

https://pubmed.ncbi.nlm.nih.gov/29937744

https://doi.org/10.3389/fpsyg.2018.00911

Google Scholar

http://scholar.google.com/scholar\_lookup?author=D..%2BKaneko&author=A..%2BToet&author=A.-M..%2BBrouwer&author=V..%2BKallen&author=J.%2BB.%2BF..%2Bvan%2BErp&publication\_year=2018&title=Methods%2Bfor%2Bevaluating%2Bemotions%2Bevoked%2Bby%2Bfood%2Bexperiences%3A%2Ba%2Bliterature%2Breview&journal=Front.+Psychol.&volume=9

85 Keltner D. Lerner J. S. ( 2010). Emotion, in

Handbook of Social Psychology

. eds Fiske S. T. Gilbert D. T. Lindzey G. ( Hoboken, NJ: John Wiley & Sons, Inc.) 317– 352.

Google Scholar

http://scholar.google.com/scholar\_lookup?author=D..%2BKeltner&author=J.%2BS..%2BLerner&publication\_year=2010&title=Emotion&journal=Handbook+of+Social+Psychology&pages=317-352

86 Kim H. Park K. Schwarz N. ( 2010). Will this trip really be exciting? The role of incidental emotions in product evaluation.

J. Consum. Res.

36, 983– 991. 10.1086/644763

https://doi.org/10.1086/644763

Google Scholar

http://scholar.google.com/scholar\_lookup?author=H..%2BKim&author=K..%2BPark&author=N..%2BSchwarz&publication\_year=2010&title=Will%2Bthis%2Btrip%2Breally%2Bbe%2Bexciting%3F%2BThe%2Brole%2Bof%2Bincidental%2Bemotions%2Bin%2Bproduct%2Bevaluation&journal=J.+Consum.+Res.&volume=36&pages=983-991

87 King S. C. Meiselman H. L. ( 2010). Development of a method to measure consumer emotions associated with foods.

Food Qual. Prefer.

21, 168– 177. 10.1016/j.foodqual.2009.02.005

https://doi.org/10.1016/j.foodqual.2009.02.005

Google Scholar

http://scholar.google.com/scholar\_lookup?author=S.%2BC..%2BKing&author=H.%2BL..%2BMeiselman&publication\_year=2010&title=Development%2Bof%2Ba%2Bmethod%2Bto%2Bmeasure%2Bconsumer%2Bemotions%2Bassociated%2Bwith%2Bfoods&journal=Food+Qual.+Prefer.&volume=21&pages=168-177

88 Kodra E. Senechal T. McDuff D. Kaliouby R. ( 2013). From dials to facial coding: automated detection of spontaneous facial expressions for media research, in

2013 10TH IEEE Int Conf Workshop Autom FACE GESTURE Recognit FGSE IEEE Int Conf Autom Face Gesture Recognit Workshop.

( Shanghai).

Google Scholar

http://scholar.google.com/scholar\_lookup?author=E..%2BKodra&author=T..%2BSenechal&author=D..%2BMcDuff&author=R..%2BKaliouby&publication\_year=2013&title=From%2Bdials%2Bto%2Bfacial%2Bcoding%3A%2Bautomated%2Bdetection%2Bof%2Bspontaneous%2Bfacial%2Bexpressions%2Bfor%2Bmedia%2Bresearch&journal=2013+10TH+IEEE+Int+Conf+Workshop+Autom+FACE+GESTURE+Recognit+FGSE+IEEE+Int+Conf+Autom+Face+Gesture+Recognit+Workshop.

89 Krumhuber E. Manstead A. ( 2009). Can duchenne smiles be feigned? New evidence on felt and false smiles.

, 807– 820. 10.1037/a0017844

Pubmed Abstract

https://pubmed.ncbi.nlm.nih.gov/20001124

https://doi.org/10.1037/a0017844

Google Scholar

http://scholar.google.com/scholar\_lookup?author=E..%2BKrumhuber&author=A..%2BManstead&publication\_year=2009&title=Can%2Bduchenne%2Bsmiles%2Bbe%2Bfeigned%3F%2BNew%2Bevidence%2Bon%2Bfelt%2Band%2Bfalse%2Bsmiles&journal=Emotion&volume=9&pages=807-820

90 Lagast S. Gellynck X. Schouteten J. J. De Herdt V. De Steur H. ( 2017). Consumers' emotions elicited by food: a systematic review of explicit and implicit methods.

Trends Food Sci. Technol.

69, 172– 189. 10.1016/j.tifs.2017.09.006

https://doi.org/10.1016/j.tifs.2017.09.006

Google Scholar

http://scholar.google.com/scholar\_lookup?author=S..%2BLagast&author=X..%2BGellynck&author=J.%2BJ..%2BSchouteten&author=V..%2BDe%2BHerdt&author=H..%2BDe%2BSteur&publication\_year=2017&title=Consumers%27%2Bemotions%2Belicited%2Bby%2Bfood%3A%2Ba%2Bsystematic%2Breview%2Bof%2Bexplicit%2Band%2Bimplicit%2Bmethods&journal=Trends+Food+Sci.+Technol.&volume=69&pages=172-189

91 Laird J. D. ( 1974). Self-attribution of emotion: the effects of expressive behavior on the quality of emotional experience.

J. Pers. Soc. Psychol.

29: 475– 486.

Pubmed Abstract

https://pubmed.ncbi.nlm.nih.gov/4818323

Google Scholar

http://scholar.google.com/scholar\_lookup?author=J.%2BD..%2BLaird&publication\_year=1974&title=Self-attribution%2Bof%2Bemotion%3A%2Bthe%2Beffects%2Bof%2Bexpressive%2Bbehavior%2Bon%2Bthe%2Bquality%2Bof%2Bemotional%2Bexperience&journal=J.+Pers.+Soc.+Psychol.&volume=29&pages=475-486

92 Lambie J. A. Marcel A. J. ( 2002). Consciousness and the varieties of emotion experience: a theoretical framework.

Psychol. Rev.

109, 219– 259. 10.1037/0033-295X.109.2.219

Pubmed Abstract

https://pubmed.ncbi.nlm.nih.gov/11990318

https://doi.org/10.1037/0033-295X.109.2.219

Google Scholar

http://scholar.google.com/scholar\_lookup?author=J.%2BA..%2BLambie&author=A.%2BJ..%2BMarcel&publication\_year=2002&title=Consciousness%2Band%2Bthe%2Bvarieties%2Bof%2Bemotion%2Bexperience%3A%2Ba%2Btheoretical%2Bframework&journal=Psychol.+Rev.&volume=109&pages=219-259

93 Lazarus R. S. ( 1991a). Cognition and motivation in emotion.

Am. Psychol.

46: 352– 367.

Google Scholar

http://scholar.google.com/scholar\_lookup?author=R.%2BS..%2BLazarus&publication\_year=1991a&title=Cognition%2Band%2Bmotivation%2Bin%2Bemotion&journal=Am.+Psychol.&volume=46&pages=352-367

94 Lazarus R. S. ( 1991b). Progress on a cognitive–motivational–relational theory of emotion.

Am. Psychol.

46, 819– 834.

Pubmed Abstract

https://pubmed.ncbi.nlm.nih.gov/1928936

Google Scholar

http://scholar.google.com/scholar\_lookup?author=R.%2BS..%2BLazarus&publication\_year=1991b&title=Progress%2Bon%2Ba%2Bcognitive%E2%80%93motivational%E2%80%93relational%2Btheory%2Bof%2Bemotion&journal=Am.+Psychol.&volume=46&pages=819-834

95 Leitch K. A. Duncan S. E. O'Keefe S. Rudd R. Gallagher D. L. ( 2015). Characterizing consumer emotional response to sweeteners using an emotion terminology questionnaire and facial expression analysis.

Food Res. Int.

76, 283– 292. 10.1016/j.foodres.2015.04.039

https://doi.org/10.1016/j.foodres.2015.04.039

Google Scholar

http://scholar.google.com/scholar\_lookup?author=K.%2BA..%2BLeitch&author=S.%2BE..%2BDuncan&author=S..%2BO%27Keefe&author=R..%2BRudd&author=D.%2BL..%2BGallagher&publication\_year=2015&title=Characterizing%2Bconsumer%2Bemotional%2Bresponse%2Bto%2Bsweeteners%2Busing%2Ban%2Bemotion%2Bterminology%2Bquestionnaire%2Band%2Bfacial%2Bexpression%2Banalysis&journal=Food+Res.+Int.&volume=76&pages=283-292

96 Lerner J. S. Keltner D. ( 2000). Beyond valence: Toward a model of emotion-specific influences on judgement and choice.

Cogn. Emot.

14, 473– 493. 10.1080/026999300402763

https://doi.org/10.1080/026999300402763

Google Scholar

http://scholar.google.com/scholar\_lookup?author=J.%2BS..%2BLerner&author=D..%2BKeltner&publication\_year=2000&title=Beyond%2Bvalence%3A%2BToward%2Ba%2Bmodel%2Bof%2Bemotion-specific%2Binfluences%2Bon%2Bjudgement%2Band%2Bchoice&journal=Cogn.+Emot.&volume=14&pages=473-493

97 Lerner J. S. Keltner D. ( 2001). Fear, anger, and risk.

J. Pers. Soc. Psychol.

81, 146– 159. 10.1037/0022-3514.81.1.146

Pubmed Abstract

https://pubmed.ncbi.nlm.nih.gov/11474720

https://doi.org/10.1037/0022-3514.81.1.146

Google Scholar

http://scholar.google.com/scholar\_lookup?author=J.%2BS..%2BLerner&author=D..%2BKeltner&publication\_year=2001&title=Fear%2C%2Banger%2C%2Band%2Brisk&journal=J.+Pers.+Soc.+Psychol.&volume=81&pages=146-159

98 Lewinski P. Tan E. Fransen M. Czarna K. Butler C. ( 2014c) Hindering facial mimicry in ad viewing: effects on consumers' emotions, attitudes purchase intentions, in

Advances in Advertising Research, Vol. VI

. eds Verlegh P. Voorveld H. Eisend M. ( Wiesbaden: European Advertising Academy. Springer Gabler).

Google Scholar

http://scholar.google.com/scholar\_lookup?author=P..%2BLewinski&author=E..%2BTan&author=M..%2BFransen&author=K..%2BCzarna&author=C..%2BButler&publication\_year=2014c&title=Hindering%2Bfacial%2Bmimicry%2Bin%2Bad%2Bviewing%3A%2Beffects%2Bon%2Bconsumers%27%2Bemotions%2C%2Battitudes%2Bpurchase%2Bintentions&journal=Advances+in+Advertising+Research%2C+Vol.+VI

99 Lewinski P. den Uyl T. M. Butler C. ( 2014d). Automated facial coding: validation of basic emotions and FACS AUs in FaceReader.

J. Neurosci. Psychol. Econ.

7, 227– 236. 10.1371/journal.pone.0223905

https://doi.org/10.1371/journal.pone.0223905

Google Scholar

http://scholar.google.com/scholar\_lookup?author=P..%2BLewinski&author=T.%2BM..%2Bden%2BUyl&author=C..%2BButler&publication\_year=2014d&title=Automated%2Bfacial%2Bcoding%3A%2Bvalidation%2Bof%2Bbasic%2Bemotions%2Band%2BFACS%2BAUs%2Bin%2BFaceReader&journal=J.+Neurosci.+Psychol.+Econ.&volume=7&pages=227-236

100 Lewinski P. Fransen M. L. Tan E. S. Snijdewind M. C. Weeda W. D. Czarna K. ( 2014a). Do(n't) laugh at that ad: emotion regulation predicts consumers' liking, in

Proceedings of the 13th International Conference on Research in Advertising

( Amsterdam, the Netherlands: European Advertising Academy).

Google Scholar

http://scholar.google.com/scholar\_lookup?author=P..%2BLewinski&author=M.%2BL..%2BFransen&author=E.%2BS..%2BTan&author=M.%2BC..%2BSnijdewind&author=W.%2BD..%2BWeeda&author=K..%2BCzarna&publication\_year=2014a&title=Do%28n%27t%29%2Blaugh%2Bat%2Bthat%2Bad%3A%2Bemotion%2Bregulation%2Bpredicts%2Bconsumers%27%2Bliking&journal=Proceedings+of+the+13th+International+Conference+on+Research+in+Advertising

101 Lewinski P. Fransen M. L. Tan E. S. H. ( 2014b). Predicting advertising effectiveness by facial expressions in response to amusing persuasive stimuli.

J. Neurosci. Psychol. Econ.

7, 1– 14. 10.1037/npe0000012

https://doi.org/10.1037/npe0000012

Google Scholar

http://scholar.google.com/scholar\_lookup?author=P..%2BLewinski&author=M.%2BL..%2BFransen&author=E.%2BS.%2BH..%2BTan&publication\_year=2014b&title=Predicting%2Badvertising%2Beffectiveness%2Bby%2Bfacial%2Bexpressions%2Bin%2Bresponse%2Bto%2Bamusing%2Bpersuasive%2Bstimuli&journal=J.+Neurosci.+Psychol.+Econ.&volume=7&pages=1-14

102 Lewis M. ( 2000). Self-conscious emotions: Embarrassment, pride, shame, and guilt, in

Handbook of emotions, 2nd edn.

ed Haviland-Jones J. M. ( New York, NY: Guilford Press), 623– 636

Google Scholar

http://scholar.google.com/scholar\_lookup?author=M..%2BLewis&publication\_year=2000&title=Self-conscious%2Bemotions%3A%2BEmbarrassment%2C%2Bpride%2C%2Bshame%2C%2Band%2Bguilt&journal=Handbook+of+emotions%2C+2nd+edn.&pages=623-636

103 Lynch R. ( 2010). It's funny because we think it's true: laughter is augmented by implicit preferences.

Evol. Hum. Behav.

31, 141– 148. 10.1016/j.evolhumbehav.2009.07.003

https://doi.org/10.1016/j.evolhumbehav.2009.07.003

Google Scholar

http://scholar.google.com/scholar\_lookup?author=R..%2BLynch&publication\_year=2010&title=It%27s%2Bfunny%2Bbecause%2Bwe%2Bthink%2Bit%27s%2Btrue%3A%2Blaughter%2Bis%2Baugmented%2Bby%2Bimplicit%2Bpreferences&journal=Evol.+Hum.+Behav.&volume=31&pages=141-148

104 Lynch R. Trivers R. ( 2012). Self-deception inhibits laughter.

Pers. Individ. Differ.

53, 491– 495. 10.1016/j.paid.2012.02.017

https://doi.org/10.1016/j.paid.2012.02.017

Google Scholar

http://scholar.google.com/scholar\_lookup?author=R..%2BLynch&author=R..%2BTrivers&publication\_year=2012&title=Self-deception%2Binhibits%2Blaughter&journal=Pers.+Individ.+Differ.&volume=53&pages=491-495

105 Maheswaran D. Chen C. Y. ( 2006). Nation equity: incidental emotions in country-of-origin effects.

J. Consum. Res.

33, 370– 376. 10.1086/508521

https://doi.org/10.1086/508521

Google Scholar

http://scholar.google.com/scholar\_lookup?author=D..%2BMaheswaran&author=C.%2BY..%2BChen&publication\_year=2006&title=Nation%2Bequity%3A%2Bincidental%2Bemotions%2Bin%2Bcountry-of-origin%2Beffects&journal=J.+Consum.+Res.&volume=33&pages=370-376

106 Martin C. Archibald J. Ball L. Carson L. ( 2013). Towards an affective self-service agent, in

Proceeding Third Int Conf Intell Hum Comput Interact IHCI 2011SE Adv Intell Syst Comput.

( Santa Clara, CA) 179, 3– 12.

Google Scholar

http://scholar.google.com/scholar\_lookup?author=C..%2BMartin&author=J..%2BArchibald&author=L..%2BBall&author=L..%2BCarson&publication\_year=2013&title=Towards%2Ban%2Baffective%2Bself-service%2Bagent&journal=Proceeding+Third+Int+Conf+Intell+Hum+Comput+Interact+IHCI+2011SE+Adv+Intell+Syst+Comput.&volume=179&pages=3-12

107 Mauss I. B. Robinson M. D. ( 2009). Measures of emotion: a review.

Cogn. Emot.

23, 209– 237. 10.1080/02699930802204677

Pubmed Abstract

https://pubmed.ncbi.nlm.nih.gov/19809584

https://doi.org/10.1080/02699930802204677

Google Scholar

http://scholar.google.com/scholar\_lookup?author=I.%2BB..%2BMauss&author=M.%2BD..%2BRobinson&publication\_year=2009&title=Measures%2Bof%2Bemotion%3A%2Ba%2Breview&journal=Cogn.+Emot.&volume=23&pages=209-237

108 Menne I. Schnellbacher C. Schwab F. ( 2016). Facing emotional reactions towards a robot - an experimental study using FACS, in

Social Robotics: 8th International Conference

, ICSR 2016 ( Kansas City, MO), 372– 381.

Google Scholar

http://scholar.google.com/scholar\_lookup?author=I..%2BMenne&author=C..%2BSchnellbacher&author=F..%2BSchwab&publication\_year=2016&title=Facing%2Bemotional%2Breactions%2Btowards%2Ba%2Brobot%2B-%2Ban%2Bexperimental%2Bstudy%2Busing%2BFACS&journal=Social+Robotics%3A+8th+International+Conference&pages=372-381

109 Mirabella G. ( 2014). Should i stay or should i go? conceptual underpinnings of goal-directed actions.

Front. Syst. Neurosci.

8: 206. 10.3389/fnsys.2014.00206

Pubmed Abstract

https://pubmed.ncbi.nlm.nih.gov/25404898

https://doi.org/10.3389/fnsys.2014.00206

Google Scholar

http://scholar.google.com/scholar\_lookup?author=G..%2BMirabella&publication\_year=2014&title=Should%2Bi%2Bstay%2Bor%2Bshould%2Bi%2Bgo%3F%2Bconceptual%2Bunderpinnings%2Bof%2Bgoal-directed%2Bactions&journal=Front.+Syst.+Neurosci.&volume=8

110 Mirabella G. ( 2018). The weight of emotions in decision-making: how fearful and happy facial stimuli modulate action readiness of goal-directed actions.

Front. Psychol.

9: 1334. 10.3389/fpsyg.2018.01334

Pubmed Abstract

https://pubmed.ncbi.nlm.nih.gov/30116211

https://doi.org/10.3389/fpsyg.2018.01334

Google Scholar

http://scholar.google.com/scholar\_lookup?author=G..%2BMirabella&publication\_year=2018&title=The%2Bweight%2Bof%2Bemotions%2Bin%2Bdecision-making%3A%2Bhow%2Bfearful%2Band%2Bhappy%2Bfacial%2Bstimuli%2Bmodulate%2Baction%2Breadiness%2Bof%2Bgoal-directed%2Bactions&journal=Front.+Psychol.&volume=9

111 Moher D. Liberati A. Tetzlaff J. Altman D. G. ( 2009). Preferred reporting items for systematic reviews and meta-analyses: the PRISMA statement.

6: e1000097. 10.1371/journal.pmed.1000097

https://doi.org/10.1371/journal.pmed.1000097

Google Scholar

http://scholar.google.com/scholar\_lookup?author=D..%2BMoher&author=A..%2BLiberati&author=J..%2BTetzlaff&author=D.%2BG..%2BAltman&publication\_year=2009&title=Preferred%2Breporting%2Bitems%2Bfor%2Bsystematic%2Breviews%2Band%2Bmeta-analyses%3A%2Bthe%2BPRISMA%2Bstatement&journal=PLoS+Med.&volume=6

112 Mozuriene E. Bartkiene E. Juodeikiene G. Zadeike D. Basinskiene L. Maruska A. et al. ( 2016). The effect of savoury plants, fermented with lactic acid bacterias, on the microbiological contamination, quality, and acceptability of unripened curd cheese.

LWT Food. Sci. Technol.

69, 161– 168. 10.1016/j.lwt.2016.01.027

https://doi.org/10.1016/j.lwt.2016.01.027

Google Scholar

http://scholar.google.com/scholar\_lookup?author=E..%2BMozuriene&author=E..%2BBartkiene&author=G..%2BJuodeikiene&author=D..%2BZadeike&author=L..%2BBasinskiene&author=A..%2BMaruska&publication\_year=2016&title=The%2Beffect%2Bof%2Bsavoury%2Bplants%2C%2Bfermented%2Bwith%2Blactic%2Bacid%2Bbacterias%2C%2Bon%2Bthe%2Bmicrobiological%2Bcontamination%2C%2Bquality%2C%2Band%2Bacceptability%2Bof%2Bunripened%2Bcurd%2Bcheese&journal=LWT+Food.+Sci.+Technol.&volume=69&pages=161-168

113 Mui P. H. C. Goudbeek M. B. Swerts M. G. J. Hovasapian A. ( 2017). Children's nonverbal displays of winning and losing: effects of social and cultural contexts on smiles.

J. Nonverbal. Behav.

41, 67– 82. 10.1007/s10919-016-0241-0

Pubmed Abstract

https://pubmed.ncbi.nlm.nih.gov/28203037

https://doi.org/10.1007/s10919-016-0241-0

Google Scholar

http://scholar.google.com/scholar\_lookup?author=P.%2BH.%2BC..%2BMui&author=M.%2BB..%2BGoudbeek&author=M.%2BG.%2BJ..%2BSwerts&author=A..%2BHovasapian&publication\_year=2017&title=Children%27s%2Bnonverbal%2Bdisplays%2Bof%2Bwinning%2Band%2Blosing%3A%2Beffects%2Bof%2Bsocial%2Band%2Bcultural%2Bcontexts%2Bon%2Bsmiles&journal=J.+Nonverbal.+Behav.&volume=41&pages=67-82

114 Namba S. Kabir R. Miyatani M. Nakao T. ( 2017). Spontaneous facial actions map onto emotional experiences in a non-social context: toward a component-based approach.

Front. Psychol.

8: 633. 10.3389/fpsyg.2017.00633

Pubmed Abstract

https://pubmed.ncbi.nlm.nih.gov/28522979

https://doi.org/10.3389/fpsyg.2017.00633

Google Scholar

http://scholar.google.com/scholar\_lookup?author=S..%2BNamba&author=R..%2BKabir&author=M..%2BMiyatani&author=T..%2BNakao&publication\_year=2017&title=Spontaneous%2Bfacial%2Bactions%2Bmap%2Bonto%2Bemotional%2Bexperiences%2Bin%2Ba%2Bnon-social%2Bcontext%3A%2Btoward%2Ba%2Bcomponent-based%2Bapproach&journal=Front.+Psychol.&volume=8

115 Noldus Information Technology ( 2014).

FaceReaderTM 6 technical specifications. Noldus Information Technology, Wageningen, The Netherlands

. Available online at:

https://student.hva.nl/binaries/content/assets/serviceplein-a-z-lemmas/media-creatie-en-informatie/media–communicatie/observatorium/factsheet-facial-coding-reference-manual.pdf?2900513938585

https://student.hva.nl/binaries/content/assets/serviceplein-a-z-lemmas/media-creatie-en-informatie/media–communicatie/observatorium/factsheet-facial-coding-reference-manual.pdf?2900513938585

Google Scholar

http://scholar.google.com/scholar\_lookup?publication\_year=2014&journal=FaceReaderTM+6+technical+specifications.+Noldus+Information+Technology%2C+Wageningen%2C+The+Netherlands

116 Novacek J. Lazarus R. S. ( 1990). The structure of personal commitments.

J. Pers. Soc. Psychol.

58, 693– 715.

Google Scholar

http://scholar.google.com/scholar\_lookup?author=J..%2BNovacek&author=R.%2BS..%2BLazarus&publication\_year=1990&title=The%2Bstructure%2Bof%2Bpersonal%2Bcommitments&journal=J.+Pers.+Soc.+Psychol.&volume=58&pages=693-715

117 Paul Ekman Group LLC ( 2019).

Facial Action Coding System. In: Paul Ekman Group

. Available online at:

https://www.paulekman.com/facial-action-coding-system/

https://www.paulekman.com/facial-action-coding-system/

(accessed July 24, 2019).

Google Scholar

http://scholar.google.com/scholar\_lookup?publication\_year=2019&journal=Facial+Action+Coding+System.+In%3A+Paul+Ekman+Group

118 Plutchik R. ( 1980).

Emotion, a Psychoevolutionary Synthesis

. New York, NY : Harper & Row.

Google Scholar

http://scholar.google.com/scholar\_lookup?author=R..%2BPlutchik&publication\_year=1980&journal=Emotion%2C+a+Psychoevolutionary+Synthesis

119 Poldrack R. ( 2006) Can cognitive processes be inferred from neuroimaging data?

Trends Cogn. Sci.

10, 59– 63. 10.1016/j.tics.2005.12.004

Pubmed Abstract

https://pubmed.ncbi.nlm.nih.gov/16406760

https://doi.org/10.1016/j.tics.2005.12.004

Google Scholar

http://scholar.google.com/scholar\_lookup?author=R..%2BPoldrack&publication\_year=2006&title=Can%2Bcognitive%2Bprocesses%2Bbe%2Binferred%2Bfrom%2Bneuroimaging%2Bdata%3F&journal=Trends+Cogn.+Sci.&volume=10&pages=59-63

120 Poldrack R. A. ( 2008) The role of fMRI in Cognitive Neuroscience: where do we stand?

Curr. Opin. Neurobiol.

18, 223– 227. 10.1016/j.conb.2008.07.006

Pubmed Abstract

https://pubmed.ncbi.nlm.nih.gov/18678252

https://doi.org/10.1016/j.conb.2008.07.006

Google Scholar

http://scholar.google.com/scholar\_lookup?author=R.%2BA..%2BPoldrack&publication\_year=2008&title=The%2Brole%2Bof%2BfMRI%2Bin%2BCognitive%2BNeuroscience%3A%2Bwhere%2Bdo%2Bwe%2Bstand%3F&journal=Curr.+Opin.+Neurobiol.&volume=18&pages=223-227

121 Raghunathan R. Pham M. T. Corfman K. P. ( 2006). Informational properties of anxiety and sadness and displaced coping.

J. Consum. Res.

32: 596– 601. 10.1086/500491

https://doi.org/10.1086/500491

Google Scholar

http://scholar.google.com/scholar\_lookup?author=R..%2BRaghunathan&author=M.%2BT..%2BPham&author=K.%2BP..%2BCorfman&publication\_year=2006&title=Informational%2Bproperties%2Bof%2Banxiety%2Band%2Bsadness%2Band%2Bdisplaced%2Bcoping&journal=J.+Consum.+Res.&volume=32&pages=596-601

122 Rasch C. Louviere J. J. Teichert T. ( 2015). Using facial EMG and eye tracking to study integral affect in discrete choice experiments.

J. Choice. Model14

, 32– 47. 10.1016/j.jocm.2015.04.001

https://doi.org/10.1016/j.jocm.2015.04.001

Google Scholar

http://scholar.google.com/scholar\_lookup?author=C..%2BRasch&author=J.%2BJ..%2BLouviere&author=T..%2BTeichert&publication\_year=2015&title=Using%2Bfacial%2BEMG%2Band%2Beye%2Btracking%2Bto%2Bstudy%2Bintegral%2Baffect%2Bin%2Bdiscrete%2Bchoice%2Bexperiments&journal=J.+Choice.+Model&volume=14&pages=32-47

123 Rosenstein D. Oster H. ( 1988). Differential facial responses to four basic tastes in newborns.

Child. Dev.

59: 1555– 1568.

Pubmed Abstract

https://pubmed.ncbi.nlm.nih.gov/3208567

Google Scholar

http://scholar.google.com/scholar\_lookup?author=D..%2BRosenstein&author=H..%2BOster&publication\_year=1988&title=Differential%2Bfacial%2Bresponses%2Bto%2Bfour%2Bbasic%2Btastes%2Bin%2Bnewborns&journal=Child.+Dev.&volume=59&pages=1555-1568

124 Rossi F. ( 2013).

Emotional Sophistication: Studies of Facial Expressions in Games

. ProQuest Information & Learning. Tuscon, AZ: The University of Arizona. Available online at:

https://repository.arizona.edu/handle/10150/268514

https://repository.arizona.edu/handle/10150/268514

Google Scholar

http://scholar.google.com/scholar\_lookup?author=F..%2BRossi&publication\_year=2013&journal=Emotional+Sophistication%3A+Studies+of+Facial+Expressions+in+Games

125 Rozin P. Haidt J. McCauley C. ( 1999). Disgust: the body and soul emotion, in

Handbook of Cognition and Emotion

, eds Dalgleish T. Power M. ( New York, NY Wiley), 429– 445.

Google Scholar

http://scholar.google.com/scholar\_lookup?author=P..%2BRozin&author=J..%2BHaidt&author=C..%2BMcCauley&publication\_year=1999&title=Disgust%3A%2Bthe%2Bbody%2Band%2Bsoul%2Bemotion&journal=Handbook+of+Cognition+and+Emotion&pages=429-445

126 Ruch W. ( 1997a).

Will the Real Relationship Between Facial Expression and Affective Experience Please Stand Up: The Case Of Exhilaration

. New York, NY: Oxford University Press.

Google Scholar

http://scholar.google.com/scholar\_lookup?author=W..%2BRuch&publication\_year=1997a&journal=Will+the+Real+Relationship+Between+Facial+Expression+and+Affective+Experience+Please+Stand+Up%3A+The+Case+Of+Exhilaration

127 Ruch W. ( 1997b).

Extraversion, Alcohol, and Enjoyment.

New York, NY: Oxford University Press.

Google Scholar

http://scholar.google.com/scholar\_lookup?author=W..%2BRuch&publication\_year=1997b&journal=Extraversion%2C+Alcohol%2C+and+Enjoyment.

128 Russell J. A. ( 1980). A circumplex model of affect.

J. Pers. Soc. Psychol.

39, 1161– 1178. 10.1037/h0077714

Pubmed Abstract

https://pubmed.ncbi.nlm.nih.gov/26804575

https://doi.org/10.1037/h0077714

Google Scholar

http://scholar.google.com/scholar\_lookup?author=J.%2BA..%2BRussell&publication\_year=1980&title=A%2Bcircumplex%2Bmodel%2Bof%2Baffect&journal=J.+Pers.+Soc.+Psychol.&volume=39&pages=1161-1178

129 Sayers W. M. Sayette M. A. ( 2013). Suppression on your own terms: internally generated displays of craving suppression predict rebound effects.

Psychol. Sci.

24, 1740– 1746. 10.1177/0956797613479977

Pubmed Abstract

https://pubmed.ncbi.nlm.nih.gov/23842957

https://doi.org/10.1177/0956797613479977

Google Scholar

http://scholar.google.com/scholar\_lookup?author=W.%2BM..%2BSayers&author=M.%2BA..%2BSayette&publication\_year=2013&title=Suppression%2Bon%2Byour%2Bown%2Bterms%3A%2Binternally%2Bgenerated%2Bdisplays%2Bof%2Bcraving%2Bsuppression%2Bpredict%2Brebound%2Beffects&journal=Psychol.+Sci.&volume=24&pages=1740-1746

130 Sayette M. Hufford M. ( 1995). Urge and affect: a facial coding analysis of smokers.

Exp. Clin. Psychopharmacol.

3: 417– 423.

Pubmed Abstract

https://pubmed.ncbi.nlm.nih.gov/12940501

Google Scholar

http://scholar.google.com/scholar\_lookup?author=M..%2BSayette&author=M..%2BHufford&publication\_year=1995&title=Urge%2Band%2Baffect%3A%2Ba%2Bfacial%2Bcoding%2Banalysis%2Bof%2Bsmokers&journal=Exp.+Clin.+Psychopharmacol.&volume=3&pages=417-423

131 Sayette M. A. Cohn J. F. Wertz J. M. Perrott M. A. Parrott D. J. ( 2001). A psychometric evaluation of the facial action coding system for assessing spontaneous expression.

J. Nonverbal. Behav.

25, 167– 185. 10.1023/A:1010671109788

https://doi.org/10.1023/A:1010671109788

Google Scholar

http://scholar.google.com/scholar\_lookup?author=M.%2BA..%2BSayette&author=J.%2BF..%2BCohn&author=J.%2BM..%2BWertz&author=M.%2BA..%2BPerrott&author=D.%2BJ..%2BParrott&publication\_year=2001&title=A%2Bpsychometric%2Bevaluation%2Bof%2Bthe%2Bfacial%2Baction%2Bcoding%2Bsystem%2Bfor%2Bassessing%2Bspontaneous%2Bexpression&journal=J.+Nonverbal.+Behav.&volume=25&pages=167-185

132 Sayette M. A. Creswell K. G. Fairbairn C. E. Dimoff J. D. Bentley K. Lazerus T. ( 2019). The effects of alcohol on positive emotion during a comedy routine: a facial coding analysis.

, 480– 488. 10.1037/emo0000451

Pubmed Abstract

https://pubmed.ncbi.nlm.nih.gov/29771544

https://doi.org/10.1037/emo0000451

Google Scholar

http://scholar.google.com/scholar\_lookup?author=M.%2BA..%2BSayette&author=K.%2BG..%2BCreswell&author=C.%2BE..%2BFairbairn&author=J.%2BD..%2BDimoff&author=K..%2BBentley&author=T..%2BLazerus&publication\_year=2019&title=The%2Beffects%2Bof%2Balcohol%2Bon%2Bpositive%2Bemotion%2Bduring%2Ba%2Bcomedy%2Broutine%3A%2Ba%2Bfacial%2Bcoding%2Banalysis&journal=Emotion&volume=19&pages=480-488

133 Sayette M. A. Martin C. S. Wertz J. M. Perrott M. A. Peters A. R. ( 2005). The effects of alcohol on cigarette craving in heavy smokers and tobacco chippers.

Psychol. Addict. Behav.

19, 263– 270. 10.1037/0893-164X.19.3.263

Pubmed Abstract

https://pubmed.ncbi.nlm.nih.gov/16187804

https://doi.org/10.1037/0893-164X.19.3.263

Google Scholar

http://scholar.google.com/scholar\_lookup?author=M.%2BA..%2BSayette&author=C.%2BS..%2BMartin&author=J.%2BM..%2BWertz&author=M.%2BA..%2BPerrott&author=A.%2BR..%2BPeters&publication\_year=2005&title=The%2Beffects%2Bof%2Balcohol%2Bon%2Bcigarette%2Bcraving%2Bin%2Bheavy%2Bsmokers%2Band%2Btobacco%2Bchippers&journal=Psychol.+Addict.+Behav.&volume=19&pages=263-270

134 Sayette M. A. Parrott D. J. ( 1999). Effects of olfactory stimuli on urge reduction in smokers.

Exp. Clin. Psychopharmacol.

7, 151– 159.

Pubmed Abstract

https://pubmed.ncbi.nlm.nih.gov/10340155

Google Scholar

http://scholar.google.com/scholar\_lookup?author=M.%2BA..%2BSayette&author=D.%2BJ..%2BParrott&publication\_year=1999&title=Effects%2Bof%2Bolfactory%2Bstimuli%2Bon%2Burge%2Breduction%2Bin%2Bsmokers&journal=Exp.+Clin.+Psychopharmacol.&volume=7&pages=151-159

135 Scherer K. R. ( 2001). Appraisal considered as a process of multilevel sequential checking, in

Appraisal Processes in Emotions: Theory, Methods, Research: Series in Affective Science

. eds Scherer K. Schorr A. Johnston T. ( New York, NY: Oxford University Press), 92– 120

Pubmed Abstract

https://pubmed.ncbi.nlm.nih.gov/17182067

Google Scholar

http://scholar.google.com/scholar\_lookup?author=K.%2BR..%2BScherer&publication\_year=2001&title=Appraisal%2Bconsidered%2Bas%2Ba%2Bprocess%2Bof%2Bmultilevel%2Bsequential%2Bchecking&journal=Appraisal+Processes+in+Emotions%3A+Theory%2C+Methods%2C+Research%3A+Series+in+Affective+Science&pages=92-120

136 Schneider K. Josephs I. ( 1991). The expressive and communicative functions of preschool children's smiles in an achievement-situation.

J. Nonverbal. Behav.

15, 185– 198. 10.1007/BF01672220

https://doi.org/10.1007/BF01672220

Google Scholar

http://scholar.google.com/scholar\_lookup?author=K..%2BSchneider&author=I..%2BJosephs&publication\_year=1991&title=The%2Bexpressive%2Band%2Bcommunicative%2Bfunctions%2Bof%2Bpreschool%2Bchildren%27s%2Bsmiles%2Bin%2Ban%2Bachievement-situation&journal=J.+Nonverbal.+Behav.&volume=15&pages=185-198

137 Schutter D. J. L. G. Hofman D. Van Honk J. ( 2008). Fearful faces selectively increase corticospinal motor tract excitability: a transcranial magnetic stimulation study.

Psychophysiology45

, 345– 348. 10.1111/j.1469-8986.2007.00635.x

Pubmed Abstract

https://pubmed.ncbi.nlm.nih.gov/18221448

https://doi.org/10.1111/j.1469-8986.2007.00635.x

Google Scholar

http://scholar.google.com/scholar\_lookup?author=D.%2BJ.%2BL.%2BG..%2BSchutter&author=D..%2BHofman&author=J..%2BVan%2BHonk&publication\_year=2008&title=Fearful%2Bfaces%2Bselectively%2Bincrease%2Bcorticospinal%2Bmotor%2Btract%2Bexcitability%3A%2Ba%2Btranscranial%2Bmagnetic%2Bstimulation%2Bstudy&journal=Psychophysiology&volume=45&pages=345-348

138 Smith C. A. Ellsworth P. C. ( 1985). Patterns of cognitive appraisal in emotion.

J. Pers. Soc. Psychol.

48, 813– 838. 10.1037/0022-3514.48.4.813

Pubmed Abstract

https://pubmed.ncbi.nlm.nih.gov/3886875

https://doi.org/10.1037/0022-3514.48.4.813

Google Scholar

http://scholar.google.com/scholar\_lookup?author=C.%2BA..%2BSmith&author=P.%2BC..%2BEllsworth&publication\_year=1985&title=Patterns%2Bof%2Bcognitive%2Bappraisal%2Bin%2Bemotion&journal=J.+Pers.+Soc.+Psychol.&volume=48&pages=813-838

139 So J. Achar C. Han D. Agrawal N. Duhachek A. Maheswaran D. ( 2015). The psychology of appraisal: specific emotions and decision-making.

J. Consum. Psychol.

25, 359– 371. 10.1016/j.jcps.2015.04.003

https://doi.org/10.1016/j.jcps.2015.04.003

Google Scholar

http://scholar.google.com/scholar\_lookup?author=J..%2BSo&author=C..%2BAchar&author=D..%2BHan&author=N..%2BAgrawal&author=A..%2BDuhachek&author=D..%2BMaheswaran&publication\_year=2015&title=The%2Bpsychology%2Bof%2Bappraisal%3A%2Bspecific%2Bemotions%2Band%2Bdecision-making&journal=J.+Consum.+Psychol.&volume=25&pages=359-371

140 Soussignan R. Schaal B. ( 1996). Forms and social signal value of smiles associated with pleasant and unpleasant sensory experience.

Ethology102

, 1020– 1041.

Google Scholar

http://scholar.google.com/scholar\_lookup?author=R..%2BSoussignan&author=B..%2BSchaal&publication\_year=1996&title=Forms%2Band%2Bsocial%2Bsignal%2Bvalue%2Bof%2Bsmiles%2Bassociated%2Bwith%2Bpleasant%2Band%2Bunpleasant%2Bsensory%2Bexperience&journal=Ethology&volume=102&pages=1020-1041

141 Soussignan R. Schaal B. Marlier L. ( 1999). Olfactory alliesthesia in human neonates: prandial state and stimulus familiarity modulate facial and autonomic responses to milk odors.

Dev. Psychobiol.

Pubmed Abstract

https://pubmed.ncbi.nlm.nih.gov/10397891

Google Scholar

http://scholar.google.com/scholar\_lookup?author=R..%2BSoussignan&author=B..%2BSchaal&author=L..%2BMarlier&publication\_year=1999&title=Olfactory%2Balliesthesia%2Bin%2Bhuman%2Bneonates%3A%2Bprandial%2Bstate%2Band%2Bstimulus%2Bfamiliarity%2Bmodulate%2Bfacial%2Band%2Bautonomic%2Bresponses%2Bto%2Bmilk%2Bodors&journal=Dev.+Psychobiol.&volume=35&pages=3-14

142 Tiedens L. Z. Linton S. ( 2001). Judgment under emotional certainty and uncertainty: the effects of specific emotions on information processing.

J. Pers. Soc. Psychol.

81, 973– 988. 10.1037/0022-3514.81.6.973

Pubmed Abstract

https://pubmed.ncbi.nlm.nih.gov/11761319

https://doi.org/10.1037/0022-3514.81.6.973

Google Scholar

http://scholar.google.com/scholar\_lookup?author=L.%2BZ..%2BTiedens&author=S..%2BLinton&publication\_year=2001&title=Judgment%2Bunder%2Bemotional%2Bcertainty%2Band%2Buncertainty%3A%2Bthe%2Beffects%2Bof%2Bspecific%2Bemotions%2Bon%2Binformation%2Bprocessing&journal=J.+Pers.+Soc.+Psychol.&volume=81&pages=973-988

143 Tomkins S. S. ( 1992).

Affect, Imagery, Consciousness

. New York, NY: Springer Publishing Co.

Google Scholar

http://scholar.google.com/scholar\_lookup?author=S.%2BS..%2BTomkins&publication\_year=1992&journal=Affect%2C+Imagery%2C+Consciousness

144 Tourangeau R. Ellsworth P. C. ( 1979). The role of facial response in the experience of emotion.

J. Pers. Soc. Psychol.

37, 1519– 1531.

Pubmed Abstract

https://pubmed.ncbi.nlm.nih.gov/501520

Google Scholar

http://scholar.google.com/scholar\_lookup?author=R..%2BTourangeau&author=P.%2BC..%2BEllsworth&publication\_year=1979&title=The%2Brole%2Bof%2Bfacial%2Bresponse%2Bin%2Bthe%2Bexperience%2Bof%2Bemotion&journal=J.+Pers.+Soc.+Psychol.&volume=37&pages=1519-1531

145 Tussyadiah I. P. Park S. ( 2018). Consumer evaluation of hotel service robots, in

Information and Communication Technologies in Tourism 2018

, eds Stangl B. Pesonen J. ( Jönköping: Springer), 308– 320

Google Scholar

http://scholar.google.com/scholar\_lookup?author=I.%2BP..%2BTussyadiah&author=S..%2BPark&publication\_year=2018&title=Consumer%2Bevaluation%2Bof%2Bhotel%2Bservice%2Brobots&journal=Information+and+Communication+Technologies+in+Tourism+2018&pages=308-320

146 Unzner L. Schneider K. ( 1990). Facial reactions in preschoolers: a descriptive study.

J. Nonverbal. Behav.

14, 19– 33. 10.1007/BF01006577

https://doi.org/10.1007/BF01006577

Google Scholar

http://scholar.google.com/scholar\_lookup?author=L..%2BUnzner&author=K..%2BSchneider&publication\_year=1990&title=Facial%2Breactions%2Bin%2Bpreschoolers%3A%2Ba%2Bdescriptive%2Bstudy&journal=J.+Nonverbal.+Behav.&volume=14&pages=19-33

147 Valstar M. F. Pantic M. ( 2006). Biologically vs. logic inspired encoding of facial actions and emotions in video in

2006 IEEE International Conference on Multimedia and Expo

( Toronto, ON: IEEE), 325– 328.

Google Scholar

http://scholar.google.com/scholar\_lookup?author=M.%2BF..%2BValstar&author=M..%2BPantic&publication\_year=2006&title=Biologically%2Bvs.%2Blogic%2Binspired%2Bencoding%2Bof%2Bfacial%2Bactions%2Band%2Bemotions%2Bin%2Bvideo&journal=2006+IEEE+International+Conference+on+Multimedia+and+Expo&pages=325-328

148 van Kuilenburg H. Wiering M. den Uyl M. ( 2005). A model based method for automatic facial expression recognition, in

Machine Learning: ECML 2005.

Eds Gama J. Camacho R. Brazdil P. B. et al. ( Berlin, Heidelberg: Springer), 194– 205.

Google Scholar

http://scholar.google.com/scholar\_lookup?author=H..%2Bvan%2BKuilenburg&author=M..%2BWiering&author=M..%2Bden%2BUyl&publication\_year=2005&title=A%2Bmodel%2Bbased%2Bmethod%2Bfor%2Bautomatic%2Bfacial%2Bexpression%2Brecognition&journal=Machine+Learning%3A+ECML+2005.&pages=194-205

149 van Loon A. M. van den Wildenberg W. P. M. van Stegeren A. H. Ridderinkhof K. R. Hajcak G. ( 2010). Emotional stimuli modulate readiness for action: A transcranial magnetic stimulation study.

Cogn. Affect. Behav. Neurosci.

10, 174– 181. 10.3758/CABN.10.2.174

Pubmed Abstract

https://pubmed.ncbi.nlm.nih.gov/20498342

https://doi.org/10.3758/CABN.10.2.174

Google Scholar

http://scholar.google.com/scholar\_lookup?author=A.%2BM..%2Bvan%2BLoon&author=W.%2BP.%2BM..%2Bvan%2Bden%2BWildenberg&author=A.%2BH..%2Bvan%2BStegeren&author=K.%2BR..%2BRidderinkhof&author=G..%2BHajcak&publication\_year=2010&title=Emotional%2Bstimuli%2Bmodulate%2Breadiness%2Bfor%2Baction%3A%2BA%2Btranscranial%2Bmagnetic%2Bstimulation%2Bstudy&journal=Cogn.+Affect.+Behav.+Neurosci.&volume=10&pages=174-181

150 van Peer J. M. Rotteveel M. Spinhoven P. Tollenaar M. S. Roelofs K. ( 2010). Affect-congruent approach and withdrawal movements of happy and angry faces facilitate affective categorisation.

Cogn. Emot.

24, 863– 875. 10.1080/02699930902935485

https://doi.org/10.1080/02699930902935485

Google Scholar

http://scholar.google.com/scholar\_lookup?author=J.%2BM..%2Bvan%2BPeer&author=M..%2BRotteveel&author=P..%2BSpinhoven&author=M.%2BS..%2BTollenaar&author=K..%2BRoelofs&publication\_year=2010&title=Affect-congruent%2Bapproach%2Band%2Bwithdrawal%2Bmovements%2Bof%2Bhappy%2Band%2Bangry%2Bfaces%2Bfacilitate%2Baffective%2Bcategorisation&journal=Cogn.+Emot.&volume=24&pages=863-875

151 Walsh A. M. Duncan S. E. Bell M. A. O'Keefe S. F. Gallagher D. ( 2017a). Integrating implicit and explicit emotional assessment of food quality and safety concerns.

Food Qual. Prefer.

56, 212– 224. 10.1016/j.foodqual.2016.11.002

https://doi.org/10.1016/j.foodqual.2016.11.002

Google Scholar

http://scholar.google.com/scholar\_lookup?author=A.%2BM..%2BWalsh&author=S.%2BE..%2BDuncan&author=M.%2BA..%2BBell&author=S.%2BF..%2BO%27Keefe&author=D..%2BGallagher&publication\_year=2017a&title=Integrating%2Bimplicit%2Band%2Bexplicit%2Bemotional%2Bassessment%2Bof%2Bfood%2Bquality%2Band%2Bsafety%2Bconcerns&journal=Food+Qual.+Prefer.&volume=56&pages=212-224

152 Walsh A. M. Duncan S. E. Bell M. A. O'Keefe S. F. Gallagher D. ( 2017b). Breakfast meals and emotions: implicit and explicit assessment of the visual experience.

J. Sens. Stud.

32: e12265. 10.1111/joss.12265

https://doi.org/10.1111/joss.12265

Google Scholar

http://scholar.google.com/scholar\_lookup?author=A.%2BM..%2BWalsh&author=S.%2BE..%2BDuncan&author=M.%2BA..%2BBell&author=S.%2BF..%2BO%27Keefe&author=D..%2BGallagher&publication\_year=2017b&title=Breakfast%2Bmeals%2Band%2Bemotions%3A%2Bimplicit%2Band%2Bexplicit%2Bassessment%2Bof%2Bthe%2Bvisual%2Bexperience&journal=J.+Sens.+Stud.&volume=32

153 Watson D. Tellegen A. ( 1985). Toward a consensual structure of mood.

Psychol. Bull.

98, 219– 235. 10.1037/0033-2909.98.2.219

https://doi.org/10.1037/0033-2909.98.2.219

Google Scholar

http://scholar.google.com/scholar\_lookup?author=D..%2BWatson&author=A..%2BTellegen&publication\_year=1985&title=Toward%2Ba%2Bconsensual%2Bstructure%2Bof%2Bmood&journal=Psychol.+Bull.&volume=98&pages=219-235

154 Weiland R. Ellgring H. Macht M. ( 2010). Gustofacial and olfactofacial responses in human adults.

Chem. Sens.

35, 841– 853. 10.1093/chemse/bjq092

Pubmed Abstract

https://pubmed.ncbi.nlm.nih.gov/20876392

https://doi.org/10.1093/chemse/bjq092

Google Scholar

http://scholar.google.com/scholar\_lookup?author=R..%2BWeiland&author=H..%2BEllgring&author=M..%2BMacht&publication\_year=2010&title=Gustofacial%2Band%2Bolfactofacial%2Bresponses%2Bin%2Bhuman%2Badults&journal=Chem.+Sens.&volume=35&pages=841-853

155 Wilcox K. Kramer T. Sen S. ( 2011). Indulgence or self-control: a dual process model of the effect of incidental pride on indulgent choice.

J. Consum. Res.

38, 151– 163. 10.1086/657606

https://doi.org/10.1086/657606

Google Scholar

http://scholar.google.com/scholar\_lookup?author=K..%2BWilcox&author=T..%2BKramer&author=S..%2BSen&publication\_year=2011&title=Indulgence%2Bor%2Bself-control%3A%2Ba%2Bdual%2Bprocess%2Bmodel%2Bof%2Bthe%2Beffect%2Bof%2Bincidental%2Bpride%2Bon%2Bindulgent%2Bchoice&journal=J.+Consum.+Res.&volume=38&pages=151-163

156 Winterich K. P. Haws K. L. ( 2011). Helpful hopefulness: the effect of future positive emotions on consumption.

J. Consum. Res.

38, 505– 524. 10.1086/659873

https://doi.org/10.1086/659873

Google Scholar

http://scholar.google.com/scholar\_lookup?author=K.%2BP..%2BWinterich&author=K.%2BL..%2BHaws&publication\_year=2011&title=Helpful%2Bhopefulness%3A%2Bthe%2Beffect%2Bof%2Bfuture%2Bpositive%2Bemotions%2Bon%2Bconsumption&journal=J.+Consum.+Res.&volume=38&pages=505-524

157 Woolf B. Burleson W. Arroyo I. Dragon T. Cooper D. Picard R. ( 2009). Affect-aware tutors: recognising and responding to student affect.

Int. J. Learn Technol.

4, 129– 164. 10.1504/ijlt.2009.028804

https://doi.org/10.1504/ijlt.2009.028804

Google Scholar

http://scholar.google.com/scholar\_lookup?author=B..%2BWoolf&author=W..%2BBurleson&author=I..%2BArroyo&author=T..%2BDragon&author=D..%2BCooper&author=R..%2BPicard&publication\_year=2009&title=Affect-aware%2Btutors%3A%2Brecognising%2Band%2Bresponding%2Bto%2Bstudent%2Baffect&journal=Int.+J.+Learn+Technol.&volume=4&pages=129-164

158 Zacche Sa A. Silva J. R. J. Alves J. G. ( 2015). Facial responses to basic tastes in the newborns of women with gestational diabetesmellitusJ

. Matern. Fetal. Neonatal. Med.

28, 1687– 1690. 10.3109/14767058.2014.964680

Pubmed Abstract

https://pubmed.ncbi.nlm.nih.gov/25212980

https://doi.org/10.3109/14767058.2014.964680

Google Scholar

http://scholar.google.com/scholar\_lookup?author=A..%2BZacche%2BSa&author=J.%2BR.%2BJ..%2BSilva&author=J.%2BG..%2BAlves&publication\_year=2015&title=Facial%2Bresponses%2Bto%2Bbasic%2Btastes%2Bin%2Bthe%2Bnewborns%2Bof%2Bwomen%2Bwith%2Bgestational%2Bdiabetes%2Bmellitus&journal=J.+Matern.+Fetal.+Neonatal.+Med.&volume=28&pages=1687-1690

159 Zhang Z. Girard J. Wu Y. Zhang X. Liu P. Ciftci U. et al. ( 2016). Multimodal spontaneous emotion corpus for human behavior analysis, in

2016 IEEE Conf Comput Vis Pattern Recognit

, ( Las Vegas, NV) 3438– 3446.

Google Scholar

http://scholar.google.com/scholar\_lookup?author=Z..%2BZhang&author=J..%2BGirard&author=Y..%2BWu&author=X..%2BZhang&author=P..%2BLiu&author=U..%2BCiftci&publication\_year=2016&title=Multimodal%2Bspontaneous%2Bemotion%2Bcorpus%2Bfor%2Bhuman%2Bbehavior%2Banalysis&journal=2016+IEEE+Conf+Comput+Vis+Pattern+Recognit&pages=3438-3446

emotions, facial action coding system, action units, facial analysis, consumers

Clark EA, Kessinger J, Duncan SE, Bell MA, Lahne J, Gallagher DL and O'Keefe SF (2020) The Facial Action Coding System for Characterization of Human Affective Response to Consumer Product-Based Stimuli: A Systematic Review.

Front. Psychol.

11:920. doi:

10.3389/fpsyg.2020.00920

http://dx.doi.org/10.3389/fpsyg.2020.00920

25 October 2019

14 April 2020

26 May 2020

Maurizio Codispoti, University of Bologna, Italy

Reviewed by

Giovanni Mirabella, University of Brescia, Italy; Dipak Ghosh, Jadavpur University, India

Check for updates

© 2020 Clark, Kessinger, Duncan, Bell, Lahne, Gallagher and O'Keefe.

This is an open-access article distributed under the terms of the

Creative Commons Attribution License (CC BY)

http://creativecommons.org/licenses/by/4.0/

. The use, distribution or reproduction in other forums is permitted, provided the original author(s) and the copyright owner(s) are credited and that the original publication in this journal is cited, in accordance with accepted academic practice. No use, distribution or reproduction is permitted which does not comply with these terms.

Correspondence: Elizabeth A. Clark

eac1992@vt.edu

mailto:eac1992@vt.edu

This article was submitted to Emotion Science, a section of the journal Frontiers in Psychology

All claims expressed in this article are solely those of the authors and do not necessarily represent those of their affiliated organizations, or those of the publisher, the editors and the reviewers. Any product that may be evaluated in this article or claim that may be made by its manufacturer is not guaranteed or endorsed by the publisher.

Editor & Reviewers

M C Maurizio Codispoti University of Bologna, Italy

https://loop.frontiersin.org/people/58004

Reviewed by

G M Giovanni Mirabella University of Brescia, Italy

https://loop.frontiersin.org/people/26234

D G Dipak Ghosh Jadavpur University, India

https://loop.frontiersin.org/people/247514

Frontiers' quality

How do we build trust in science?

Behind each Frontiers journal is an editorial board committed to upholding research integrity and scientific quality

https://www.frontiersin.org/about/quality

\[Published in Frontiers in Psychology

Emotion Science

impact factor

citescore\](https://www.frontiersin.org/journals/psychology)

Article metrics

View details

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#metrics

Download PDF

https://public-pages-files-2025.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/pdf

Download other formats

http://www.readcube.com/articles/10.3389/fpsyg.2020.00920

https://public-pages-files-2025.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/epub

https://public-pages-files-2025.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/xml

Cite article Share article

https://public-pages-files-2025.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/pdf

Download other format

http://www.readcube.com/articles/10.3389/fpsyg.2020.00920

https://public-pages-files-2025.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/epub

https://public-pages-files-2025.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/xml

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#outline

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#figures

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#cite

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#share

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#metrics

Suppl. material

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#supplementaryMaterial

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full

Suppl. material

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#h1

Introduction

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#s1

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#s2

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#s3

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#s4

Conclusions

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#s5

Data availability statement

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#h7

Author contributions

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#h8

Acknowledgments

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#h9

Conflict of interest

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#h10

Supplementary material

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#s9

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#h12

Figures and Tables

View in article

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#F1

View in article

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#F2

View in article

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#F3

Table 1 Single action units in the facial action code Ekman et al.,

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#B49

View in article

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#T1

Table 2 Overview of the studies included in the systematic review by outcome of interest including the Facial Action Coding System (FACS) application, purpose of study, products assessed, and validation method in the study.

View in article

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#T2

Table 3 Rules for mapping Action Units to emotions, according to the FACS investigators guide. A/B means “either A or B”.

View in article

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full#T3

Copy to clipboard

Clark EA, Kessinger J, Duncan SE, Bell MA, Lahne J, Gallagher DL and O'Keefe SF (2020) The Facial Action Coding System for Characterization of Human Affective Response to Consumer Product-Based Stimuli: A Systematic Review. Front. Psychol. 11:920. doi: 10.3389/fpsyg.2020.00920

Copy citation

Export citation file

https://public-pages-files-2025.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/bibTex

https://public-pages-files-2025.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/endNote

Reference Manager

https://public-pages-files-2025.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/reference

Simple Text file

https://public-pages-files-2025.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/text

https://www.facebook.com/sharer/sharer.php?u=https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full

https://www.facebook.com/sharer/sharer.php?u=https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full

https://www.twitter.com/share?url=https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full

https://www.twitter.com/share?url=https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full

https://www.linkedin.com/share?url=https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full

https://www.linkedin.com/share?url=https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full

\[\](mailto:?subject=Interesting science article: The Facial Action Coding System for Characterization of Human Affective Response to Consumer Product-Based Stimuli: A Systematic Review&body=Hi!!%0D%0A%0D%0AI think you might find interesting the article "The Facial Action Coding System for Characterization of Human Affective Response to Consumer Product-Based Stimuli: A Systematic Review".%0D%0A%0D%0AYou can read more about it here: https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full)\[Email\](mailto:?subject=Interesting science article: The Facial Action Coding System for Characterization of Human Affective Response to Consumer Product-Based Stimuli: A Systematic Review&body=Hi!!%0D%0A%0D%0AI think you might find interesting the article "The Facial Action Coding System for Characterization of Human Affective Response to Consumer Product-Based Stimuli: A Systematic Review".%0D%0A%0D%0AYou can read more about it here: https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full)

https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2020.00920/full

Table 1.DOCX

https://public-pages-files-2025.frontiersin.org/articles/507534/file/Table\_1.DOCX/507534\_supplementary-materials\_tables\_1\_docx/1

Author guidelines

https://www.frontiersin.org/guidelines/author-guidelines

Services for authors

https://www.frontiersin.org/for-authors/author-services

Policies and publication ethics

https://www.frontiersin.org/guidelines/policies-and-publication-ethics

Editor guidelines

https://www.frontiersin.org/guidelines/editor-guidelines

https://www.frontiersin.org/about/fee-policy

https://www.frontiersin.org/articles

Research Topics

https://www.frontiersin.org/research-topics

https://www.frontiersin.org/journals

How we publish

https://www.frontiersin.org/about/how-we-publish

Frontiers Forum

https://forum.frontiersin.org/

Frontiers Policy Labs

https://policylabs.frontiersin.org/

Frontiers for Young Minds

https://kids.frontiersin.org/

Frontiers Planet Prize

https://www.frontiersin.org/about/frontiers-planet-prize

Help center

https://helpcenter.frontiersin.org/

Emails and alerts

https://subscription-management.frontiersin.org/emails/preferences#block0

https://www.frontiersin.org/about/contact

https://www.frontiersin.org/submission/submit

Career opportunities

https://careers.frontiersin.org/

https://www.facebook.com/Frontiersin

https://twitter.com/frontiersin

https://www.linkedin.com/company/frontiers

https://www.instagram.com/frontiersin\_

© 2026 Frontiers Media SA. All rights reserved.

Privacy policy

https://www.frontiersin.org/legal/privacy-policy

Terms and conditions

https://www.frontiersin.org/legal/terms-and-conditions

Accessibility statement

https://www.frontiersin.org/about/accessibility-statement

Share on WeChat

Scan with WeChat to share this article

We use cookies

Our website uses cookies that are essential for its operation and additional cookies to track performance, or to improve and personalize our services. To manage your cookie preferences, please click Cookie Settings. For more information on how we use cookies, please see our

Cookie Policy

https://www.frontiersin.org/legal/privacy-policy

Cookies Settings Reject non-essential cookies Accept cookies

Privacy Preference Center

Our website uses cookies that are necessary for its operation. Additional cookies are only used with your consent. These cookies are used to store and access information such as the characteristics of your device as well as certain personal data (IP address, navigation usage, geolocation data) and we process them to analyse the traffic on our website in order to provide you a better user experience, evaluate the efficiency of our communications and to personalise content to your interests. Some cookies are placed by third-party companies with which we work to deliver relevant ads on social media and the internet. Click on the different categories' headings to change your cookie preferences. If you wish to learn more about how we use cookies, please see our cookie policy below.

Cookie Policy

https://www.frontiersin.org/legal/list-of-cookies

Manage Consent Preferences

Strictly Necessary Cookies

Always Active

These cookies are necessary for our websites to function as they enable you to navigate around the sites and use our features. They cannot be switched off in our systems. They are activated set in response to your actions such as setting your privacy preferences, logging-in or filling in forms. You can set your browser to block or alert you about these cookies, but some parts of the site will not then work.

Performance/Analytics Cookies

Performance/Analytics Cookies

These cookies allow us to collect information about how visitors use our website, including the number of visitors, the websites that referred them to our website, and the pages that they visited. We use them to compile reports, to measure and improve the performance of our website, analyze which pages are the most viewed, see how visitors move around the site and fix bugs. If you do not allow these cookies, your experience will not be altered but we will not be able to improve the performance and content of our website.

Targeting/Advertising Cookies

Targeting/Advertising Cookies

These cookies may be set by us to offer your personalized content and opportunities to cooperate. They may also be used by social media companies we work with to build a profile of your interests and show you relevant adverts on their services. They do not store directly personal information but are based on unique identifiers related to your browser and internet device. If you do not allow these cookies, you will experience less targeted advertising.

Cookie List

checkbox label label

Apply Cancel

Consent Leg.Interest

checkbox label label

checkbox label label

checkbox label label

Confirm My Choices

