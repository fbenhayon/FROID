---
sourceFile: "Automated Facial Action Coding System for Dynamic Analysis of Facial Expressions in Neuropsychiatric Disorders - PMC"
exportedBy: "Kortex"
exportDate: "2026-06-29T01:00:27.652Z"
---

# Automated Facial Action Coding System for Dynamic Analysis of Facial Expressions in Neuropsychiatric Disorders - PMC

5806581b-ad9d-495f-bed4-e030f661ca0c

Automated Facial Action Coding System for Dynamic Analysis of Facial Expressions in Neuropsychiatric Disorders - PMC

8caa9045-dc45-490d-bda8-6e75dff265a7

https://pmc.ncbi.nlm.nih.gov/articles/PMC3402717/

Checking your browser - reCAPTCHA

Checking your browser before accessing pmc.ncbi.nlm.nih.gov ...

https://www.google.com/recaptcha/challengepage/

if you are not automatically redirected after 5 seconds.

Try again later

Your computer or network may be sending automated queries. To protect our users, we can't process your request right now. For more details visit

our help page

https://support.google.com/websearch/answer/86640

