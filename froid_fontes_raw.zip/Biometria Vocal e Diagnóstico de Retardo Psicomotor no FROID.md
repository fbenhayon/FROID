# Biometria Vocal e Diagnóstico de Retardo Psicomotor no FROID

O FROID utiliza a Taxa de Cruzamento por Zero (ZCR) e o Coeficiente Cepstral de Frequência Mel 7 (MFCC7) como biomarcadores de precisão matemática para quantificar objetivamente o retardo psicomotor (PMR) \[1-3\]. O retardo psicomotor é uma manifestação clínica caracterizada pela lentificação dos pensamentos e pela diminuição dos movimentos físicos, sendo originado por disfunções neurológicas no córtex pré-frontal e nos gânglios da base \[4, 5\].

Abaixo detalho como cada um desses parâmetros é integrado na arquitetura do sistema:

### 1. Taxa de Cruzamento por Zero (ZCR) e Articulação
A ZCR é uma característica prosódica que mede o número de vezes que o sinal de áudio passa pelo eixo zero em um intervalo de tempo \[6, 7\]. 
\*   \*\*Métrica de Ritmo:\*\* No contexto do FROID, a ZCR identifica o ritmo e a taxa de articulação do paciente, sendo que segmentos sonorizados (vogais) apresentam valores mais baixos \[2, 6\].
\*   \*\*Identificação de Fadiga:\*\* Uma redução significativa na ZCR, quando associada a um prolongamento anormal das pausas no discurso, comprova matematicamente a falta de energia articulatória e a letargia neuromuscular \[1, 2, 8\].
\*   \*\*Biópsia Temporal:\*\* O sistema utiliza essa queda na ZCR para evidenciar episódios de baixa vocalização e demonstrar a dificuldade no planejamento motor da fala, transformando a lentificação percebida em dados físicos auditáveis \[1, 5\].

### 2. Coeficiente Cepstral Mel 7 (MFCC7) e Predição Clínica
Enquanto a ZCR monitora o ritmo, o MFCC7 modela as propriedades de ressonância e o formato físico do trato vocal \[9, 10\].
\*   \*\*Modelagem do Trato Vocal:\*\* O MFCC7 capta microalterações fonéticas na dinâmica neuromuscular que são imperceptíveis à audição clínica humana subjetiva \[10, 11\].
\*   \*\*Correlação com a Escala PHQ-9:\*\* Este coeficiente possui uma forte correlação direta com a severidade dos sintomas depressivos globais, servindo como um preditor quantitativo para a pontuação na escala \*Patient Health Questionnaire-9\* (PHQ-9) \[2, 12, 13\].
\*   \*\*Especificidade Semântica:\*\* A inteligência do FROID isola o MFCC7 especificamente durante verbalizações de conteúdos com valência semântica negativa, onde sua capacidade de discriminação diagnóstica é maximizada \[2, 8, 12\].

### Sinergia Multimodal no Diagnóstico
A genialidade do FROID reside na integração simultânea desses dados. O percentual de risco de depressão escala no sistema quando o MFCC7 se eleva acusticamente em conjunto com os marcadores de retardo psicomotor identificados pela ZCR e pelas pausas prolongadas \[2, 8\]. Essa fusão de parâmetros auditáveis permite que o sistema execute uma biópsia espectral da exaustão neurológica e afetiva do paciente, revelando padrões e comportamentos que passariam despercebidos e fornecendo uma base científica inquestionável para o suporte à decisão clínica \[3, 5, 11, 14\].