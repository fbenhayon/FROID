---
sourceFile: "Facial Action Coding System - Paul Ekman Group"
exportedBy: "Kortex"
exportDate: "2026-06-29T01:00:28.023Z"
---

# Facial Action Coding System - Paul Ekman Group

dc32ea17-de65-47f4-a3d6-b30d089762c2

Facial Action Coding System - Paul Ekman Group

5080f63b-8680-4e22-94fe-4517e0c179b1

https://www.paulekman.com/facial-action-coding-system/

Facial Action Coding System - Paul Ekman Group

ABOUT Close ABOUT Open ABOUT

https://www.paulekman.com/about/paul-ekman/

Paul Ekman Memorial

https://www.paulekman.com/paul-ekman-memorial-page/

https://www.paulekman.com/eve-ekman/

Paul Ekman Group

https://www.paulekman.com/about/about-paul-ekman-group-llc/

https://www.paulekman.com/about/paul-ekman/

Paul Ekman Memorial

https://www.paulekman.com/paul-ekman-memorial-page/

https://www.paulekman.com/eve-ekman/

Paul Ekman Group

https://www.paulekman.com/about/about-paul-ekman-group-llc/

RESEARCH Close RESEARCH Open RESEARCH

Journal Articles

https://www.paulekman.com/resources/journal-articles/

https://www.paulekman.com/resources/books/

https://www.paulekman.com/blog/

https://www.paulekman.com/quizzes/

Photographs

https://www.paulekman.com/resources/photographs/

Journal Articles

https://www.paulekman.com/resources/journal-articles/

https://www.paulekman.com/resources/books/

https://www.paulekman.com/blog/

https://www.paulekman.com/quizzes/

Photographs

https://www.paulekman.com/resources/photographs/

COLLABORATIONS Close COLLABORATIONS Open COLLABORATIONS

Atlas of Emotions

https://www.paulekman.com/projects/atlas-of-emotions/

The Dalai Lama

https://www.paulekman.com/projects/the-dalai-lama/

Global Compassion

https://www.paulekman.com/projects/global-compassion/

https://www.paulekman.com/projects/inside-out/

https://www.paulekman.com/projects/lie-to-me/

Atlas of Emotions

https://www.paulekman.com/projects/atlas-of-emotions/

The Dalai Lama

https://www.paulekman.com/projects/the-dalai-lama/

Global Compassion

https://www.paulekman.com/projects/global-compassion/

https://www.paulekman.com/projects/inside-out/

https://www.paulekman.com/projects/lie-to-me/

RESOURCES Close RESOURCES Open RESOURCES NONVERBAL COMMUNICATIONS

Micro Expressions

https://www.paulekman.com/resources/micro-expressions/

Universal Facial Expressions

https://www.paulekman.com/resources/universal-facial-expressions/

Types of Facial Expressions

https://www.paulekman.com/nonverbal-communication/types-of-facial-expressions/

Types of Gestures

https://www.paulekman.com/nonverbal-communication/types-of-gestures/

Micro Expressions

https://www.paulekman.com/resources/micro-expressions/

Universal Facial Expressions

https://www.paulekman.com/resources/universal-facial-expressions/

Types of Facial Expressions

https://www.paulekman.com/nonverbal-communication/types-of-facial-expressions/

Types of Gestures

https://www.paulekman.com/nonverbal-communication/types-of-gestures/

Universal Emotions

https://www.paulekman.com/universal-emotions/

https://www.paulekman.com/universal-emotions/what-is-anger/

https://www.paulekman.com/universal-emotions/what-is-contempt/

https://www.paulekman.com/universal-emotions/what-is-disgust/

https://www.paulekman.com/universal-emotions/what-is-enjoyment/

https://www.paulekman.com/universal-emotions/what-is-fear/

https://www.paulekman.com/universal-emotions/what-is-sadness/

https://www.paulekman.com/universal-emotions/what-is-surprise/

Animal Emotions

https://www.paulekman.com/animal-emotions/

Universal Emotions

https://www.paulekman.com/universal-emotions/

https://www.paulekman.com/universal-emotions/what-is-anger/

https://www.paulekman.com/universal-emotions/what-is-contempt/

https://www.paulekman.com/universal-emotions/what-is-disgust/

https://www.paulekman.com/universal-emotions/what-is-enjoyment/

https://www.paulekman.com/universal-emotions/what-is-fear/

https://www.paulekman.com/universal-emotions/what-is-sadness/

https://www.paulekman.com/universal-emotions/what-is-surprise/

Animal Emotions

https://www.paulekman.com/animal-emotions/

What Does Compassion Mean?

https://www.paulekman.com/what-does-compassion-mean/

What Does Compassion Mean?

https://www.paulekman.com/what-does-compassion-mean/

https://www.paulekman.com/deception/

Children Lying

https://www.paulekman.com/deception/children-lying/

Deception Detection

https://www.paulekman.com/deception/deception-detection/

https://www.paulekman.com/deception/

Children Lying

https://www.paulekman.com/deception/children-lying/

Deception Detection

https://www.paulekman.com/deception/deception-detection/

PROFESSIONAL DEVELOPMENT

Educators and Academics

https://www.paulekman.com/professional-development-for-educators-and-academics/

Educators and Academics

https://www.paulekman.com/professional-development-for-educators-and-academics/

ACADEMY Close ACADEMY Open ACADEMY

Micro Expressions Training Tools

https://www.paulekman.com/micro-expressions-training-tools/

The Feelings Field Guide

https://www.paulekman.com/the-feelings-field-guide/

Facial Action Coding System

https://www.paulekman.com/facial-action-coding-system/

Cultivating Emotional Balance

https://www.paulekman.com/projects/cultivating-emotional-balance/

https://www.paulekman.com/workshops/

Micro Expressions Training Tools

https://www.paulekman.com/micro-expressions-training-tools/

The Feelings Field Guide

https://www.paulekman.com/the-feelings-field-guide/

Facial Action Coding System

https://www.paulekman.com/facial-action-coding-system/

Cultivating Emotional Balance

https://www.paulekman.com/projects/cultivating-emotional-balance/

https://www.paulekman.com/workshops/

ACCOUNT Close ACCOUNT Open ACCOUNT

https://www.paulekman.com/login/

https://www.paulekman.com/cart/

https://www.paulekman.com/login/

https://www.paulekman.com/cart/

Close Open Search Website Search Search

Return to My Trainings

https://www.paulekman.com/my-account/trainings

Save 20% on the Ekman Library with code Ekman20 through April 9th, 2026 | Shop now

https://www.paulekman.com/micro-expressions-training-tools/

Facial Action Coding System

FACIAL ACTION CODING SYSTEM

Tap to unmute

Your browser can't play this video.

https://www.youtube.com/supported\_browsers

https://www.youtube.com/

An error occurred.

Try watching this video on www.youtube.com

https://www.youtube.com/watch?v=6RzCWRxnc84

, or enable JavaScript if it is disabled in your browser.

The Facial Action Coding System (FACS) is a comprehensive, anatomically based system for describing all visually discernible facial movement. It breaks down facial expressions into individual components of muscle movement, called Action Units (AUs).

USED BY RESEARCHERS AND ANIMATORS

FACS is used across many different personal and professional settings. It is often used in various scientific settings for research. It is also used by animators and computer scientists interested in facial recognition.

FACS may also enable greater awareness and sensitivity to subtle facial behaviors. Such skills are useful for psychotherapists, interviewers, and anyone working in communications

FACS MANUAL

WHAT'S INCLUDED

FACS Manual – 527-page PDF

Investigator's Guide – 197-page PDF

Example photos and videos

ADD TO CART

https://www.paulekman.com/?add-to-cart=13843

FACS MANUAL

ALL THE ACTION UNITS

The FACS manual describes the criteria for observing and coding each Action Unit. It also describes how AUs appear in combinations. The FACS manual was first published in 1978 by Ekman and Friesen, and was most recently revised in 2002. The Paul Ekman Group offers the manual for sale.

SELF STUDY WITH THE FACS MANUAL

The FACS manual is self-instructional. The user reads the manual and practices coding various pictures and videos. This self-instruction usually takes about 50 to 100 hours to complete.

THE ONLY STANDARD

The FACS Final Test is the only standard for proficiency in FACS coding that is available. Anyone who wants to state that they know FACS and can code in FACS must pass the FACS Final test. After completing the self-study, or a workshop, you can take the final test for certification. The Paul Ekman Group offers the FACS test for sale.

PREPARING FOR THE TEST (SELF STUDY)

FACS self-instruction usually takes about 50 to 100 hours to complete. If a user studies FACS five days a week for two hours a day, then learning will be closer to 50 than 100 hours. Dr. Ekman recommends training in groups. This can help make the high volume of information easier to learn.

WORKSHOP TRAINING FOR FACS CERTIFICATION

Erika Rosenberg

http://erikarosenberg.com/

who teaches a five-day FACS workshop that takes students through the entire manual and prepares them for certification. Currently there are no online or in-person versions of FACS training that have been evaluated or approved by Paul Ekman.

WHAT'S INCLUDED

34-question, video-based exam

ADD TO CART

https://www.paulekman.com/?add-to-cart=16661

FREQUENTLY ASKED QUESTIONS

HOW DID THE RESEARCH FOR FACS BEGIN?

You can read about the development of FACS in the FACS Investigator's Guide (which comes with the manual). Also, the history of facial measurement is discussed in the book edited by Ekman & Rosenberg, What the Face Reveals: Basic and Applied Studies of Spontaneous Facial Expression using FACS (2e). There are also accounts in many other published academic articles.

HOW WERE THE ACTION UNITS (AUs) DISCOVERED?

This is discussed in the Investigator's Guide. The anatomist Hjorstjo (1970) did important groundwork in identifying the units of action based on facial muscle groups on which Ekman and Friesen built in developing FACS as a measurement system.

WHERE CAN I FIND THE ORIGINAL EKMAN & FRIESEN 1978 ARTICLE?

The original version of FACS was published in 1978. It was a manual, not an article, available for training as the current manual is. The original version is out of print, and techniques have been modified since then. The 2002 manual is the current version, and it is the only one that should be used for scoring today.

WE NEED RECOMMENDATIONS OR A LIST OF FACS EXPERTS TO HIRE FOR A RESEARCH PROJECT. COULD YOU HELP US?

Right now, there is no central place where FACS coders advertise and are accessible. Also, there is considerable variability in experience among FACS coders. If you are interested in hiring someone, first make sure they are FACS certified (i.e., have passed the FACS final test). You would also want to be sure they have had coding experience beyond testing – as the Final test simply tells us that someone is proficient in recognizing the AUs, and coding real life data reliably takes practice.

WHAT IS EMFACS AND HOW CAN I OBTAIN IT?

EMFACS (Emotion FACS) is a selective application of FACS scoring, in which the coders only scores behavior that is likely to have emotional significance. To do this, the coder scans the video for core combinations of events that have been found to suggest certain emotions (much like the prototypes in Table 10-2). The coders only codes the events in a video record that contains such core combinations — they use FACS coding to score those events, but they are not coding everything on the video. So EMFACS is FACS selectively applied. EMFACS saves time as one is not coding everything. The drawback is that it can be harder to get intercoder agreement on EMFACS coding as the coders have to agree on two things: 1) whether to code an event (a result of their online scanning of the video for the core combinations) and 2) how to code those events that they have chosen to code. Bear in mind, EMFACS coding still yields FACS codes, so the data have to be interpreted into emotion categories.

EMFACS is only a set of instructions on how to selectively FACS code in this way. The EMFACS instructions are only available people who have passed the FACS final test. The reason is that we have to make sure people have mastery of FACS before applying rules to use FACS selectively in this way. This is based on the wishes of the authors of EMFACS — Paul Ekman and Wallace Friesen, and it makes good sense. Only people who know FACS as a comprehensive system can correctly apply it on a selective basis. If you take the final test and pass, you can receive the document.

Increase your emotional awareness and detect deception

COMPARE PACKAGES

https://www.paulekman.com/micro-expressions-training-tools/

DR. EKMAN'S BLOG

https://www.paulekman.com/blog/

Reflections on Inside Out 2

https://www.paulekman.com/blog/reflections-on-inside-out-2/

July 8, 2024

Paul Ekman's Unfinished Research on Emotions and Deception

https://www.paulekman.com/blog/paul-ekman-unfinished-research/

May 13, 2024

Emotion Communication: The Signals and Messages of Universal Emotions

https://www.paulekman.com/blog/emotion-communication-messages-signals/

August 14, 2023

https://www.paulekman.com/support/contact-us/

Paul Ekman Group Privacy Policy

https://www.paulekman.com/privacy-policy/

Terms & Conditions

https://www.paulekman.com/terms-conditions/

Technical Requirements

https://www.paulekman.com/support/technical-requirements/

https://www.paulekman.com/faq/

https://www.paulekman.com/support/contact-us/

Paul Ekman Group Privacy Policy

https://www.paulekman.com/privacy-policy/

Terms & Conditions

https://www.paulekman.com/terms-conditions/

Technical Requirements

https://www.paulekman.com/support/technical-requirements/

https://www.paulekman.com/faq/

Subscribe to get the latest news, event invitations, special discounts, and more!

https://www.facebook.com/PaulEkmanGroup

https://www.twitter.com/PaulEkman

http://www.youtube.com/user/thepaulekmangroup

https://www.linkedin.com/in/paulekman/

Search Submit Clear

https://www.paulekman.com/about/paul-ekman/

Paul Ekman Memorial

https://www.paulekman.com/paul-ekman-memorial-page/

https://www.paulekman.com/eve-ekman/

Paul Ekman Group

https://www.paulekman.com/about/about-paul-ekman-group-llc/

